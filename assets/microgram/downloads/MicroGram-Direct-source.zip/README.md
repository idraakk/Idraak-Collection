# MicroGram

MicroGram turns YouTube videos and playlists into short, swipeable learning reels. Choose a reel duration, resume where you left off, and see how far you have progressed through a lecture or playlist.

[Get MicroGram from the Collection](https://idraakk.github.io/Idraak-Collection/microgram/)

## Learn with MicroGram

- Import a video or playlist and open any reel from its Library profile.
- Save reels, write text notes, or capture paused frames as **Screen Notes**. Review captures in albums organized by video.
- Track your daily goal, learning heatmap, and lecture-by-lecture progress.
- Read creator posts, leave public replies, or send private feedback through **Write to Idraak**.

The Android app resolves and plays supported lecture streams directly on the device. The companion web code uses a separate playback path. MicroGram Studio serves community content and settings. It does not relay lecture video.

## MicroGram Studio

[Open MicroGram Studio](https://microgram-community.idraakmk.workers.dev/)

Studio is the administrator dashboard for the app. Write and preview posts, save browser-local drafts, publish individual changes, and moderate replies by post. Separate workspaces cover reader messages, sponsored content, Android update notices, and app access. Publishing a post does not require a new Android build. See the [Studio setup and publishing guide](docs/COMMUNITY_PUBLISHING.md).

## Build the Android app

Install Node.js 22 or later, Java 21, and the Android SDK. From PowerShell at the repository root:

```powershell
npm.cmd ci
$env:VITE_COMMUNITY_URL = 'https://microgram-community.idraakmk.workers.dev'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/build-android.ps1
```

The script builds and tests the Android app and writes a **debug-signed** `artifacts/Microgram.apk`. Set `VITE_COMMUNITY_URL` to your own Studio deployment when building for a different community. See the [Android build guide](docs/ANDROID_DIRECT.md) and [playback design](docs/REEL_PLAYBACK_SYSTEM.md).

## Distribute on Android

- **Direct download**. Generate a release-signed APK with a backed-up private signing key. Attach `Microgram.apk`, the matching corresponding-source archive, and SHA-256 checksums to a GitHub Release. For a download link anyone can open, use a public release repository or another public host. Test installation and updates with the same signing key before sharing.
- **F-Droid**. The main catalog requires a public source repository, an accepted free-software license, and a build F-Droid can reproduce from the published source. Review the [inclusion policy](https://f-droid.org/docs/Inclusion_Policy/) and [submission guide](https://f-droid.org/docs/Submitting_to_F-Droid_Quick_Start_Guide/) before requesting packaging.

## License

See [LICENSE](LICENSE) for the original MIT-licensed project components. The combined Android Direct build links NewPipeExtractor and is distributed under GPL-3.0-or-later with the matching corresponding source and notices. See the [NewPipe notice](android/NEWPIPE-NOTICE.md).
