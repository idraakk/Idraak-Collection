# NewPipe-enabled Android edition

This Android edition links NewPipeExtractor v0.26.5, licensed GPL-3.0-or-later.
Upstream: https://github.com/TeamNewPipe/NewPipeExtractor/tree/v0.26.5

Distribution of the combined NewPipe-enabled APK must satisfy GPL-3.0-or-later, including providing its corresponding source and build instructions. Preserve the existing MIT notices for original MicroGram code and all upstream dependency notices. Do not represent this APK as the official NewPipe application.

The source package accompanying this prototype includes the MicroGram source and build files, and an unmodified archive of NewPipeExtractor v0.26.5 under `third-party/`. NewPipeExtractor is pinned in Gradle. Any modified dependency sources must also be provided when distributing.

This build uses the existing HTML/MSE player, connected to on-device native requests. There is no laptop, Render or Funnel media fallback in the Android transport.
