package app.microgram.learn;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

public final class DirectDownloader extends Downloader {
  @Override
  public Response execute(Request request) throws IOException, ReCaptchaException {
    URL url = new URL(request.url());
    if (!url.getProtocol().equals("https"))
      throw new IOException("Only HTTPS source requests are supported.");
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    connection.setConnectTimeout(15000);
    connection.setReadTimeout(25000);
    connection.setRequestMethod(request.httpMethod());
    connection.setRequestProperty("User-Agent", "Mozilla/5.0");
    connection.setRequestProperty("Accept-Encoding", "identity");
    for (Map.Entry<String, List<String>> h : request.headers().entrySet())
      connection.setRequestProperty(h.getKey(), String.join(", ", h.getValue()));
    connection.setRequestProperty("Accept-Encoding", "identity");
    byte[] body = request.dataToSend();
    if (body != null) {
      connection.setDoOutput(true);
      try (OutputStream out = connection.getOutputStream()) {
        out.write(body);
      }
    }
    try {
      int code = connection.getResponseCode();
      if (code == 429)
        throw new ReCaptchaException(
            "YouTube temporarily blocked requests from this device.", request.url());
      InputStream input = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
      String text = "";
      if (input != null)
        try (InputStream stream = input) {
          text = new String(readBounded(stream, 12 * 1024 * 1024), StandardCharsets.UTF_8);
        }
      return new Response(
          code,
          connection.getResponseMessage(),
          connection.getHeaderFields(),
          text,
          connection.getURL().toString());
    } finally {
      connection.disconnect();
    }
  }

  static byte[] readBounded(InputStream input, int max) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] buffer = new byte[16384];
    int n;
    while ((n = input.read(buffer)) != -1) {
      if (out.size() + n > max) throw new IOException("Source response exceeds its size limit.");
      out.write(buffer, 0, n);
    }
    return out.toByteArray();
  }
}
