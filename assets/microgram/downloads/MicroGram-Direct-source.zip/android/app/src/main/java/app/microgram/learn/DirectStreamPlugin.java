package app.microgram.learn;

import android.net.Uri;
import android.webkit.WebResourceResponse;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

@CapacitorPlugin(name = "DirectStream")
public class DirectStreamPlugin extends Plugin {
  private final ExecutorService executor = Executors.newFixedThreadPool(2);

  @PluginMethod
  public void startupReady(PluginCall call) {
    if (getActivity() instanceof MainActivity activity) {
      activity.runOnUiThread(activity::finishStartup);
    }
    call.resolve();
  }

  @PluginMethod
  public void request(PluginCall call) {
    executor.execute(
        () -> {
          try {
            String path = call.getString("path", ""), method = call.getString("method", "POST");
            if (!path.startsWith("/api/")
                || path.contains("..")
                || (!method.equals("POST") && !method.equals("DELETE")))
              throw new IllegalArgumentException("Invalid native API request.");
            WebResourceResponse response;
            try {
              response =
                  NativeApi.get(getContext())
                      .handle(
                          method,
                          Uri.parse("https://localhost" + path),
                          call.getString("body", "{}"),
                          Collections.emptyMap());
            } catch (Exception error) {
              response = NativeApi.error(error);
            }
            JSObject result = new JSObject();
            result.put("status", response.getStatusCode());
            try (java.io.InputStream input = response.getData()) {
              result.put(
                  "body",
                  new String(
                      DirectDownloader.readBounded(input, 4 * 1024 * 1024),
                      StandardCharsets.UTF_8));
            }
            call.resolve(result);
          } catch (Exception error) {
            call.reject("Native API request failed.", error);
          }
        });
  }

  @PluginMethod
  public void original(PluginCall call) {
    executor.execute(
        () -> {
          try {
            NativeApi.get(getContext())
                .writeOriginal(
                    call.getString("id", ""),
                    call.getString("operation", ""),
                    call.getString("data"));
            call.resolve();
          } catch (Exception error) {
            call.reject(error.getMessage(), error);
          }
        });
  }

  @Override
  protected void handleOnDestroy() {
    executor.shutdownNow();
  }
}
