package app.microgram.learn;

import java.io.*;

/** Lets WebView apply its own initial seek, but never reads past a requested end. */
final class FilePrefixStream extends FilterInputStream {
  private long remaining;
  FilePrefixStream(File file, long length) throws IOException {
    super(new FileInputStream(file));
    remaining = length;
  }
  @Override public int read() throws IOException {
    if (remaining <= 0) return -1;
    int value = in.read();
    if (value >= 0) remaining--;
    return value;
  }
  @Override public int read(byte[] out, int offset, int length) throws IOException {
    if (length == 0) return 0;
    if (remaining <= 0) return -1;
    int count = in.read(out, offset, (int)Math.min(length, remaining));
    if (count > 0) remaining -= count;
    return count;
  }
  @Override public long skip(long count) throws IOException {
    long skipped = in.skip(Math.max(0, Math.min(count, remaining)));
    remaining -= skipped;
    return skipped;
  }
  @Override public int available() throws IOException {
    return (int)Math.min(in.available(), remaining);
  }
}
