package app.microgram.learn;

import android.os.Bundle;
import android.webkit.*;
import com.getcapacitor.*;

public class MainActivity extends BridgeActivity {
  private static final int TAB_BAR_COLOR = 0xff0c1014;
  private int statusInset = 0;
  private androidx.core.graphics.Insets navigationInsets = androidx.core.graphics.Insets.NONE;
  private Runnable startupReady;
  void finishStartup() {
    Runnable ready = startupReady;
    startupReady = null;
    if (ready != null) ready.run();
  }
  private void updateWebInsets() {
    float top = statusInset / getResources().getDisplayMetrics().density;
    bridge.getWebView().evaluateJavascript("document.documentElement.style.setProperty('--native-top', '" + top + "px')", null);
  }
  @Override
  @SuppressWarnings("deprecation")
  public void onCreate(Bundle state) {
    registerPlugin(DirectStreamPlugin.class);
    super.onCreate(state);
    // A full rectangular startup layer keeps the signature outside Android's icon mask.
    android.widget.FrameLayout startup = new android.widget.FrameLayout(this);
    startup.setBackgroundColor(android.graphics.Color.BLACK);
    android.widget.ImageView mark = new android.widget.ImageView(this);
    mark.setImageResource(R.drawable.microgram_splash);
    mark.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
    int size = (int) (288 * getResources().getDisplayMetrics().density);
    startup.addView(mark, new android.widget.FrameLayout.LayoutParams(size, size, android.view.Gravity.CENTER));
    android.view.ViewGroup decor = findViewById(android.R.id.content);
    decor.addView(startup, new android.view.ViewGroup.LayoutParams(-1, -1));
    long startupStarted = android.os.SystemClock.uptimeMillis();
    Runnable dismissStartup = () -> {
      startupReady = null;
      startup.animate().alpha(0f).setDuration(160)
          .withEndAction(() -> decor.removeView(startup)).start();
    };
    startup.postDelayed(dismissStartup, 12000);
    startupReady = () -> bridge.getWebView().postVisualStateCallback(1,
        new WebView.VisualStateCallback() {
          @Override public void onComplete(long requestId) {
            if (startup.getParent() == null) return;
            startup.removeCallbacks(dismissStartup);
            startup.postDelayed(dismissStartup, Math.max(0,
                700 - (android.os.SystemClock.uptimeMillis() - startupStarted)));
          }
        });
    // Content scrolls behind the status bar; CSS reserves its height at scroll start.
    // Native padding consumes these insets so CSS cannot add them a second time.
    android.view.View root = (android.view.View) bridge.getWebView().getParent();
    // Extend the WebView tab surface into Android's reserved navigation inset.
    root.setBackground(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK) {
      private final android.graphics.Paint paint = new android.graphics.Paint();
      @Override public void draw(android.graphics.Canvas canvas) {
        super.draw(canvas);
        android.graphics.Rect b = getBounds();
        paint.setColor(TAB_BAR_COLOR);
        if (navigationInsets.bottom > 0)
          canvas.drawRect(b.left, b.bottom - navigationInsets.bottom, b.right, b.bottom, paint);
        if (navigationInsets.left > 0)
          canvas.drawRect(b.left, b.top, b.left + navigationInsets.left, b.bottom, paint);
        if (navigationInsets.right > 0)
          canvas.drawRect(b.right - navigationInsets.right, b.top, b.right, b.bottom, paint);
      }
    });
    androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
    getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P)
      getWindow().setNavigationBarDividerColor(android.graphics.Color.TRANSPARENT);
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q)
      getWindow().setNavigationBarContrastEnforced(false);
    androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
      int types = androidx.core.view.WindowInsetsCompat.Type.systemBars()
          | androidx.core.view.WindowInsetsCompat.Type.displayCutout();
      androidx.core.graphics.Insets bars = insets.getInsets(types);
      int keyboard = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime()).bottom;
      statusInset = bars.top;
      navigationInsets = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars());
      view.invalidate();
      view.setPadding(bars.left, 0, bars.right, Math.max(bars.bottom, keyboard));
      updateWebInsets();
      return new androidx.core.view.WindowInsetsCompat.Builder(insets)
          .setInsets(types, androidx.core.graphics.Insets.NONE).build();
    });
    androidx.core.view.WindowInsetsControllerCompat bars = androidx.core.view.WindowCompat
        .getInsetsController(getWindow(), getWindow().getDecorView());
    bars.setAppearanceLightStatusBars(false);
    bars.setAppearanceLightNavigationBars(false);
    bars.show(androidx.core.view.WindowInsetsCompat.Type.systemBars());
    androidx.core.view.ViewCompat.requestApplyInsets(root);
    NativeApi api = NativeApi.get(this);
    bridge.getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false);
    bridge.setWebViewClient(
        new BridgeWebViewClient(bridge) {
          @Override
          public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            updateWebInsets();
          }
          @Override
          public WebResourceResponse shouldInterceptRequest(
              WebView view, WebResourceRequest request) {
            android.net.Uri uri = request.getUrl();
            if ("https".equals(uri.getScheme())
                && "localhost".equals(uri.getHost())
                && uri.getPath() != null
                && uri.getPath().startsWith("/api/")) {
              try {
                return api.handle(request.getMethod(), uri, "", request.getRequestHeaders());
              } catch (Exception error) {
                return NativeApi.error(error);
              }
            }
            return super.shouldInterceptRequest(view, request);
          }
        });
  }
}
