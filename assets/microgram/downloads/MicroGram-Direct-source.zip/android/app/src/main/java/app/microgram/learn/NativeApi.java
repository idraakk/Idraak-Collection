package app.microgram.learn;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceResponse;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.playlist.PlaylistInfo;
import org.schabi.newpipe.extractor.stream.*;

public final class NativeApi {
  private static NativeApi instance;

  public static synchronized NativeApi get(Context context) {
    if (instance == null) instance = new NativeApi(context.getApplicationContext());
    return instance;
  }

  private final File cache, originals;
  private final android.content.SharedPreferences settings;
  private final ConcurrentHashMap<String, JSONObject> metadata = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, Source> sources = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, FutureTask<Source>> pending = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, Object> blockLocks = new ConcurrentHashMap<>();
  private volatile long generation;
  private volatile JSONObject warmStatus = new JSONObject();
  private final java.util.concurrent.atomic.AtomicLong warmEpoch =
      new java.util.concurrent.atomic.AtomicLong();
  private final ExecutorService warmer = Executors.newSingleThreadExecutor();
  private final android.util.LruCache<String, android.graphics.Bitmap> previewSheets =
      new android.util.LruCache<>(8 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, android.graphics.Bitmap value) {
          return value.getByteCount();
        }
      };
  private static final int BLOCK = 1024 * 1024;
  private static final long DEFAULT_LIMIT = 250L * 1024 * 1024;

  private NativeApi(Context context) {
    cache = new File(context.getCacheDir(), "direct-video-chunks");
    cache.mkdirs();
    originals = new File(context.getFilesDir(), "original-videos");
    originals.mkdirs();
    settings = context.getSharedPreferences("direct-streaming", Context.MODE_PRIVATE);
    NewPipe.init(new DirectDownloader());
  }

  static final class Track {
    final String id, url, codec, mime, version;
    final int bandwidth, width, height, initStart, initEnd, indexStart, indexEnd;

    Track(Stream stream, int sequence, long duration) throws Exception {
      id = "t" + sequence;
      url = stream.getContent();
      Uri parsed = Uri.parse(url);
      if (!"https".equals(parsed.getScheme())
          || parsed.getHost() == null
          || !parsed.getHost().endsWith(".googlevideo.com"))
        throw new IOException("Unsupported media host.");
      if (stream instanceof VideoStream) {
        VideoStream v = (VideoStream) stream;
        codec = v.getCodec();
        bandwidth = v.getBitrate();
        width = v.getWidth();
        height = v.getHeight();
        initStart = v.getInitStart();
        initEnd = v.getInitEnd();
        indexStart = v.getIndexStart();
        indexEnd = v.getIndexEnd();
        mime = "video/mp4";
      } else {
        AudioStream a = (AudioStream) stream;
        codec = a.getCodec();
        bandwidth = a.getBitrate();
        width = height = 0;
        initStart = a.getInitStart();
        initEnd = a.getInitEnd();
        indexStart = a.getIndexStart();
        indexEnd = a.getIndexEnd();
        mime = "audio/mp4";
      }
      if (codec == null
          || codec.isEmpty()
          || indexStart < 0
          || indexEnd <= indexStart
          || initEnd < 0) throw new IOException("Source has no supported segment index.");
      version =
          hash(
              stream.getId()
                  + ":"
                  + duration
                  + ":"
                  + bandwidth
                  + ":"
                  + codec
                  + ":"
                  + parsed.getQueryParameter("clen")
                  + ":"
                  + indexEnd);
    }
  }

  static final class Source {
    final StreamInfo info;
    final LinkedHashMap<String, Track> tracks = new LinkedHashMap<>();
    final long created = System.currentTimeMillis();

    Source(StreamInfo info) throws Exception {
      this.info = info;
      int i = 0;
      List<VideoStream> videos = new ArrayList<>(info.getVideoOnlyStreams());
      videos.sort((a, b) -> Integer.compare(b.getHeight(), a.getHeight()));
      Set<Integer> heights = new HashSet<>();
      for (VideoStream v : videos) {
        if (v.getHeight() < 144
            || v.getHeight() > 1080
            || v.getCodec() == null
            || !v.getCodec().startsWith("avc1")
            || heights.contains(v.getHeight())
            || !v.isUrl()) continue;
        try {
          Track t = new Track(v, i++, info.getDuration());
          tracks.put(t.id, t);
          heights.add(v.getHeight());
        } catch (Exception ignored) {
        }
      }
      List<AudioStream> audios = new ArrayList<>(info.getAudioStreams());
      audios.sort(
          (a, b) ->
              Boolean.compare(
                  b.getAudioTrackType() != null && b.getAudioTrackType().name().equals("ORIGINAL"),
                  a.getAudioTrackType() != null
                      && a.getAudioTrackType().name().equals("ORIGINAL")));
      for (AudioStream a : audios) {
        if (a.getCodec() == null || !a.getCodec().startsWith("mp4a") || !a.isUrl()) continue;
        try {
          Track t = new Track(a, i++, info.getDuration());
          tracks.put(t.id, t);
          break;
        } catch (Exception ignored) {
        }
      }
      if (heights.isEmpty() || tracks.values().stream().noneMatch(t -> t.mime.equals("audio/mp4")))
        throw new IOException("This video does not expose compatible H.264/AAC streams.");
    }
  }

  private Source source(String id) throws Exception {
    checkId(id);
    Source hit = sources.get(id);
    if (hit != null && System.currentTimeMillis() - hit.created < 5 * 60 * 1000) return hit;
    FutureTask<Source> task =
        new FutureTask<>(
            () ->
                new Source(
                    StreamInfo.getInfo(
                        ServiceList.YouTube, "https://www.youtube.com/watch?v=" + id)));
    FutureTask<Source> existing = pending.putIfAbsent(id, task);
    if (existing != null) return existing.get(80, TimeUnit.SECONDS);
    try {
      task.run();
      Source value = task.get();
      if (sources.size() > 12) sources.clear();
      sources.put(id, value);
      rememberMetadata(
          id,
          value.info.getUploaderName(),
          value.info.getUploaderAvatars(),
          value.info.getViewCount(),
          value.info.getUploadDate());
      return value;
    } finally {
      pending.remove(id, task);
    }
  }

  static String hash(String value) throws Exception {
    byte[] bytes =
        MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
    StringBuilder out = new StringBuilder();
    for (int i = 0; i < 12; i++) out.append(String.format(Locale.ROOT, "%02x", bytes[i]));
    return out.toString();
  }

  static void checkId(String id) {
    if (!id.matches("[A-Za-z0-9_-]{11}")) throw new IllegalArgumentException("Invalid video ID.");
  }

  private static WebResourceResponse response(
      String mime, int status, InputStream body, Map<String, String> extra) {
    Map<String, String> headers = new HashMap<>(extra);
    headers.put("Cache-Control", "no-store");
    return new WebResourceResponse(
        mime,
        "UTF-8",
        status,
        status == 200 ? "OK" : status == 206 ? "Partial Content" : "Request failed",
        headers,
        body);
  }

  private static WebResourceResponse text(String text, String mime) {
    return response(
        mime,
        200,
        new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)),
        Collections.emptyMap());
  }

  private static WebResourceResponse json(JSONObject value) {
    return text(value.toString(), "application/json");
  }

  public static WebResourceResponse error(Exception error) {
    String message =
        "Could not resolve this video on your phone. Try again or choose another lecture.";
    Throwable root = error;
    while (root.getCause() != null) root = root.getCause();
    String name = root.getClass().getSimpleName();
    if (name.contains("ReCaptcha"))
      message = "YouTube temporarily blocked requests from this device. Please try later.";
    else if (root instanceof IOException)
      message =
          root.getMessage() == null
              ? message
              : root.getMessage().replaceAll("https?://[^ ]+", "[source]");
    try {
      return response(
          "application/json",
          502,
          new ByteArrayInputStream(
              new JSONObject().put("error", message).toString().getBytes(StandardCharsets.UTF_8)),
          Collections.emptyMap());
    } catch (Exception ignored) {
      throw new RuntimeException(ignored);
    }
  }

  public WebResourceResponse handle(
      String method, Uri uri, String body, Map<String, String> headers) throws Exception {
    String path = uri.getPath();
    if (path.equals("/api/health"))
      return json(
          new JSONObject().put("status", "ok").put("youtubeConfigured", true).put("native", true));
    if (path.equals("/api/import") && method.equals("POST"))
      return json(importLink(new JSONObject(body).getString("url")));
    if (path.startsWith("/api/library-metadata")) {
      JSONObject args = body == null || body.isEmpty() ? new JSONObject() : new JSONObject(body);
      return json(libraryMetadata(args));
    }
    if (path.startsWith("/api/media/storage")) return json(storage(method, uri, body));
    String[] p = path.split("/");
    if (p.length >= 5 && p[2].equals("media")) {
      String id = p[3];
      checkId(id);
      if (p[4].equals("warm")) {
        if (method.equals("GET")) return json(warmStatus);
        JSONObject options = new JSONObject(body);
        JSONArray starts = options.getJSONArray("starts");
        if (starts.length() > 8) throw new IOException("Too many openings.");
        double[] times = new double[starts.length()];
        for (int i = 0; i < times.length; i++) {
          times[i] = starts.getDouble(i);
          if (!Double.isFinite(times[i]) || times[i] < 0 || times[i] > 86400)
            throw new IOException("Invalid time.");
        }
        long epoch = warmEpoch.incrementAndGet();
        warmStatus =
            new JSONObject()
                .put("state", times.length == 0 ? "cancelled" : "scheduled")
                .put("id", id)
                .put("starts", starts);
        if (times.length > 0)
          warmer.execute(
              () -> {
                try {
                  int blocks = warmOpenings(id, times, epoch);
                  if (epoch == warmEpoch.get())
                    warmStatus =
                        new JSONObject()
                            .put("state", "completed")
                            .put("id", id)
                            .put("starts", starts)
                            .put("blocksTouched", blocks);
                } catch (Exception error) {
                  try {
                    if (epoch == warmEpoch.get())
                      warmStatus =
                          new JSONObject()
                              .put("state", "failed")
                              .put("error", "Opening prefetch unavailable.");
                  } catch (Exception ignored) {
                  }
                }
              });
        return json(new JSONObject().put("scheduled", times.length > 0));
      }
      if (p[4].equals("preview")) {
        double time = Double.parseDouble(uri.getQueryParameter("time"));
        if (!Double.isFinite(time) || time < 0 || time > 86400)
          throw new IOException("Invalid time.");
        if (method.equals("POST")) {
          JSONObject args = new JSONObject(body);
          String encoded = args.getString("image");
          if (encoded.length() > 180000) throw new IOException("Preview too large.");
          byte[] jpeg = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
          if (jpeg.length < 4 || jpeg[0] != (byte) 0xff || jpeg[1] != (byte) 0xd8)
            throw new IOException("Invalid preview.");
          synchronized (this) {
            trim(Math.max(0, limit() - jpeg.length));
            java.nio.file.Files.write(
                new File(cache, id + "-frame-" + Math.round(time * 1000) + ".chunk").toPath(),
                jpeg);
          }
          return json(new JSONObject().put("stored", true));
        }
        return preview(id, time);
      }
      if (p[4].equals("status") || p[4].equals("prepare"))
        return json(
            new JSONObject()
                .put(
                    "state",
                    new File(originals, id + ".mp4").exists() || !id.startsWith("local")
                        ? "ready"
                        : "missing"));
      if (p[4].equals("keepalive")) return json(new JSONObject().put("ok", true));
      if (p[4].equals("file")) return original(id, header(headers, "Range"));
      if (p[4].equals("captions")) return captions(id, uri.getQueryParameter("language"));
    }
    if (p.length >= 5 && p[2].equals("stream")) {
      String id = p[3];
      checkId(id);
      if (p[4].equals("manifest.mpd")) return text(manifest(id), "application/dash+xml");
      if (p.length == 6 && p[4].equals("track"))
        return media(
            id,
            p[5],
            uri.getQueryParameter("version"),
            uri.getQueryParameter("range") != null
                ? uri.getQueryParameter("range")
                : header(headers, "Range"));
    }
    return response(
        "application/json",
        404,
        new ByteArrayInputStream(
            "{\"error\":\"Unknown native endpoint\"}".getBytes(StandardCharsets.UTF_8)),
        Collections.emptyMap());
  }

  static String header(Map<String, String> headers, String name) {
    for (Map.Entry<String, String> e : headers.entrySet())
      if (e.getKey().equalsIgnoreCase(name)) return e.getValue();
    return "";
  }

  private String manifest(String id) throws Exception {
    Source s = source(id);
    StringBuilder xml =
        new StringBuilder(
            "<?xml version=\"1.0\"?><MPD xmlns=\"urn:mpeg:dash:schema:mpd:2011\" type=\"static\""
                + " profiles=\"urn:mpeg:dash:profile:isoff-on-demand:2011\""
                + " minBufferTime=\"PT1.5S\" mediaPresentationDuration=\"PT"
                + s.info.getDuration()
                + "S\"><Period>");
    for (String mime : new String[] {"video/mp4", "audio/mp4"}) {
      xml.append("<AdaptationSet mimeType=\"")
          .append(mime)
          .append("\" contentType=\"")
          .append(mime.startsWith("video") ? "video" : "audio")
          .append("\">");
      for (Track t : s.tracks.values())
        if (t.mime.equals(mime)) {
          xml.append("<Representation id=\"")
              .append(t.id)
              .append("\" bandwidth=\"")
              .append(Math.max(t.bandwidth, 128000))
              .append("\" codecs=\"")
              .append(t.codec)
              .append("\"");
          if (t.height > 0)
            xml.append(" width=\"")
                .append(t.width)
                .append("\" height=\"")
                .append(t.height)
                .append("\"");
          xml.append("><BaseURL>/api/stream/")
              .append(id)
              .append("/track/")
              .append(t.id)
              .append("?version=")
              .append(t.version)
              .append("</BaseURL><SegmentBase indexRange=\"")
              .append(t.indexStart)
              .append("-")
              .append(t.indexEnd)
              .append("\"><Initialization range=\"")
              .append(t.initStart)
              .append("-")
              .append(t.initEnd)
              .append("\"/></SegmentBase></Representation>");
        }
      xml.append("</AdaptationSet>");
    }
    return xml.append("</Period></MPD>").toString();
  }

  private static class Block {
    byte[] data;
    long total;

    Block(byte[] data, long total) {
      this.data = data;
      this.total = total;
    }
  }

  private Block block(String id, Track track, long offset) throws Exception {
    String key = id + "-" + track.version + "-" + offset;
    Object lock = blockLocks.computeIfAbsent(key, k -> new Object());
    try {
      synchronized (lock) {
        File data = new File(cache, key + ".chunk"), meta = new File(cache, key + ".meta");
        if (data.isFile() && meta.isFile())
          try {
            long total =
                Long.parseLong(
                    new String(
                        java.nio.file.Files.readAllBytes(meta.toPath()), StandardCharsets.UTF_8));
            byte[] bytes = java.nio.file.Files.readAllBytes(data.toPath());
            if (total <= offset || bytes.length != Math.min(BLOCK, total - offset))
              throw new IOException("Incomplete cached chunk.");
            data.setLastModified(System.currentTimeMillis());
            return new Block(bytes, total);
          } catch (Exception ignored) {
          }
        long epoch = generation;
        HttpURLConnection c = (HttpURLConnection) new URL(track.url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Range", "bytes=" + offset + "-" + (offset + BLOCK - 1));
        c.setRequestProperty("Accept-Encoding", "identity");
        Block result;
        try {
          int status = c.getResponseCode();
          if (status != 206) {
            if (status == 403 || status == 410) sources.remove(id);
            throw new IOException(
                "Source returned " + status + ". Reopen this video to refresh its stream.");
          }
          java.util.regex.Matcher range =
              java.util.regex.Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+)")
                  .matcher(
                      c.getHeaderField("Content-Range") == null
                          ? ""
                          : c.getHeaderField("Content-Range"));
          if (!range.matches() || Long.parseLong(range.group(1)) != offset)
            throw new IOException("Invalid media byte range.");
          long end = Long.parseLong(range.group(2)), total = Long.parseLong(range.group(3));
          byte[] bytes;
          try (InputStream in = c.getInputStream()) {
            bytes = DirectDownloader.readBounded(in, BLOCK);
          }
          if (bytes.length != end - offset + 1) throw new IOException("Incomplete media chunk.");
          result = new Block(bytes, total);
        } finally {
          c.disconnect();
        }
        synchronized (this) {
          if (epoch == generation) {
            try {
              trim(Math.max(0, limit() - result.data.length));
              java.nio.file.Files.write(data.toPath(), result.data);
              java.nio.file.Files.write(
                  meta.toPath(), Long.toString(result.total).getBytes(StandardCharsets.UTF_8));
            } catch (IOException ignored) {
            }
          }
        }
        return result;
      }
    } finally {
      blockLocks.remove(key, lock);
    }
  }

  private WebResourceResponse media(String id, String trackId, String version, String range)
      throws Exception {
    Source s = source(id);
    Track t = s.tracks.get(trackId);
    if (t == null || !t.version.equals(version))
      throw new IOException("Video format changed. Reopen this lecture.");
    java.util.regex.Matcher m =
        java.util.regex.Pattern.compile("bytes=(\\d+)-(\\d+)").matcher(range);
    if (!m.matches()) throw new IOException("A bounded byte range is required.");
    long start = Long.parseLong(m.group(1)), requestedEnd = Long.parseLong(m.group(2));
    if (start < 0 || requestedEnd < start || requestedEnd - start > 32L * 1024 * 1024)
      throw new IOException("Invalid range size.");
    Block first = block(id, t, start / BLOCK * BLOCK);
    long end = Math.min(requestedEnd, first.total - 1);
    if (start > end) throw new IOException("Range is outside this file.");
    InputStream input =
        new InputStream() {
          long cursor = start;
          Block current = first;
          long aligned = start / BLOCK * BLOCK;
          boolean closed;

          @Override
          public int read() throws IOException {
            byte[] one = new byte[1];
            return read(one, 0, 1) == -1 ? -1 : one[0] & 255;
          }

          @Override
          public int read(byte[] out, int off, int len) throws IOException {
            if (closed || cursor > end) return -1;
            if (len == 0) return 0;
            long wanted = cursor / BLOCK * BLOCK;
            if (wanted != aligned) {
              try {
                current = block(id, t, wanted);
                aligned = wanted;
              } catch (Exception e) {
                throw new IOException("Next video chunk unavailable.", e);
              }
            }
            int position = (int) (cursor - aligned);
            int n = (int) Math.min(Math.min(len, end - cursor + 1), current.data.length - position);
            if (n <= 0) throw new IOException("Incomplete cached range.");
            System.arraycopy(current.data, position, out, off, n);
            cursor += n;
            return n;
          }

          @Override
          public void close() {
            closed = true;
            current = null;
          }
        };
    Map<String, String> headers = new HashMap<>();
    headers.put("Content-Range", "bytes " + start + "-" + end + "/" + first.total);
    headers.put("Content-Length", Long.toString(end - start + 1));
    headers.put("Accept-Ranges", "bytes");
    return response(t.mime, 206, input, headers);
  }

  private WebResourceResponse original(String id, String range) throws Exception {
    File file = new File(originals, id + ".mp4");
    if (!file.exists()) throw new IOException("This local file is missing. Import it again.");
    java.util.regex.Matcher m =
        java.util.regex.Pattern.compile("bytes=(\\d+)-(\\d*)").matcher(range);
    long start = m.matches() ? Long.parseLong(m.group(1)) : 0,
        end =
            m.matches() && !m.group(2).isEmpty()
                ? Math.min(Long.parseLong(m.group(2)), file.length() - 1)
                : file.length() - 1;
    if (start < 0 || end < start || start >= file.length())
      throw new IOException("Invalid original file range.");
    // WebView applies the Range seek to intercepted streams itself. Supply
    // the entire seekable file instead of pre-slicing it a second time.
    Map<String, String> headers = new HashMap<>();
    headers.put("Accept-Ranges", "bytes");
    if (m.matches())
      headers.put("Content-Range", "bytes " + start + "-" + end + "/" + file.length());
    return response(
        "video/mp4", m.matches() ? 206 : 200, new FilePrefixStream(file, end + 1), headers);
  }

  private long limit() {
    return settings.getLong("limit", DEFAULT_LIMIT);
  }

  private synchronized void trim(long max) {
    File[] files = cache.listFiles((d, n) -> n.endsWith(".chunk"));
    if (files == null) return;
    Arrays.sort(files, Comparator.comparingLong(File::lastModified));
    long used = 0;
    for (File f : files) used += f.length();
    for (File f : files) {
      if (used <= max) break;
      long bytes = f.length();
      if (f.delete()) {
        used -= bytes;
        new File(cache, f.getName().replace(".chunk", ".meta")).delete();
      }
    }
  }

  private synchronized JSONObject storage(String method, Uri uri, String body) throws Exception {
    String path = uri.getPath();
    JSONObject args = body == null || body.isEmpty() ? new JSONObject() : new JSONObject(body);
    if (path.endsWith("/clear")) {
      generation++;
      warmEpoch.incrementAndGet();
      previewSheets.evictAll();
      JSONArray ids = args.optJSONArray("ids");
      Set<String> selected = new HashSet<>();
      if (ids != null) for (int i = 0; i < ids.length(); i++) selected.add(ids.getString(i));
      long freed = 0;
      Set<String> removed = new HashSet<>();
      File[] files = cache.listFiles();
      if (files != null)
        for (File f : files) {
          String id =
              f.getName()
                  .split("-", 2)[0]; // IDs can contain hyphens, use the fixed 11-char prefix below.
          id = f.getName().length() >= 11 ? f.getName().substring(0, 11) : "";
          if (ids == null || selected.contains(id)) {
            if (f.getName().endsWith(".chunk")) freed += f.length();
            if (f.delete()) removed.add(id);
          }
        }
      return new JSONObject().put("freed", freed).put("removed", removed.size()).put("skipped", 0);
    }
    if (path.endsWith("/limit")) {
      double gib = args.getDouble("gib");
      if (gib < 0.125 || gib > 4) throw new IOException("Invalid cache limit.");
      settings.edit().putLong("limit", (long) (gib * 1024 * 1024 * 1024)).apply();
      trim(limit());
    }
    if (method.equals("DELETE") && "delete-original".equals(uri.getQueryParameter("confirm"))) {
      String id = uri.getLastPathSegment();
      checkId(id);
      new File(originals, id + ".mp4").delete();
      return new JSONObject().put("deleted", true);
    }
    Map<String, Long> sizes = new LinkedHashMap<>();
    long used = 0;
    File[] files = cache.listFiles((d, n) -> n.endsWith(".chunk"));
    if (files != null)
      for (File f : files) {
        String id = f.getName().substring(0, 11);
        used += f.length();
        sizes.put(id, sizes.getOrDefault(id, 0L) + f.length());
      }
    JSONArray entries = new JSONArray();
    for (Map.Entry<String, Long> e : sizes.entrySet())
      entries.put(
          new JSONObject()
              .put("id", e.getKey())
              .put("bytes", e.getValue())
              .put("kind", "download")
              .put("protected", false));
    File[] originalFiles = originals.listFiles((d, n) -> n.endsWith(".mp4"));
    if (originalFiles != null)
      for (File f : originalFiles)
        entries.put(
            new JSONObject()
                .put("id", f.getName().substring(0, 11))
                .put("bytes", f.length())
                .put("kind", "upload")
                .put("protected", false));
    return new JSONObject()
        .put("used", used)
        .put("limit", limit())
        .put("free", cache.getUsableSpace())
        .put("entries", entries)
        .put("downloading", false)
        .put("device", true);
  }

  private byte[] indexBytes(String id, Track t) throws Exception {
    if (t.indexEnd - t.indexStart > 256 * 1024) throw new IOException("Index too large.");
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    for (long cursor = t.indexStart; cursor <= t.indexEnd; ) {
      long aligned = cursor / BLOCK * BLOCK;
      Block b = block(id, t, aligned);
      int offset = (int) (cursor - aligned),
          count = (int) Math.min(t.indexEnd - cursor + 1, b.data.length - offset);
      if (count <= 0) throw new IOException("Incomplete index.");
      out.write(b.data, offset, count);
      cursor += count;
    }
    return out.toByteArray();
  }

  private int warmOpenings(String id, double[] times, long epoch) throws Exception {
    if (epoch != warmEpoch.get()) return 0;
    Source s = source(id);
    Track video = null, audio = null;
    for (Track t : s.tracks.values()) {
      if (t.height > 0 && t.height <= 720 && (video == null || t.height > video.height)) video = t;
      if (t.mime.equals("audio/mp4")) audio = t;
    }
    if (video == null || audio == null) return 0;
    List<Track> tracks = List.of(audio, video);
    Map<String, List<SegmentIndex.Part>> indexes = new HashMap<>();
    for (Track t : tracks) {
      if (epoch != warmEpoch.get()) return 0;
      indexes.put(t.id, SegmentIndex.parse(indexBytes(id, t), t.indexStart));
    }
    Set<String> requested = new HashSet<>();
    for (double time : times)
      for (Track t : tracks)
        for (SegmentIndex.Part part : indexes.get(t.id)) {
          if (epoch != warmEpoch.get()) return 0;
          if (part.time() + part.duration() <= Math.max(0, time - 0.1) || part.time() >= time + 4)
            continue;
          for (long offset = part.start() / BLOCK * BLOCK; offset <= part.end(); offset += BLOCK) {
            if (epoch != warmEpoch.get() || Thread.currentThread().isInterrupted()) return 0;
            String key = t.version + ":" + offset;
            if (!requested.add(key)) continue;
            if (requested.size() > 16)
              return 16; // at most 16 MiB for one viewport, often cache hits
            block(id, t, offset);
          }
        }
    return requested.size();
  }

  private WebResourceResponse preview(String id, double seconds) throws Exception {
    File exact = new File(cache, id + "-frame-" + Math.round(seconds * 1000) + ".chunk");
    if (exact.isFile()) {
      exact.setLastModified(System.currentTimeMillis());
      return response("image/jpeg", 200, new FileInputStream(exact), Collections.emptyMap());
    }
    Source source = source(id);
    Frameset chosen = null;
    for (Frameset f : source.info.getPreviewFrames()) {
      if (f.getDurationPerFrame() <= 0 || f.getTotalCount() < 1 || f.getUrls().isEmpty()) continue;
      if (chosen == null
          || (f.getFrameWidth() <= 320
              && (chosen.getFrameWidth() > 320 || f.getFrameWidth() > chosen.getFrameWidth())))
        chosen = f;
    }
    if (chosen == null) throw new IOException("Preview frames unavailable.");
    long time =
        Math.min(
            Math.round(seconds * 1000),
            (long) (chosen.getTotalCount() - 1) * chosen.getDurationPerFrame());
    int[] bounds = chosen.getFrameBoundsAt(time);
    if (bounds[0] >= chosen.getUrls().size()) throw new IOException("Preview unavailable.");
    String url = chosen.getUrls().get(bounds[0]);
    Uri uri = Uri.parse(url);
    if (!"https".equals(uri.getScheme())
        || uri.getHost() == null
        || !uri.getHost().endsWith(".ytimg.com")) throw new IOException("Invalid preview host.");
    String key = id + "-storyboard-" + hash(url);
    android.graphics.Bitmap sheet = previewSheets.get(key);
    if (sheet == null) {
      Object lock = blockLocks.computeIfAbsent(key, k -> new Object());
      synchronized (lock) {
        sheet = previewSheets.get(key);
        if (sheet == null) {
          File file = new File(cache, key + ".chunk");
          byte[] bytes;
          if (file.isFile()) bytes = java.nio.file.Files.readAllBytes(file.toPath());
          else {
            long epoch = generation;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            try (InputStream in = c.getInputStream()) {
              bytes = DirectDownloader.readBounded(in, 2 * 1024 * 1024);
            } finally {
              c.disconnect();
            }
            synchronized (this) {
              if (epoch == generation) {
                trim(Math.max(0, limit() - bytes.length));
                java.nio.file.Files.write(file.toPath(), bytes);
              }
            }
          }
          android.graphics.BitmapFactory.Options opts =
              new android.graphics.BitmapFactory.Options();
          opts.inJustDecodeBounds = true;
          android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
          if (opts.outWidth <= 0
              || opts.outHeight <= 0
              || (long) opts.outWidth * opts.outHeight > 8000000)
            throw new IOException("Preview too large.");
          sheet = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
          if (sheet == null) throw new IOException("Invalid preview image.");
          previewSheets.put(key, sheet);
        }
      }
      blockLocks.remove(key, lock);
    }
    if (bounds[3] > sheet.getWidth() || bounds[4] > sheet.getHeight())
      throw new IOException("Preview outside image.");
    android.graphics.Bitmap frame =
        android.graphics.Bitmap.createBitmap(
            sheet, bounds[1], bounds[2], bounds[3] - bounds[1], bounds[4] - bounds[2]);
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    frame.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out);
    if (frame != sheet) frame.recycle();
    return response(
        "image/jpeg", 200, new ByteArrayInputStream(out.toByteArray()), Collections.emptyMap());
  }

  private JSONObject cachedMetadata(String key) {
    JSONObject value = metadata.get(key);
    if (value == null) {
      try {
        value = new JSONObject(settings.getString("metadata:" + key, "{}"));
      } catch (Exception ignored) {
        return null;
      }
    }
    if (!value.has("id")
        || System.currentTimeMillis() - value.optLong("storedAt", 0) > 30L * 86400000) return null;
    return value;
  }

  private void rememberPlaylistMetadata(String id, PlaylistInfo info) throws Exception {
    JSONObject value =
        new JSONObject()
            .put("id", id)
            .put("channel", info.getUploaderName())
            .put("storedAt", System.currentTimeMillis());
    List<Image> avatars = info.getUploaderAvatars(), covers = info.getThumbnails();
    if (!avatars.isEmpty()) value.put("avatar", avatars.get(avatars.size() - 1).getUrl());
    if (!covers.isEmpty()) value.put("thumbnail", covers.get(covers.size() - 1).getUrl());
    metadata.put("p:" + id, value);
    settings.edit().putString("metadata:p:" + id, value.toString()).apply();
  }

  private JSONObject libraryMetadata(JSONObject args) throws Exception {
    JSONArray videos = new JSONArray(), playlists = new JSONArray();
    JSONArray ids = args.optJSONArray("videoIds"), lists = args.optJSONArray("playlistIds");
    if ((ids != null && ids.length() > 20) || (lists != null && lists.length() > 20))
      throw new IOException("Too many metadata requests.");
    if (ids != null)
      for (int i = 0; i < ids.length(); i++) {
        String id = ids.getString(i);
        checkId(id);
        JSONObject value = cachedMetadata(id);
        if (value == null || !value.has("avatar")) {
          try {
            source(id);
            value = cachedMetadata(id);
          } catch (Exception ignored) {
          }
        }
        if (value != null) videos.put(value);
      }
    if (lists != null)
      for (int i = 0; i < lists.length(); i++) {
        String id = lists.getString(i);
        if (!id.matches("[A-Za-z0-9_-]{10,150}")) continue;
        JSONObject value = cachedMetadata("p:" + id);
        if (value == null) {
          try {
            rememberPlaylistMetadata(
                id,
                PlaylistInfo.getInfo(
                    ServiceList.YouTube, "https://www.youtube.com/playlist?list=" + id));
            value = cachedMetadata("p:" + id);
          } catch (Exception ignored) {
          }
        }
        if (value != null) playlists.put(value);
      }
    return new JSONObject().put("videos", videos).put("playlists", playlists);
  }

  private void rememberMetadata(
      String id,
      String channel,
      List<Image> avatars,
      long views,
      org.schabi.newpipe.extractor.localization.DateWrapper date) {
    try {
      JSONObject value =
          new JSONObject()
              .put("id", id)
              .put("channel", channel)
              .put("views", Long.toString(Math.max(0, views)));
      if (avatars != null && !avatars.isEmpty())
        value.put("avatar", avatars.get(avatars.size() - 1).getUrl());
      if (date != null) value.put("publishedAt", date.offsetDateTime().toString());
      if (metadata.size() > 1000) metadata.clear();
      value.put("storedAt", System.currentTimeMillis());
      metadata.put(id, value);
      if (value.has("avatar"))
        settings.edit().putString("metadata:" + id, value.toString()).apply();
    } catch (Exception ignored) {
    }
  }

  private JSONObject video(String id, String title, String channel, long duration)
      throws Exception {
    return new JSONObject()
        .put("id", id)
        .put("title", title)
        .put("channel", channel)
        .put("duration", duration)
        .put("thumbnail", "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg");
  }

  private JSONObject importLink(String link) throws Exception {
    Uri uri = Uri.parse(link);
    String host = uri.getHost();
    if (host == null
        || !(host.equals("youtube.com")
            || host.endsWith(".youtube.com")
            || host.equals("youtu.be")))
      throw new IOException("Use a YouTube video or playlist link.");
    if (!"https".equals(uri.getScheme()) && !"http".equals(uri.getScheme()))
      throw new IOException("Invalid link scheme.");
    String list = uri.getQueryParameter("list");
    JSONArray videos = new JSONArray();
    String title, channel, id, kind;
    int skipped = 0;
    if (list != null && !list.isEmpty()) {
      if (!list.matches("[A-Za-z0-9_-]{10,150}")) throw new IOException("Invalid playlist ID.");
      id = list;
      kind = "playlist";
      String url = "https://www.youtube.com/playlist?list=" + list;
      PlaylistInfo info = PlaylistInfo.getInfo(ServiceList.YouTube, url);
      title = info.getName();
      channel = info.getUploaderName();
      rememberPlaylistMetadata(id, info);
      List<StreamInfoItem> items = new ArrayList<>(info.getRelatedItems());
      Page next = info.getNextPage();
      Set<String> pages = new HashSet<>();
      while (Page.isValid(next) && items.size() < 1000) {
        String pageId = next.getUrl() + ":" + next.getId();
        if (!pages.add(pageId)) break;
        ListExtractor.InfoItemsPage<StreamInfoItem> more =
            PlaylistInfo.getMoreItems(ServiceList.YouTube, url, next);
        items.addAll(more.getItems());
        next = more.getNextPage();
      }
      if (Page.isValid(next) || items.size() > 1000)
        throw new IOException("Please split playlists larger than 1,000 videos.");
      Set<String> seen = new HashSet<>();
      for (StreamInfoItem item : items) {
        String videoId = ServiceList.YouTube.getStreamLHFactory().getId(item.getUrl());
        if (item.getDuration() <= 0 || item.getDuration() > 86400 || !seen.add(videoId)) {
          skipped++;
          continue;
        }
        videos.put(video(videoId, item.getName(), item.getUploaderName(), item.getDuration()));
        rememberMetadata(
            videoId,
            item.getUploaderName(),
            item.getUploaderAvatars(),
            item.getViewCount(),
            item.getUploadDate());
      }
    } else {
      id = ServiceList.YouTube.getStreamLHFactory().getId(link);
      checkId(id);
      kind = "video";
      StreamInfo info = source(id).info;
      title = info.getName();
      channel = info.getUploaderName();
      videos.put(video(id, title, channel, info.getDuration()));
    }
    if (videos.length() == 0)
      throw new IOException("No playable lectures were found in this link.");
    JSONObject course =
        new JSONObject()
            .put("id", id)
            .put("kind", kind)
            .put("title", title)
            .put("channel", channel == null ? "" : channel)
            .put("videos", videos)
            .put("importedAt", System.currentTimeMillis());
    return new JSONObject().put("course", course).put("skipped", skipped);
  }

  private WebResourceResponse captions(String id, String language) throws Exception {
    List<SubtitlesStream> subs = source(id).info.getSubtitles();
    JSONArray tracks = new JSONArray();
    for (SubtitlesStream sub : subs)
      tracks.put(
          new JSONObject()
              .put("language", sub.getLanguageTag())
              .put("label", sub.getDisplayLanguageName()));
    if (language == null) return json(new JSONObject().put("tracks", tracks));
    for (SubtitlesStream sub : subs)
      if (sub.getLanguageTag().equals(language)) {
        String url = sub.getContent();
        url = url.replaceAll("([?&])fmt=[^&]*", "$1fmt=vtt");
        if (!url.contains("fmt=")) url += "&fmt=vtt";
        String vtt = NewPipe.getDownloader().get(url).responseBody();
        if (!vtt.trim().startsWith("WEBVTT"))
          throw new IOException("This caption track is not available as WebVTT.");
        return json(new JSONObject().put("vtt", vtt));
      }
    throw new IOException("Caption language is unavailable.");
  }

  public synchronized void writeOriginal(String id, String operation, String encoded)
      throws Exception {
    checkId(id);
    File part = new File(originals, id + ".part"), file = new File(originals, id + ".mp4");
    if (operation.equals("begin")) {
      try (FileOutputStream out = new FileOutputStream(part)) {}
      return;
    }
    if (operation.equals("cancel")) {
      part.delete();
      return;
    }
    if (operation.equals("finish")) {
      if (!part.isFile()) throw new IOException("Upload not started.");
      java.nio.file.Files.move(
          part.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
      return;
    }
    if (!operation.equals("append")
        || !part.isFile()
        || encoded == null
        || encoded.length() > 400000) throw new IOException("Invalid upload chunk.");
    byte[] bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
    if (part.length() + bytes.length > 2L * 1024 * 1024 * 1024
        || originals.getUsableSpace() < bytes.length + 8 * 1024 * 1024)
      throw new IOException("Not enough device storage.");
    try (FileOutputStream out = new FileOutputStream(part, true)) {
      out.write(bytes);
    }
  }
}
