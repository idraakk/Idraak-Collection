package app.microgram.learn;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/** Reads MP4 sidx references without downloading or transcoding the video. */
final class SegmentIndex {
  record Part(double time, double duration, long start, long end) {}

  static List<Part> parse(byte[] bytes, long absoluteStart) throws IOException {
    try {
      ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN);
      while (b.remaining() >= 8) {
        int box = b.position();
        long size = Integer.toUnsignedLong(b.getInt());
        int type = b.getInt();
        if (size < 8 || size > bytes.length - box) throw new IOException("Invalid index box.");
        if (type != 0x73696478) {
          b.position((int) (box + size));
          continue;
        }
        int version = (b.getInt() >>> 24) & 255;
        if (version > 1) throw new IOException("Unsupported index version.");
        b.getInt();
        long scale = Integer.toUnsignedLong(b.getInt());
        long earliest = version == 0 ? Integer.toUnsignedLong(b.getInt()) : b.getLong();
        long first = version == 0 ? Integer.toUnsignedLong(b.getInt()) : b.getLong();
        b.getShort();
        int count = Short.toUnsignedInt(b.getShort());
        if (scale <= 0
            || earliest < 0
            || first < 0
            || count > 8192
            || count * 12 > box + size - b.position())
          throw new IOException("Invalid segment index.");
        long offset = Math.addExact(absoluteStart + box + size, first);
        double time = (double) earliest / scale;
        List<Part> result = new ArrayList<>();
        for (int i = 0; i < count; i++) {
          int reference = b.getInt();
          long duration = Integer.toUnsignedLong(b.getInt());
          b.getInt();
          if (reference < 0 || reference == 0 || duration == 0)
            throw new IOException("Unsupported segment reference.");
          long end = Math.addExact(offset, reference - 1L);
          result.add(new Part(time, (double) duration / scale, offset, end));
          offset = end + 1;
          time += (double) duration / scale;
        }
        return result;
      }
      throw new IOException("No segment index.");
    } catch (RuntimeException error) {
      throw new IOException("Malformed segment index.", error);
    }
  }
}
