package app.microgram.learn;
import org.junit.Test;
import java.io.*;
import static org.junit.Assert.*;
public class DirectDownloaderTest {
 @Test public void responseSizeBoundIsEnforced() throws Exception {
  assertArrayEquals(new byte[]{1,2,3},DirectDownloader.readBounded(new ByteArrayInputStream(new byte[]{1,2,3}),3));
  try {DirectDownloader.readBounded(new ByteArrayInputStream(new byte[10]),9);fail("Oversized response accepted");}catch(IOException expected){}
 }
 @Test public void emptyResponseIsSupported()throws Exception{assertEquals(0,DirectDownloader.readBounded(new ByteArrayInputStream(new byte[0]),1).length);}
}
