package app.microgram.learn;

import org.junit.Test;
import java.nio.file.*;
import static org.junit.Assert.*;

public class FilePrefixStreamTest {
  @Test public void webViewSeekReturnsExactlyRequestedOriginalRange() throws Exception {
    Path file = Files.createTempFile("microgram-range", ".mp4");
    byte[] bytes = new byte[2000];
    for (int i=0;i<bytes.length;i++) bytes[i]=(byte)(i%251);
    Files.write(file, bytes);
    try (FilePrefixStream stream = new FilePrefixStream(file.toFile(), 200)) {
      assertEquals(100, stream.skip(100));
      byte[] actual = stream.readAllBytes();
      assertArrayEquals(java.util.Arrays.copyOfRange(bytes,100,200),actual);
      assertEquals(-1,stream.read());
    } finally { Files.deleteIfExists(file); }
  }
}
