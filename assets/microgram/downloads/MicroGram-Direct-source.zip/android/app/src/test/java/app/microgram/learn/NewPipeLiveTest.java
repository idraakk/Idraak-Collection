package app.microgram.learn;
import org.junit.*;
import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.stream.*;
import org.schabi.newpipe.extractor.playlist.PlaylistInfo;
import static org.junit.Assert.*;
public class NewPipeLiveTest {
 @Before public void setup(){Assume.assumeTrue(Boolean.getBoolean("microgram.live"));NewPipe.init(new DirectDownloader());}
 @Test public void resolvesLectureAndSeparateAudioVideoOnClientConnection()throws Exception{
  StreamInfo info=StreamInfo.getInfo(ServiceList.YouTube,"https://www.youtube.com/watch?v=KGOEK0-XBIg");
  assertTrue(info.getDuration()>0);assertFalse(info.getAudioStreams().isEmpty());
  VideoStream selected=info.getVideoOnlyStreams().stream().filter(v->v.getHeight()>=720&&v.getHeight()<=1080&&v.getCodec()!=null&&v.getCodec().startsWith("avc1")).findFirst().orElseThrow();
  assertTrue(selected.getIndexEnd()>selected.getIndexStart());
  java.net.HttpURLConnection connection=(java.net.HttpURLConnection)new java.net.URL(selected.getContent()).openConnection();
  connection.setRequestProperty("Range","bytes=0-65535");connection.setConnectTimeout(15000);connection.setReadTimeout(20000);
  try{assertEquals(206,connection.getResponseCode());try(java.io.InputStream input=connection.getInputStream()){assertEquals(65536,DirectDownloader.readBounded(input,65536).length);}}finally{connection.disconnect();}
  System.out.println("Client-side NewPipe resolved HD video and audio; direct 64 KiB range succeeded.");
 }
 @Test public void resolvesPlaylistWithoutServerOrDataApiKey()throws Exception{
  PlaylistInfo info=PlaylistInfo.getInfo(ServiceList.YouTube,"https://www.youtube.com/playlist?list=PLQEaRBV9gAFvzp6XhcNFpk1WdOcyVo9qT");
  assertFalse(info.getRelatedItems().isEmpty());assertTrue(info.getStreamCount()>0);
 }
}
