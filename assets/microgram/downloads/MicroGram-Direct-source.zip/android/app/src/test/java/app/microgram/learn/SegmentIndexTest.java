package app.microgram.learn;

import static org.junit.Assert.*;

import java.nio.*;
import org.junit.Test;

public class SegmentIndexTest {
  @Test
  public void mapsTimeToAbsoluteMediaRanges() throws Exception {
    ByteBuffer b = ByteBuffer.allocate(56).order(ByteOrder.BIG_ENDIAN);
    b.putInt(56)
        .putInt(0x73696478)
        .putInt(0)
        .putInt(1)
        .putInt(1000)
        .putInt(0)
        .putInt(20)
        .putShort((short) 0)
        .putShort((short) 2);
    b.putInt(100).putInt(4000).putInt(0).putInt(200).putInt(6000).putInt(0);
    var parts = SegmentIndex.parse(b.array(), 740);
    assertEquals(2, parts.size());
    assertEquals(816, parts.get(0).start());
    assertEquals(915, parts.get(0).end());
    assertEquals(4, parts.get(1).time(), 0.001);
    assertEquals(1115, parts.get(1).end());
  }

  @Test(expected = java.io.IOException.class)
  public void rejectsTruncatedIndexes() throws Exception {
    SegmentIndex.parse(new byte[] {0, 0, 0, 56, 115, 105, 100, 120}, 0);
  }
}
