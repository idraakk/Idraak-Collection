CREATE TABLE IF NOT EXISTS access_passes (
  id TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  days INTEGER NOT NULL,
  issued_at INTEGER NOT NULL,
  code_hash TEXT NOT NULL UNIQUE,
  token_hash TEXT UNIQUE,
  expires_at INTEGER,
  revoked INTEGER NOT NULL DEFAULT 0
);
