import { z } from 'zod';
import { feedSchema, freeAccess } from '../src/community/schema';
import type { Environment } from './worker';

async function digest(value: string) {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, '0')).join('');
}
const codeSchema = z.object({
  code: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-F0-9-]{35}$/),
});
const issueSchema = z.object({
  label: z.string().trim().min(1).max(120),
  days: z.number().int().min(1).max(3660),
});

export async function accessRoute(
  request: Request,
  env: Environment,
  json: (value: unknown, status?: number) => Response,
  readJson: (request: Request, limit: number) => Promise<unknown>,
) {
  const path = new URL(request.url).pathname;
  const method = request.method;
  if (path === '/admin/access-passes' && method === 'GET') {
    const rows = await env.DB.prepare(
      'SELECT id, label, days, issued_at, expires_at, revoked FROM access_passes ORDER BY issued_at DESC LIMIT 100',
    ).all();
    return json({ passes: rows.results });
  }
  if (path === '/admin/access-passes' && method === 'POST') {
    const form = issueSchema.safeParse(await readJson(request, 2048));
    if (!form.success)
      return json({ error: 'Enter a label and a duration from 1 to 3660 days.' }, 400);
    const id = crypto.randomUUID();
    const code = crypto.randomUUID().replace(/-/g, '').toUpperCase().match(/.{8}/g)!.join('-');
    await env.DB.prepare(
      'INSERT INTO access_passes(id,label,days,issued_at,code_hash) VALUES (?,?,?,?,?)',
    )
      .bind(id, form.data.label, form.data.days, Date.now(), await digest(code))
      .run();
    return json({ id, code }, 201);
  }
  const revoke = /^\/admin\/access-passes\/([a-f0-9-]{36})$/.exec(path);
  if (revoke && method === 'DELETE') {
    await env.DB.prepare('UPDATE access_passes SET revoked=1 WHERE id=?').bind(revoke[1]).run();
    return json({ ok: true });
  }
  if (path !== '/access' && path !== '/access/redeem') return;
  if (path === '/access/redeem' && method === 'POST') {
    const ip = request.headers.get('CF-Connecting-IP') || 'local';
    if (!(await env.LIMITER.limit({ key: 'access-redeem:' + ip })).success)
      return json({ error: 'Too many attempts. Try again in a minute.' }, 429);
    const form = codeSchema.safeParse(await readJson(request, 1024));
    if (!form.success) return json({ error: 'Enter the full access code.' }, 400);
    const token = crypto.randomUUID() + crypto.randomUUID();
    const row = await env.DB.prepare(
      'UPDATE access_passes SET token_hash=?, expires_at=? + days * 86400000 WHERE code_hash=? AND token_hash IS NULL AND revoked=0 RETURNING expires_at',
    )
      .bind(await digest(token), Date.now(), await digest(form.data.code))
      .first<{ expires_at: number }>();
    if (!row) return json({ error: 'This code is invalid, revoked, or already used.' }, 403);
    return json({ token, expiresAt: row.expires_at });
  }
  if (path !== '/access' || method !== 'GET') return json({ error: 'Method not allowed.' }, 405);
  const stored = await env.DB.prepare('SELECT body FROM content WHERE id=1').first<{
    body: string;
  }>();
  const policy = stored
    ? (feedSchema.parse(JSON.parse(stored.body)).access ?? freeAccess)
    : freeAccess;
  let expiresAt: number | undefined;
  if (policy.mode === 'membership') {
    const bearer = /^Bearer ([a-f0-9-]{72})$/.exec(request.headers.get('Authorization') || '');
    if (bearer) {
      const pass = await env.DB.prepare(
        'SELECT expires_at FROM access_passes WHERE token_hash=? AND revoked=0 AND expires_at>?',
      )
        .bind(await digest(bearer[1]), Date.now())
        .first<{ expires_at: number }>();
      expiresAt = pass?.expires_at;
    }
  }
  return json({ policy, expiresAt });
}
