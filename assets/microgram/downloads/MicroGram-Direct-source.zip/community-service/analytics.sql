CREATE TABLE IF NOT EXISTS analytics_usage (
  installation TEXT NOT NULL,
  session TEXT NOT NULL,
  day TEXT NOT NULL,
  opened INTEGER NOT NULL,
  active_ms INTEGER NOT NULL,
  watch_ms INTEGER NOT NULL,
  PRIMARY KEY (installation, session, day)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS analytics_usage_day ON analytics_usage(day, installation);
CREATE TABLE IF NOT EXISTS analytics_installs (
  installation TEXT PRIMARY KEY,
  first_day TEXT NOT NULL
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS analytics_installs_day ON analytics_installs(first_day);
CREATE TABLE IF NOT EXISTS analytics_downloads (
  day TEXT PRIMARY KEY,
  requests INTEGER NOT NULL
) WITHOUT ROWID;
