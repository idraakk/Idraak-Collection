import { z } from 'zod';
import type { Environment } from './worker';

const offset = 19_800_000;
const dayMs = 86_400_000;
const dateFor = (time: number) => new Date(time + offset).toISOString().slice(0, 10);
const destination =
  'https://idraakk.github.io/Idraak-Collection/assets/microgram/downloads/Microgram.apk';
const payload = z.object({
  installation: z.uuid(),
  rows: z
    .array(
      z.object({
        id: z.uuid(),
        openedAt: z
          .number()
          .int()
          .nonnegative()
          .max(8_640_000_000_000_000 - offset),
        day: z.iso.date(),
        activeMs: z.number().int().nonnegative().max(dayMs),
        watchMs: z.number().int().nonnegative().max(dayMs),
      }),
    )
    .min(1)
    .max(24),
});

type Period = {
  label: string;
  installs: number;
  opens: number;
  active: number;
  activeMs: number;
  watchMs: number;
  downloads: number;
};

export async function analytics(
  request: Request,
  env: Environment,
  ctx: { waitUntil(promise: Promise<unknown>): void },
  json: (body: unknown, status?: number) => Response,
  readJson: (request: Request, limit: number) => Promise<unknown>,
) {
  const url = new URL(request.url);
  const now = Date.now();
  const latest = dateFor(now);
  const earliest = dateFor(now - 15 * dayMs);
  const db = env.DB;

  if (url.pathname === '/download/android' && ['GET', 'HEAD'].includes(request.method)) {
    if (
      request.method === 'GET' &&
      ![request.headers.get('Sec-Purpose'), request.headers.get('Purpose')].some((purpose) =>
        /prefetch|prerender/i.test(purpose || ''),
      )
    ) {
      ctx.waitUntil(
        (async () => {
          const { success } = await env.ANALYTICS_LIMITER.limit({
            key: 'apk:' + (request.headers.get('CF-Connecting-IP') || 'unknown'),
          });
          if (success)
            await db
              .prepare(
                `INSERT INTO analytics_downloads (day, requests) VALUES (?, 1)
          ON CONFLICT(day) DO UPDATE SET requests = requests + 1`,
              )
              .bind(latest)
              .run();
        })().catch((error) => console.error('APK counter failed', error)),
      );
    }
    return new Response(null, {
      status: 302,
      headers: { Location: destination, 'Cache-Control': 'no-store' },
    });
  }

  if (url.pathname === '/analytics/sessions' && request.method === 'POST') {
    const { success } = await env.ANALYTICS_LIMITER.limit({
      key: 'app:' + (request.headers.get('CF-Connecting-IP') || 'unknown'),
    });
    if (!success) return json({ error: 'Please retry later.' }, 429);
    const parsed = payload.safeParse(await readJson(request, 6000));
    if (!parsed.success) return json({ error: 'Invalid usage snapshot.' }, 400);
    const { installation, rows } = parsed.data;
    const accepted = rows.filter(
      (row) =>
        row.day >= earliest &&
        row.day <= latest &&
        row.openedAt <= now + 300_000 &&
        dateFor(row.openedAt) <= row.day,
    );
    if (!accepted.length) return json({ ok: true });
    const first = accepted.reduce((min, row) => (row.day < min ? row.day : min), accepted[0].day);
    await db.batch([
      db
        .prepare(
          `INSERT INTO analytics_installs (installation, first_day) VALUES (?, ?)
        ON CONFLICT(installation) DO UPDATE SET first_day = MIN(first_day, excluded.first_day)`,
        )
        .bind(installation, first),
      ...accepted.map((row) =>
        db
          .prepare(
            `INSERT INTO analytics_usage
        (installation, session, day, opened, active_ms, watch_ms) VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(installation, session, day) DO UPDATE SET
          opened = MAX(opened, excluded.opened),
          active_ms = MAX(active_ms, excluded.active_ms),
          watch_ms = MAX(watch_ms, excluded.watch_ms)`,
          )
          .bind(
            installation,
            row.id,
            row.day,
            Number(dateFor(row.openedAt) === row.day),
            row.activeMs,
            Math.min(row.watchMs, row.activeMs),
          ),
      ),
    ]);
    return json({ ok: true });
  }

  if (url.pathname === '/admin/analytics' && request.method === 'GET') {
    const requested = Number(url.searchParams.get('days'));
    const days = [7, 30, 90].includes(requested) ? requested : 30;
    const start = dateFor(now - (days - 1) * dayMs);
    // Monday labels use the same local reporting date as each usage snapshot.
    const week = "date(day, '-6 days', 'weekday 1')";
    function query(group: string) {
      return db
        .prepare(
          `WITH usage AS (
        SELECT ${group} label, COUNT(DISTINCT installation) active, SUM(opened) opens,
          SUM(active_ms) activeMs, SUM(watch_ms) watchMs
        FROM analytics_usage WHERE day BETWEEN ?1 AND ?2 GROUP BY label
      ), installs AS (
        SELECT ${group} label, COUNT(*) installs FROM
          (SELECT first_day day FROM analytics_installs WHERE first_day BETWEEN ?1 AND ?2) GROUP BY label
      ), downloads AS (
        SELECT ${group} label, SUM(requests) downloads FROM analytics_downloads
          WHERE day BETWEEN ?1 AND ?2 GROUP BY label
      ), labels AS (
        SELECT label FROM usage UNION SELECT label FROM installs UNION SELECT label FROM downloads
      )
      SELECT label, COALESCE(active, 0) active, COALESCE(opens, 0) opens,
        COALESCE(activeMs, 0) activeMs, COALESCE(watchMs, 0) watchMs,
        COALESCE(installs, 0) installs, COALESCE(downloads, 0) downloads
      FROM labels LEFT JOIN usage USING (label) LEFT JOIN installs USING (label)
        LEFT JOIN downloads USING (label) ORDER BY label`,
        )
        .bind(start, latest)
        .all<Period>();
    }
    const [total, daily, weekly, lifetime] = await Promise.all([
      query("'total'"),
      query('day'),
      query(week),
      db
        .prepare('SELECT COALESCE(SUM(requests), 0) downloads FROM analytics_downloads')
        .first<{ downloads: number }>(),
    ]);
    return json({
      start,
      latest,
      total: total.results[0] || null,
      daily: daily.results,
      weekly: weekly.results,
      lifetimeDownloads: lifetime?.downloads ?? 0,
    });
  }
  return null;
}
