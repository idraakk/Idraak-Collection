import { test, expect } from '@playwright/test';
import { initial, localDate } from '../../src/storage';
import { readFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
test.beforeEach(async ({ page }) => {
  await page.route('https://community.example/access', (route) =>
    route.fulfill({ json: { policy: { mode: 'free' } } }),
  );
  // Serve the built files through Playwright routing: no laptop hosting process is needed.
  await page.route('https://microgram.test/**', async (route) => {
    const pathname = new URL(route.request().url()).pathname;
    const studio = pathname.startsWith('/community-service/public/');
    const root = resolve(studio ? 'community-service/public' : '.tools/community-test-dist');
    const relative = studio
      ? pathname.slice('/community-service/public/'.length)
      : pathname === '/'
        ? 'index.html'
        : pathname.slice(1);
    const file = resolve(root, relative);
    if (!file.startsWith(root + sep)) return route.fulfill({ status: 403 });
    const types: Record<string, string> = {
      '.html': 'text/html',
      '.js': 'text/javascript',
      '.css': 'text/css',
      '.svg': 'image/svg+xml',
      '.woff2': 'font/woff2',
      '.json': 'application/json',
    };
    try {
      await route.fulfill({
        body: await readFile(file),
        contentType: types[extname(file)] || 'application/octet-stream',
      });
    } catch {
      await route.fulfill({ status: 404 });
    }
  });
});
const feed = {
  version: 1,
  revision: 'test-1',
  enabled: true,
  feedbackEnabled: true,
  posts: [
    {
      id: 'welcome',
      topic: 'A note from Idraak',
      kind: 'announcement',
      pinned: true,
      publishedAt: '2026-01-01T00:00:00.000Z',
      blocks: [
        { type: 'heading', text: 'Let’s build MicroGram together.' },
        {
          type: 'text',
          text: 'Your next update lives here.\n\nTell me what would make learning easier.',
        },
        { type: 'link', label: 'Find Idraak', url: 'https://www.instagram.com/idraakk/' },
      ],
    },
  ],
};
test('Home shows remote posts and sends only explicit feedback', async ({ page }) => {
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Reader', username: 'reader' },
  });
  await page.route('**/api/**', (route) => route.fulfill({ json: { videos: [], playlists: [] } }));
  await page.route('https://community.example/feed', (route) => route.fulfill({ json: feed }));
  let sent: Record<string, unknown> = {};
  await page.route('https://community.example/feedback', async (route) => {
    sent = route.request().postDataJSON();
    await route.fulfill({ status: 201, json: { ok: true } });
  });
  await page.goto('/');
  await expect(page.getByText('Let’s build MicroGram together.')).toBeVisible();
  await expect(page.getByRole('button', { name: /Replies \d/ })).toHaveCount(0);
  const feedPosts = page.locator('.community-feed > article');
  await expect
    .poll(() =>
      feedPosts.evaluateAll((posts) => posts.map((post) => post.getAttribute('aria-label'))),
    )
    .toEqual([
      'Idraak · A note from Idraak',
      'Idraak · Meet MicroGram',
      'Reader · Your daily goal',
      'Reader · Your learning year',
      'Idraak · Make your next scroll count',
      'Idraak · A better kind of scrolling',
    ]);

  const footer = page.locator('.home-footer-bar');
  const tabs = page.getByRole('navigation', { name: 'Main navigation' });
  await expect(footer).toBeHidden();
  await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
  await expect(footer).toBeVisible();
  const footerAtBottom = (await footer.boundingBox())!;
  const tabsBox = (await tabs.boundingBox())!;
  expect(footerAtBottom.y + footerAtBottom.height).toBeCloseTo(tabsBox.y, 0);
  await page.evaluate(() => window.scrollBy(0, -24));
  await expect(footer).toBeVisible();
  expect((await footer.boundingBox())!.y).toBe(footerAtBottom.y);
  await page.getByRole('button', { name: 'Write to Idraak' }).click();
  const feedbackScroll = await page.evaluate(() => window.scrollY);
  await page.mouse.move(4, 120);
  await page.mouse.wheel(0, -600);
  await expect(page.locator('html')).toHaveCSS('overflow-y', 'hidden');
  expect(await page.evaluate(() => window.scrollY)).toBe(feedbackScroll);
  await expect(page.getByRole('button', { name: 'Send message' })).toHaveCSS(
    'background-color',
    'rgb(255, 78, 148)',
  );
  await page.getByLabel('Your message', { exact: true }).fill('I would love more study tips.');
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  await expect(
    page.getByText('Message sent. Thank you for helping shape MicroGram.'),
  ).toBeVisible();
  expect(Object.keys(sent).sort()).toEqual(['category', 'message', 'replyTo', 'website']);
  await page.screenshot({ path: 'artifacts/community-home.png', fullPage: true });
  await page.reload();
  await expect(page.getByText('Let’s build MicroGram together.')).toBeVisible();
});
test('Home puts learning progress first on the next launch with heatmap activity', async ({
  page,
}) => {
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    { ...initial, profile: { name: 'Reader' } },
  );
  await page.route('https://community.example/feed', (route) =>
    route.fulfill({ json: { ...feed, posts: [] } }),
  );
  await page.goto('/');
  const order = () =>
    page
      .locator('.community-feed > article')
      .evaluateAll((posts) => posts.slice(0, 3).map((post) => post.getAttribute('aria-label')));
  await expect
    .poll(order)
    .toEqual([
      'Idraak · Meet MicroGram',
      'Reader · Your daily goal',
      'Reader · Your learning year',
    ]);
  await page.addInitScript((date) => {
    const state = JSON.parse(localStorage.getItem('microgram.v1')!);
    state.activity[date] = 30;
    localStorage.setItem('microgram.v1', JSON.stringify(state));
  }, localDate());
  await page.reload();
  await expect
    .poll(order)
    .toEqual([
      'Reader · Your daily goal',
      'Reader · Your learning year',
      'Idraak · Meet MicroGram',
    ]);
});

test('Studio signs in, edits, previews and publishes a revision-checked draft', async ({
  page,
}) => {
  let published: Record<string, unknown> | undefined;
  let expectedRevision = '';
  await page.route('**/admin/feed', async (route) => {
    if (route.request().method() === 'PUT') {
      published = route.request().postDataJSON();
      expectedRevision = route.request().headers()['if-match'];
      await route.fulfill({ json: { ...published, revision: 'test-2' } });
    } else await route.fulfill({ json: feed });
  });
  await page.route('**/studio-auth/login', (route) => route.fulfill({ json: { ok: true } }));
  await page.goto('/community-service/public/index.html');
  await page.getByLabel('Username', { exact: true }).fill('idraakk');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Open Studio' }).click();
  const originalRow = page.locator('.post-row').filter({ hasText: 'A note from Idraak' });
  await originalRow.getByRole('button', { name: 'Preview', exact: true }).click();
  await expect(
    originalRow.getByRole('heading', { name: 'Let’s build MicroGram together.' }),
  ).toBeVisible();
  await page.route('**/admin/engagement?post=welcome', (route) =>
    route.fulfill({
      json: {
        comments: [
          {
            id: 'welcome-reply',
            post_id: 'welcome',
            name: 'Maya',
            username: 'maya',
            created_at: 123,
            message: 'This is helpful.',
          },
        ],
      },
    }),
  );
  await originalRow.getByRole('button', { name: /Comments on A note from Idraak/ }).click();
  await expect(originalRow.getByText('Maya @maya', { exact: true })).toBeVisible();
  await expect(originalRow.getByText('This is helpful.', { exact: true })).toBeVisible();
  await originalRow.getByRole('button', { name: /Comments on A note from Idraak/ }).click();
  await page.getByRole('button', { name: '+ New post' }).click();
  await expect(page.getByLabel('Allow comments on this post')).not.toBeChecked();
  await expect(page.locator('#preview .preview-replies')).toHaveCount(0);
  await page.getByLabel('Allow comments on this post').check();
  await expect(page.locator('#preview .preview-replies')).toHaveCount(1);
  await page.getByLabel('Topic', { exact: true }).fill('Next release');
  await page.getByLabel('Message', { exact: true }).fill('A new chapter for MicroGram.');
  await expect(page.locator('#preview').getByText('A new chapter for MicroGram.')).toBeVisible();
  await page.getByRole('button', { name: 'Live Home' }).click();
  await expect(page.locator('#preview').getByText('A new chapter for MicroGram.')).toHaveCount(0);
  await page.getByRole('button', { name: 'Draft Home' }).click();
  await expect(page.locator('#preview').getByText('A new chapter for MicroGram.')).toBeVisible();
  await page.getByRole('button', { name: 'Save changes', exact: true }).click();
  await page.getByRole('button', { name: 'App access', exact: true }).click();
  await page.getByLabel('Checkout or subscription page URL').fill('bad checkout draft');
  await page.getByRole('button', { name: 'Android updates', exact: true }).click();
  await page.getByLabel('Show update prompt').check();
  await page.getByLabel('Require update before opening the app').check();
  await page.getByLabel('APK version code').fill('8');
  await page.getByLabel('Display version').fill('1.5.1');
  await page
    .getByLabel('Firebase tester release or APK URL')
    .fill('https://example.com/latest.apk');
  page.on('dialog', (dialog) => dialog.accept());
  await page.getByRole('button', { name: 'Publish update settings' }).click();
  await expect(page.getByText('Settings published.', { exact: true })).toBeVisible();
  expect(expectedRevision).toBe('test-1');
  expect(published?.access).toMatchObject({
    mode: 'free',
    release: { versionCode: 8, required: true, url: 'https://example.com/latest.apk' },
  });
  expect(published?.access).not.toHaveProperty('checkout');
  expect(published?.posts as unknown[]).toHaveLength(1);
  await page.getByRole('button', { name: 'Posts', exact: true }).click();
  await page.getByRole('button', { name: 'Publish changes', exact: true }).click();
  await expect(page.getByText('Published: Next release', { exact: true })).toBeVisible();
  expect(expectedRevision).toBe('test-2');
  expect(published?.posts as unknown[]).toHaveLength(2);
  expect(published?.posts).toContainEqual(
    expect.objectContaining({ topic: 'Next release', commentsEnabled: true }),
  );
  await page.route('**/admin/engagement*', (route) => {
    const older = new URL(route.request().url()).searchParams.has('cursor');
    return route.fulfill({
      json: {
        views: [],
        comments: [
          {
            id: older ? 'older' : 'latest',
            name: older ? 'Older reader' : 'Reader',
            username: 'learner',
            post_id: 'welcome',
            created_at: 123,
            message: 'Thanks!',
          },
        ],
        nextCursor: older ? undefined : '123:latest',
      },
    });
  });
  let deleted = false;
  await page.route('**/admin/comments/latest', (route) => {
    deleted = route.request().method() === 'DELETE';
    return route.fulfill({ json: { ok: true } });
  });
  await page.getByRole('button', { name: 'Comments', exact: true }).click();
  await expect(page.getByText('Reader @learner', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Load older comments' }).click();
  await expect(page.getByText('Older reader @learner', { exact: true })).toBeVisible();
  await page
    .getByRole('article')
    .filter({ hasText: 'Reader @learner' })
    .first()
    .getByRole('button', { name: 'Delete comment' })
    .click();
  await expect(page.getByText('Reader @learner', { exact: true })).toHaveCount(0);
  expect(deleted).toBe(true);
  await page.getByRole('button', { name: 'Posts', exact: true }).click();
  await page.screenshot({ path: 'artifacts/community-studio.png', fullPage: true });
});

test('a viewed pinned post moves below learning cards and Back preserves its location', async ({
  page,
}) => {
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Reader', username: 'reader' },
  });
  await page.route('**/api/**', (route) => route.fulfill({ json: { videos: [], playlists: [] } }));
  await page.route('https://community.example/feed', (route) =>
    route.fulfill({
      json: {
        ...feed,
        posts: [{ ...feed.posts[0], pinned: true, commentsEnabled: true }],
      },
    }),
  );
  let views = 0;
  await page.route('**/posts/welcome/view', (route) => {
    views++;
    return route.fulfill({ json: { ok: true } });
  });
  let sent: Record<string, unknown> = {};
  let count = 2;
  await page.route('**/posts/reply-counts', (route) =>
    route.fulfill({ json: { counts: { welcome: count } } }),
  );
  await page.route('**/posts/welcome/comments/reply1', (route) => {
    expect(route.request().headers().authorization).toBe('Bearer ' + sent.ownerToken);
    count = 2;
    return route.fulfill({ json: { ok: true } });
  });
  await page.route('**/posts/welcome/comments', async (route) => {
    if (route.request().method() === 'POST') {
      sent = route.request().postDataJSON();
      count = 3;
      return route.fulfill({
        status: 201,
        json: {
          id: 'reply1',
          created_at: Date.now(),
          name: sent.name,
          username: sent.username,
          message: sent.message,
          owned: true,
        },
      });
    }
    return route.fulfill({ json: { enabled: true, comments: [] } });
  });
  await page.goto('/');
  const heading = page.getByRole('heading', { name: 'Let’s build MicroGram together.' });
  const goal = page.getByRole('heading', { name: 'Daily learning goal' });
  await expect(heading).toBeVisible();
  expect(await heading.evaluate((el) => el.getBoundingClientRect().top)).toBeLessThan(
    await goal.evaluate((el) => el.getBoundingClientRect().top),
  );
  await expect.poll(() => views).toBe(1);
  const post = page.getByRole('article', { name: 'Idraak · A note from Idraak' });
  const trigger = post.getByRole('button', { name: 'Replies 2' });
  await trigger.scrollIntoViewIfNeeded();
  const priorScroll = await page.evaluate(() => window.scrollY);
  await trigger.click();
  const thread = page.getByRole('dialog', { name: 'Post conversation' });
  await expect(thread.getByText('No replies yet.')).toBeVisible();
  await thread.getByRole('textbox', { name: 'Post your reply' }).fill('A public reply');
  await thread.getByRole('button', { name: 'Reply', exact: true }).click();
  await expect(thread.getByText('A public reply')).toBeVisible();
  expect(sent).toMatchObject({
    name: 'Reader',
    username: 'reader',
    message: 'A public reply',
    ownerToken: expect.any(String),
  });
  await expect(thread.getByText('Replies are public.', { exact: false })).toHaveCount(0);
  await thread.getByLabel('Options for your reply').click();
  await thread.getByRole('button', { name: 'Delete reply' }).click();
  const confirmation = page.getByRole('dialog', { name: 'Delete your reply?' });
  await confirmation.getByRole('button', { name: 'Cancel' }).click();
  await expect(thread.getByText('A public reply')).toBeVisible();
  await thread.getByLabel('Options for your reply').click();
  await thread.getByRole('button', { name: 'Delete reply' }).click();
  await confirmation.getByRole('button', { name: 'Delete reply' }).click();
  await expect(thread.getByText('A public reply')).toHaveCount(0);
  await page.evaluate(() => window.history.back());
  await expect(thread).toHaveCount(0);
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBe(priorScroll);
  await expect(trigger).toBeFocused();
  await page.reload();
  await expect(heading).toBeVisible();
  expect(await heading.evaluate((el) => el.getBoundingClientRect().top)).toBeGreaterThan(
    await goal.evaluate((el) => el.getBoundingClientRect().top),
  );
});

test('pulling down on Home refreshes without a permanent toolbar button', async ({ page }) => {
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Reader' },
  });
  let requests = 0;
  await page.route('https://community.example/feed', async (route) => {
    requests++;
    if (requests > 1) await new Promise((resolve) => setTimeout(resolve, 350));
    await route.fulfill({ json: feed });
  });
  await page.goto('/');
  await expect(page.getByText('Let’s build MicroGram together.')).toBeVisible();
  await page.evaluate(() => {
    window.scrollTo(0, 0);
    for (const [name, y] of [
      ['touchstart', 100],
      ['touchmove', 235],
      ['touchend', 235],
    ] as const) {
      const touch = new Touch({ identifier: 1, target: document.body, clientX: 140, clientY: y });
      document.body.dispatchEvent(
        new TouchEvent(name, {
          bubbles: true,
          cancelable: true,
          touches: name === 'touchend' ? [] : [touch],
        }),
      );
    }
  });
  await expect.poll(() => requests).toBe(2);
  await expect(page.locator('.community-pull-indicator')).toHaveAttribute('data-visible', 'false');
});

test('a remote membership gate unlocks after a valid code is redeemed', async ({ page }) => {
  let authorized = false;
  const token = '0'.repeat(72);
  await page.route('https://community.example/access', (route) => {
    const expiresAt =
      authorized && route.request().headers().authorization === 'Bearer ' + token
        ? Date.now() + 60000
        : undefined;
    return route.fulfill({
      json: {
        policy: {
          mode: 'membership',
          title: 'Members only',
          message: 'Enter your code to continue.',
        },
        expiresAt,
      },
    });
  });
  await page.route('https://community.example/access/redeem', (route) => {
    authorized = true;
    return route.fulfill({ json: { token, expiresAt: Date.now() + 60000 } });
  });
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Reader' },
  });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Members only' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Daily learning goal' })).toHaveCount(0);
  await page.getByLabel('Already have a code?').fill('12345678-12345678-12345678-12345678');
  await page.getByRole('button', { name: 'Unlock', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Daily learning goal' })).toBeVisible();
});

test('startup shows the logo without loading text until access is ready', async ({ page }) => {
  let release!: () => void;
  const pending = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route('https://community.example/access', async (route) => {
    await pending;
    await route.fulfill({ json: { policy: { mode: 'free' } } });
  });
  await page.route('https://community.example/feed', (route) => route.fulfill({ json: feed }));
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Reader' },
  });
  await page.goto('/');
  try {
    await expect(page.getByRole('img', { name: 'MicroGram', exact: true })).toBeVisible();
    await expect(page.getByText(/opening microgram|loading microgram/i)).toHaveCount(0);
  } finally {
    release();
  }
  await expect(page.getByRole('heading', { name: 'Daily learning goal' })).toBeVisible();
});

test('Studio can edit a restored layout with inline rich formatting', async ({ page }) => {
  const original = JSON.parse(await readFile(resolve('src/community/editorials.json'), 'utf8'))[1];
  await page.route('**/studio-auth/login', (route) => route.fulfill({ json: { ok: true } }));
  await page.route('**/admin/feed', (route) =>
    route.fulfill({ json: { ...feed, editorials: [original] } }),
  );
  await page.goto('/community-service/public/index.html');
  await page.getByLabel('Username', { exact: true }).fill('idraakk');
  await page.getByLabel('Password', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: 'Open Studio', exact: true }).click();
  await page
    .locator('#posts')
    .getByRole('button', { name: 'Make your next scroll count', exact: true })
    .click();
  await expect(page.getByLabel('Post layout')).toHaveValue('purpose');
  await expect(page.locator('#preview .preview-purpose h2')).toContainText('scroll count.');
  const field = page.locator('.rich-editor-field').first();
  await field.getByRole('textbox', { name: 'Heading' }).fill('An editable headline');
  await field.getByRole('button', { name: 'Bold', exact: true }).click();
  await expect(page.locator('#preview .preview-purpose h2 span')).toHaveCSS('font-weight', '700');
});

test('reel shortcuts navigate, pause, and capture without interfering with note text', async ({
  page,
}) => {
  const video = {
    id: 'landscape01',
    title: 'Desktop lecture',
    channel: 'Teacher',
    duration: 35,
    thumbnail: '/local-cover.svg',
    local: true,
  };
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    consent: true,
    seconds: 15,
    profile: { name: 'Alex' },
    courses: [
      {
        id: 'desktop',
        title: video.title,
        channel: video.channel,
        importedAt: Date.now(),
        videos: [video],
      },
    ],
  });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/landscape-test.mp4');
  await page.route('**/api/media/*/file*', (route) => {
    const range = /^bytes=(\d+)-(\d*)$/.exec(route.request().headers().range ?? '');
    const start = Number(range?.[1] ?? 0);
    const end = range?.[2] ? Math.min(Number(range[2]), body.length - 1) : body.length - 1;
    return route.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'accept-ranges': 'bytes',
        'content-length': String(end - start + 1),
        ...(range ? { 'content-range': 'bytes ' + start + '-' + end + '/' + body.length } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.route('https://community.example/feed', (r) =>
    r.fulfill({ json: { ...feed, posts: [] } }),
  );
  await page.goto('/');
  await page
    .getByRole('navigation', { name: 'Main navigation' })
    .getByRole('button', { name: 'Reels', exact: true })
    .click();
  const player = page.locator('.native-video');
  await expect
    .poll(() => player.evaluate((v: HTMLVideoElement) => !v.paused && v.readyState >= 2))
    .toBe(true);
  const position = page.locator('.reel-card .reel-counter');
  await expect(position).toContainText(/1\s*\/\s*3/);
  await page.keyboard.press('ArrowDown');
  await expect(position).toContainText(/2\s*\/\s*3/);
  await page.keyboard.press('ArrowUp');
  await expect(position).toContainText(/1\s*\/\s*3/);
  await expect.poll(() => player.evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
  await page.keyboard.press('Space');
  await expect(page.getByRole('button', { name: 'Capture screen note' })).toBeVisible();
  const currentTime = () => player.evaluate((v: HTMLVideoElement) => v.currentTime);
  const before = await currentTime();
  await page.keyboard.press('Shift+ArrowRight');
  await expect.poll(currentTime).toBeCloseTo(before + 5, 1);
  await page.keyboard.press('Shift+ArrowLeft');
  await expect.poll(currentTime).toBeCloseTo(before, 1);
  await page.keyboard.press('Shift+ArrowLeft');
  await expect.poll(currentTime).toBeCloseTo(0, 1);
  await expect(position).toContainText(/1\s*\/\s*3/);
  await expect.poll(() => player.evaluate((v: HTMLVideoElement) => v.paused)).toBe(true);
  await page.keyboard.press('Control+Space');
  await expect(page.getByRole('dialog')).toBeVisible();
  const label = page.getByLabel('Label optional', { exact: true });
  await label.pressSequentially('Keyboard note');
  await expect(label).toHaveValue('Keyboard note');
});
