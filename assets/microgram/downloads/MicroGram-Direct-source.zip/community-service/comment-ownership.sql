ALTER TABLE post_comments ADD COLUMN owner_hash TEXT;
