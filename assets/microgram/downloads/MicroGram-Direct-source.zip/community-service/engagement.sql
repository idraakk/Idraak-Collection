CREATE TABLE IF NOT EXISTS post_views (
  post_id TEXT NOT NULL,
  viewer TEXT NOT NULL,
  PRIMARY KEY (post_id, viewer)
);
CREATE TABLE IF NOT EXISTS post_comments (
  id TEXT PRIMARY KEY,
  post_id TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  name TEXT NOT NULL,
  username TEXT NOT NULL,
  message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS post_comments_thread ON post_comments(post_id, created_at DESC);
