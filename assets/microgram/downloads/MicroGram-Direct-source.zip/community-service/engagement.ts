import { archivePosts, commentInput, feedSchema, visiblePosts } from '../src/community/schema';
import type { Environment } from './worker';

async function ownerHash(value: unknown) {
  if (typeof value !== 'string' || !/^[a-f0-9-]{72}$/.test(value)) return null;
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, '0')).join('');
}
export async function engagement(
  request: Request,
  env: Environment,
  json: (value: unknown, status?: number) => Response,
  readJson: (request: Request, limit: number) => Promise<unknown>,
) {
  const { pathname } = new URL(request.url);
  const { method } = request;
  if (pathname === '/admin/engagement' && method === 'GET') {
    const views = await env.DB.prepare(
      'SELECT post_id, COUNT(*) AS count FROM post_views GROUP BY post_id',
    ).all();
    const params = new URL(request.url).searchParams;
    const postId = params.get('post');
    if (postId !== null && !/^[\w-]{1,80}$/.test(postId))
      return json({ error: 'Invalid post ID' }, 400);
    const cursor = params.get('cursor');
    const match = cursor && /^(\d{1,15}):([\w-]{1,80})$/.exec(cursor);
    if (cursor && !match) return json({ error: 'Invalid comments cursor' }, 400);
    const conditions: string[] = [];
    const values: (string | number)[] = [];
    if (postId) {
      conditions.push('post_id = ?');
      values.push(postId);
    }
    if (match) {
      conditions.push('(created_at, id) < (?, ?)');
      values.push(Number(match[1]), match[2]);
    }
    const where = conditions.length ? ' WHERE ' + conditions.join(' AND ') : '';
    const query = 'SELECT id, post_id, created_at, name, username, message FROM post_comments';
    const order = ' ORDER BY created_at DESC, id DESC LIMIT 101';
    const comments = await env.DB.prepare(query + where + order)
      .bind(...values)
      .all<{ id: string; created_at: number }>();
    const totals = await env.DB.prepare(
      'SELECT post_id, COUNT(*) AS count FROM post_comments GROUP BY post_id',
    ).all();
    const page = comments.results.slice(0, 100);
    const last = page.at(-1);
    return json({
      views: views.results,
      comments: page,
      totals: totals.results,
      nextCursor:
        last && comments.results.length > 100 ? last.created_at + ':' + last.id : undefined,
    });
  }
  const removal = /^\/admin\/comments\/([\w-]+)$/.exec(pathname);
  if (removal && method === 'DELETE') {
    await env.DB.prepare('DELETE FROM post_comments WHERE id = ?').bind(removal[1]).run();
    return json({ ok: true });
  }
  if (pathname === '/posts/reply-counts' && method === 'GET') {
    const result = await env.DB.prepare(
      'SELECT post_id, COUNT(*) AS count FROM post_comments GROUP BY post_id',
    ).all<{ post_id: string; count: number }>();
    return json({
      counts: Object.fromEntries(result.results.map(({ post_id, count }) => [post_id, count])),
    });
  }
  const ownedRemoval = /^\/posts\/([\w-]{1,80})\/comments\/([a-f0-9-]{36})$/.exec(pathname);
  if (ownedRemoval && method === 'DELETE') {
    const hash = await ownerHash(request.headers.get('Authorization')?.replace(/^Bearer /, ''));
    if (!hash) return json({ error: 'You can delete only your own replies' }, 403);
    const result = await env.DB.prepare(
      'DELETE FROM post_comments WHERE id=? AND post_id=? AND owner_hash=?',
    )
      .bind(ownedRemoval[2], ownedRemoval[1], hash)
      .run();
    return result.meta.changes
      ? json({ ok: true })
      : json({ error: 'Reply unavailable or not yours' }, 403);
  }
  const post = /^\/posts\/([\w-]{1,80})\/(comments|view)$/.exec(pathname);
  if (!post) return;
  const [, id, action] = post;
  if (method !== 'GET' && method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const record = await env.DB.prepare('SELECT body FROM content WHERE id = 1').first<{
    body: string;
  }>();
  const feed = record && feedSchema.safeParse(JSON.parse(record.body));
  if (!feed?.success) return json({ error: 'Post unavailable' }, 404);
  const entry = [
    ...visiblePosts(feed.data),
    ...visiblePosts({ ...feed.data, posts: archivePosts(feed.data) }),
  ].find((post) => post.id === id);
  if (!entry) return json({ error: 'Post unavailable' }, 404);
  if (action === 'comments' && entry.commentsEnabled !== true) {
    return method === 'GET'
      ? json({ comments: [], enabled: false })
      : json({ error: 'Replies are closed' }, 403);
  }

  if (action === 'comments' && method === 'GET') {
    const hash = await ownerHash(request.headers.get('Authorization')?.replace(/^Bearer /, ''));
    const result = await env.DB.prepare(
      'SELECT id, name, username, message, created_at, CASE WHEN owner_hash = ? THEN 1 ELSE 0 END AS owned FROM post_comments WHERE post_id = ? ORDER BY created_at DESC LIMIT 100',
    )
      .bind(hash, id)
      .all();
    return json({ comments: result.results, enabled: true });
  }
  if (method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const key = request.headers.get('CF-Connecting-IP') || 'local';
  if (
    !(
      await env.LIMITER.limit({
        key: action === 'view' ? 'view:' + id + ':' + key : 'comment:' + key,
      })
    ).success
  )
    return json({ error: 'Please wait before trying again' }, 429);
  const payload = await readJson(request, 4096);
  if (action === 'view') {
    const viewer = (payload as { viewer?: unknown } | null)?.viewer;
    if (typeof viewer !== 'string' || !/^[a-f0-9-]{36}$/.test(viewer))
      return json({ error: 'Invalid view' }, 400);
    const digest = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(id + ':' + viewer),
    );
    const unique = [...new Uint8Array(digest)]
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
    await env.DB.prepare('INSERT OR IGNORE INTO post_views (post_id, viewer) VALUES (?, ?)')
      .bind(id, unique)
      .run();
    return json({ ok: true });
  }
  const comment = commentInput.safeParse(payload);
  if (!comment.success) return json({ error: 'Check your name and reply' }, 400);
  const hash = await ownerHash((payload as { ownerToken?: unknown } | null)?.ownerToken);
  const reply = { id: crypto.randomUUID(), created_at: Date.now(), ...comment.data, owned: !!hash };
  await env.DB.prepare(
    'INSERT INTO post_comments (id, post_id, created_at, name, username, message, owner_hash) VALUES (?, ?, ?, ?, ?, ?, ?)',
  )
    .bind(reply.id, id, reply.created_at, reply.name, reply.username, reply.message, hash)
    .run();
  return json(reply, 201);
}
