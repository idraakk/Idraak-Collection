const number = new Intl.NumberFormat();
const shortDate = new Intl.DateTimeFormat(undefined, {
  day: 'numeric',
  month: 'short',
  timeZone: 'UTC',
});
const metrics = [
  ['downloads', 'APK download requests'],
  ['installs', 'First measured opens'],
  ['active', 'Active installs'],
  ['opens', 'App opens'],
  ['activeMs', 'Foreground time'],
  ['watchMs', 'Reel watch time'],
];
const dayMs = 86_400_000;
const empty = Object.fromEntries(metrics.map(([key]) => [key, 0]));

function metricText(key, value) {
  if (!key.endsWith('Ms')) return number.format(value);
  const seconds = Math.floor(value / 1000);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds / 60) % 60;
  if (hours) return number.format(hours) + ' h ' + minutes + ' min';
  return minutes ? minutes + ' min ' + (seconds % 60) + ' sec' : seconds + ' sec';
}

export function setupAnalytics(api) {
  const byId = (id) => document.getElementById('analytics-' + id);
  const range = byId('range');
  const group = byId('group');
  const metric = byId('metric');
  let report;
  let loadId = 0;

  function node(tag, value, parent, className) {
    const item = document.createElement(tag);
    item.textContent = value;
    if (className) item.className = className;
    parent.append(item);
    return item;
  }

  function draw() {
    if (!report) return;
    const weekly = group.value === 'weekly';
    const data = new Map(report[group.value].map((row) => [row.label, row]));
    let first = Date.parse(report.start);
    const last = Date.parse(report.latest);
    if (weekly) first -= ((new Date(first).getUTCDay() + 6) % 7) * dayMs;
    const rows = [];
    for (let date = first; date <= last; date += (weekly ? 7 : 1) * dayMs) {
      const label = new Date(date).toISOString().slice(0, 10);
      rows.push({ ...empty, label, ...data.get(label) });
    }
    byId('period').textContent = weekly ? 'Week starting' : 'Day';
    byId('dates').textContent =
      shortDate.format(Date.parse(report.start)) + ' – ' + shortDate.format(last) + ' · IST';
    const field = metric.value;
    const peak = Math.max(1, ...rows.map((row) => row[field]));
    const chart = byId('chart');
    const table = byId('rows');
    chart.replaceChildren();
    table.replaceChildren();
    for (const [index, row] of rows.entries()) {
      const dateLabel = shortDate.format(Date.parse(row.label));
      const col = node('div', '', chart, 'analytics-column');
      col.title = dateLabel + ' · ' + metricText(field, row[field]);
      const bar = node('div', '', col, 'analytics-bar');
      bar.style.height = Math.max(row[field] ? 3 : 1, (100 * row[field]) / peak) + '%';
      if (!row[field]) bar.classList.add('empty');
      if (index === 0 || index === rows.length - 1 || (rows.length <= 31 && index % 7 === 0)) {
        node('span', dateLabel, col, 'analytics-chart-label');
      }
    }
    for (const row of rows.toReversed()) {
      const tr = node('tr', '', table);
      node('th', row.label, tr).scope = 'row';
      for (const key of ['active', 'opens', 'activeMs', 'watchMs', 'downloads', 'installs']) {
        node('td', metricText(key, row[key]), tr);
      }
    }
  }

  async function load() {
    const id = ++loadId;
    byId('status').textContent = 'Loading analytics…';
    try {
      const next = await api('/admin/analytics?days=' + range.value);
      if (id !== loadId) return;
      report = next;
      const cards = byId('kpis');
      cards.replaceChildren();
      for (const [key, label] of metrics) {
        const card = node('div', '', cards, 'analytics-kpi');
        node('h3', label, card);
        node('strong', metricText(key, report.total?.[key] || 0), card);
        if (key === 'downloads')
          node('small', number.format(report.lifetimeDownloads) + ' since tracking began', card);
        if (key === 'activeMs' && report.total?.active) {
          node(
            'small',
            metricText(key, report.total.activeMs / report.total.active) + ' per active install',
            card,
          );
        }
      }
      draw();
      byId('status').textContent = report.total
        ? ''
        : 'No activity has been reported for this period yet.';
      byId('results').hidden = false;
    } catch (error) {
      if (id === loadId) byId('status').textContent = error.message;
    }
  }

  range.addEventListener('change', load);
  group.addEventListener('change', draw);
  metric.addEventListener('change', draw);
  byId('refresh').addEventListener('click', load);
  return load;
}
