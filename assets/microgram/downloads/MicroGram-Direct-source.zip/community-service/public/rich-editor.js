const fontFamilies = {
  sans: 'system-ui, sans-serif',
  serif: 'Georgia, serif',
  mono: 'ui-monospace, monospace',
};
const hex = /^#[0-9a-f]{6}$/i;

function safeLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password ? url.href : '';
  } catch {
    return '';
  }
}

function colorHex(value) {
  if (hex.test(value)) return value;
  const rgb = /^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/.exec(value);
  return rgb
    ? '#' +
        rgb
          .slice(1)
          .map((component) => Number(component).toString(16).padStart(2, '0'))
          .join('')
    : undefined;
}

export function drawRich(block, parent) {
  if (block.align) parent.style.textAlign = block.align;
  if (!Array.isArray(block.runs) || !block.runs.length) {
    parent.append(document.createTextNode(block.text || ''));
    return;
  }
  for (const run of block.runs) {
    const href = safeLink(run.href);
    const span = document.createElement(href ? 'a' : 'span');
    span.textContent = run.text;
    if (href) {
      span.href = href;
      span.target = '_blank';
      span.rel = 'noopener noreferrer';
    }
    if (hex.test(run.color)) span.style.color = run.color;
    if (hex.test(run.highlight)) span.style.backgroundColor = run.highlight;
    if (fontFamilies[run.font]) {
      span.style.fontFamily = fontFamilies[run.font];
      span.dataset.font = run.font;
    }
    if (Number.isInteger(run.size) && run.size >= 12 && run.size <= 48)
      span.style.fontSize = run.size + 'px';
    if (run.bold) span.style.fontWeight = '700';
    if (run.italic) span.style.fontStyle = 'italic';
    span.style.textDecoration = [run.underline && 'underline', run.strike && 'line-through']
      .filter(Boolean)
      .join(' ');
    parent.append(span);
  }
}

function readRuns(editor) {
  const runs = [];
  const append = (text, marks) => {
    if (!text) return;
    const last = runs.at(-1);
    if (
      last &&
      Object.keys(marks).length === Object.keys(last).length - 1 &&
      Object.entries(marks).every(([key, value]) => last[key] === value)
    )
      last.text += text;
    else runs.push({ ...marks, text });
  };
  const walk = (node, marks) => {
    if (node.nodeType === Node.TEXT_NODE) {
      append(node.textContent, marks);
      return;
    }
    if (!(node instanceof HTMLElement)) return;
    if (node.tagName === 'BR') {
      append('\n', marks);
      return;
    }
    const next = { ...marks };
    const style = node.style;
    if (node.dataset.clear === 'true') for (const key of Object.keys(next)) delete next[key];
    if (node.tagName === 'A') {
      const href = safeLink(node.getAttribute('href'));
      if (href) next.href = href;
    }
    if (style.fontWeight === '700' || node.tagName === 'B' || node.tagName === 'STRONG')
      next.bold = true;
    else if (style.fontWeight === '400') delete next.bold;
    if (style.fontStyle === 'italic' || node.tagName === 'I' || node.tagName === 'EM')
      next.italic = true;
    else if (style.fontStyle === 'normal') delete next.italic;
    if (style.textDecoration.includes('underline')) next.underline = true;
    if (style.textDecoration.includes('line-through')) next.strike = true;
    if (node.dataset.noUnderline) delete next.underline;
    if (node.dataset.noStrike) delete next.strike;
    const color = colorHex(style.color),
      highlight = colorHex(style.backgroundColor);
    if (color) next.color = color;
    if (highlight) next.highlight = highlight;
    if (fontFamilies[node.dataset.font]) next.font = node.dataset.font;
    const size = parseInt(style.fontSize, 10);
    if (size >= 12 && size <= 48) next.size = size;
    if (node.tagName === 'DIV' && runs.length && !runs.at(-1).text.endsWith('\n'))
      append('\n', marks);
    for (const child of node.childNodes) walk(child, next);
  };
  for (const child of editor.childNodes) walk(child, {});
  return runs;
}

export function richEditor(parent, block, label, changed) {
  const field = document.createElement('div');
  field.className = 'rich-editor-field';
  const toolbar = document.createElement('div');
  toolbar.className = 'rich-toolbar';
  toolbar.setAttribute('aria-label', 'Format ' + label.toLowerCase());
  const editor = document.createElement('div');
  editor.contentEditable = 'true';
  editor.className = 'rich-input';
  editor.setAttribute('role', 'textbox');
  editor.setAttribute('aria-label', label);
  editor.setAttribute('aria-multiline', 'true');
  drawRich(block, editor);
  let lastRange;
  const remember = () => {
    const selection = window.getSelection();
    if (selection?.rangeCount && editor.contains(selection.getRangeAt(0).commonAncestorContainer))
      lastRange = selection.getRangeAt(0).cloneRange();
  };
  for (const event of ['mouseup', 'keyup', 'blur']) editor.addEventListener(event, remember);
  const update = () => {
    const runs = readRuns(editor);
    block.text = runs.map((run) => run.text).join('');
    block.runs = runs.some((run) => Object.keys(run).length > 1) ? runs : undefined;
    changed();
  };
  const apply = (mutate, tag = 'span') => {
    remember();
    const range =
      lastRange && editor.contains(lastRange.commonAncestorContainer)
        ? lastRange.cloneRange()
        : document.createRange();
    if (!lastRange || !editor.contains(range.commonAncestorContainer) || range.collapsed)
      range.selectNodeContents(editor);
    const source =
      range.startContainer.nodeType === Node.TEXT_NODE
        ? range.startContainer.parentElement
        : range.startContainer;
    const original = getComputedStyle(source);
    const wrapper = document.createElement(tag);
    mutate(wrapper, original, range);
    const contents = range.extractContents();
    if (wrapper.dataset.clear) wrapper.textContent = contents.textContent;
    else wrapper.append(contents);
    range.insertNode(wrapper);
    editor.focus();
    range.selectNodeContents(wrapper);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    remember();
    update();
  };
  const button = (text, title, action) => {
    const control = document.createElement('button');
    control.type = 'button';
    control.textContent = text;
    control.setAttribute('aria-label', title);
    control.title = title;
    control.addEventListener('mousedown', (event) => {
      remember();
      event.preventDefault();
    });
    control.onclick = action;
    toolbar.append(control);
  };
  button('B', 'Bold', () =>
    apply((node, css) => (node.style.fontWeight = Number(css.fontWeight) >= 600 ? '400' : '700')),
  );
  button('I', 'Italic', () =>
    apply((node, css) => (node.style.fontStyle = css.fontStyle === 'italic' ? 'normal' : 'italic')),
  );
  button('U', 'Underline', () =>
    apply((node, css) => {
      if (css.textDecorationLine.includes('underline')) node.dataset.noUnderline = 'true';
      else node.style.textDecoration = 'underline';
    }),
  );
  button('S', 'Strikethrough', () =>
    apply((node, css) => {
      if (css.textDecorationLine.includes('line-through')) node.dataset.noStrike = 'true';
      else node.style.textDecoration = 'line-through';
    }),
  );
  button('Link', 'Add HTTPS link', () => {
    const href = safeLink(window.prompt('Public HTTPS URL'));
    if (href)
      apply((node) => {
        node.href = href;
      }, 'a');
  });
  button('Clear', 'Clear formatting', () => apply((node) => (node.dataset.clear = 'true')));
  const select = (title, choices, change) => {
    const input = document.createElement('select');
    input.setAttribute('aria-label', title);
    for (const [value, label] of [['', title], ...choices]) input.add(new Option(label, value));
    input.addEventListener('mousedown', remember);
    input.onchange = () => {
      if (input.value) change(input.value);
      input.value = '';
    };
    toolbar.append(input);
  };
  select(
    'Font',
    Object.keys(fontFamilies).map((font) => [font, font]),
    (font) =>
      apply((node) => {
        node.dataset.font = font;
        node.style.fontFamily = fontFamilies[font];
      }),
  );
  select(
    'Size',
    [12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48].map((size) => [String(size), size + ' px']),
    (size) => apply((node) => (node.style.fontSize = size + 'px')),
  );
  select(
    'Align',
    [
      ['left', 'Left'],
      ['center', 'Center'],
      ['right', 'Right'],
    ],
    (value) => {
      block.align = value;
      editor.style.textAlign = value;
      update();
    },
  );
  for (const [title, property, initial] of [
    ['Text color', 'color', '#ff4e94'],
    ['Highlight', 'backgroundColor', '#76415a'],
  ]) {
    const name = document.createElement('label');
    name.textContent = title;
    const input = document.createElement('input');
    input.type = 'color';
    input.value = initial;
    input.addEventListener('mousedown', remember);
    input.onchange = () => apply((node) => (node.style[property] = input.value));
    name.append(input);
    toolbar.append(name);
  }
  editor.addEventListener('input', update);
  editor.addEventListener('click', (event) => {
    if (event.target.closest('a')) event.preventDefault();
  });
  const paste = (event) => {
    event.preventDefault();
    document.execCommand(
      'insertText',
      false,
      (event.clipboardData || event.dataTransfer)?.getData('text/plain') || '',
    );
  };
  editor.addEventListener('paste', paste);
  editor.addEventListener('drop', paste);
  field.append(toolbar, editor);
  parent.append(field);
}
