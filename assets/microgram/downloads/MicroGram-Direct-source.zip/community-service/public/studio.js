import { drawRich, richEditor } from './rich-editor.js';
import { setupAnalytics } from './analytics.js';
const loadAnalytics = setupAnalytics(api);
const $ = (id) => document.getElementById(id);
let feed,
  revision = '',
  selected = -1,
  dirty = false,
  before;
let publishedFeed,
  previewMode = 'live',
  counts = {},
  previewTimer;
const draftKey = 'microgram-studio-post-drafts';
let drafts = {};
try {
  drafts = JSON.parse(localStorage.getItem(draftKey)) || {};
} catch {}
function storeDrafts() {
  localStorage.setItem(draftKey, JSON.stringify(drafts));
}
function showSection(section) {
  document.querySelectorAll('[data-section]').forEach((button) => {
    button.setAttribute('aria-pressed', String(button.dataset.section === section));
  });
  $('studio').dataset.active = section;
  document.querySelectorAll('[data-view]').forEach((panel) => {
    panel.hidden = !panel.dataset.view.split(' ').includes(section);
    if (panel instanceof HTMLDetailsElement && panel.classList.contains('studio-settings'))
      panel.open = !panel.hidden;
  });
  if (section === 'comments') void run(() => comments());
  if (section === 'analytics') void loadAnalytics();
  if (section === 'sponsors' || section === 'posts') {
    previewMode = section === 'sponsors' ? 'ad' : selected >= 0 ? 'draft' : 'live';
    renderPreview();
  }
}
$('sponsor-slot').append($('ad-settings'));
document.querySelectorAll('[data-section]').forEach((button) => {
  button.onclick = () => showSection(button.dataset.section);
});
const status = (text) => {
  $('status').textContent = text;
};
async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Request failed');
  return body;
}
async function run(work) {
  try {
    await work();
  } catch (error) {
    status(error.message);
  }
}
function element(tag, text, parent) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  if (parent) parent.append(node);
  return node;
}
function safeUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'https:' && !u.username && !u.password ? u.href : '';
  } catch {
    return '';
  }
}
function previewBlock(block, parent) {
  if (block.type === 'text') {
    const copy = element('p', '', parent);
    copy.className = 'preview-copy';
    drawRich(block, copy);
  }
  if (block.type === 'heading') drawRich(block, element('h2', '', parent));
  if (block.type === 'quote') {
    const quote = element('blockquote', '', parent);
    drawRich(block, quote);
    if (block.attribution) element('cite', block.attribution, quote);
  }
  if (block.type === 'list') {
    const list = element('ul', '', parent);
    for (const item of block.items || []) element('li', item, list);
  }
  if (block.type === 'image' || block.type === 'video') {
    const source = safeUrl(block.src);
    if (!source) return;
    const figure = element('figure', '', parent);
    const media = element(block.type === 'image' ? 'img' : 'video', '', figure);
    const ratios = { square: '1', portrait: '4 / 5', wide: '16 / 9' };
    media.style.aspectRatio = ratios[block.ratio] || '';
    media.style.objectFit = block.fit || (ratios[block.ratio] ? 'cover' : 'contain');
    if (block.zoom > 1) media.style.transform = 'scale(' + Math.min(block.zoom, 2) + ')';
    media.src = source;
    if (block.type === 'image') {
      media.alt = block.alt || '';
      media.loading = 'lazy';
    } else {
      media.controls = true;
      media.loop = !!block.loop;
      media.muted = !!block.muted;
      if (safeUrl(block.poster)) media.poster = safeUrl(block.poster);
      media.preload = 'none';
      media.playsInline = true;
    }
    if (block.caption) element('figcaption', block.caption, figure);
  }
  if (block.type === 'gallery') {
    const gallery = element('div', '', parent);
    gallery.className = 'preview-gallery';
    for (const image of block.images || []) previewBlock({ ...image, type: 'image' }, gallery);
  }
  if (block.type === 'link' && safeUrl(block.url)) {
    const a = element('a', block.label, parent);
    a.href = safeUrl(block.url);
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
  }
}
function isEditorial(post) {
  return post.id.startsWith('editorial-');
}
function editorFeed(remote, fallback = []) {
  return { ...remote, posts: [...remote.posts, ...(remote.editorials ?? fallback)] };
}
function serializeFeed() {
  return {
    ...feed,
    posts: feed.posts.filter((post) => !isEditorial(post)),
    editorials: feed.posts.filter(isEditorial),
  };
}
let replyTotals = {};
const openPostPanels = new Map();
function postStatus(post) {
  const live = publishedFeed.posts.find(({ id }) => id === post.id);
  if (!live || drafts[post.id]) return 'Draft';
  if (Date.parse(live.publishedAt) > Date.now()) return 'Scheduled';
  if (live.expiresAt && Date.parse(live.expiresAt) <= Date.now()) return 'Expired';
  return 'Published';
}
function render() {
  $('posts').after($('post-form'));
  $('posts').replaceChildren();
  const search = $('post-search').value.trim().toLowerCase();
  const filter = $('post-filter').value;
  feed.posts.forEach((post, index) => {
    const state = postStatus(post);
    const excerpt = post.blocks.find(({ text }) => text)?.text ?? '';
    if (
      index !== selected &&
      ((filter && state !== filter) ||
        (search && ![post.topic, excerpt].some((value) => value.toLowerCase().includes(search))))
    )
      return;
    const row = element('section', '', $('posts'));
    row.className = 'post-row';
    const summary = element('div', '', row);
    summary.className = 'post-row-summary';
    const identity = element('div', '', summary);
    identity.className = 'post-identity';
    const image = post.blocks.find(({ type }) => ['image', 'gallery', 'video'].includes(type));
    const thumb = safeUrl(
      image?.src && image.type === 'image' ? image.src : image?.poster || image?.images?.[0]?.src,
    );
    if (thumb) {
      const img = element('img', '', identity);
      img.src = thumb;
      img.alt = '';
      img.loading = 'lazy';
    }
    const copy = element('div', '', identity);
    const button = element('button', post.topic, copy);
    button.className = 'post-title';
    button.setAttribute('aria-expanded', String(index === selected));
    button.setAttribute('aria-controls', 'post-form');
    button.onclick = () => {
      if (selected >= 0 && !savePost()) return;
      select(index === selected ? -1 : index);
    };
    element('small', excerpt || (isEditorial(post) ? 'Original post' : post.kind), copy);
    const badge = element('span', state, summary);
    badge.className = 'post-status';
    badge.dataset.status = state.toLowerCase();
    element('span', (counts[post.id] ?? 0).toLocaleString(), summary).className = 'post-views';
    const replies = element('button', '', summary);
    replies.className = 'post-comment-count';
    replies.dataset.commentPost = post.id;
    const total = replyTotals[post.id] ?? 0;
    replies.textContent = String(total);
    replies.setAttribute('aria-label', 'Comments on ' + post.topic + ' (' + total + ')');
    const actions = element('div', '', row);
    actions.className = 'post-row-actions';
    const preview = element('button', 'Preview', actions);
    const edit = element('button', index === selected ? 'Close editor' : 'Edit post', actions);
    edit.onclick = button.onclick;
    const panel = element('div', '', row);
    panel.className = 'post-detail';
    function show(mode) {
      panel.replaceChildren();
      panel.hidden = !mode;
      preview.setAttribute('aria-expanded', String(mode === 'preview'));
      replies.setAttribute('aria-expanded', String(mode === 'comments'));
      if (!mode) return;
      if (mode === 'preview') {
        const surface = element('div', '', panel);
        surface.className = 'phone-feed inline-preview';
        previewPost(index === selected ? previewDraft() : post, surface);
      } else {
        element('h3', 'Comments', panel);
        const target = element('div', '', panel);
        const more = element('button', 'Load older comments', panel);
        more.hidden = true;
        const load = commentLoader(target, more, post.id);
        more.onclick = () => void load(true);
        void load();
      }
    }
    function toggle(mode) {
      const next = openPostPanels.get(post.id) === mode ? undefined : mode;
      if (next) openPostPanels.set(post.id, next);
      else openPostPanels.delete(post.id);
      show(next);
    }
    preview.onclick = () => toggle('preview');
    replies.onclick = () => toggle('comments');
    show(openPostPanels.get(post.id));
    if (index === selected) {
      $('post-editor-title').textContent = post.topic;
      row.append($('post-form'));
    }
  });
  if (!$('posts').children.length)
    element('p', 'No matching posts.', $('posts')).className = 'empty-posts';
  renderPreview();
}
$('post-search').oninput = () => {
  if (selected < 0 || savePost()) render();
};
$('post-filter').onchange = $('post-search').oninput;
function previewEditorial(post, card) {
  const purpose = post.layout === 'purpose';
  if (!purpose && post.layout !== 'momentum') {
    for (const block of post.blocks) previewBlock(block, card);
    return;
  }
  const content = element('section', '', card);
  content.className = purpose ? 'preview-purpose' : 'preview-momentum';
  const [title, intro] = post.blocks;
  if (title) previewBlock(title, content);
  if (intro) previewBlock(intro, content);
  if (!purpose && post.blocks[2]) drawRich(post.blocks[2], element('h3', '', content));
  const steps = element('div', '', content);
  steps.className = 'preview-steps';
  const blocks = post.blocks.slice(purpose ? 2 : 3);
  let index = 0;
  for (let i = 0; i < blocks.length; i++) {
    const heading = blocks[i],
      body = blocks[i + 1];
    if (heading.type !== 'heading' || body?.type !== 'text') {
      previewBlock(heading, steps);
      continue;
    }
    const row = element('div', '', steps);
    element('span', purpose ? ['↗', '▣', '♧'][index % 3] : String(index + 1).padStart(2, '0'), row);
    const copy = element('div', '', row);
    drawRich(heading, element('h3', '', copy));
    drawRich(body, element('p', '', copy));
    index++;
    i++;
  }
  if (post.id === 'editorial-next-scroll')
    element('span', 'Start learning ↗', content).className = 'preview-start';
}
function previewPost(post, parent) {
  const card = element('article', '', parent);
  card.dataset.previewPost = post.id;
  card.className = 'preview-post';
  card.dataset.postFont = post.font || 'default';
  if (/^#[0-9a-f]{6}$/i.test(post.color || '')) card.style.setProperty('--post-color', post.color);
  const author = element('div', '', card);
  author.className = 'preview-author';
  const icon = element('img', '', author);
  icon.src = 'microgram.svg';
  icon.alt = '';
  const who = element('div', '', author);
  element('strong', 'Idraak', who);
  const byline = !post.headingPlacement || ['byline', 'both'].includes(post.headingPlacement);
  element('small', '@idraakk' + (byline && post.topic ? ' · ' + post.topic : ''), who);
  const meta =
    (post.pinned ? 'Pinned · ' : '') +
    (post.kind === 'sponsored'
      ? 'Advertisement · ' + post.sponsor
      : post.kind === 'announcement'
        ? 'Announcement'
        : 'From the creator');
  element('small', meta, card);
  if (['body', 'both'].includes(post.headingPlacement)) element('h2', post.topic, card);
  previewEditorial(post, card);
  if (post.commentsEnabled) element('small', '○  Replies', card).className = 'preview-replies';
}
function learningPreview(parent) {
  const goal = element('article', '', parent);
  element('small', 'You · Your daily goal', goal);
  element('strong', 'Daily learning goal', goal);
  element('p', 'Today · 0 / 20 min', goal);
  element('div', '', goal).className = 'preview-progress';
  const year = element('article', '', parent);
  element('small', 'You · Your learning year', year);
  element('strong', 'Your learning year', year);
  const grid = element('div', '', year);
  grid.className = 'preview-heatmap';
  for (let i = 0; i < 84; i++) element('i', '', grid);
}
function renderPreview() {
  if (!feed) return;
  clearInterval(previewTimer);
  const surface = $('preview');
  const offset = surface.scrollTop;
  let activeCard;
  surface.replaceChildren();
  for (const mode of ['live', 'draft', 'ad'])
    $('show-' + mode).setAttribute('aria-pressed', String(mode === previewMode));
  if (previewMode === 'ad') {
    renderAd(surface);
    $('preview-caption').textContent = 'Preview the sponsorship timing and skip button.';
    return;
  }
  const current = previewMode === 'live' ? publishedFeed : feed;
  const draft = previewMode === 'draft' && selected >= 0 ? previewDraft() : null;
  const now = Date.now();
  const posts = current.enabled
    ? current.posts.filter(
        (post) =>
          post.id !== draft?.id &&
          Date.parse(post.publishedAt) <= now &&
          (!post.expiresAt || Date.parse(post.expiresAt) > now),
      )
    : [];
  posts.sort(
    (a, b) =>
      Number(!!b.pinned) - Number(!!a.pinned) ||
      Date.parse(b.publishedAt) - Date.parse(a.publishedAt),
  );
  element('strong', 'microgram.', surface).className = 'preview-brand';
  element('small', 'Your lectures, one reel at a time.', surface);
  if (draft && !isEditorial(draft)) {
    previewPost(draft, surface);
    activeCard = surface.lastElementChild;
  }
  for (const post of posts.filter((post) => !isEditorial(post))) previewPost(post, surface);
  learningPreview(surface);
  for (const post of current.posts.filter(isEditorial)) {
    const displayed = draft?.id === post.id ? draft : post;
    if (
      Date.parse(displayed.publishedAt) <= now &&
      (!displayed.expiresAt || Date.parse(displayed.expiresAt) > now)
    )
      previewPost(displayed, surface);
    if (displayed === draft) {
      if (surface.lastElementChild?.dataset.previewPost !== draft.id) previewPost(draft, surface);
      activeCard = surface.lastElementChild;
    }
  }
  $('preview-caption').textContent =
    previewMode === 'live'
      ? 'Published feed for a reader seeing these posts for the first time. Learning cards use sample data.'
      : 'Preview updates as you type. The selected draft is shown as a new post.';
  surface.scrollTop = activeCard ? activeCard.offsetTop : offset;
}
function previewDraft() {
  try {
    return readPost(false);
  } catch {
    return feed.posts[selected];
  }
}
function readAd() {
  return {
    enabled: $('ad-enabled').checked,
    creativeUrl: $('ad-creative').value.trim() || undefined,
    name: $('ad-name').value.trim(),
    message: $('ad-message').value.trim(),
    video: $('ad-video').value.trim() || undefined,
    poster: $('ad-poster').value.trim() || undefined,
    url: $('ad-url').value.trim() || undefined,
    every: Number($('ad-every').value),
    duration: Number($('ad-duration').value),
    skipAfter: Number($('ad-skip').value),
  };
}
function renderAd(surface) {
  const ad = readAd();
  const slide = element('div', '', surface);
  slide.className = 'preview-ad';
  const source = safeUrl(ad.video) || safeUrl(ad.poster);
  if (source) {
    const media = element(safeUrl(ad.video) ? 'video' : 'img', '', slide);
    media.src = source;
    if (safeUrl(ad.video)) {
      media.muted = true;
      media.autoplay = true;
      media.playsInline = true;
      if (safeUrl(ad.poster)) media.poster = safeUrl(ad.poster);
    } else media.alt = '';
  }
  const header = element('header', '', slide);
  element('span', 'Sponsored · ' + (ad.name || 'Sponsor name'), header);
  const skip = element('button', 'Skip ad', header);
  const footer = element('footer', '', slide);
  element('p', ad.message || 'Your sponsorship message', footer);
  if (safeUrl(ad.url)) element('span', 'Learn more', footer);
  const started = Date.now();
  const finish = () => {
    clearInterval(previewTimer);
    slide.replaceChildren(element('p', 'Ad finished · the next reel resumes here.'));
  };
  const tick = () => {
    const elapsed = Math.floor((Date.now() - started) / 1000);
    if (elapsed >= Math.max(1, ad.duration)) return finish();
    skip.disabled = elapsed < ad.skipAfter;
    skip.textContent = skip.disabled ? 'Skip in ' + (ad.skipAfter - elapsed) + 's' : 'Skip ad';
  };
  skip.onclick = finish;
  tick();
  previewTimer = setInterval(tick, 200);
}
function checkoutAddress() {
  const field = $('access-checkout');
  const input = field.value.trim();
  if (!input) return undefined;
  try {
    const url = new URL(input.includes('://') ? input : 'https://' + input);
    if (
      url.protocol === 'https:' &&
      !url.username &&
      !url.password &&
      url.hostname.includes('.') &&
      !url.hostname.endsWith('.localhost') &&
      !url.hostname.endsWith('.local')
    )
      return url.href;
  } catch {
    /* Checked before publishing when membership is active. */
  }
  return undefined;
}
function readRelease() {
  if (!$('release-enabled').checked) return undefined;
  return {
    versionCode: Number($('release-code').value),
    versionName: $('release-version').value.trim(),
    url: $('release-url').value.trim(),
    required: $('release-required').checked,
    title: $('release-title-input').value.trim() || 'Update MicroGram',
    message: $('release-message').value.trim() || 'Install the latest version to continue.',
  };
}
function renderReleasePreview() {
  const release = readRelease();
  $('release-preview-title').textContent = release?.title || 'Update MicroGram';
  $('release-preview-message').textContent = release?.message || 'The update prompt is off.';
  $('release-preview-action').textContent = !release
    ? ''
    : release.required
      ? 'Get the update · Required'
      : 'Get the update · Not now';
}
function readAccess() {
  return {
    mode: $('access-mode').value,
    title: $('access-title').value.trim() || 'MicroGram access',
    message:
      $('access-message').value.trim() || 'Enter an access code to continue using MicroGram.',
    checkout: checkoutAddress(),
    checkoutLabel: $('access-checkout-label').value.trim() || undefined,
    notice: $('access-notice').value.trim() || undefined,
    release: readRelease(),
  };
}
function renderAccessPreview() {
  const policy = readAccess();
  $('access-preview-title').textContent =
    policy.mode === 'free' ? 'MicroGram is open' : policy.title;
  $('access-preview-message').textContent =
    policy.mode === 'free' ? policy.notice || 'Everyone can use the app.' : policy.message;
}
async function loadPasses() {
  const data = await api('/admin/access-passes');
  const target = $('access-passes');
  target.replaceChildren();
  if (!data.passes.length) element('p', 'No access codes issued yet.', target);
  for (const pass of data.passes) {
    const row = element('article', '', target);
    element('strong', pass.label, row);
    const label = pass.revoked
      ? 'Revoked'
      : pass.expires_at
        ? 'Expires ' + new Date(pass.expires_at).toLocaleDateString()
        : 'Awaiting redemption';
    element('p', pass.days + ' days · ' + label, row);
    if (!pass.revoked) {
      const revoke = element('button', 'Revoke access', row);
      revoke.onclick = () => {
        if (confirm('Revoke this code and any access it granted?'))
          void run(async () => {
            await api('/admin/access-passes/' + pass.id, { method: 'DELETE' });
            await loadPasses();
          });
      };
    }
  }
}
$('load-passes').onclick = () => void run(loadPasses);
$('issue-pass').onclick = () =>
  void run(async () => {
    const issue = $('issue-pass');
    issue.disabled = true;
    try {
      const result = await api('/admin/access-passes', {
        method: 'POST',
        body: JSON.stringify({ label: $('pass-label').value, days: Number($('pass-days').value) }),
      });
      $('issued-code').value = result.code;
      $('issued-pass').hidden = false;
      await loadPasses();
    } finally {
      issue.disabled = false;
    }
  });
$('copy-pass').onclick = () =>
  void run(async () => {
    await navigator.clipboard.writeText($('issued-code').value);
    status('Access code copied.');
  });
function fillConfig() {
  $('enabled').checked = feed.enabled;
  $('feedback-enabled').checked = feed.feedbackEnabled;
  const policy = feed.access;
  $('access-mode').value = policy?.mode || 'free';
  $('access-title').value = policy?.title || '';
  $('access-message').value = policy?.message || '';
  $('access-checkout').value = policy?.checkout || '';
  $('access-checkout-label').value = policy?.checkoutLabel || '';
  $('access-notice').value = policy?.notice || '';
  renderAccessPreview();
  const release = policy?.release;
  $('release-enabled').checked = !!release;
  $('release-required').checked = !!release?.required;
  $('release-code').value = release?.versionCode ?? '';
  $('release-version').value = release?.versionName || '';
  $('release-url').value = release?.url || '';
  $('release-title-input').value = release?.title || '';
  $('release-message').value = release?.message || '';
  renderReleasePreview();
  const ad = feed.reelAd;
  $('ad-creative').value = ad?.creativeUrl || '';
  $('ad-enabled').checked = !!ad?.enabled;
  for (const field of ['name', 'message', 'video', 'poster', 'url'])
    $('ad-' + field).value = ad?.[field] || '';
  $('ad-every').value = ad?.every ?? 10;
  $('ad-duration').value = ad?.duration ?? 10;
  $('ad-skip').value = ad?.skipAfter ?? 0;
}
function dateInput(value) {
  if (!value) return '';
  const date = new Date(value);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}
function renderBlockEditor() {
  const advanced = $('advanced').checked;
  const target = $('friendly-blocks');
  target.hidden = !advanced;
  $('simple-content').hidden = advanced;
  target.replaceChildren();
  if (!advanced) return;
  let blocks;
  try {
    blocks = JSON.parse($('blocks').value);
  } catch {
    return;
  }
  if (!Array.isArray(blocks)) return;
  const fields = {
    heading: [['text', 'Heading']],
    text: [['text', 'Paragraph']],
    quote: [
      ['text', 'Quote'],
      ['attribution', 'Attribution'],
    ],
    image: [
      ['src', 'Image URL'],
      ['alt', 'Image description'],
      ['caption', 'Caption'],
    ],
    video: [
      ['src', 'Video URL'],
      ['poster', 'Thumbnail URL'],
      ['caption', 'Caption'],
    ],
    link: [
      ['label', 'Link text'],
      ['url', 'Link URL'],
      ['description', 'Description'],
    ],
    list: [['items', 'List items, one per line']],
  };
  const update = () => {
    $('blocks').value = JSON.stringify(blocks, null, 2);
  };
  const structuralChange = () => {
    update();
    dirty = true;
    renderBlockEditor();
    renderPreview();
  };
  blocks.forEach((block, index) => {
    if (!block || typeof block.type !== 'string') return;
    const group = element('fieldset', '', target);
    element('legend', 'Block ' + (index + 1) + ' · ' + block.type, group);
    for (const [key, title] of fields[block.type] || []) {
      if (key === 'text') {
        richEditor(group, block, title, () => {
          update();
          dirty = true;
          renderPreview();
        });
        continue;
      }
      const label = element('label', title, group);
      const input = element(key === 'text' || key === 'items' ? 'textarea' : 'input', '', label);
      if (key === 'text' || key === 'items') input.rows = 2;
      input.value = Array.isArray(block[key]) ? block[key].join('\n') : block[key] || '';
      input.addEventListener('input', () => {
        block[key] =
          key === 'items' ? input.value.split('\n').filter((line) => line.trim()) : input.value;
        update();
      });
    }
    if (!fields[block.type]) element('p', 'Edit this block in Advanced blocks below.', group);
    const remove = element('button', 'Remove block', group);
    remove.type = 'button';
    remove.onclick = () => {
      blocks.splice(index, 1);
      structuralChange();
    };
  });
  for (const [type, label] of [
    ['heading', 'Add heading'],
    ['text', 'Add paragraph'],
    ['quote', 'Add quote'],
    ['list', 'Add list'],
  ]) {
    const add = element('button', label, target);
    add.type = 'button';
    add.onclick = () => {
      blocks.push(
        type === 'list'
          ? { type, items: ['New list item'] }
          : {
              type,
              text:
                type === 'heading'
                  ? 'New heading'
                  : type === 'quote'
                    ? 'New quote'
                    : 'New paragraph',
            },
      );
      structuralChange();
    };
  }
}
$('use-rich-editor').onclick = () => {
  if (selected < 0) return;
  try {
    $('blocks').value = JSON.stringify(
      readPost(false).blocks.length
        ? readPost(false).blocks
        : [{ type: 'text', text: 'Write your post here.' }],
      null,
      2,
    );
    $('advanced').checked = true;
    dirty = true;
    renderBlockEditor();
    renderPreview();
  } catch (error) {
    status(error.message);
  }
};
$('advanced').addEventListener('change', renderBlockEditor);
$('blocks').addEventListener('input', renderBlockEditor);
function select(index) {
  selected = index;
  if (index >= 0) previewMode = 'draft';
  const p = feed.posts[index];
  $('post-form').hidden = !p;
  if (!p) {
    render();
    return;
  }
  $('topic').value = p.topic;
  $('heading-placement').value = p.headingPlacement || 'byline';
  $('post-layout').value = p.layout || 'standard';
  $('post-font').value = p.font || 'default';
  $('post-color').value = p.color || '#f3f5f7';
  $('kind').value = p.kind;
  $('sponsor').value = p.sponsor || '';
  $('date').value = dateInput(p.publishedAt);
  $('expires').value = dateInput(p.expiresAt);
  $('pinned').checked = p.pinned;
  $('post-comments').checked = p.commentsEnabled === true;
  $('message').value = p.blocks
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('\n\n');
  const media = p.blocks.find((b) => ['image', 'video'].includes(b.type));
  $('media').value = media?.src || '';
  $('media-type').value = media?.type || 'image';
  $('media-ratio').value = media?.ratio || 'original';
  $('media-fit').value = media?.fit || 'auto';
  $('media-zoom').value = media?.zoom || 1;
  $('zoom-value').textContent = Math.round(Number($('media-zoom').value) * 100) + '%';
  $('media-poster').value = media?.poster || '';
  $('media-loop').checked = !!media?.loop;
  $('media-muted').checked = !!media?.muted;
  $('caption').value = media?.caption || media?.alt || '';
  const link = p.blocks.find((b) => b.type === 'link');
  $('link-label').value = link?.label || '';
  $('link-url').value = link?.url || '';
  // Preserve all existing block types/order unless the author deliberately chooses simple fields.
  $('advanced').checked =
    p.blocks.some(
      (b) => b.runs?.length || b.align || !['text', 'image', 'video', 'link'].includes(b.type),
    ) ||
    p.blocks.filter((b) => ['image', 'video'].includes(b.type)).length > 1 ||
    p.blocks.filter((b) => b.type === 'link').length > 1 ||
    p.blocks.some((b) => b.description || (b.type === 'image' && b.alt !== (b.caption || b.alt)));
  $('blocks').value = JSON.stringify(p.blocks, null, 2);
  renderBlockEditor();
  render();
}
function readPost(strict = true) {
  let blocks;
  if ($('advanced').checked) {
    blocks = JSON.parse($('blocks').value);
    if (!Array.isArray(blocks) || !blocks.length)
      throw new Error('Add at least one content block.');
  } else {
    blocks = $('message')
      .value.split(/\n\s*\n/)
      .filter((text) => text.trim())
      .map((text) => ({ type: 'text', text }));
    if ($('media').value) {
      const type = $('media-type').value;
      blocks.push({
        type,
        src: $('media').value,
        ratio: $('media-ratio').value,
        fit: $('media-fit').value === 'auto' ? undefined : $('media-fit').value,
        zoom: Number($('media-zoom').value),
        caption: $('caption').value,
        ...(type === 'image'
          ? { alt: $('caption').value }
          : {
              poster: $('media-poster').value || undefined,
              loop: $('media-loop').checked,
              muted: $('media-muted').checked,
            }),
      });
    }
    if ($('link-url').value)
      blocks.push({
        type: 'link',
        url: $('link-url').value,
        label: $('link-label').value || 'Learn more',
      });
    if (strict && !blocks.length) throw new Error('Write a message or add media.');
  }
  return {
    ...feed.posts[selected],
    topic: $('topic').value,
    kind: $('kind').value,
    headingPlacement: $('heading-placement').value,
    layout: $('post-layout').value,
    font: $('post-font').value,
    color:
      $('post-color').value === '#f3f5f7' && !feed.posts[selected].color
        ? undefined
        : $('post-color').value,
    sponsor: $('sponsor').value || undefined,
    pinned: $('pinned').checked,
    commentsEnabled: $('post-comments').checked,
    publishedAt:
      $('date').value && $('date').value !== dateInput(feed.posts[selected].publishedAt)
        ? new Date($('date').value).toISOString()
        : feed.posts[selected].publishedAt,
    expiresAt: $('expires').value ? new Date($('expires').value).toISOString() : undefined,
    blocks,
  };
}
function savePost() {
  try {
    if (selected < 0) return true;
    if (!$('post-form').reportValidity()) return false;
    const post = readPost();
    if (
      JSON.stringify(post) !== JSON.stringify(feed.posts[selected]) ||
      !publishedFeed.posts.some(({ id }) => id === post.id)
    ) {
      feed.posts[selected] = post;
      drafts[post.id] = post;
      storeDrafts();
    }
    return true;
  } catch (error) {
    status(error.message);
    return false;
  }
}
function captureConfig() {
  feed.enabled = $('enabled').checked;
  feed.feedbackEnabled = $('feedback-enabled').checked;
  const policy = readAccess();
  if (policy.mode === 'membership' && $('access-checkout').value.trim() && !policy.checkout) {
    $('access-settings').open = true;
    $('access-checkout').focus();
    throw new Error(
      'Checkout URL: enter a public HTTPS address such as https://example.com/checkout, or leave it blank.',
    );
  }
  if (
    policy.release &&
    (!Number.isInteger(policy.release.versionCode) ||
      policy.release.versionCode < 1 ||
      !policy.release.versionName ||
      !safeUrl(policy.release.url))
  ) {
    $('release-settings').open = true;
    throw new Error(
      'Android updates: enter the APK version code, display version and public HTTPS tester link.',
    );
  }
  feed.access = policy;
  const ad = readAd();
  feed.reelAd =
    ad.enabled || ad.name || ad.message || ad.video || ad.poster || ad.creativeUrl ? ad : undefined;
}
async function load() {
  feed = editorFeed(await api('/admin/feed'));
  publishedFeed = structuredClone(feed);
  feed.posts = [
    ...Object.values(drafts).filter(({ id }) => !feed.posts.some((post) => post.id === id)),
    ...feed.posts.map((post) => drafts[post.id] || post),
  ];
  fillConfig();
  revision = feed.revision;
  selected = -1;
  dirty = false;
  $('post-form').hidden = true;
  render();
  status('Published content loaded.');
  void api('/admin/engagement')
    .then(({ views, totals }) => {
      replyTotals = Object.fromEntries(
        (totals || []).map(({ post_id, count }) => [post_id, count]),
      );
      counts = Object.fromEntries(views.map(({ post_id, count }) => [post_id, count]));
      if (feed) render();
    })
    .catch(() => {});
}
async function openStudio() {
  await load();
  $('studio-password').value = '';
  $('login').hidden = true;
  $('studio').hidden = false;
  $('logout').hidden = false;
  showSection('posts');
}
$('login').onsubmit = (event) => {
  event.preventDefault();
  void run(async () => {
    await api('/studio-auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: $('studio-username').value.trim(),
        password: $('studio-password').value,
      }),
    });
    await openStudio();
  });
};
void api('/studio-auth/status')
  .then(({ authenticated }) => {
    if (authenticated && $('studio').hidden) void run(openStudio);
  })
  .catch(() => {});
$('logout').onclick = () => {
  if (dirty && !confirm('Discard unpublished changes and sign out?')) return;
  void run(async () => {
    await api('/studio-auth/logout', { method: 'POST' });
    dirty = false;
    location.reload();
  });
};
$('load').onclick = () => {
  if (!dirty || confirm('Discard your unpublished draft and reload?')) void run(load);
};
$('add').onclick = () => {
  if (selected >= 0 && !savePost()) return;
  feed.posts.unshift({
    id: crypto.randomUUID(),
    kind: 'post',
    topic: 'New post',
    publishedAt: new Date().toISOString(),
    pinned: false,
    commentsEnabled: false,
    blocks: [{ type: 'text', text: 'Write your message here.' }],
  });
  dirty = true;
  select(0);
  $('topic').focus({ preventScroll: true });
};
$('post-form').onsubmit = (event) => {
  event.preventDefault();
  if (savePost()) {
    render();
    status('Post saved to draft. Publish when ready.');
  }
};
let publishing = false;
async function publishCandidate(candidate) {
  if (publishing) throw new Error('A publication is already in progress.');
  publishing = true;
  try {
    const remote = await api('/admin/feed', {
      method: 'PUT',
      headers: { 'If-Match': revision },
      body: JSON.stringify({
        ...candidate,
        posts: candidate.posts.filter((post) => !isEditorial(post)),
        editorials: candidate.posts.filter(isEditorial),
      }),
    });
    publishedFeed = editorFeed(remote, candidate.posts.filter(isEditorial));
    revision = publishedFeed.revision;
    feed.revision = revision;
  } finally {
    publishing = false;
  }
}
$('publish-post').onclick = () =>
  void run(async () => {
    if (!savePost() || selected < 0) return;
    const post = feed.posts[selected];
    const posts = publishedFeed.posts.some(({ id }) => id === post.id)
      ? publishedFeed.posts.map((entry) => (entry.id === post.id ? post : entry))
      : [...publishedFeed.posts, post];
    await publishCandidate({ ...publishedFeed, posts });
    if (drafts[post.id] === post) {
      delete drafts[post.id];
      storeDrafts();
    }
    render();
    status('Published: ' + post.topic);
  });
$('delete').onclick = () =>
  void run(async () => {
    const post = feed.posts[selected];
    if (!post || !confirm('Delete "' + post.topic + '"?')) return;
    if (publishedFeed.posts.some(({ id }) => id === post.id))
      await publishCandidate({
        ...publishedFeed,
        posts: publishedFeed.posts.filter(({ id }) => id !== post.id),
      });
    delete drafts[post.id];
    storeDrafts();
    feed.posts = feed.posts.filter(({ id }) => id !== post.id);
    select(-1);
    status('Post deleted.');
  });
$('publish').onclick = () =>
  void run(async () => {
    const { enabled, feedbackEnabled } = {
      enabled: $('enabled').checked,
      feedbackEnabled: $('feedback-enabled').checked,
    };
    await publishCandidate({ ...publishedFeed, enabled, feedbackEnabled });
    Object.assign(feed, { enabled, feedbackEnabled });
    renderPreview();
    status('Feed settings published.');
  });
document.querySelectorAll('[data-publish]').forEach((button) => {
  button.onclick = () =>
    void run(async () => {
      const scope = button.dataset.publish;
      const candidate = structuredClone(publishedFeed);
      if (scope === 'sponsors') {
        const ad = readAd();
        candidate.reelAd =
          ad.enabled || ad.name || ad.message || ad.video || ad.poster || ad.creativeUrl
            ? ad
            : undefined;
      } else if (scope === 'access') {
        const { release, ...policy } = readAccess();
        if (policy.mode === 'membership' && $('access-checkout').value.trim() && !policy.checkout)
          throw new Error('Enter a public HTTPS checkout address or leave it blank.');
        candidate.access = { ...policy, release: publishedFeed.access?.release };
      } else {
        const release = readRelease();
        if (
          release &&
          (!Number.isInteger(release.versionCode) ||
            release.versionCode < 1 ||
            !release.versionName ||
            !safeUrl(release.url))
        )
          throw new Error('Enter the APK build number, display version, and public HTTPS URL.');
        if (release?.required && !confirm('Require readers on older builds to update?')) return;
        candidate.access = { ...(publishedFeed.access || { mode: 'free' }), release };
      }
      await publishCandidate(candidate);
      status('Settings published.');
    });
});
$('export').onclick = () =>
  void run(async () => {
    if (!savePost()) return;
    captureConfig();
    const a = document.createElement('a');
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(serializeFeed(), null, 2)], { type: 'application/json' }),
    );
    a.href = url;
    a.download = 'microgram-feed-backup.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
$('import').onchange = () =>
  void run(async () => {
    const file = $('import').files[0];
    if (!file) return;
    if (file.size > 262144) throw new Error('Draft must be smaller than 256 KB.');
    const draft = JSON.parse(await file.text());
    if (draft.version !== 1 || !Array.isArray(draft.posts) || draft.posts.length > 50)
      throw new Error('Invalid version 1 feed');
    if (dirty && !confirm('Replace this draft with the imported file?')) return;
    feed = editorFeed(draft, publishedFeed.posts.filter(isEditorial));
    drafts = Object.fromEntries(feed.posts.map((post) => [post.id, post]));
    storeDrafts();
    fillConfig();
    dirty = true;
    select(-1);
    status('Draft imported. Server validation runs before publication.');
  });
async function messages(older = false) {
  const rows = await api('/admin/feedback' + (older && before ? `?before=${before}` : ''));
  if (!older) $('messages').replaceChildren();
  if (!rows.length && !older) element('p', 'No messages yet.', $('messages'));
  for (const row of rows) {
    const article = element('article', '', $('messages'));
    element('small', `${row.category} · ${new Date(row.created_at).toLocaleString()}`, article);
    element('p', row.message, article);
    if (row.reply_to) element('p', `Reply to: ${row.reply_to}`, article);
    const remove = element('button', 'Delete message', article);
    remove.onclick = () => {
      if (confirm('Permanently delete this message?'))
        void run(async () => {
          await api(`/admin/feedback/${encodeURIComponent(row.id)}`, { method: 'DELETE' });
          article.remove();
        });
    };
  }
  before = rows.at(-1)?.created_at;
  $('older').hidden = rows.length < 100;
  status(`Loaded ${rows.length} messages. These messages were sent privately.`);
}
$('feedback').onclick = () => void run(() => messages());
$('older').onclick = () => void run(() => messages(true));
$('studio').addEventListener('input', (event) => {
  if (event.target.closest('.post-index-tools')) return;
  dirty = true;
  renderAccessPreview();
  renderReleasePreview();
  $('zoom-value').textContent = Math.round(Number($('media-zoom').value) * 100) + '%';
  if (previewMode !== 'live') renderPreview();
});
for (const mode of ['live', 'draft', 'ad'])
  $('show-' + mode).onclick = () => {
    previewMode = mode;
    renderPreview();
  };
$('test-ad').onclick = () => {
  previewMode = 'ad';
  renderPreview();
  $('show-ad').scrollIntoView({ block: 'nearest' });
};
function commentLoader(target, more, postId) {
  let cursor;
  let loading = false;
  async function loadComments(older = false) {
    if (loading) return;
    loading = true;
    more.disabled = true;
    if (!older) target.replaceChildren(element('p', 'Loading comments…'));
    try {
      const query = new URLSearchParams();
      if (postId) query.set('post', postId);
      if (older && cursor) query.set('cursor', cursor);
      const activity = await api('/admin/engagement?' + query);
      if (!older) target.replaceChildren();
      if (!older && !activity.comments.length) element('p', 'No public replies yet.', target);
      for (const row of activity.comments) {
        const entry = element('article', '', target);
        const heading = element('div', '', entry);
        heading.className = 'comment-heading';
        const person = element('div', '', heading);
        element('strong', row.name + (row.username ? ' @' + row.username : ''), person);
        const post = publishedFeed.posts.find(({ id }) => id === row.post_id);
        element(
          'small',
          [postId ? '' : post?.topic || 'Removed post', new Date(row.created_at).toLocaleString()]
            .filter(Boolean)
            .join(' · '),
          person,
        );
        element('p', row.message, entry);
        element('button', 'Delete comment', heading).onclick = () => {
          if (confirm('Delete this public comment?'))
            void run(async () => {
              await api('/admin/comments/' + encodeURIComponent(row.id), { method: 'DELETE' });
              entry.remove();
              replyTotals[row.post_id] = Math.max(0, (replyTotals[row.post_id] || 0) - 1);
              const count = document.querySelector(
                '[data-comment-post="' + CSS.escape(row.post_id) + '"]',
              );
              if (count) {
                count.textContent = String(replyTotals[row.post_id]);
                count.setAttribute(
                  'aria-label',
                  'Comments on ' + (post?.topic || 'post') + ' (' + replyTotals[row.post_id] + ')',
                );
              }
              if (!target.children.length && !cursor)
                element('p', 'No public replies yet.', target);
            });
        };
      }
      cursor = activity.nextCursor;
      more.hidden = !cursor;
    } catch (error) {
      if (!older) target.replaceChildren();
      const retry = element('button', 'Retry loading comments', target);
      retry.onclick = () => {
        retry.remove();
        void loadComments(older);
      };
      retry.title = error.message;
    } finally {
      loading = false;
      more.disabled = false;
    }
  }
  return loadComments;
}
const comments = commentLoader($('post-activity'), $('older-comments'));
$('engagement').onclick = () => void comments();
$('older-comments').onclick = () => void comments(true);
window.addEventListener('beforeunload', (event) => {
  if (dirty) {
    event.preventDefault();
    event.returnValue = '';
  }
});
