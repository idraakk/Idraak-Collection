CREATE TABLE IF NOT EXISTS content (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  revision TEXT NOT NULL,
  body TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL,
  category TEXT NOT NULL,
  message TEXT NOT NULL,
  reply_to TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS feedback_created ON feedback(created_at);
