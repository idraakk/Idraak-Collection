import type { Environment } from './worker';

const sessionCookie = '__Host-mg_studio';
const sessionSeconds = 12 * 3600;
const username = 'idraakk';

function cookie(request: Request) {
  return request.headers
    .get('Cookie')
    ?.split(';')
    .map((part) => part.trim())
    .find((part) => part.startsWith(sessionCookie + '='))
    ?.slice(sessionCookie.length + 1);
}
function encode(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes), (value) => value.toString(16).padStart(2, '0')).join('');
}
async function key(secret: string) {
  return crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify'],
  );
}
async function makeTicket(secret: string) {
  const body = [Math.floor(Date.now() / 1000) + sessionSeconds, crypto.randomUUID()].join('.');
  return (
    body +
    '.' +
    encode(await crypto.subtle.sign('HMAC', await key(secret), new TextEncoder().encode(body)))
  );
}
export async function studioSession(request: Request, secret?: string) {
  const value = cookie(request);
  if (!value || !secret || secret.length < 32) return false;
  const match = /^(\d{10})\.([a-f0-9-]{36})\.([a-f0-9]{64})$/.exec(value);
  if (!match || Number(match[1]) <= Date.now() / 1000) return false;
  const signature = Uint8Array.from(match[3].match(/../g)!, (byte) => parseInt(byte, 16));
  return crypto.subtle.verify(
    'HMAC',
    await key(secret),
    signature,
    new TextEncoder().encode(value.slice(0, -65)),
  );
}
async function matchesPassword(value: string, expected: string) {
  const digest = async (input: string) =>
    new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input)));
  const [a, b] = await Promise.all([digest(value), digest(expected)]);
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a[i] ^ b[i];
  return difference === 0;
}
export async function studioAuth(
  request: Request,
  env: Environment,
  json: (value: unknown, status?: number) => Response,
  readJson: (request: Request, limit: number) => Promise<unknown>,
) {
  const url = new URL(request.url);
  const action = url.pathname;
  if (action === '/studio-auth/status' && request.method === 'GET') {
    return json({ authenticated: await studioSession(request, env.STUDIO_SESSION_SECRET) });
  }
  if (request.method !== 'POST' || request.headers.get('Origin') !== url.origin)
    return json({ error: 'Open MicroGram Studio directly.' }, 403);
  function withCookie(value: string, seconds: number) {
    const response = json({ ok: true });
    response.headers.append(
      'Set-Cookie',
      sessionCookie +
        '=' +
        value +
        '; Max-Age=' +
        seconds +
        '; Path=/; Secure; HttpOnly; SameSite=Strict',
    );
    return response;
  }
  if (action === '/studio-auth/login') {
    const ip = request.headers.get('CF-Connecting-IP') || 'local';
    if (!(await env.LIMITER.limit({ key: 'studio-login:' + ip })).success)
      return json({ error: 'Too many attempts. Try again in a minute.' }, 429);
    if (!env.STUDIO_PASSWORD || !env.STUDIO_SESSION_SECRET || env.STUDIO_SESSION_SECRET.length < 32)
      return json({ error: 'Studio sign-in is unavailable.' }, 503);
    const form = (await readJson(request, 512)) as {
      username?: unknown;
      password?: unknown;
    } | null;
    if (
      form?.username !== username ||
      typeof form.password !== 'string' ||
      !(await matchesPassword(form.password, env.STUDIO_PASSWORD))
    )
      return json({ error: 'Incorrect username or password.' }, 401);
    return withCookie(await makeTicket(env.STUDIO_SESSION_SECRET), sessionSeconds);
  }
  if (action === '/studio-auth/logout') return withCookie('', 0);
  return json({ error: 'Not found.' }, 404);
}
