import { accessRoute } from './access';
import { studioAuth, studioSession } from './studio-auth';
import { engagement } from './engagement';
import { analytics } from './analytics';
import { archivePosts, emptyFeed, feedbackSchema, feedSchema } from '../src/community/schema';

interface Statement {
  bind(...values: unknown[]): Statement;
  first<T>(): Promise<T | null>;
  all<T>(): Promise<{ results: T[] }>;
  run(): Promise<{ meta: { changes?: number } }>;
}
export interface Environment {
  DB: { prepare(sql: string): Statement; batch(statements: Statement[]): Promise<unknown> };
  ASSETS: { fetch(request: Request): Promise<Response> };
  LIMITER: { limit(options: { key: string }): Promise<{ success: boolean }> };
  ANALYTICS_LIMITER: Environment['LIMITER'];
  STUDIO_PASSWORD?: string;
  STUDIO_SESSION_SECRET?: string;
  ALLOWED_ORIGINS: string;
}
const MAX = 256 * 1024;
async function readJson(request: Request, limit: number) {
  const reader = request.body?.getReader();
  if (!reader) throw new Error('Missing body');
  let size = 0,
    body = '';
  const decoder = new TextDecoder();
  try {
    while (true) {
      const result = await reader.read();
      if (result.done) break;
      size += result.value.byteLength;
      if (size > limit) throw new Error('Request is too large');
      body += decoder.decode(result.value, { stream: true });
    }
    return JSON.parse(body + decoder.decode());
  } finally {
    await reader.cancel().catch(() => {});
  }
}
export default {
  async fetch(request: Request, env: Environment, ctx: { waitUntil(promise: Promise<unknown>): void }): Promise<Response> {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin');
    const allowed =
      !origin || origin === url.origin || (env.ALLOWED_ORIGINS || '').split(',').includes(origin);
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store',
      Vary: 'Origin',
      ...(origin && allowed ? { 'Access-Control-Allow-Origin': origin } : {}),
    };
    const json = (value: unknown, status = 200) =>
      new Response(JSON.stringify(value), { status, headers });
    if (
      !['/feed', '/feedback'].includes(url.pathname) &&
      !url.pathname.startsWith('/admin/') &&
      !url.pathname.startsWith('/posts/') &&
      !url.pathname.startsWith('/studio-auth/') &&
      !url.pathname.startsWith('/analytics/') &&
      !['/access', '/access/redeem', '/download/android'].includes(url.pathname)
    )
      return env.ASSETS.fetch(request);
    if (!allowed) return json({ error: 'Origin not allowed' }, 403);
    if (request.method === 'OPTIONS')
      return new Response(null, {
        status: 204,
        headers: {
          ...headers,
          'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization, If-Match',
          ...(url.pathname === '/analytics/sessions' ? { 'Access-Control-Max-Age': '600' } : {}),
        },
      });
    try {
      if (url.pathname.startsWith('/studio-auth/'))
        return await studioAuth(request, env, json, readJson);
      if (url.pathname.startsWith('/admin/')) {
        const trustedOrigin = origin === url.origin || (!origin && request.method === 'GET');
        if (!trustedOrigin || !(await studioSession(request, env.STUDIO_SESSION_SECRET)))
          return json({ error: 'Sign in to MicroGram Studio.' }, 401);
      }
      const report = await analytics(request, env, ctx, json, readJson);
      if (report) return report;
      const access = await accessRoute(request, env, json, readJson);
      if (access) return access;
      const social = await engagement(request, env, json, readJson);
      if (social) return social;
      if (
        request.method === 'GET' &&
        (url.pathname === '/feed' || url.pathname === '/admin/feed')
      ) {
        const row = await env.DB.prepare('SELECT body FROM content WHERE id = 1').first<{
          body: string;
        }>();
        const feed = row ? feedSchema.parse(JSON.parse(row.body)) : emptyFeed;
        return json(
          url.pathname === '/admin/feed' ? { ...feed, editorials: archivePosts(feed) } : feed,
        );
      }
      if (request.method === 'PUT' && url.pathname === '/admin/feed') {
        const parsed = feedSchema.safeParse(await readJson(request, MAX));
        if (!parsed.success)
          return json(
            {
              error: parsed.error.issues
                .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
                .join('; '),
            },
            400,
          );
        const expected = request.headers.get('If-Match');
        if (!expected) return json({ error: 'Load the current feed before publishing' }, 428);
        const next = { ...parsed.data, revision: crypto.randomUUID() };
        const body = JSON.stringify(next);
        if (new TextEncoder().encode(body).byteLength > MAX)
          return json({ error: 'Published feed must be smaller than 256 KiB' }, 400);
        // Compare-and-swap avoids overwriting another browser's newer publication.
        const result =
          expected === 'empty'
            ? await env.DB.prepare(
                'INSERT INTO content (id, revision, body) VALUES (1, ?, ?) ON CONFLICT(id) DO NOTHING',
              )
                .bind(next.revision, body)
                .run()
            : await env.DB.prepare(
                'UPDATE content SET revision = ?, body = ? WHERE id = 1 AND revision = ?',
              )
                .bind(next.revision, body, expected)
                .run();
        if (!result.meta.changes)
          return json(
            {
              error: 'Someone published a newer version. Export your draft, reload, and merge it.',
            },
            409,
          );
        return json(next);
      }
      if (request.method === 'POST' && url.pathname === '/feedback') {
        if (
          !(
            await env.LIMITER.limit({
              key: `feedback:${request.headers.get('CF-Connecting-IP') || 'unknown'}`,
            })
          ).success
        )
          return json({ error: 'Please wait a minute before sending again' }, 429);
        const row = await env.DB.prepare('SELECT body FROM content WHERE id = 1').first<{
          body: string;
        }>();
        const config = row && feedSchema.safeParse(JSON.parse(row.body));
        if (!config || !config.success || !config.data.enabled || !config.data.feedbackEnabled)
          return json({ error: 'Feedback is not open right now' }, 503);
        const parsed = feedbackSchema.safeParse(await readJson(request, 12000));
        if (!parsed.success) return json({ error: 'Check your message' }, 400);
        if (parsed.data.website) return json({ ok: true });
        await env.DB.prepare(
          'INSERT INTO feedback (id, created_at, category, message, reply_to) VALUES (?, ?, ?, ?, ?)',
        )
          .bind(
            crypto.randomUUID(),
            Date.now(),
            parsed.data.category,
            parsed.data.message,
            parsed.data.replyTo,
          )
          .run();
        return json({ ok: true }, 201);
      }
      if (request.method === 'GET' && url.pathname === '/admin/feedback') {
        const before = Number(url.searchParams.get('before')) || Date.now() + 1;
        const result = await env.DB.prepare(
          'SELECT * FROM feedback WHERE created_at > ? AND created_at < ? ORDER BY created_at DESC LIMIT 100',
        )
          .bind(Date.now() - 90 * 86400000, before)
          .all();
        return json(result.results);
      }
      if (request.method === 'DELETE' && /^\/admin\/feedback\/[\w-]+$/.test(url.pathname)) {
        await env.DB.prepare('DELETE FROM feedback WHERE id = ?')
          .bind(url.pathname.split('/').pop())
          .run();
        return json({ ok: true });
      }
      return json({ error: 'Not found' }, 404);
    } catch {
      return json(
        { error: 'Request could not be completed. Check the content and try again.' },
        400,
      );
    }
  },
  async scheduled(_event: unknown, env: Environment) {
    await env.DB.prepare("DELETE FROM analytics_usage WHERE day < date('now', '-100 days')").run();
    await env.DB.prepare('DELETE FROM feedback WHERE created_at <= ?')
      .bind(Date.now() - 90 * 86400000)
      .run();
  },
};
