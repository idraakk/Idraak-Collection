# MicroGram Direct for Android

This Android build keeps the React interface and replaces the website's media backend with an on-device NewPipeExtractor integration. No MicroGram server, Tailscale, YouTube Data API key, or laptop connection is required by this playback path. The existing website still uses its separate backend.

## Playback and storage

- Capacitor packages the built interface at `https://localhost` inside Android WebView.
- `DirectStreamPlugin` processes imports and storage mutations. `MainActivity` intercepts local API requests and hands them to `NativeApi`.
- NewPipeExtractor **v0.26.5** resolves YouTube metadata and signed media URLs on the phone. Signed URLs remain in the native layer.
- The native layer generates a DASH manifest for compatible H.264 video (up to 1080p) and AAC audio. The existing Shaka player requests byte ranges through the native layer directly from the source.
- Requested ranges use 1 MiB cache blocks. The default limit is 250 MiB, with least recently used eviction. Clearing this cache does not delete Screen Notes, progress, or locally imported originals.
- Imported MP4 originals are separate persistent files; explicit removal is needed to delete them. Android's app storage reset/uninstall deletes all app data.
- Android reserves native system-bar insets so all pages stay below the status bar. Library channel and playlist metadata is cached locally for up to 30 days.
- Scrolling playback uses a bounded pool of prepared video surfaces (normally three; two under constrained conditions and up to four on high-memory devices), plus bounded opening prefetch. See [the playback design](REEL_PLAYBACK_SYSTEM.md) for priorities, limits, preview accuracy and validation.

The Android path does not register the website's streaming service worker. The same HTML video element remains available for reel controls and frame capture.

Live streams, restricted videos, and sources without compatible indexed MP4 tracks are not supported. YouTube changes can break extraction; this requires maintenance and should not be represented as guaranteed playback of every video.

## Build

Requires Node/npm, Java 21, Android SDK platform 36 and platform tools. The current development machine uses a portable JDK in `.tools/jdk/` and the SDK in `.tools/android-sdk/`. These tools and personal configuration are excluded from Git.

```powershell
npm.cmd ci
npm.cmd run android:direct
```

For opt-in live extraction and range tests:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/build-android.ps1 -LiveTest
```

The script builds the frontend, synchronizes Capacitor, removes compressed website duplicates from Android assets, runs Gradle and unit tests, then copies the debug APK to `artifacts/MicroGram-Direct-debug.apk`.

To use an SDK outside the workspace, set `sdk.dir` in the ignored `android/local.properties`. Adapt the build script's `ANDROID_SDK_ROOT` if needed.

## Install and test

```powershell
.tools/android-sdk/platform-tools/adb.exe install -r artifacts/MicroGram-Direct-debug.apk
.tools/android-sdk/platform-tools/adb.exe shell am start -n app.microgram.learn/.MainActivity
```

Test imports, playlist identity, audible playback, forward/back seeking, swiping, rotation, captions when provided by the source, Screen Notes capture, and cache clearing on a real phone. A successful Gradle build does not establish that source playback works on a particular network.

This is a debug-signed test APK. Friends can install the APK itself without Tailscale. Distribution updates must keep the same signing identity to preserve their installed app data. A release build needs a dedicated backed-up signing key; do not put signing keys into Git or distribute the debug keystore.

## Source and notices

Read [the NewPipe notice](../android/NEWPIPE-NOTICE.md). NewPipeExtractor is GPL-3.0-or-later; distributing the combined APK requires providing corresponding source under compatible terms, the license, notices, and build instructions. Retain the original project's MIT notice too. Share the matching source archive with the APK. Build output, personal settings, API keys, tools, user media and keystores must not be included in that archive.
