# Architecture and engineering notes

```mermaid
flowchart LR
  A[React + TypeScript UI] --> B[Segment and watch-coverage engine]
  B --> C[Versioned device storage]
  A --> D[Official YouTube iframe player]
  A --> E[POST /api/import]
  E --> F[YouTube Data API v3]
  G[Capacitor Android shell] --> A
  G --> H[Native lifecycle, share sheet, backup file]
```

## Boundaries

`src/core.ts` contains pure segmentation, source parsing, coverage, and duration logic. `src/storage.ts` owns the versioned backup schema and metadata expiry. `src/Player.tsx` owns one live player per playback session: same-video reels seek in place and different lectures load a new source into that player. It is destroyed when playback is closed, not on each swipe. `server/youtube.ts` owns metadata import; it never fetches arbitrary user URLs. `src/native.ts` owns native/web sharing and export differences.

The UI lives in `src/App.tsx` with responsive CSS. The starter lecture is a bundled, explicitly marked example containing one video; the illustration is original decorative artwork, not a video frame. Player-reported duration corrects its initial duration once playback loads.

## Import API

`POST /api/import` accepts `{ "url": "https://www.youtube.com/playlist?list=..." }` and returns `{ course, skipped }`. Playlist IDs take precedence over a video ID in a playlist watch URL. All pages are loaded, video details are fetched in batches of 50, unavailable/live/non-embeddable entries are removed, duplicates are counted as skipped, and source order is retained. No partial success is returned for an over-limit playlist.

`GET /api/health` exposes service health and whether a key is configured, never the key itself. Missing key returns a clear 503 for imports; an invalid source returns 400; upstream failures return 502. Request JSON is capped at 4 KB. There are four concurrent imports and a 15-import-per-hour per-IP limiter. The key is never bundled into the client. Source requests use fixed Google endpoints and 15-second request timeouts.

The current limiter is in memory. It is appropriate only for a small single-instance pilot. A public launch needs shared rate limits, abuse monitoring, trusted reverse-proxy configuration, and quota budgets. Do not blindly set `trust proxy=true`; configure the exact hosting topology and verify client IP attribution.

## Progress

Coverage is a set of integer seconds per video. At 250 ms intervals, the player records normal forward playback while visible. Jumps, reverse seeks, non-playing states, and background intervals are excluded. The 90% rule tolerates end-of-segment polling and integer boundaries. Replaying seconds does not increase completion; genuine replay time contributes to daily activity. Completion across the whole library deduplicates the same video segments.

This is local habit tracking, not an anti-cheat system. Local data can be edited. Long libraries can exceed browser storage capacity; failures are surfaced, and backup export is provided. A later storage migration should replace JSON second arrays with compressed intervals in IndexedDB or SQLite, with migration tests. Notes/bookmarks are currently keyed by video, duration, and reel index, so they appear under their original reel duration.

Persistence occurs after edits, periodically during viewing, on page hide, and on native backgrounding. Imported metadata is removed after 30 days when loading/restoring and while the app is open; reimport refreshes metadata while watch coverage remains. The bundled starter is not API-cached metadata. Offline notes work while the app is open, but YouTube playback and imports require a connection. This is not an offline-video product.

## Privacy and security

- No account, analytics SDK, ad SDK, or cloud progress storage.
- Native automatic backup is disabled; users export explicitly.
- Google receives playback and thumbnail requests. Playback is opt-in. Thumbnail requests can occur before playback opt-in.
- Helmet headers and a content security policy protect production web delivery; Vite development is not production hosting.
- Backup imports are size-bounded and validated. Thumbnail URLs are restricted to HTTPS `i.ytimg.com`.
- CORS permits configured origins; CORS is not authentication or quota protection.
- Native backup exports use the app cache and OS share sheet. Exported files may contain private notes; their storage location is the user's choice.

## Tests and limits

Unit tests cover segmentation, source validation, progress/seek logic, backup validation, playlist pagination/order, and import failures. Browser tests cover the actual UI flows, mobile overflow, and persistent notes/settings. API calls in the successful-import browser test are mocked; that test is not proof of real Google credential access. Playback integration tests use a controllable player double to verify the app’s boundary logic separately from YouTube availability.

Physical Android playback, WebView identity/referrer handling, release signing, and store review remain release gates. Generated Android source is not equivalent to a tested APK or AAB.
