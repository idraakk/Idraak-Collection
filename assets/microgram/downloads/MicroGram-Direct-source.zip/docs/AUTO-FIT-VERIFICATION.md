# Merged main app and automatic Fit — 26 October 2026

Merge checkpoint: `c25a7bb`. The personal edition's native player and media cache backend were merged into the main app, retaining ports 5173/3001, the main library storage key, and Android application ID. The historical public app remains available at `847fe77`; the independent personal copy remains on 5174.

The subsequent patch defaults playback to Fit and rotates landscape source video when the viewport is portrait. Portrait/square sources remain upright. Intrinsic video dimensions are learned from actual media metadata and persisted. Manual overrides stay effective through the same lecture. Switching lectures resets Fit, and automatic rotation responds to resizing. Adjacent video previews use the same orientation. Gallery covers fill their tiles and rotate according to known source dimensions, falling back to image dimensions until a video is played.

Validation: 22 unit tests passed. Ten browser checks passed (the empty-library check was rerun after fixing a null-orientation edge case). The new mixed-orientation test uses real portrait and landscape MP4 fixtures and verifies metadata-driven rotation, Fit defaults, viewport changes, manual overrides, transitions between sources, thumbnail orientation, and dimension persistence. Phone screenshots were visually inspected in `artifacts/auto-fit-landscape.png`, `artifacts/auto-fit-portrait.png`, and `artifacts/oriented-profile.png`.

These checks do not establish public-hosting readiness, rights to download/redistribute third-party content, or physical-device behavior. This remains the existing local-network cache implementation; no deployment is performed.
