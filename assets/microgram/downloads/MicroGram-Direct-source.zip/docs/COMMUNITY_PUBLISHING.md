# MicroGram Studio operations

The deployed Studio is at [microgram-community.idraakmk.workers.dev](https://microgram-community.idraakmk.workers.dev/). The Android build reads its HTTPS origin from `VITE_COMMUNITY_URL`. Once an APK is configured, post changes appear without rebuilding it.

The Cloudflare Worker and D1 store published feed settings, reader-submitted messages and public replies, access configuration, and deduplicated post view counts. Lecture media follows the Android device-direct playback path. Post images and video use their own HTTPS media URLs.

## Deploy once (PowerShell, from the project folder)

1. Make a Cloudflare account and open its Workers & Pages dashboard. The service uses Workers, D1, and static assets. Check the current free-plan limits before publishing widely.
2. Authenticate the deployment tool:

   ```powershell
   npx wrangler@4 login
   ```

3. Create the database:

   ```powershell
   npx wrangler@4 d1 create microgram-community
   ```

   Copy the returned `database_id` into `community-service/wrangler.jsonc`, replacing `REPLACE_WITH_D1_DATABASE_ID`. Keep the binding named `DB`.

4. Create the tables:

   ```powershell
   npx wrangler@4 d1 execute microgram-community --remote --file community-service/schema.sql --config community-service/wrangler.jsonc
   npx wrangler@4 d1 execute microgram-community --remote --file community-service/engagement.sql --config community-service/wrangler.jsonc
   npx wrangler@4 d1 execute microgram-community --remote --file community-service/comment-ownership.sql --config community-service/wrangler.jsonc
   npx wrangler@4 d1 execute microgram-community --remote --file community-service/access.sql --config community-service/wrangler.jsonc
   ```

   Run the comment ownership migration once per database. Existing deployments should apply only missing migrations.

5. Set the Studio password and generate a separate random session signing secret (at least 32 characters). Put both in Worker secrets and keep them out of the source and APK.

   ```powershell
   npx wrangler@4 secret put STUDIO_PASSWORD --config community-service/wrangler.jsonc
   npx wrangler@4 secret put STUDIO_SESSION_SECRET --config community-service/wrangler.jsonc
   ```

6. Deploy:

   ```powershell
   npx wrangler@4 deploy --config community-service/wrangler.jsonc
   ```

   The command prints an HTTPS URL such as `https://microgram-community.YOUR-SUBDOMAIN.workers.dev`. Open that URL for Studio. Sign in as **idraakk** with the configured Studio password. Import `community-service/example-feed.json` if you need sample drafts, then publish the desired posts individually. Visit `/feed` to verify the published JSON.

7. Configure the APK using the real service origin (no `/feed` suffix):

   ```powershell
   $env:VITE_COMMUNITY_URL = 'https://microgram-community.YOUR-SUBDOMAIN.workers.dev'
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/build-android.ps1
   ```

   Put the same public URL into your ignored `.env.local` for future builds. Keep Studio credentials out of that file. The public origin is not a secret.

8. Share `artifacts/Microgram.apk` with the corresponding source archive. Use the same signing key for updates. The current build is still a debug-signed APK; establish and securely back up a release signing key before broad distribution. Do not uninstall an existing app just to update it, because that removes local learning data.

**Do not distribute the unconfigured build expecting live posts.** With an empty URL, the remote feature is hidden and makes no requests. This is intentional: the app must not call an invented service address. After configuring the permanent origin and rebuilding once, future content comes from Studio.

For a website build, set `VITE_COMMUNITY_URL` both at build time and on the Express host. Add that website's exact origin to `ALLOWED_ORIGINS` in the Worker configuration. Android's `https://localhost` is already allowed. Do not add admin secrets to browser configuration. Prefer a stable custom domain for the service if you expect to move providers later; changing the compiled service address otherwise requires an app update.

## Publishing day to day

- In **Posts**, open a row, edit its content, and check the phone or inline preview. **Save changes** stores a draft in your browser. **Publish changes** sends just that post to readers. Date fields use your computer's local time.
- Comments default to off. Turn on **Allow comments on this post** and publish that post to enable them. Turning it off hides replies without deleting them.
- Click a post's comment count to moderate its replies. **Comments** is the cross-post moderation view, and **Messages** is the private reader inbox.
- **Sponsored deals**, **Android updates**, **App access**, and **Feed settings and backups** each have their own publishing controls. An Android update prompt links to the configured HTTPS download. Keep required updates disabled until you have tested that download and its signing identity.
- **Export backup** exports the current feed draft as JSON. Import it to recover drafts and republish the individual posts you want to restore. Treat published content and media URLs as public.

See the [Android guide](ANDROID_DIRECT.md) for build, installation, and source-distribution details.

## Android usage analytics

Apply `community-service/analytics.sql` to D1 before deploying the Worker. In Studio, open **Analytics** to switch between 7-, 30-, or 90-day ranges and daily or Monday-start weekly groups. The chart and exact numbers use India Standard Time.

- APK download requests count GET requests through `/download/android`, including repeat visits. Existing direct APK URLs, completed transfers, and historical downloads are outside that count.
- App opens count each transition into the foreground while usage sharing is enabled. First measured opens are the first reported day for an install ID, which can happen after an update. Active installs are distinct within each period.
- Android checkpoints usage locally every 20 seconds, uploads about every five minutes while active, and can upload sooner when backgrounded or reconnected. Upload attempts are spaced by at least one minute, and failures back off. The Worker skips unchanged database rows.
- Foreground time excludes background time. Reel watch time estimates real playback time from the player clock, adjusted for playback speed. Reports include offline activity once a device reconnects.
- The current Android testing build defaults to usage sharing on. Set `VITE_PERSONAL_USAGE_ANALYTICS=false` at build time to default new installs to off. The Settings toggle preserves a user's prior choice. The telemetry contains a random install ID, foreground session ID, reporting dates and duration counters. It excludes learning content and profile details. Turning sharing off clears the local queue and install ID. Detailed usage rows expire after 100 days.
