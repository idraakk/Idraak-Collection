# Compact Library styling verification

Rollback baseline: `1cb9212`.

- Removed the shared breadcrumb/import/profile header from every view. Mobile Settings is now accessible in Stats; desktop sidebar Settings remains.
- Library search is a header icon. Activating it replaces the wordmark with an inline input, without adding a new row; closing it clears the filter.
- Library uses self-hosted Roboto 400/500/700. The Library wordmark uses Roboto Condensed 700 as a close available alternative, alongside a red play symbol. It does not embed YouTube's custom logo font.
- Multiline title line-height reduced from 1.4 to 1.2 (about 14%). Watched counts share the metadata row; long channel/stat text truncates while watched counts stay visible.
- Touch feedback uses a 4.5% white overlay on the dark card, with a short fade. Native scrolling remains enabled. The layer stays during touch dragging and clears on touch end/cancel. Reduced motion disables the fade.
- Phone options use a dimmed backdrop and dark bottom sheet with aligned icon rows; desktop retains a compact dropdown. Existing removal/cache safeguards remain.

Research: Google Design's YouTube Sans case study documents custom YouTube lettering and Roboto for system/body text: https://design.google/library/youtube-sans-font . Material state-layer guidance informed the subdued pressed overlay: https://m2.material.io/design/interaction/states.html . The exact YouTube scroll animation was not independently measured; the effect is an approximation.

Validation: seven relevant browser checks passed, with the Library test additionally covering trusted touch drag feedback, menu dismissal, and collapsed search. Visual screenshots were reviewed; production build and Android synchronization passed. New font packages reported no npm audit vulnerabilities at installation.

Latest changes remain uncommitted for review.
