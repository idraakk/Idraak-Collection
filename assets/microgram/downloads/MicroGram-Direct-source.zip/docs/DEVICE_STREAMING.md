# MicroGram device-streaming experiment

Baseline: tag `finalized-ui-2026-10-31`, commit `2305eed`. Work is isolated on `codex/device-streaming`.

## What this build does

- Existing React interface, navigation, captions and Screen Notes remain.
- YouTube extraction resolves separate H.264 video and AAC audio streams. A generated DASH manifest lets Shaka Player synchronize audio/video and choose available qualities up to 1080p; there is no full lecture download to server disk. The existing HTML video element still supports seeking, playback speed, rotation and frame capture.
- Browser requests 1 MiB ranges. IndexedDB keeps a 250 MiB default least-recently-used cache, adjustable in Settings. Notes/images are separate and are never evicted with video chunks.
- MP4 imports stay on the device as original files; they are outside the temporary cache budget and require explicit deletion.
- HD browser playback requires `STREAM_RELAY=true` (enabled in the Render blueprint). Google video responses failed direct browser CORS tests. The relay forwards bounded ranges without writing video files. **This uses server bandwidth.** It is not direct YouTube-to-phone delivery. The older combined-stream endpoint remains only for compatibility.
- Adaptive playback targets 40 seconds buffered ahead and 45 seconds behind in memory; exact amounts depend on source segment boundaries. Persistent chunks have a separate 250 MiB default LRU budget. Adjacent reel previews use thumbnails rather than starting duplicate streams. In-flight requests may finish after pause. No 100-user load test has been performed.
- Two metadata resolutions run concurrently, with a bounded queue and duplicate-request sharing. Expired media URLs refresh on upstream 403/410 responses. Network chunks retry transient failures. Audio, video quality and source-version cache keys are isolated to prevent mixing bytes.
- HTTPS is required on phones. Plain LAN HTTP cannot run the device-cache worker. localhost is allowed for laptop development.
- Source restrictions, unavailable formats, stream expiry and datacenter-IP blocking can still prevent playback. No login-cookie, paid-video, DRM or access-control bypass is implemented.
- Browser storage can be evicted by the browser/OS. Export learning data and Screen Notes backups. Cache does not imply complete offline lecture availability.

## Lowest-cost deployment: Render trial

1. Push this branch to your own private Git repository (do not upload `.env`, `.media`, `.venv` or keys).
2. In Render, create a Blueprint from that repository using `render.yaml`.
3. Enter `YOUTUBE_API_KEY` with YouTube Data API enabled for video/playlist metadata. Keep it on the server only.
4. Render generates `FRIENDS_PASSWORD`; copy it from the service's environment settings. Username is `friends`. Share the HTTPS URL and password only with the invited group.
5. Keep `STREAM_RELAY=true` for HD browser playback. The blueprint sets `TRUST_PROXY_HOPS=1` behind Render; only use this setting behind a known trusted reverse proxy. Monitor outbound traffic before expanding the group.
6. Use the generated HTTPS URL. Friends can open it in Chrome or use Add to Home screen. This is a website installation, not a native APK.

Render's free service sleeps after inactivity and has resource/usage limits. Treat it as a small pilot, not guaranteed free service for 100 heavy video users. Docker deployment itself has not been exercised locally unless noted in the test report.

## Predictable paid option: small Linux VPS

Use a small VPS with included transfer (check current Hetzner CX availability/pricing and region). Budget approximately EUR 5–10/month plus applicable tax/IP/domain costs, not a guaranteed quote. Serve this container behind an HTTPS reverse proxy such as Caddy. Avoid exposing port 3001 publicly without authentication/TLS.

Build: `docker build -f Dockerfile.streaming -t microgram-streaming .`
Run: `docker run -d --restart unless-stopped --name microgram -p 127.0.0.1:3001:3001 --env-file streaming.env microgram-streaming`

Create `streaming.env` outside version control containing `YOUTUBE_API_KEY=...`, `FRIENDS_PASSWORD=...`, and `STREAM_RELAY=true`. No media volume is required in streaming mode. User data lives in each user's browser, not in the container. A custom domain and Caddy configuration must be supplied for that VPS.

Cloudflare Pages alone cannot run the Python/Node resolver. A static free frontend does not eliminate the backend/relay cost.

## Local experimental website

PowerShell:

```
$env:VITE_DEVICE_STREAMING='true'
npm.cmd run build
$env:STREAMING_MODE='device'
$env:STREAM_RELAY='true'
$env:PORT='3003'
npm.cmd start
```

Open `http://localhost:3003` on the laptop. For phone tests, use an HTTPS deployment. Keep the finalized Vite preview on 5173 separate.

Tests (requires the experimental server running):

```
$env:PLAYWRIGHT_CHANNEL='msedge'
$env:STREAM_TEST_URL='http://localhost:3003'
npx.cmd playwright test e2e/device-streaming.spec.ts
```

Set `LIVE_STREAM=true` for the opt-in real YouTube playback check. It uses public network data and may fail when the external source blocks access.

## Rollback / APK

Use the finalized tag in a separate checkout to return to the server-download edition. Do not switch the production frontend feature flag without rebuilding.

The existing Capacitor project is preserved, but this browser service-worker transport has not been validated in Android WebView. Do not distribute an APK of this experiment as equivalent. A native Media3 transport remains a separate integration task.

## Cost references checked 2026-10-31

- https://render.com/docs/free
- https://developers.cloudflare.com/pages/functions/pricing/
- https://www.hetzner.com/cloud/cost-optimized/

A 1 Mbps lecture uses about 450 MB per hour. 100 people watching one hour daily is about 1.35 TB/month before overhead. With relay enabled, that outbound traffic is on the host. Device caching reduces repeated transfer, but does not eliminate first-view traffic.

## Verification for this experiment

- Production TypeScript/Vite build: passed.
- Unit suite including MP4 index parsing and cold-start recovery: 79 tests passed.
- Actual public YouTube resolver: passed without downloading a server file.
- Actual direct browser playback: failed; range response lacked CORS headers.
- Actual adaptive playback through the relay: three public sources (`fNk_zzaMoSs`, `aircAruvnKk`, `3JZ_D3ELwOQ`) decoded at 1080p with audio in desktop Edge. Seeking and frame capture passed.
- Device MP4 import, seeking, capture, preserving originals on cache clear, explicit deletion: passed.
- Mocked byte-source regressions: byte accuracy across chunk boundaries, audio/video cache isolation, cache hits without transfer, LRU eviction and clearing passed.
- Docker is not installed in this workspace; container build and Render/VPS deployment remain unverified.
- Phone/browser diversity, sustained paused/read-ahead behaviour, source coverage, native APK and 100-user load remain unverified. This is an experimental release, not a production certification.

### Cold-start recovery

Failed or truncated index probes retry with a fresh deadline. Concurrent opens share pending manifest/index requests. If a complete manifest attempt fails, the resolver refreshes the source and retries before returning an error. The player also retries its initial load once, suppressing temporary startup errors until recovery finishes. Persistent failures still report an error; retries are bounded.

### Startup and phone testing

The browser keeps successful manifests privately for 60 seconds. A retry bypasses that cache. Concurrent requests for the same video chunk share one bounded transfer, and cached chunks are returned without waiting for bookkeeping writes. Player initialization and an uncached network request can still cause a short delay; the loading overlay explains this and mentions double-tapping to hide controls.

For Android USB testing, install Android SDK Platform Tools, enable USB debugging on the phone, connect the USB cable and accept the debugging prompt. With the streaming server running on port 3003, run `adb reverse tcp:3003 tcp:3003`, then open `http://localhost:3003` in the phone's Chrome browser. Keep the laptop/server running and cable connected. This does not publish the app. For wireless/friends testing, use an HTTPS deployment (see above). Plain LAN HTTP does not support this device cache.

Startup verification: a cached reload resumed HD playback in 813 ms in one local Edge test (not a performance guarantee). Slow optional qualities no longer block an available video/audio pair. Manifest and chunk connection deadlines are explicitly aligned with resolver/relay deadlines. The loading hint, concurrent chunk reuse, local MP4 playback and cache tests passed. Phone hardware has not been tested.

### Reel-aware look-ahead

The main Reels tab now warms DASH byte ranges at upcoming reel boundaries, rather than relying only on continuous read-ahead. Targets are the next reel's first 10 seconds, the following reel's first 6 seconds, a third reel's first 4 seconds, and the previous reel's first 4 seconds (actual transfer follows source segment and 1 MiB cache boundaries). Audio and the currently selected video quality are prefetched. This applies inside the active lecture; opening a different lecture still requires that source's startup.

One low-priority prefetch runs at a time, only with healthy foreground playback and at least 4 seconds already buffered. Pause, seek, hidden-tab and disposal stop the prefetch reader; an already requested 1 MiB cache block may finish. Speculative ranges have a conservative 24 MiB budget per reel position, reduced to 4 MiB/only the next reel when browser Data Saver or 2G is reported. The normal device cache budget and LRU eviction still apply. Saved-only playback does not speculate on other lecture reels.

Network speed, quality changes, cache eviction and source availability can still cause buffering. No claim of zero buffering, equal Instagram data usage or broad phone-device performance is made.

Verification: 79 unit tests, production build, and five device-streaming browser tests passed. A local Edge test with 2.5 seconds between swipes measured 861 ms, 780 ms and 687 ms from swipe to playback at the next reel; timings include transitions and test polling. These are local observations, not guaranteed device/network performance.
