# Put MicroGram online: first friends trial

## How playback works

YouTube source -> Node byte-range relay (memory only) -> HTTPS browser -> Service Worker -> bounded IndexedDB cache -> Shaka DASH player. The server resolves URLs with yt-dlp/Python, generates a DASH manifest and forwards requested ranges. It does not save full lectures to disk. React/TypeScript/Vite provide the interface. The YouTube Data API imports playlist/video metadata. Notes, progress, captures and cached chunks live in each browser. No account sync exists.

## Recommended first trial: Render Free

1. Create a GitHub account and install GitHub Desktop if needed. Create a PRIVATE repository called MicroGram. Add this existing project folder to GitHub Desktop, publish privately, and push branch `codex/device-streaming`. Never add `.env`, keys, `.media`, `.venv`, or `streaming.env`. The repository already ignores those files.
2. Create a Render account at https://dashboard.render.com and connect GitHub. Grant access to this repository.
3. Click New -> Blueprint. Select MicroGram and branch `codex/device-streaming`. Use the root `render.yaml`. Review the proposed `microgram-friends` Docker Web Service and ensure its compute plan says Free. Do not choose Static Site.
4. Enter `YOUTUBE_API_KEY` when prompted, using your server-side key with YouTube Data API v3 enabled. Keep it out of client code. The blueprint enables STREAM_RELAY=true and configures the trusted proxy hop. FRIENDS_PASSWORD is generated automatically.
5. Deploy. Watch the build logs until Live. Docker installs Node/Python dependencies and builds the streaming frontend. No separate database, disk, frontend hosting or custom domain is needed for this trial.
6. Open the service Environment settings and reveal/copy FRIENDS_PASSWORD. Visit the generated HTTPS onrender.com URL. Sign in with username `friends` and that password.
7. Import ONE lecture, play it, swipe several reels, capture a Screen Note, then refresh and reopen. This cloud-host test matters: YouTube may block datacenter requests even when laptop tests pass. If blocked, do not invite everyone yet or buy larger compute expecting it to fix source blocking.
8. Share the HTTPS address and password with 2-5 friends first. On Android Chrome they can select Add to Home screen / Install if available. The laptop can be off once Render serves the app.
9. Check Render Billing / Monthly Included Usage after the first sessions. Free compute does not mean unlimited relay traffic. Without a payment method, exhausted bandwidth can suspend the service; with one, supplementary usage can be charged. Review spend controls before adding payment details.
10. Export important learning data regularly. Each browser/device has its own local learning space; changing domain or clearing browser data does not transfer it automatically.

Free services sleep after 15 idle minutes and can take around a minute to wake. They may also be suspended for unusually high service-initiated internet traffic. This makes Free a trial, not a promised zero-cost service for 100 video users.

## If the trial works and usage grows

An always-on small Linux VPS with included transfer is usually more predictable for this relay architecture. Compare current regional traffic allowances and total price (tax, IPv4, domain); do not pay until source playback has been tested there. EU Hetzner plans advertise at least 20 TB included transfer, while other regions differ. Deployment requires Docker, an HTTPS reverse proxy such as Caddy, a hostname and the same environment values. See DEVICE_STREAMING.md for container commands.

At 2 Mbps, watching one hour transfers roughly 0.9 GB, before extra preloading/overhead. Twenty friends watching an hour daily would therefore use about 540 GB/month; 100 friends about 2.7 TB/month. Actual adaptive bitrate and caching change this substantially.

## APK later

Start with the HTTPS installable website. The existing Capacitor project has not been validated with this Service Worker transport in Android WebView. A tested native playback/cache integration is required before distributing an equivalent APK. Browser packaging alone is not proof of equivalent behavior.

References checked 2026-10-31:

- https://render.com/docs/free
- https://render.com/docs/blueprint-spec
- https://render.com/pricing
- https://www.hetzner.com/cloud/general-purpose/
