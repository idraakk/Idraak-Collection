# MicroGram laptop hosting

## Daily use

From this project folder, run `npm.cmd run host:laptop`. It builds the streaming website, starts the loopback-only server on port 3003, enables the byte-range relay and keeps Windows awake while the host runs. Display sleep is allowed. Closing the laptop lid, manually sleeping it or disconnecting the internet can still take it offline.

Login is disabled by default, so anyone with the public URL can use the app and its video relay. To enable login, set `requirePassword` to `true` in `.hosting/config.json` and restart the host. Username is then `friends`, with the password from that file. This folder is ignored by Git. Do not send the config file or credentials to public repositories. The existing `.env` supplies the YouTube metadata API key.

Install Tailscale, sign in to your own account and connect the laptop. Then run `npm.cmd run host:share`. Approve enabling Funnel/HTTPS in the Tailscale page if prompted. The command prints a public `https://...ts.net` address. Friends only need the URL when login is disabled; they do not need Tailscale installed.

Check the HTTPS link from a phone on mobile data. Test import, playback, several swipes, seeking and Screen Notes before inviting more users. Funnel has non-configurable bandwidth limits; this is a small-group trial, not a guaranteed 100-user service. Local and tunneled browser origins have separate storage.

To stop the app: `npm.cmd run host:stop`. To disable public routing too: `& "$env:ProgramFiles\Tailscale\tailscale.exe" funnel --https=443 off`. No Render service is needed for this setup.

## What is shared

Funnel points to the app's HTTP port, not the project directory. The app exposes its API and built `dist` frontend with optional Basic authentication controlled by the local config. Video ranges pass through the laptop to the browser's bounded cache. Full lectures are not saved by this streaming transport on the laptop. Home upload bandwidth and source availability constrain playback.

The launcher does not configure an exit node or advertise LAN routes. The server only listens on 127.0.0.1. HTTPS terminates at the Tailscale client and forwards to that listener. The app trusts exactly one proxy hop in this mode.

Sources: https://tailscale.com/docs/features/tailscale-funnel

## Public Funnel performance

Measured public ingress was substantially slower than local playback: a 1 MiB video range took 0.31 seconds locally and 12.76 seconds through Funnel in one test. These are observations, not a guaranteed cap or a measurement of home upload speed. A good video download connection alone does not establish hosting upload capacity.

Production builds now precompress JS/CSS assets with Brotli and gzip and cache fingerprinted assets for one year. The main bundle transferred about 149 KB compressed instead of 499 KB. Video ranges are not compressed. On ts.net hosts, the player begins with a conservative bandwidth estimate, restricts speculative warming to the next reel, and uses 256 KiB device-cache blocks. Resolution may be lower when the link is slow. Local playback retains its normal quality and look-ahead defaults.

For dependable HD, the public delivery path must sustain the video/audio bitrate. App optimization cannot guarantee that over Funnel's non-configurable bandwidth limit. Direct private Tailscale connectivity can be tested separately, but requires clients to install Tailscale and suitable access/account limits; it is not the same public-browser-only experience.

### Private phone test without public Funnel

A separate private Serve endpoint is configured on HTTPS port 8443. Install Tailscale on your own phone, sign in to the same account and enable its connection. Then open the laptop's ts.net hostname with `:8443` added. It is available only inside the tailnet; friends without Tailscale cannot open it. This can use direct device-to-device connectivity, but actual route and upload capacity still determine performance. Keep the public 443 Funnel separate.

Configure: `tailscale serve --bg --https=8443 http://127.0.0.1:3003`
Disable private endpoint: `tailscale serve --https=8443 off`

Public Funnel startup is capped at 480p for the first eight seconds of playback, after which normal adaptive choices up to 1080p are allowed. The private 8443 endpoint retains normal playback defaults. A public-path browser test measured 8 seconds to first playback versus 27 seconds before this startup adjustment; page interactivity varied from 2.8 to 5.4 seconds and swipes still took about 3 seconds. This does not establish Instagram-like performance over Funnel.
