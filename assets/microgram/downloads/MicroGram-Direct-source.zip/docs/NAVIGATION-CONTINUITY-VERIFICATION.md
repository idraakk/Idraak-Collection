# Neutral chrome and navigation continuity

Implemented 2026-10-30.

- Rotate, the five bottom tabs and the profile completion count use their previous neutral colors. Other pink accents remain.
- Watching uses a standard CircleCheck outline; playback speed uses a Gauge outline with the current rate below it. Both share the bare outline treatment and inherited dark edge used by Save and Notes.
- Settings is a child of Insights in Back navigation: Settings -> Insights -> Home. This applies to browser Back and the native Back handler.
- A validated session navigation snapshot preserves the active section, selected course/reel, profile return location, control visibility and scroll position on refresh. It is separate from learning data and is scoped to the current browser tab. Missing or expired courses fall back to Library. Transient dialogs are not reopened.
- Browser history reuses existing MicroGram entries on refresh, preserving parent steps without duplicating them.
- An explicit pause clears pending tap/resume intent unless it was initiated by scrubbing itself.

Validation: six navigation/storage unit checks passed. Browser tests passed for refresh through Library/profile/reel, Settings/Insights Back paths, existing rapid Back and profile exits, Home confirmation flows, and playback controls with refresh. Production build and Android asset sync passed. Reviewed artifacts/reel-outline-controls.png. Hardware Back on Android still needs a device smoke test.
