# Library and navigation polish

Baseline commit: `6dd449f`.

- Library titles have no button padding and share the metadata left edge. Channel, view count (without the word views), and publication age occupy one ellipsized line. Card row spacing is reduced.
- Profile tiles have a red bottom-boundary line representing retained watched coverage for that reel. Coverage is based on recorded watched seconds, not current playback position or a seek to the end, and therefore does not reset on replay.
- Browser subpages use one temporary same-URL history entry. Back closes an overlay/player, returns from a profile to the Library, or returns another tab to Home. Once at Home, browser Back can leave normally. The native Android listener uses the same navigation decision and minimizes from Home. Native device hardware Back was not separately exercised in this environment.
- Opening a profile and opening its reel animate from the right over 190 ms. Tab changes and backward navigation do not animate. Reduced-motion preferences disable the entry animation.

Five browser checks passed covering actual history Back, nested views, animation scope, tile coverage, Library behavior, and existing playback/media serving. Production build and Android asset sync passed. The phone Library screenshot was reviewed for text alignment and compact metadata.

This refinement patch is uncommitted for review.
