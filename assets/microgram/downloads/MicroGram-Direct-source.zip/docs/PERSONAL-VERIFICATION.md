# Personal edition verification — 26 October 2026

Public app checkpoint: `847fe77`. Public working tree remained clean after personal development. This independent copy uses port 5174/API 3002, browser storage `microgram.personal.v1`, and Android application ID `app.microgram.personal`.

- 18 unit tests passed.
- All 9 personal browser checks passed in Microsoft Edge, including an actual generated MP4 upload, ordered reel profile, native playback, full viewport video bounds, controls inside the video bounds, swipe navigation with a preserved video element, final-reel looping, notes without unmounting the player, persistence, and HTTP 206 range serving.
- Production build and Capacitor Android asset sync passed. This is not a signed APK build.
- The starter lecture `fNk_zzaMoSs` downloaded successfully to the private cache (22,029,396 bytes). A live browser probe observed native playback at 1920×1080, advancing from 2.14 seconds to 60.01 seconds after next-reel navigation, with zero iframes.
- The downloader's old short test video was unavailable; the error path displayed correctly. No account cookies or restriction bypass was used.
- Phone-sized fullscreen and swipe screenshots are in `artifacts/personal-fullscreen.png`, `artifacts/personal-swipe.png`, and `artifacts/personal-youtube-cached.png`. The cached-lecture screenshot was visually inspected.

Not verified: physical Android hardware, a signed/installable APK, all YouTube formats/videos, internet-free use on a phone, or production deployment. First playback of an uncached lecture waits for the full download; neighboring reels of a cached lecture show a paused frame preview during swiping. Native video playback is not a claim of 100% visual or behavioral identity with Instagram.
