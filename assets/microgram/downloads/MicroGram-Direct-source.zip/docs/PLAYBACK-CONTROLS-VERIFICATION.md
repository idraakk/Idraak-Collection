# Reel playback controls verification

- Rollback baseline for the latest gesture/visibility patch: `b626e5c` (speed, captions and timeline).
- Speeds: 1, 1.25, 1.5, 1.75, 2; saved on this browser/device and applied to later reels.
- Hold the video for 350 ms for temporary 2x. Movement over 10 px cancels only a pending hold. Once 2x is active, dragging keeps 2x active and suppresses reel swiping until release. Release/cancellation, blur, resize, navigation, or hiding the page safely ends the hold. A completed hold suppresses the synthetic tap-to-pause.
- Speed badge opens playback speed and caption controls. Captions are requested per video; select a language or Off. Local MP4 imports have no YouTube subtitle source.
- Captions use YouTube's existing WebVTT timing with a hidden browser TextTrack and a small text overlay. No generated captions. Track availability depends on YouTube; failures have a retry option.
- Caption responses have a bounded server memory cache (20 entries, 30-minute validity), 2 concurrent extraction requests, 90-second subprocess timeout, and 2 MB per-track limit. No caption files are saved to disk.
- The bottom boundary line shows current playback position within the reel, including loop resets, rather than cumulative watched coverage. Completion accounting is unchanged.
- Profile completion checks are green.

Validation: production build and Capacitor sync passed. Existing playback, orientation, completion and media range tests passed. Dedicated browser checks cover saved speed, mouse and trusted touch hold/release/cancel, movement cancellation, cue synchronization after seeking, captions Off, and the timeline/nav boundary. Test caption fixtures are synthetic and use range-capable MP4 responses.

Live YouTube check: the starter lecture fNk_zzaMoSs returned language tracks and a valid English WEBVTT track (15,078 characters). Future availability is not guaranteed. No real subtitle content was saved to the repository.

## Gesture and visibility refinement

Double-click or double-tap the video hides/restores controls without pausing. Hidden state persists across reel navigation; the reel number, timeline, bottom navigation and enabled captions remain. Single taps still pause/resume after a short double-tap detection interval. Speed choices apply immediately; outside pointer presses dismiss the menu. Captions rotate with the video and use the fitted content dimensions, including letterboxing. Lecture avatars use video thumbnails (playlist avatars use the first lecture); missing images fall back to the existing cover asset.

Verified with five browser checks plus a final trusted-touch check covering hold-and-drag, touch cancellation, hidden-mode swipe, and double-tap restoration. Rotated-caption and quiet-reel screenshots saved in artifacts. Production build and Android asset sync passed.
