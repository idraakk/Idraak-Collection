# Playback identity refinement — 2026-10-27

Baseline committed as ec9d61c before this patch.

MicroGram Pink is #FF4E94 (RGB 255, 78, 148), the existing Continue Learning and Saved accent. Profile tile coverage, watched status, reel count and the YouTube link now share this color.

Playback settings replaces the redundant rail Play button. Speed and caption choices use compact themed menus with immediate selection. Mute is visible above the central Play button only while paused. The footer slogan was removed globally, profile spacing tightened, and tile covers fill their frame with crop correction for standard letterboxed YouTube covers.

Scrubbing coalesces pending positions instead of continuously interrupting decoding. Each completed seek gets a render opportunity before the next position is applied. The final release lands at the latest selected position and resumes only if playback was active before dragging. This improves live feedback but does not guarantee displaying every intermediate frame during fast dragging or on slow hardware/network connections.

Validation: production build and Android asset sync pass. Browser coverage exercises navigation, native playback, speed/caption choices, pause-only mute, mouse/touch scrubbing and watched-progress preservation. Exact profile accent RGB values are checked. Real phone decoding performance remains device-dependent.
