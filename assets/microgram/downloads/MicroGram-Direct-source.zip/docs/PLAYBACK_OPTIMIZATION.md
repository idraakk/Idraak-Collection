# Android playback and layout patch — 1 November 2026

The subsequent [prepared-player pool](REEL_PLAYBACK_SYSTEM.md) supersedes the single-element Android playback buffer described below. This document preserves the earlier change and its measured baseline.

## What changed

- Android owns system-bar and cutout padding. Insets passed to WebView are zeroed after native padding, preventing either overlap or double spacing. Keyboard insets remain supported.
- Library images have no button padding and cover the entire thumbnail rectangle. Existing playlist stack layers remain in place. Album photos use cover rendering inside their stacked frames; the full-screen photo viewer retains its fit behavior.
- Native library metadata now includes playlist owners and refreshes missing channel avatars. Metadata persists across process restarts for up to 30 days. Channel images can retry the alternate YouTube image host.
- A plain local poster replaces WebView's default video artwork. Loading feedback uses a smaller translucent surface. Delayed buffering feedback checks actual playback readiness and does not show for stale waiting events or paused video.
- Android's playback buffer targets two upcoming reel boundaries: 130 seconds ahead and 70 seconds behind for 60-second reels, capped at 180 seconds ahead and 120 behind. This buffers media in MSE; it does not keep every future frame decoded. Isolated saved reels use a smaller window.
- Native cache blocks increased from 256 KiB to 1 MiB to reduce sequential network round trips. The existing bounded LRU disk cache and user-selected limit still apply. Older short blocks are validated and refetched when necessary.
- On a committed same-video swipe, seeking begins during the transition. A temporary canvas holds the outgoing frame so it does not change to the incoming moment halfway through the animation. At the transition's end, a completed/preparing seek is reused rather than issued again. Watch-time accounting ignores the pending outgoing segment.

## Research and limits

[Meta's video delivery description](https://engineering.fb.com/2024/12/10/video-engineering/inside-facebooks-video-delivery-system/) describes an in-memory content pool and media prefetching to support swiping. [Android's Instagram/Facebook preload article](https://android-developers.googleblog.com/2026/03/instagram-and-facebook-deliver-instant.html) describes keeping upcoming videos ready in memory, beyond disk prefetch. MicroGram adapts those principles to its existing HTML/MSE player; this patch does not integrate Media3 PreloadManager.

[Android's WebView inset documentation](https://developer.android.com/develop/ui/views/layout/webapps/understand-window-insets) explains how to consume native padding without passing duplicate safe-area dimensions into web content.

Unlike a service controlling its uploads, MicroGram does not control YouTube's encodings, keyframes, availability, or CDN behavior. Disk-cache hits also do not eliminate decoder seeking. Network stalls, seeking outside prepared ranges, and switches between lectures can still take time.

## Physical-phone observation

Four consecutive 60-second reel jumps were measured on the connected Android 15 phone. The measurement includes the existing 280 ms slide animation and waits for media readiness at the target time.

| Build | Observed jump times | Mean |
| --- | --- | --- |
| Before this patch | 1102, 1064, 1096, 1125 ms | 1097 ms |
| With overlapping seek | 677, 638, 615, 727 ms | 664 ms |

This small sample shows about 39% less waiting in that sequence. It is not a controlled network benchmark or a guarantee of identical results on other devices or lectures. Playback remained at 1080p during the phone checks.

Final checks: 86 frontend unit tests passed; six native unit/live tests passed. The production-browser regression passed forward/back seeking, transition-canvas cleanup, suppression of a stale waiting event, feedback for a simulated sustained stall, local-file frame capture, and device-scoped storage clearing. On the phone, three channel avatars loaded, library image bounds exactly matched their thumbnail rectangles, album photos used cover rendering, and reverse navigation returned to 1080p playback. The updated APK was installed without clearing user data.
