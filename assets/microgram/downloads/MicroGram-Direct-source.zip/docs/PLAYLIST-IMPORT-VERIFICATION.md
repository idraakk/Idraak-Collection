# Playlist import diagnosis and verification

User-reported symptom: importing a playlist appeared to open the existing top video rather than add a visible playlist card.

The exact supplied playlist, PLtUBJBQF5VJgSzegWtlFiNTWehra8eSHU, returned 14 videos and passed the original full browser import/persistence check. The reported wrong-profile failure was not reproduced. The previous success flow automatically opened a profile, making Library confirmation indirect.

Changes:

- Successful imports now return to Library, with the imported or updated item first and a named confirmation with video count.
- Validate the returned resource ID against the requested playlist/video before changing state.
- Save the new Library state before closing the dialog; persistence failures stay visible in the dialog and do not navigate to a profile.
- Retain an explicit optional video/playlist kind, including through persistence, with backward-compatible inference for old entries.
- Playlist IDs remain distinct from video IDs. Re-import updates the same playlist without replacing its separately imported first video or creating a duplicate playlist.

Verification: seven browser checks passed, including the supplied live playlist, Library/reload persistence, an existing-first-video collision, a one-video playlist, re-import, wrong resource responses, and simulated storage exhaustion. The live check is opt-in via LIVE_PLAYLIST_URL and uses an isolated browser context rather than changing the user's browser Library. Screenshot: artifacts/live-playlist-import.png.
