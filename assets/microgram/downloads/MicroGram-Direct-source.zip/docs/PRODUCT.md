# MicroGram product plan

**Promise:** turn a lecture someone already wants to finish into a finite sequence of small, visible wins.

The initial audience is students learning from public YouTube lecture playlists, especially exam preparation, mathematics, and programming. The core loop is import → watch a segment → reflect or save → scroll → see progress → return tomorrow. Learning remains in lecture order; there is no unrelated recommendation feed.

## Shipped in this repository

- Responsive dark learning feed with scroll, swipe, arrow-key navigation, focus mode, and reduced-motion support.
- Official YouTube embedded playback. Segments are time windows, not new video files. The original framing, attribution, controls, advertisements, and YouTube behavior remain.
- Public video/playlist imports, pagination, source ordering, deduplication, unavailable-video exclusion, and clear failures. Maximum 1,000 entries per playlist.
- 15/30/60/90-second segments, including a short final segment. One hour is 60 reels at 60 seconds, 120 at 30 seconds, or 240 at 15 seconds.
- Per-video and per-playlist completion counts; daily learning minutes and seven-day activity.
- Library entries open learning profiles with avatars, source attribution, progress stats, and a three-column chronological reel gallery. Each tile opens its exact segment; Back returns to the profile. Lecture filters and incremental loading support larger playlists.
- Local bookmarks, timestamped notes, timestamped sharing, export/restore, and complete local deletion.
- Android source project, native sharing/export, and app lifecycle handling.

## Design decisions

Use the familiarity of a Reels interaction without impersonating Instagram. MicroGram owns its visual identity: charcoal surfaces, lime highlights, restrained typography, and an original mark. Wide lecture content is letterboxed rather than cropped; diagrams and equations must remain legible. The player is not covered by custom UI.

Scrolling alone never awards completion. Watch coverage is recorded by source-video seconds; a reel completes at 90%. Changing the reel size recomputes the denominator using the same coverage, rather than losing progress. Completion is a habit signal, not proof of comprehension. A seek larger than 2.5 seconds between samples is ignored.

Keep the experience finite: the total is always visible, the last reel does not jump to an unrelated course, and finishing a daily goal does not trigger an endless feed. Notes ask learners to explain the idea in their own words.

## Deliberately deferred

Accounts/cross-device sync, transcript-based semantic cuts, AI summaries/quizzes, offline video, recommendations, billing, notifications, referral rewards, social profiles, and analytics ingestion are **not implemented**. No interface pretends these services exist.

Fixed-duration segments can interrupt an explanation. Validate the basic learning loop before adding chapter-aware segmentation. A later semantic-cut feature needs a legitimate transcript source and an independently tested segmentation service. YouTube video downloading is not part of this product.

## Validation before expansion

Recruit 15–25 students already studying an actual playlist. Observe import success, time to first playback, whether the reel length helps or distracts, and whether learners return. Compare a small voluntary pilot with ordinary lecture viewing. Ask short recall questions after a lesson; completion alone is not the outcome.

Proposed measures (not collected by this build): successful import rate, playback-start success, unique minutes meaningfully watched, lecture completion, seven-day return rate, and self-reported usefulness. Define consent and retention before collecting analytics. Do not optimize raw scrolling time.

First distribution experiments: share timestamped learning moments, creator-approved playlist collections, and opt-in student study groups. No viral growth or commercial success is guaranteed.

## Later architecture

Add managed authentication and PostgreSQL only when cross-device demand justifies them. Synchronize watch intervals as idempotent unions; never add client completion counters blindly. Keep per-user authorization at every data boundary. Use a durable shared rate limiter, operational monitoring, and budget alarms before scaling beyond one API instance. Add a job queue only if playlist processing regularly exceeds the current request budget.
