# Profile, data ownership, course lengths and browser Back

Implemented 2026-10-30. User is testing in a phone browser.

## Back and Notes

Chrome can animate a history traversal before JavaScript receives popstate. Removing CSS animations cannot promise to remove this browser-owned transition. See Chrome's [same-document transition guidance](https://developer.chrome.com/docs/web-platform/view-transitions/same-document) and [Navigation API restrictions](https://developer.chrome.com/docs/web-platform/navigation-api). Tests on desktop Edge do not reproduce the Android browser compositor.

The popstate context now carries hasUAVisualTransition. A profile exit skips its own slide if the browser already supplied a transition. Tab changes stay instantaneous in app code. Phone Back and Done both call NotesDialog.close; the closing panel recomputes its origin and scales toward the Notes button. Keyboard/browser-owned effects remain outside website control.

Open Note from Saved opens only the note overlay, without creating a video player or changing the saved collection. Both Back and Done return to the same Notes list. Watching the linked video remains a separate action.

## Real per-course reel lengths

The removed Settings control previously changed a global duration, including existing lectures. Imports also changed that global value. Course metadata now stores reelSeconds; existing courses migrate using their prior global value. Import length is a separate draft and never changes other courses. Saved moment IDs continue to resolve their original boundaries. Local MP4 and YouTube imports both record their chosen length.

## Profile and activity

First launch asks for a name. Home greets that name and shows an interactive GitHub-style 365-day calendar using MicroGram Pink intensity. It uses actual device activity, with no generated activity. Goal-relative intensity and individual-day values are derived from the same video-time activity used by Insights. Settings can edit the name.

## Data controls

The daily-goal picker is a themed menu with keyboard navigation. Browser export appends a real download anchor and keeps its Blob URL alive for 30 seconds. Restore validates and migrates a backup, then persists it before applying it to the app. The backup contains the profile, courses and their lengths, notes, bookmarks, progress, activity, reflections, speeds and preferences.

Full reset clears all MicroGram-prefixed local/session keys and in-memory metadata, resume queues, profile and learning data. Empty default state is persisted so the starter course does not reappear. Native temporary export files are removed where applicable. A separate unchecked option clears eligible server downloads; active/shared/original video protection remains. Exported backups outside the app are not remotely removed.

## Loading feedback

A cache-status check no longer means Preparing. Fast checks show no message. Longer checks show a small loader. Preparing your lecture appears only after the server reports an actual preparation job, and is delayed briefly to avoid transient flashes. Status checks time out rather than hanging indefinitely.

## Validation

50 unit tests and the production build passed. Targeted browser tests verified first-run name persistence, pink heatmap data, per-import duration isolation, a real exported-file reset/restore round trip, full device-data reset, themed daily goals, slow cached-video checks without preparation flashes, actual preparation feedback, note-only opening, saved playback, and browser-transition flags. Screenshots reviewed: artifacts/home-personal-heatmap.png and artifacts/goal-themed-menu.png. Android assets synced. Phone-browser visual-compositor behavior still needs device verification; a website cannot guarantee disabling Chrome's own transition.
