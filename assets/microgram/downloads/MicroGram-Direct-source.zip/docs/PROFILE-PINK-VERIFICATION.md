# Profile navigation and subtle pink polish

Implemented on 2026-10-27.

- Nested browser history entries preserve Reel -> Profile -> Library -> Home. Native Back listeners now read current state without listener-registration gaps.
- Profile exits animate an inert outgoing snapshot; the underlying Library renders immediately, avoiding the live profile flashing back.
- Compact profile typography, icon-only top bar, pink primary action, lower tile text with a shorter gradient, and a compact lecture picker.
- Pink tile coverage lines and quiet reel completion accents. Library thumbnail progress remains red.
- Removed hold-speed text, redundant tile/footer copy, and the current Share action. Speaker and speed controls moved upward.
- Download cleanup defaults on when removing a course. Existing protection for shared videos, active downloads, and originals remains.
- Accessible range control adds pointer/touch/keyboard seeking to the boundary timeline. Playback pauses during a drag and resumes only if it was previously playing. Seeking resets watch-interval bookkeeping so skipped seconds do not count as watched.

Validation: production build and Android asset sync passed. Nine targeted Edge browser tests passed, covering Library, native video playback, navigation, storage safeguards, and mouse seeking. The navigation tests include repeated rapid consecutive Back presses. Profile screenshot reviewed at artifacts/profile-refined.png.

Actual Android hardware Back/gesture behavior still needs a device smoke test. This patch does not implement a public sharing/deep-link service; a future Share action can offer timestamped YouTube links with a copy fallback.
