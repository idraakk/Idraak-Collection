# Reel viewport and persistent navigation — 26 October 2026

Removed automatic browser Fullscreen API entry/exit. Playback now uses a two-row layout: the available reel viewport and a persistent bottom navigation bar. Removed the inherited 100vh minimum height from the 100dvh reel root, which could otherwise extend beyond the visible browser viewport. Bottom safe-area space belongs to navigation rather than being counted again in reel controls. Fit content remains centered in the remaining player area.

Navigation uses a rounded charcoal selection pill, a filled selected Learn icon, and aria-current. Learn stays selected during playback even when the reel was opened from a Library profile. Tapping the selected Learn tab retains playback; choosing another tab exits playback. Existing app destinations are retained.

Eight relevant browser checks passed, followed by a targeted orientation/navigation check after refining tab switching and the selected icon. Checks cover no browser fullscreen request, portrait video ending above navigation, landscape navigation within viewport bounds, tab selection and switching, native playback, and profile restoration. Production build and Android sync passed. Phone-sized screenshots were inspected. Actual Android browser chrome/gesture-bar behavior still needs verification on hardware.
