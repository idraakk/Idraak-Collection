# Dedicated Reels tab — 2026-10-27

Baseline commit: 1ac3cf0.

Added Reels between Library and Saved. It opens the existing immersive player at the last opened playback reel, using an optional persisted course/video/start bookmark. Browsing a different profile does not overwrite this bookmark. In this tab, adjacent reels are restricted to the remembered lecture; playlist profile playback retains its existing playlist sequence. Back from the dedicated tab returns to Home. Missing/deleted bookmarks fall back to an available course; an empty library redirects to Library with an import hint. Consent still gates playback.

Per-course resume indices remain in playlist coordinates even when the dedicated tab filters to one lecture. The timestamp bookmark also adapts when reel duration changes.

Reduced speed circle to 32px with a 2px border, strengthened the Watching label/ring, enlarged Save optically to 31px, tightened profile spacing, and applied restrained pink menu icons/checkbox/hover accents. Five navigation targets fit narrow screens.

Validation: production build and Android asset sync passed. Browser checks passed for Library, rapid nested Back, playback controls and the new tab. New coverage verifies multi-video playlist resume, preceding/following reels, first-reel boundary, reload persistence and leaving the tab. Reviewed artifacts/reels-tab.png and artifacts/library-options-mobile.png. Android hardware gestures still require a device smoke test.
