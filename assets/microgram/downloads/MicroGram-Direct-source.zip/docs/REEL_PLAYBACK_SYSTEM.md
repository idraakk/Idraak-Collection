# Prepared reel playback — Android

## Why the old cache still paused

The earlier implementation cached video ranges and started seeking during the slide animation. A cache hit avoided a download, but the visible video element still had to flush its decoder and seek. Increasing its forward buffer did not remove that step.

The Android path now uses a bounded pool of real video surfaces. Only the selected surface is audible and playing. The next and previous surfaces are paused at their prepared starting frames. A committed swipe selects an already prepared element before the browser paints the new reel, instead of seeking the foreground element after the animation.

## Preparation layers

1. **Import/profile preparation:** fetch openings for the first three reels of the imported/selected lecture. This starts without waiting for the user to press Play. Data Saver/2G prepares only the first opening.
2. **Decoded neighbours:** three video surfaces by default: current, next and previous. Devices reporting at least eight GiB of memory can use a fourth surface for a second upcoming reel. At the beginning of a lecture unused previous slots can prepare additional upcoming reels. Gesture-time intent can start the next preparation before the slide finishes. Low-memory devices and constrained connections use two surfaces. Standby surfaces are paused, muted and retain small buffers; they never contribute watch time.
3. **Surrounding openings:** prepare approximately four seconds at nearby starts. Initially prioritize current, next in the swipe direction, the other neighbour, then the second in the swipe direction. After five seconds of dwelling, extend to five in the current direction and two behind. Changing direction reverses the priority.
4. **Bounded native cache:** parse the MP4 segment index and request only the needed video/audio byte ranges. One background worker touches at most 16 one-MiB media blocks per job, plus index overhead. Blocks already cached do not need another download. New viewport requests invalidate stale jobs between block requests. The existing cache limit and LRU eviction apply.

The foreground retains a larger playback buffer than standby surfaces. Preparation begins at HD 720p where available; adaptive playback may use lower quality when necessary and allows 1080p after stable viewing. Already buffered lower-resolution segments may play before a quality upgrade becomes visible. Playback buffers are not a whole-lecture download.

Leaving or hiding active playback, or clearing the video cache, cancels that playback's opening preparation. Explicit import/profile priming is also bounded and may finish if the user leaves before it completes. No additional scheduler work starts while the active video is paused; bounded in-flight work may finish. The website and isolated saved-note playback retain their single-player path.

## Tile and incoming-frame previews

Prepared surfaces publish their starting frame as a small JPEG. These exact prepared-frame previews are reused by incoming swipe panels and profile tiles. The JavaScript image cache is capped at eight MiB/128 images. Persisted JPEGs use the same bounded native cache as video parts.

For tiles not decoded yet, NewPipe's timestamped YouTube storyboards provide inexpensive distinct previews. A storyboard is sampled periodically, so its image may be near a reel boundary rather than the exact boundary frame. Downloading and decoding every reel solely to make exact thumbnails would add substantial data and CPU work; this implementation does not do that. Storyboard sheets are shared, fetched lazily and decoded under an eight-MiB bitmap cache. If previews are unavailable, the original cover remains the fallback.

User Screen Notes remain separate from this disposable preview cache. Captions stay timed to the full lecture and rebind to the selected video surface. A small caption-text cache prevents downloading the same subtitle file on every surface switch.

## Research

- [Android Developers: Instagram and Facebook preload](https://android-developers.googleblog.com/2026/03/instagram-and-facebook-deliver-instant.html) describes adjacent readiness in memory using Media3 PreloadManager and reducing work under device pressure. MicroGram applies the readiness principle with its existing HTML/MSE player; it does not claim to use Instagram's code or Media3.
- [Meta's video delivery system](https://engineering.fb.com/2024/12/10/video-engineering/inside-facebooks-video-delivery-system/) describes media prefetching and in-memory pools.
- [Shaka's preload documentation](https://shaka-project.github.io/shaka-player/docs/api/tutorial-preload.html) distinguishes manifest/segment preparation from attached playback.
- [NewPipe Frameset source](https://github.com/TeamNewPipe/NewPipeExtractor/blob/v0.26.5/extractor/src/main/java/org/schabi/newpipe/extractor/stream/Frameset.java) defines storyboard timing and frame bounds.

## Validation and limits

On the connected Android 15 phone, the initial initial corrected three-surface pool kept the current surface playing and both neighbours paused and ready. Four forward switches measured **360, 371, 349 and 342 ms**, including the existing 280 ms slide. A mixed forward/reverse sample measured **354, 347, 335 and 567 ms**. These are small device observations, not cross-device guarantees. The previous single-element implementation measured roughly 664 ms in its earlier sample.

First-three-opening preparation completed on the device, touching four cache blocks in that check. Timestamp preview requests at 0, 60 and 120 seconds returned distinct JPEGs of roughly two KiB each. Capture from the selected pool surface returned a valid 1280×720 Screen Note preview.

The final high-memory build kept four surfaces ready on the eight-GiB test device. Six rapid forward swipes, with only 150 ms between measurements, took **349, 327, 329, 316, 320 and 1158 ms**. The sixth outran the prepared window. The first five therefore started playing roughly 36�69 ms after the existing 280 ms slide completed; the sixth demonstrates the bounded fallback rather than an unconditional instant-play claim.

Validation: 90 frontend unit tests, eight native unit/live tests and the production-browser playback/capture regression passed. On-device checks confirmed speed 1.5× and a Hindi subtitle track with 1209 cues followed a surface switch; the original 1×/captions-off settings were restored afterward. Profile tiles loaded timestamp-specific images, and the installed APK preserved existing library/progress/notes data.

YouTube controls the encodings, keyframes, availability and CDN. Skipping beyond prepared neighbours, very slow connections, resource pressure and unavailable sources can still cause waiting. The bounded fallback loads the requested reel without creating unlimited players or downloading complete lectures.


## Per-video layout and adaptive quality

- The viewer measures its actual stage, excluding navigation. Automatic fill retains at least 94% of the picture; larger crops default to fit. Rotation is included in that calculation. Explicit fit/fill and rotation choices persist per video in version-compatible backups.
- Incoming and previous reel stills use the same fit/fill and rotation resolver as playback. Profile tiles always cover their rectangles. Dimensions discovered by prepared surfaces are shared with the resolver before activation.
- Quality offers Automatic, Higher picture quality, Data saver, and available resolution ceilings. These are adaptive preferences, not forced bitrate locks: all lower representations remain eligible. Standby surfaces cap at 720p (or the lower chosen ceiling); the foreground permits the chosen ceiling after five healthy seconds with at least three seconds buffered. A real foreground stall temporarily caps at 480p, then restores the preference after recovery. Data saver caps at 360p. This cannot guarantee zero buffering on a connection that cannot sustain even the lowest available representation.
- The menu reports the rendered video height, rather than claiming the selected ceiling is already displayed. Already buffered segments can retain their previous quality briefly.
- Quality changes configure existing controllers and do not rebuild the decoder pool. Preferences are independent for each source video.

## Progressive profile thumbnails

Initial storyboard previews have a restrained gray shimmer while loading. A single muted video-only decoder then captures better exact frames for visible profile tiles without playing their audio or recording watch time. It has a half-second buffering goal and no segment prefetch. Completed frames reuse the existing 640px JPEG memory/disk cache; full-bleed tile layout is unchanged.

Only visible/near-visible tiles request upgrades. At most 12 captures or 12 MiB of decoder-reported transferred media are allowed per minute; native one-MiB block rounding and manifest/index requests add overhead. Leaving the tiles cancels queued/current work and releases the decoder. Work also pauses while an active reel is playing. Low-bandwidth conditions can delay upgrades; the quick preview remains usable meanwhile.

Quality controls are informed by [YouTube's documented quality modes](https://support.google.com/youtube/answer/91449?co=GENIE.Platform%3DAndroid&hl=en) and implemented through the pinned Shaka Player's adaptive bitrate and representation restrictions. The crop threshold and buffer recovery policy are MicroGram's design decisions.


November 1 validation: 95 frontend tests pass; Android assembly and six non-network native unit tests pass (two opt-in extractor live tests skipped in this build). On the connected phone, visible profile frames upgraded to 640px without opening reels, the decoder released afterward, and a touch-driven incoming preview preserved fit letterboxing. Fill persisted when reopening another reel of the same video. Quality choices remain discoverable after lowering the preference; the controller uses soft ABR restrictions, retaining lower-resolution recovery and allowing the lowest available stream if a saved ceiling is unavailable. Explicit changes preserve two buffered seconds while replacing later data.


## Library covers and overlay consistency

Library covers request maxresdefault first, then fall back through SD/HQ only if the larger cover is unavailable (including YouTube's tiny HTTP-200 placeholder). This is independent of low-resolution timestamp previews. Unconfigured videos default to Higher picture quality; explicit saved preferences remain unchanged.

The immersive current and incoming panels render the same ReelOverlay component: identical title/avatar/timestamp geometry and identical numeric counter markup. Legacy preview-specific layout rules exclude this shared overlay. Visible thumbnail upgrades enter the queue before preview-image load callbacks and are processed in lecture/timestamp order, avoiding network completion order deciding the upgrade sequence.


Validation for the overlay/cover patch: 99 frontend tests pass, including shared active/preview markup, maximum-resolution cover priority, timestamp queue ordering and Higher picture quality defaults. Android assembly and non-network native checks pass. On the phone, five Library covers loaded maxresdefault at 1280px. Active and incoming title, avatar, timestamp and counter coordinates matched exactly relative to their panels. USB disconnected after these measurements; the updated APK was already installed.


## Saved media caching and section gestures

High-resolution Library covers are warmed on launch/import (two image requests at a time, first six covers) and retain a bounded 24 MiB decoded-image working set. Screen Notes reuse stable object URLs across remounts, deduplicate concurrent IndexedDB reads, and warm the first three cover photos of the first six albums. The URL cache is bounded to 64 entries / 16 MiB of blob data and invalidates on replacement/deletion. First-time network cover requests can still take time; warm navigation avoids repeat reads and decode work.

Saved's Screen Notes, Notes and Reels panels follow horizontal touch movement and settle with a 220ms slide. Vertical scrolling, album navigation and the main bottom tabs keep their existing behavior. Offscreen panels are hidden/inert; options menus are not clipped at rest. The former album borders are restored from d4ad2a7 (2px #b5acb1, front #ece7e9), retaining cover fill.

The circular launcher wordmark is generated as vectors and density-specific PNGs from the app's Manrope typeface, with black background and #ff4e94 lettering. The reference's rounded dots are drawn as circles; no white outer background is included. Rebuild with scripts/generate-brand-icon.py; the font license is included under public/font-notices.

Validation: 102 frontend tests and Android build/unit checks pass. Connected-phone navigation loaded Library covers in about 273ms and reused identical loaded album image URLs on return in about 131ms. Left and right Saved swipes traversed all three sections successfully; each layer's restored photo border was checked on-device. Timings are warm-cache observations, not network guarantees.


Saved pager correction: pointer capture after horizontal intent, full-height target, measured panel heights, continuous indicator. White/pink wordmark now used for launcher and black startup screen. 99 frontend tests and Android checks passed. Real lower-screen touches at y=620 traversed all three sections in both directions on the phone; indicator followed each drag. APK installed preserving data.

Saved refinements: album borders increased from 2px to 3.5px preserving the historical colors and shape. Splash uses a dedicated 288dp vector rather than a launcher-sized 108dp drawable. Pager uses one timed completion path, clips moving panels independently, and reserves measured content height to prevent browser scroll clamping. Section changes preserve the visible outer scroll position. Real phone tests with a temporary tall DOM fixture preserved scrollY=350.095 across four alternating swipes; no data was changed. 99 tests and Android build/native checks passed.

Saved shared-track revision: one flex track moves every panel with a single transform; panels clip their own content. Incoming sections offset their first content to the visible top when the outgoing page is deeply scrolled, then atomically normalize outer scroll to the content boundary at settle. Phone measurements from scrollY=500 landed at content start (scrollY=152.38, viewport top approximately zero). Mid-drag adjoining edges matched within floating-point rounding in both directions. Splash artwork enlarged 25% within its vector viewport. 99 frontend tests and Android build/native checks passed; APK installed.

Phone visual correction: swipe viewport owns full-width gutters and a viewport-based minimum even when content is empty. Panels contain their content inside padded full-width bounds. Album stack inset 36px 20px 10px keeps every rotated photo within its cover; all three layer bounds checked on phone. Empty-content DOM fixture swiped at y=700 through all three sections and back. Mid-swipe screenshots visually inspected. Splash vector uses mask-safe scale80/1024 with offset14; cold-start screenshot shows no clipped letters. Existing data retained.

Home feed: reusable authored posts wrap all existing Home sections with Idraak / @idraakk and the temporary MicroGram avatar. One background, thin post separators, no nested card surfaces. Existing learning goal/heatmap functionality retained. Footer links Instagram idraakk and LinkedIn /in/idraak. Home wordmark and vector startup artwork include by Idraak. Phone screenshots inspected; four post surfaces have no background-image or border; link destinations checked. 99 frontend tests and Android build/native checks passed.

Brand/profile refinement: Android system splash uses a transparent icon; a rectangular native startup overlay renders the vector wordmark and lighter Manrope 400 signature without circular clipping. It fades after the first WebView visual state with a short minimum visibility and bounded fallback. Home credit uses Manrope 400, content line heights tightened, and social/privacy links share one footer. Optional local username validates 1-30 letters/numbers/dot/underscore; older name-only profiles and backups remain accepted. Clear Data resets both profile drafts. Phone verified unified footer, working privacy action, 400-weight credit and username field. Cold-start captures confirmed full unmasked signature. 99 existing tests plus username compatibility test pass; Android build/native checks pass.

Learner profiles/feed update: required username in setup/editor, optional local photo chosen through circular drag/pinch/slider cropper. A 384px JPEG is saved in profile state with a 400KB data-URL schema ceiling, included in backups; name-only legacy profiles remain compatible. Phone crop fixture output 19KB,384x384; fixture was discarded. Goal/year posts use learner name/username/photo; creator posts retain Idraak. Introduction post explains chosen-duration YouTube reels and organized screen captures above an SVG wordmark with italic signature. Credit removed from Home header, wordmark enlarged, steps compacted, footer LinkedIn precedes Instagram and creator credit italicized. Native status top inset now becomes scrollable CSS padding rather than fixed native padding; bottom/keyboard and side protection retained. Reels toolbar top measured exactly equal to native status inset (51.81 CSS px). Home/Library/Insights main content moved from y=51.81 to y=-128.38 at scroll180, confirming drawing behind status region. Saved uses the same inset but short lists naturally have less scroll extent. 100 tests, Android build/native checks passed.

Home polish: prior work committed as 82d034e. Intro creator badge, paragraph break before Capture a frame, rounded brand image, reduced settings icon. Startup signature 10% smaller in medium italic Manrope. Home snapshots progress-first ordering on mount after any learning activity; it never reorders during the mounted visit. Footer docks only at document end and releases on scroll up; phone confirmed its bottom meets bottom navigation. Photo crop adds dim outside-circle image/grid, compact controls and explicit Cancel. Phone confirmed 240px crop circle inside 272px preview; Cancel retained existing avatar after zoom. 100 tests and Android build/native checks passed. Native screenshot review used because WebView screenshot capture timed out for this overlay.

Reference styling refinement: upright right-aligned credit with muted by and brighter Idraak in both vector startup and SVG brand post. Intro text #f3f5f7 with 15px/19.5px line metrics (13.3% tighter). Badge uses blue fill, dark check and no outer stroke. Threads live inspection was rate limited, so these values match the requested appearance rather than a claimed exact measured native Threads specification. Crop sheet portaled outside the profile modal to document body; phone sheet width399.43 at x6 on411px viewport. Grid spacing48px with1.5px lines, visually reviewed using native screenshot. Test fixture discarded without saving. 100 frontend tests and Android build/native checks passed.
