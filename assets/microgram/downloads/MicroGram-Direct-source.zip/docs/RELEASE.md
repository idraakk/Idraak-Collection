# Android and production release runbook

## Current status

The web application, API service, and Android source project are implemented. This workspace has no configured YouTube key, production host, signing keystore, Android SDK/JDK, or Play Console credentials. No APK/AAB has been compiled or published. Real-device YouTube playback must be verified before a release claim.

## Configure YouTube

1. Create/select a Google Cloud project, enable YouTube Data API v3, and create an API key.
2. Restrict it to YouTube Data API v3 and your backend environment where supported. Set quota/budget alerts.
3. Copy `.env.example` to `.env`. Set `YOUTUBE_API_KEY` on the server only. Never use a `VITE_` prefix for secrets.
4. Import a real multi-video public playlist. Verify titles, ordering, unavailable entries, counts, final partial reels, and a private playlist failure.

References: [Data API getting started](https://developers.google.com/youtube/v3/getting-started), [player API](https://developers.google.com/youtube/iframe_api_reference), [developer policies](https://developers.google.com/youtube/terms/developer-policies), [minimum functionality](https://developers.google.com/youtube/terms/required-minimum-functionality).

## Deploy the API and web app

Use Node 22+ (tested here with Node 24), `npm ci`, `npm run check`, then `npm start`. The server serves `dist` and `/api` on `PORT` (default 3001). A container definition is included. Terminate TLS at the hosting platform or reverse proxy. Set the exact web and native origins in `ALLOWED_ORIGINS`. Configure health checks at `/api/health`.

Before opening public access, configure trusted proxy behavior, shared request limits if using multiple instances, uptime/error monitoring, and Google quota alerts. Record actual host log retention and operator contact information in the published privacy policy. The in-app privacy copy is a product disclosure, not a completed store-hosted policy with your legal/operator details.

## Build Android

1. Install Android Studio, a compatible JDK, and the Android SDK required by `android/variables.gradle` (compile/target 36, minimum 24 in this generated project).
2. Set `VITE_API_BASE_URL=https://your-api-host` before building. Native `localhost` is the phone, not your development computer. Rebuild whenever this setting changes.
3. Run `npm run android:sync`, then `npm run android:open`.
4. Confirm the final application ID (`app.microgram.learn` is currently a provisional identifier), name, version code, icons, and signing ownership before first publication.
5. Run on a physical device. Generate a signed Android App Bundle from Android Studio only after verification. Keep keystores and passwords outside this repository.

Capacitor docs: [Android setup](https://capacitorjs.com/docs/android), [environment setup](https://capacitorjs.com/docs/getting-started/environment-setup).

## Device acceptance checklist

- Video starts after opt-in; player branding/controls are visible and not cropped or covered.
- Verify YouTube client identity/referrer requirements on Android WebView. An error 153 is a release blocker; do not work around it by extracting/downloading video streams. Browser success alone is insufficient.
- Portrait and landscape, small screens, display/font scaling, TalkBack labels, system bars, gesture/back navigation, reduced motion.
- Swipe during playback, first/last reel, crossing lecture boundaries, final short reel, replay, buffering, embedded-player seeking.
- App switching, screen lock, audio interruption: no hidden playback or progress accumulation.
- Airplane mode, recovery, quota exhaustion, restricted/private/deleted videos, and very long playlists.
- Native share sheet, timestamp links, backup export/restore, app restart, storage-full behavior, and full deletion.
- No source lecture is cropped into unreadability, including landscape equations and screen recordings.

## Play Console

Supply your developer identity, package ownership, signing, store listing assets, support contact, a publicly accessible privacy policy, content-rating answers, target audience, and accurate Data Safety declarations reflecting YouTube and hosting behavior. Check current Google Play requirements at submission time. Do not declare “no data collected” without evaluating embedded YouTube and server/network processing.

For applicable new personal accounts, Google currently requires a closed test with at least 12 opted-in testers for 14 continuous days before applying for production access. [Official testing requirements](https://support.google.com/googleplay/android-developer/answer/14151465).

Launch first to a small internal/closed cohort. Resolve playback failures and misleading progress before expanding distribution. Store approval and product adoption cannot be guaranteed.
