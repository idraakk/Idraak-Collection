# Saved playback, lecture speed and note motion

Baseline committed as 9a0639d before this patch.

- Tab changes, including Back to Home, clear page transition state and outgoing snapshots immediately. The profile Back action retains its short exit animation; opening profile/reel detail remains animated.
- Playback speed belongs to each underlying lecture video ID, survives refresh and backup, and applies across that lecture's reels. Other videos retain their own rate (default 1x). The old global speed preference is no longer applied to unrelated lectures.
- Saved uses a three-column reel grid plus a separate Notes list. Saved playback keeps Saved selected, navigates within its captured saved/notes collection, returns to that list on Back, and preserves its position through refresh.
- Saved references are resolved using their original reel lengths, so changing the global reel duration does not hide old bookmarks or notes. Duplicate IDs and equivalent video/time ranges are grouped; different timestamps remain distinct. Underlying note text is preserved. Loading state normalizes repeated bookmark IDs.
- Notes highlight pink when the current moment has text. The panel opens from the Notes control in 160ms and closes back toward it in 150ms; reduced-motion preferences are respected. Back, Escape, Done and backdrop dismissal follow the same close path. Notes entered without bookmarks appear in the Notes list; entering a note no longer automatically bookmarks it.
- Notes open with playback paused, including when opened directly from the Notes list. Short desktop sidebars can scroll to their bottom controls.

Validation: 47 unit tests passed. Browser checks covered deduplication, original-duration saved clips, speed isolation across different videos and persistence on refresh, Saved-tab playback and return, standalone notes and pink highlighting, reverse note animation, instantaneous tab Back and preserved profile transitions. Existing native-player, captions, hold speed and refresh navigation checks passed. Screenshots reviewed: artifacts/saved-grid.png, artifacts/saved-notes.png and artifacts/reel-note-dialog.png. Production build and Android asset sync passed. Actual Android hardware Back still needs a device smoke test.
