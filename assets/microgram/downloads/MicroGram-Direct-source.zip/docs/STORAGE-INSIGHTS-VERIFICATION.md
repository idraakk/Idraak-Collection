# Storage recovery, import safeguards and learning insights

Implemented 2026-10-30. Baseline changes committed as 7855e06.

## Storage diagnosis and fix

The screenshot's storage error was reproducible from the reservation code: every video reserved the 2 GiB file ceiling plus 6 GiB of scratch space and a 1 GiB disk margin, so the disk check required 7 GiB free regardless of actual video size. This server had no cached MP4s and approximately 4.95 GiB free.

Preparation now probes the selected formats, estimates their combined bytes with headroom, and reserves temporary space in proportion to that estimate. Missing size metadata uses a bounded fallback. Completed size and the cache budget are checked before the file is promoted; the existing 2 GiB file cap remains. A disk guard stops ongoing preparation below 256 MiB free. Low disk and full cache errors explain different remedies. Clearing downloads or changing the budget invalidates stale storage-failure jobs.

Reference for size metadata and JSON output: [yt-dlp documentation](https://github.com/yt-dlp/yt-dlp#output-template).

Live validation: the starter lecture fNk_zzaMoSs successfully reached ready on this server with under 5 GiB free; the resulting MP4 is 22,029,396 bytes. No user files were deleted to make this test pass.

## Playlist safeguards

A malformed list parameter no longer falls back silently to a single video. Valid watch/share URLs with a playlist retain playlist precedence. The import dialog previews whether the link is a playlist or a single video. Successful imports clear an older remembered Library profile so it cannot reopen an unrelated video. Existing ID validation, playlist identity, ordering, pagination, persistence and duplicate-video safeguards remain.

The previously supplied live playlist PLtUBJBQF5VJgSzegWtlFiNTWehra8eSHU imported as its own playlist card and survived refresh. The exact intermittent report was not reproduced for every possible link; a shared link without a playlist ID genuinely identifies only a video.

## Insights, settings and theme

Insights provides 7/30-day playback activity, active days, current streak, goal days, deduplicated library coverage, completed reels, remaining video time and course-level progress. Playback time is labelled as video time including replays; coverage counts watched seconds once across shared videos. The calculation note explains reel-length changes and current-goal comparisons.

Settings distinguishes local learning data from server video files, includes Home reflections in backup/clear descriptions, and confirms storage-budget changes that can evict downloads. Secondary storage explanations are collapsible. Primary buttons, dialogs, import validation, toasts, storage errors and utility pages use MicroGram Pink. Playback error overlays provide Manage storage and hide unrelated playback controls.

Validation: 40 unit tests passed. Targeted browser checks covered new Insights/Settings, recovery UI, playlist import and mismatched responses, cache protections, native playback and Reels resume. The live playlist test passed. Production build passed. Phone and desktop screenshots are in artifacts/insights-mobile.png, artifacts/insights-desktop.png, artifacts/settings-themed.png and artifacts/storage-recovery.png.
