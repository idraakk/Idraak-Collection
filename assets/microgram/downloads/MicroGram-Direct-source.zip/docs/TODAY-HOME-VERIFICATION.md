# Today Home, Library return and safe removal

Baseline commit: 7702f33.

Home is now a personal Today workspace: a 3/5/10-minute suggested learning window, a resumable lecture, an editable learning intention, and a daily reflection journal (up to 30 entries). It does not enforce a timer or invent social activity. These fields use the existing local state and backup format; older state remains compatible.

Library remembers the profile used to launch playback. Selecting Library from playback restores that profile and its scroll position; the profile Back arrow returns to the list. White speed/watching rings now have heavier white edges and dark shadows for bright footage.

Library removal and download cleanup use a themed modal confirmation with Cancel as initial focus. Back/Escape cancel before any request, and destructive work disables dismissal while busy. Settings cache and original-file deletion use the same dialog. Copy accurately identifies media storage as the server, not necessarily the phone. Existing shared/active/original protections are unchanged.

Browser coverage checks local Home draft persistence, profile restoration, no deletion before confirmation, Back cancellation, accepted removal, and storage protections. Home phone/desktop and removal-dialog screenshots are in artifacts/today-mobile.png, artifacts/today-desktop.png and artifacts/remove-confirmation.png.
