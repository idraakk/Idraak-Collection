import { setupName } from './setupName';
import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, starter } from '../src/storage';
async function playback(page: Page) {
  const cover = await readFile('public/local-cover.svg');
  await page.route('https://i.ytimg.com/**', (r) =>
    r.fulfill({ contentType: 'image/svg+xml', body: cover }),
  );
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 15,
      courses: [{ ...starter, videos: [{ ...starter.videos[0], duration: 40 }] }],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.route('**/api/media/storage/clear', (r) =>
    r.fulfill({ json: { freed: 0, removed: 0, skipped: 0 } }),
  );
}
test('feed, bookmarks, notes, duration, persistence, and empty library work', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await playback(page);
  await page.goto('/');
  await setupName(page);
  await expect(page.locator('.today-home')).toBeVisible();
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await page.getByRole('button', { name: 'Save moment', exact: true }).click();
  await page.getByRole('button', { name: 'Add a note' }).click();
  await page.getByLabel('Your takeaway').fill('Vectors have magnitude and direction.');
  await page.getByRole('button', { name: 'Done', exact: true }).click();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await page.getByRole('tab', { name: /^Notes/ }).click();
  await expect(page.getByText('Vectors have magnitude and direction.')).toBeVisible();
  await page.reload();
  await page.locator('.sidebar').getByRole('button', { name: 'Settings', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Reel duration', exact: true })).toHaveCount(0);
  await page
    .locator('.sidebar')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.locator('.feed-options summary').first().click();
  await page.getByRole('button', { name: 'Remove from library' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Remove', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Your next lecture starts here' })).toBeVisible();
  expect(errors).toEqual([]);
});
test('import validates links, handles server configuration, and imports a playlist', async ({
  page,
}) => {
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Import a playlist', exact: true }).click();
  await page.getByLabel('YouTube link').fill('https://example.com/lecture');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('alert')).toContainText('youtube.com');
  await page.route('**/api/import', (route) =>
    route.fulfill({ status: 503, json: { error: 'Imports need a YouTube API key.' } }),
  );
  await page.getByLabel('YouTube link').fill('https://youtu.be/fNk_zzaMoSs');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('alert')).toContainText('API key');
  await page.route('**/api/import', (route) =>
    route.fulfill({
      json: {
        course: {
          id: 'test-playlist',
          title: 'Test playlist',
          channel: 'Teacher',
          importedAt: Date.now(),
          videos: [
            {
              id: 'aaaaaaaaaaa',
              title: 'First lecture',
              channel: 'Teacher',
              duration: 125,
              thumbnail: 'https://i.ytimg.com/vi/aaaaaaaaaaa/hqdefault.jpg',
            },
            {
              id: 'bbbbbbbbbbb',
              title: 'Second lecture',
              channel: 'Teacher',
              duration: 60,
              thumbnail: 'https://i.ytimg.com/vi/bbbbbbbbbbb/hqdefault.jpg',
            },
          ],
        },
        skipped: 1,
      },
    }),
  );
  await page.getByLabel('YouTube link').fill('https://youtube.com/playlist?list=test-playlist');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(
    page.locator('.youtube-feed-card').filter({ hasText: 'Test playlist' }),
  ).toBeVisible();
  await page.getByRole('button', { name: 'Open Test playlist profile' }).click();
  await expect(page.getByRole('heading', { name: 'Test playlist', exact: true })).toBeVisible();
  await expect(page.locator('.profile-reel-tile')).toHaveCount(4);
  await expect(page.locator('.profile-reel-tile').first()).toHaveAttribute(
    'aria-label',
    /Play reel 1: First lecture, 0:00 to 1:00/,
  );
  await expect(page.locator('.profile-reel-tile').last()).toHaveAttribute(
    'aria-label',
    /Play reel 4: Second lecture, 0:00 to 1:00/,
  );
});
test('mobile layout has no horizontal overflow and navigates reels', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await playback(page);
  await page.goto('/');
  await setupName(page);
  await expect(page.locator('.mobile-nav')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  );
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page.screenshot({ path: 'artifacts/mobile.png', fullPage: true });
  await page.locator('.mobile-nav').getByRole('button', { name: 'My progress' }).click();
  await expect(page.getByRole('heading', { name: 'Insights', exact: true })).toBeVisible();
});
test('desktop reference screenshot', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/');
  await setupName(page);
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: 'artifacts/desktop.png', fullPage: true });
});
