import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial } from '../src/storage';

test('completion feedback counts watched reels once and survives navigation and reload', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 15,
      courses: [
        {
          id: 'completion-test',
          title: 'Completion test',
          channel: 'Test',
          importedAt: Date.now(),
          videos: [
            {
              id: 'feedback001',
              title: 'Quiet completion',
              channel: 'Test',
              duration: 40,
              local: true,
              thumbnail: '/local-cover.svg',
            },
          ],
        },
      ],
    },
  );
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const counter = page.locator('.reels-watched');
  const badge = page.locator('.reel-completion');
  await expect(counter).toHaveAttribute('aria-label', '0 of 3 reels watched in this lecture');
  await expect(badge).not.toHaveClass(/is-complete/);
  // Real playback must earn completion; opening a reel alone does not.
  await expect(counter).toHaveAttribute('aria-label', '1 of 3 reels watched in this lecture', {
    timeout: 20000,
  });
  await expect(badge).toHaveClass(/is-complete/);
  await page.getByRole('button', { name: 'Pause lecture' }).click();
  await page.screenshot({ path: 'artifacts/reel-completion.png' });
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(badge).not.toHaveClass(/is-complete/);
  await expect(counter).toHaveAttribute('aria-label', '1 of 3 reels watched in this lecture');
  await page.keyboard.press('ArrowUp');
  await expect(badge).toHaveClass(/is-complete/);
  await expect(counter).toHaveAttribute('aria-label', '1 of 3 reels watched in this lecture');
  await page.reload();
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(counter).toHaveAttribute('aria-label', '1 of 3 reels watched in this lecture');
  await expect(badge).toHaveClass(/is-complete/);
});
