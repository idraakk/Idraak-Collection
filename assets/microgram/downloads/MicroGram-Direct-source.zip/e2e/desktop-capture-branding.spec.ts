import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial } from '../src/storage';

test('laptop frame capture opens an editor and saves a readable image', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  const video = {
    id: 'landscape01',
    title: 'Desktop lecture',
    channel: 'Teacher',
    duration: 35,
    thumbnail: '/local-cover.svg',
    local: true,
  };
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    consent: true,
    profile: { name: 'Alex' },
    courses: [
      {
        id: 'desktop',
        title: video.title,
        channel: video.channel,
        importedAt: Date.now(),
        videos: [video],
      },
    ],
  });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/landscape-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const player = page.locator('.native-video');
  await expect
    .poll(() => player.evaluate((v: HTMLVideoElement) => !v.paused && v.readyState >= 2))
    .toBe(true);
  await player.click();
  const capture = page.getByRole('button', { name: 'Capture screen note' });
  await expect(capture).toBeVisible();
  const before = (await capture.boundingBox())!;
  await page.mouse.move(before.x + before.width / 2, before.y + before.height / 2);
  await page.mouse.down();
  await page.waitForTimeout(250);
  const pressed = (await capture.boundingBox())!;
  expect(Math.abs(pressed.x - before.x)).toBeLessThan(2);
  expect(Math.abs(pressed.y - before.y)).toBeLessThan(2);
  await page.mouse.up();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect
    .poll(() =>
      page.locator('.screen-note-full-frame img').evaluate((i: HTMLImageElement) => i.naturalWidth),
    )
    .toBeGreaterThan(0);
  await page.getByLabel('Label optional', { exact: true }).fill('Desktop capture');
  await page.getByRole('button', { name: 'Save screen note', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  expect(
    await page.evaluate(
      () => JSON.parse(localStorage.getItem('microgram.v1')!).screenNotes[0].label,
    ),
  ).toBe('Desktop capture');
});

test('desktop branding shares one pink mark; the mobile layout keeps it hidden', async ({
  page,
  request,
}) => {
  const health = await request.get('/api/health');
  expect(health.headers()['content-security-policy']).toMatch(/img-src[^;]*blob:/);
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
  });
  await page.goto('/');
  await expect(page).toHaveTitle('MicroGram');
  await expect(page.locator('.sidebar .brand-icon')).toBeVisible();
  await expect(page.locator('.app-footer .brand-icon')).toBeVisible();
  const icon = await page.locator('link[rel="icon"]').getAttribute('href');
  expect(
    await page
      .locator('.brand-icon')
      .evaluateAll((images) => images.map((i) => i.getAttribute('src'))),
  ).toEqual([icon, icon]);
  await page.screenshot({ path: 'artifacts/branding-desktop.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.locator('.brand-icon:visible')).toHaveCount(0);
});
