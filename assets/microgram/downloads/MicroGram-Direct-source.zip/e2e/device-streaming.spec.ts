import { test, expect } from '@playwright/test';
import { initial } from '../src/storage';
test.skip(!process.env.STREAM_TEST_URL, 'Set STREAM_TEST_URL to an experimental streaming server.');
test.use({ baseURL: process.env.STREAM_TEST_URL || 'http://localhost:3002' });
for (const videoId of (process.env.LIVE_VIDEO_IDS || 'fNk_zzaMoSs,aircAruvnKk,3JZ_D3ELwOQ').split(
  ',',
)) {
  test(`live HD streaming plays, seeks and captures ${videoId}`, async ({ page }) => {
    test.skip(process.env.LIVE_STREAM !== 'true');
    test.setTimeout(150000);
    let warmRequests = 0;
    page.on('request', (r) => {
      if (r.headers()['x-microgram-prefetch'] === '1') warmRequests++;
    });
    page.on('console', (m) => {
      if (m.text().startsWith('Adaptive startup')) console.log(m.text());
    });
    page.on('response', (r) => {
      const path = new URL(r.url()).pathname;
      if (r.status() >= 400 && path.startsWith('/api/stream/'))
        console.log('Stream response', r.status(), path);
    });
    await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
      ...initial,
      consent: true,
      profile: { name: 'Streaming test' },
      courses: [
        {
          id: 'stream',
          title: 'Streaming test',
          channel: 'Test',
          importedAt: Date.now(),
          videos: [
            {
              id: videoId,
              title: 'Streaming test',
              channel: 'Test',
              duration: 240,
              thumbnail: '/local-cover.svg',
            },
          ],
        },
      ],
    });
    await page.goto('/');
    await page.getByRole('button', { name: 'Play this reel' }).click();
    await expect
      .poll(() => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.currentTime), {
        timeout: 80000,
      })
      .toBeGreaterThan(1);
    if (process.env.RAPID_SWIPES === 'true') {
      for (let i = 1; i <= 3; i++) {
        await page.waitForTimeout(2500);
        const started = Date.now();
        await page.keyboard.press('ArrowDown');
        await expect
          .poll(
            () =>
              page.locator('.native-video').evaluate((v: HTMLVideoElement) => ({
                ready: v.readyState >= 3 && !v.seeking,
                time: v.currentTime,
              })),
            { timeout: 15000 },
          )
          .toMatchObject({ ready: true });
        await expect
          .poll(
            () => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.currentTime),
            { timeout: 15000, intervals: [50] },
          )
          .toBeGreaterThan(i * 60 + 0.1);
        console.log('Rapid swipe to reel', i + 1, 'playback ms', Date.now() - started);
      }
      expect(warmRequests).toBeGreaterThan(0);
      console.log('Reel prefetch requests', warmRequests);
      return;
    }
    await expect
      .poll(() => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.videoHeight), {
        timeout: 30000,
      })
      .toBeGreaterThanOrEqual(720);
    await page.locator('.native-video').evaluate((v: HTMLVideoElement) => {
      v.currentTime = 25;
      v.playbackRate = 2;
    });
    await expect
      .poll(() => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.currentTime), {
        timeout: 30000,
      })
      .toBeGreaterThan(26);
    const decoded = await page.locator('.native-video').evaluate((v: HTMLVideoElement) => ({
      height: v.videoHeight,
      audioBytes: (v as HTMLVideoElement & { webkitAudioDecodedByteCount: number })
        .webkitAudioDecodedByteCount,
    }));
    console.log('Decoded media', videoId, decoded);
    expect(decoded.audioBytes).toBeGreaterThan(0);
    await page.keyboard.press('ArrowDown');
    await expect
      .poll(() => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.currentTime), {
        timeout: 30000,
      })
      .toBeGreaterThan(61);
    await page.keyboard.press('ArrowUp');
    await expect
      .poll(() => page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.currentTime), {
        timeout: 30000,
      })
      .toBeLessThan(60);
    await page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.pause());
    await page.getByRole('button', { name: 'Capture screen note' }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect
      .poll(() =>
        page
          .locator('.screen-note-full-frame img')
          .evaluate((i: HTMLImageElement) => i.naturalWidth),
      )
      .toBeGreaterThanOrEqual(1280);
    const storage = await page.evaluate(() => fetch('/api/media/storage').then((r) => r.json()));
    expect(storage.used).toBeGreaterThan(0);
    expect(storage.used).toBeLessThanOrEqual(storage.limit);
    if (process.env.WARM_REOPEN === 'true') {
      const started = Date.now();
      await page.reload();
      await expect
        .poll(
          () =>
            page
              .locator('.native-video')
              .evaluate(
                (v: HTMLVideoElement) => v.readyState >= 3 && !v.paused && v.videoHeight >= 720,
              ),
          { timeout: 15000 },
        )
        .toBe(true);
      console.log('Cached reopen to playback (ms)', Date.now() - started);
    }
  });
}

test('device originals play, seek and capture without server uploads; deletion is device scoped', async ({
  page,
}) => {
  const { readFile } = await import('node:fs/promises');
  const body = await readFile('artifacts/landscape-test.mp4');
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    consent: true,
    profile: { name: 'Test' },
    courses: [
      {
        id: 'local',
        reelSeconds: 15,
        title: 'Local lecture',
        channel: 'Me',
        importedAt: 1,
        videos: [
          {
            id: 'localtest01',
            title: 'Local lecture',
            channel: 'Me',
            local: true,
            duration: 35,
            thumbnail: '/local-cover.svg',
          },
        ],
      },
    ],
  });
  await page.goto('/');
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  const result = await page.evaluate(async (b) => {
    const bytes = Uint8Array.from(atob(b), (c) => c.charCodeAt(0));
    return (
      await fetch('/api/media/localtest01/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'video/mp4' },
        body: bytes,
      })
    ).status;
  }, body.toString('base64'));
  expect(result).toBe(200);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const video = page.locator('.native-video');
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThan(1);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.readyState)).toBe(4);
  await page.keyboard.press('ArrowDown');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime)).toBeGreaterThanOrEqual(15);
  await expect(page.locator('.seek-transition-frame')).not.toBeVisible();
  await page.keyboard.press('ArrowUp');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime)).toBeLessThan(15);
  await expect(page.locator('.seek-transition-frame')).not.toBeVisible();
  await video.evaluate((v: HTMLVideoElement) => v.dispatchEvent(new Event('waiting')));
  await page.waitForTimeout(1300);
  await expect(page.getByText('Buffering your video', { exact: true })).not.toBeVisible();
  await video.evaluate((v: HTMLVideoElement) => v.pause());
  await expect(page.getByRole('button', { name: 'Capture screen note', exact: true })).toBeVisible();
  await video.evaluate((v: HTMLVideoElement) => {
    Object.defineProperty(v, 'readyState', { configurable: true, get: () => 1 });
    Object.defineProperty(v, 'paused', { configurable: true, get: () => false });
    v.dispatchEvent(new Event('waiting'));
  });
  await expect(page.getByText('Buffering your video', { exact: true })).toBeVisible();
  await expect(
    page.getByText('Double-tap the video to hide or show the controls.', { exact: true }),
  ).not.toBeVisible();
  await expect(page.getByText('QUICK TIP', { exact: true })).toBeVisible();
  await video.evaluate((v: HTMLVideoElement) => {
    Reflect.deleteProperty(v, 'readyState');
    Reflect.deleteProperty(v, 'paused');
    v.dispatchEvent(new Event('playing'));
  });
  await video.evaluate((v: HTMLVideoElement) => {
    v.pause();
    v.currentTime = 10;
  });
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.seeking)).toBe(false);
  await page.getByRole('button', { name: 'Capture screen note' }).click();
  await expect
    .poll(() =>
      page.locator('.screen-note-full-frame img').evaluate((i: HTMLImageElement) => i.naturalWidth),
    )
    .toBeGreaterThan(0);
  const storage = await page.evaluate(() => fetch('/api/media/storage').then((r) => r.json()));
  expect(storage.entries[0].kind).toBe('upload');
  await page.evaluate(() => fetch('/api/media/storage/clear', { method: 'POST', body: '{}' }));
  expect(
    await page.evaluate(() =>
      fetch('/api/media/storage')
        .then((r) => r.json())
        .then((s) => s.entries.length),
    ),
  ).toBe(1);
  await page.evaluate(() =>
    fetch('/api/media/storage/localtest01?confirm=delete-original', { method: 'DELETE' }),
  );
  expect(
    await page.evaluate(() =>
      fetch('/api/media/storage')
        .then((r) => r.json())
        .then((s) => s.entries.length),
    ),
  ).toBe(0);
});

test('range cache evicts oldest chunks, reuses hits and clears only video bytes', async ({
  page,
  context,
}) => {
  let transfers = 0;
  await context.route('**/api/stream/aaaaaaaaaaa/source', (r) =>
    r.fulfill({ json: { url: 'https://fixture.googlevideo.com/media', relay: false } }),
  );
  await context.route('https://fixture.googlevideo.com/media', (r) => {
    transfers++;
    const start = Number(/bytes=(\d+)-/.exec(r.request().headers().range)![1]);
    return r.fulfill({
      status: 206,
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Range': `bytes ${start}-${start + 1048575}/3145728`,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Expose-Headers': 'Content-Range',
      },
      body: Buffer.alloc(1048576, start ? 2 : 1),
    });
  });
  await page.goto('/');
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  await page.evaluate(() => fetch('/api/media/storage').then((r) => r.json()));
  await page.evaluate(
    () =>
      new Promise<void>((resolve, reject) => {
        const r = indexedDB.open('microgram.video-chunks.v1', 2);
        r.onsuccess = () => {
          const t = r.result.transaction('settings', 'readwrite');
          t.objectStore('settings').put(1048576, 'limit');
          t.oncomplete = () => {
            r.result.close();
            resolve();
          };
          t.onerror = () => reject(t.error);
        };
      }),
  );
  const read = async (start: number) =>
    page.evaluate(async (n) => {
      const r = await fetch('/api/media/aaaaaaaaaaa/file', {
        headers: { Range: `bytes=${n}-${n + 31}` },
      });
      return {
        status: r.status,
        range: r.headers.get('content-range'),
        bytes: [...new Uint8Array(await r.arrayBuffer())],
      };
    }, start);
  expect((await read(0)).bytes).toEqual(Array(32).fill(1));
  expect((await read(1048576)).bytes).toEqual(Array(32).fill(2));
  expect(transfers).toBe(2);
  await read(1048576);
  expect(transfers).toBe(2);
  const snapshot = await page.evaluate(() => fetch('/api/media/storage').then((r) => r.json()));
  expect(snapshot.used).toBe(1048576);
  await read(0);
  expect(transfers).toBe(3);
  await page.evaluate(() => fetch('/api/media/storage/clear', { method: 'POST', body: '{}' }));
  expect(
    await page.evaluate(() =>
      fetch('/api/media/storage')
        .then((r) => r.json())
        .then((s) => s.used),
    ),
  ).toBe(0);
});

test('adaptive cache assembles exact multi-chunk ranges and isolates video/audio tracks', async ({
  context,
  page,
}) => {
  const chunk = 1024 * 1024;
  let requests = 0;
  await context.route('**/api/stream/cachetest01/track/*', async (route) => {
    requests++;
    const range = /bytes=(\d+)-(\d+)/.exec(route.request().headers()['range'])!;
    const start = Number(range[1]),
      end = Math.min(Number(range[2]), 3 * chunk - 1);
    const value = route.request().url().includes('/140?') ? 9 : 1 + Math.floor(start / chunk);
    await route.fulfill({
      status: 206,
      headers: {
        'content-type': 'video/mp4',
        'content-range': `bytes ${start}-${end}/${3 * chunk}`,
      },
      body: Buffer.alloc(end - start + 1, value),
    });
  });
  await page.goto('/');
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  const read = async (format: string, start: number, end: number) =>
    page.evaluate(
      async ({ format, start, end }) => {
        const response = await fetch(
          `/api/stream/cachetest01/track/${format}?version=0123456789abcdef`,
          { headers: { Range: `bytes=${start}-${end}` } },
        );
        return {
          status: response.status,
          range: response.headers.get('Content-Range'),
          bytes: [...new Uint8Array(await response.arrayBuffer())],
        };
      },
      { format, start, end },
    );
  const joined = await read('137', chunk - 17, chunk + 32);
  expect(joined.status).toBe(206);
  expect(joined.bytes).toEqual([...Array(17).fill(1), ...Array(33).fill(2)]);
  expect(joined.range).toBe(`bytes ${chunk - 17}-${chunk + 32}/${3 * chunk}`);
  expect(requests).toBe(2);
  await read('137', chunk - 17, chunk + 32);
  expect(requests).toBe(2);
  expect((await read('140', 0, 3)).bytes).toEqual([9, 9, 9, 9]);
  expect(requests).toBe(3);
  const concurrent = await Promise.all([read('136', 0, 31), read('136', 32, 63)]);
  expect(concurrent[0].bytes).toEqual(Array(32).fill(1));
  expect(concurrent[1].bytes).toEqual(Array(32).fill(1));
  expect(requests).toBe(4);
  await page.evaluate(() =>
    fetch('/api/media/storage/clear', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    }),
  );
  expect(
    await page.evaluate(() =>
      fetch('/api/media/storage')
        .then((r) => r.json())
        .then((s) => s.used),
    ),
  ).toBe(0);
});

test('delayed startup explains loading and the double-tap gesture', async ({ context, page }) => {
  await context.route('**/api/stream/**/manifest.mpd', () => {});
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    consent: true,
    profile: { name: 'Test' },
    courses: [
      {
        id: 'loading',
        title: 'Lecture',
        channel: 'Test',
        importedAt: Date.now(),
        videos: [
          {
            id: 'loadingtest',
            title: 'Lecture',
            channel: 'Test',
            duration: 240,
            thumbnail: '/local-cover.svg',
          },
        ],
      },
    ],
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.getByText('Getting your video ready', { exact: true })).toBeVisible();
  await expect(
    page.getByText('Double-tap the video to hide or show the controls.', { exact: true }),
  ).toBeVisible();
  await page.screenshot({ path: 'artifacts/stream-loading-hint.png' });
});
