import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, starter } from '../src/storage';
test('Home explains MicroGram, Library restores its profile, and deletion requires confirmation', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    { ...initial, profile: { name: 'Alex' }, consent: true },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  let cleared = 0;
  await page.route('**/api/media/storage/clear', (r) => {
    cleared++;
    return r.fulfill({ json: { freed: 1000, removed: 1, skipped: 0 } });
  });
  await page.goto('/');
  await setupName(page);
  await expect(page.locator('.home-purpose')).toContainText('Make your next');
  await expect(page.locator('.home-purpose')).toContainText(
    'Add a YouTube video or a whole playlist.',
  );
  expect(
    await page
      .locator('.today-home > section')
      .evaluateAll((nodes) => nodes.map((n) => n.className)),
  ).toEqual(['home-purpose', 'home-daily-goal', 'home-heatmap', 'home-momentum']);
  await expect(page.locator('.home-momentum')).toContainText(
    'Put that rewarding feeling to work to help you stay with your lectures.',
  );
  await expect(page.locator('.home-momentum-points > div')).toHaveCount(3);
  await expect(page.locator('.home-momentum-points > div').last()).toContainText(
    'Revise later from your Screen Notes Library.',
  );
  await expect(page.locator('.today-session,.today-intention,.today-reflection')).toHaveCount(0);
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.getByRole('menuitemradio', { name: '6 hours', exact: true }).click();
  await page.reload();
  await expect(
    page.getByRole('button', { name: 'Daily learning goal', exact: true }),
  ).toContainText('6 hours');
  await expect(page.locator('.heatmap-goal')).toHaveText('360 min daily goal');
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.getByRole('menuitemradio', { name: '15 minutes', exact: true }).click();
  await page.screenshot({ path: 'artifacts/today-mobile.png', fullPage: true });
  await page.reload();
  await expect(page.locator('.heatmap-goal')).toHaveText('15 min daily goal');
  await expect(page.locator('.home-purpose-steps > div')).toHaveCount(3);
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: 'artifacts/today-desktop.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  const library = page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true });
  await library.click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await page.getByRole('button', { name: /Play reel 2:/ }).click();
  await library.click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await expect(page.locator('.app')).not.toHaveClass(/immersive-mode/);
  await page.getByRole('button', { name: 'Back to library' }).click();
  await page.locator('.feed-options summary').first().click();
  await page.getByRole('button', { name: 'Remove from library', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  expect(cleared).toBe(0);
  await page.screenshot({ path: 'artifacts/remove-confirmation.png' });
  await page.goBack();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.youtube-feed-card')).toHaveCount(1);
  expect(cleared).toBe(0);
  await page.getByRole('button', { name: 'Remove from library', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Remove', exact: true }).click();
  await expect(page.locator('.youtube-feed-card')).toHaveCount(0);
  expect(cleared).toBe(1);
});
