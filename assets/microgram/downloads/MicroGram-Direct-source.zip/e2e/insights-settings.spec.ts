import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial, starter, localDate } from '../src/storage';
test('insights show deduplicated coverage, period activity and themed settings', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const activity = Object.fromEntries(
    [0, 1, 2, 4].map((offset, i) => {
      const d = new Date();
      d.setDate(d.getDate() - offset);
      return [localDate(d), [720, 300, 900, 60][i]];
    }),
  );
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    consent: true,
    courses: [starter, { ...starter, id: 'shared-playlist', title: 'A second course' }],
    activity,
    progress: { fNk_zzaMoSs: Array.from({ length: 180 }, (_, i) => i) },
  });
  let storageLimit = 10;
  let updates = 0;
  await page.route('**/api/media/storage', (r) =>
    r.fulfill({
      json: { entries: [], used: 0, free: 4.9 * 1024 ** 3, limit: storageLimit * 1024 ** 3 },
    }),
  );
  await page.route('**/api/media/storage/limit', (r) => {
    storageLimit = r.request().postDataJSON().gib;
    updates++;
    return r.fulfill({ json: {} });
  });
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My progress', exact: true })
    .click();
  await expect(page.getByRole('heading', { name: 'Insights', exact: true })).toBeVisible();
  await expect(page.getByRole('progressbar', { name: 'Library video coverage' })).toHaveAttribute(
    'aria-valuenow',
    '30',
  );
  await expect(page.locator('.coverage-facts')).toContainText('1 unique lecture');
  await expect(page.locator('.coverage-facts')).toContainText('3/10 reels completed');
  await page.screenshot({ path: 'artifacts/insights-mobile.png', fullPage: true });
  await page.getByRole('button', { name: 'Last 30 days' }).click();
  await expect(page.locator('.rhythm-chart > div')).toHaveCount(30);
  await expect(page.getByRole('button', { name: 'Last 30 days' })).toHaveAttribute(
    'aria-pressed',
    'true',
  );
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: 'artifacts/insights-desktop.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.getByRole('menuitemradio', { name: '15 minutes', exact: true }).click();
  await page.getByRole('button', { name: 'Open your settings' }).click();
  await expect(page.getByRole('heading', { name: 'Settings', exact: true })).toBeVisible();
  await expect(page.locator('.setting-goal-value')).toHaveText('15 min/day');
  await expect(page.getByRole('button', { name: 'Daily learning goal', exact: true })).toHaveCount(
    0,
  );
  await page.getByLabel('Video storage limit').selectOption('5');
  await page.getByRole('dialog').getByRole('button', { name: 'Cancel', exact: true }).click();
  expect(updates).toBe(0);
  await page.getByLabel('Video storage limit').selectOption('5');
  await page
    .getByRole('dialog')
    .getByRole('button', { name: 'Confirm deletion', exact: true })
    .click();
  await expect(page.getByLabel('Video storage limit')).toHaveValue('5');
  expect(updates).toBe(1);
  await page.screenshot({ path: 'artifacts/settings-themed.png', fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole('button', { name: 'Back to Home' }).click();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My progress', exact: true })
    .click();
  await expect(page.locator('.insight-metrics')).toContainText('15 minutes of video per day');
  await expect(page.locator('.rhythm-goal-summary')).toContainText('15 min/day');
  await expect(page.locator('.rhythm-goal-summary :is(button,input,select)')).toHaveCount(0);
});
test('storage playback error offers themed recovery instead of a generic blue retry', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    consent: true,
  });
  await page.route('**/api/media/*/status', (r) =>
    r.fulfill({
      json: {
        state: 'error',
        error: 'Not enough server disk space. 0.5 GB is free. Clear downloads on the server drive.',
      },
    }),
  );
  await page.route('**/api/media/storage', (r) =>
    r.fulfill({ json: { entries: [], used: 0, free: 0.5 * 1024 ** 3, limit: 10 * 1024 ** 3 } }),
  );
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.getByRole('alert')).toContainText('Storage needs attention');
  await expect(page.getByRole('button', { name: 'Try again' })).toHaveCSS(
    'background-color',
    'rgb(255, 78, 148)',
  );
  await page.screenshot({ path: 'artifacts/storage-recovery.png' });
  await page.getByRole('button', { name: 'Manage storage' }).click();
  await expect(page.getByRole('heading', { name: 'Video storage' })).toBeVisible();
});
