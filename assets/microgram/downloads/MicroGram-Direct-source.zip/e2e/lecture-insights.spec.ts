import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, localDate } from '../src/storage';
import type { Course } from '../src/core';

const a = {
  id: 'aaaaaaaaaaa',
  title: 'Vectors explained',
  channel: 'Math studio',
  duration: 120,
  thumbnail: '/local-cover.svg',
  local: true,
};
const b = { ...a, id: 'bbbbbbbbbbb', title: 'Matrices explained' };
const single = {
  id: 'single',
  title: a.title,
  channel: a.channel,
  videos: [a],
  importedAt: Date.now(),
  reelSeconds: 30 as const,
};
const playlist = { ...single, id: 'playlist', title: 'Linear algebra course', videos: [a, b] };
async function setup(page: Page, history = true, lectureCourse: Course = playlist) {
  await page.setViewportSize({ width: 390, height: 844 });
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [single, lectureCourse],
      progress: {
        [a.id]: Array.from({ length: 60 }, (_, i) => i),
        [b.id]: Array.from({ length: 90 }, (_, i) => i),
      },
      activity: { [localDate()]: 900 },
      ...(history
        ? {
            videoActivity: {
              [a.id]: { [localDate()]: 120, [localDate(yesterday)]: 60 },
              [b.id]: { [localDate()]: 30 },
            },
          }
        : {}),
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
}
async function stats(page: Page) {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My progress', exact: true })
    .click();
}
test('lecture rows expand into scoped daily graphs and all-time coverage, without leaving Stats', async ({
  page,
}) => {
  await setup(page);
  await stats(page);
  await expect(page.getByText('Continue where a little more will make a difference.')).toHaveCount(
    0,
  );
  const toggle = page.getByRole('button', {
    name: `View insights for ${single.title}`,
    exact: true,
  });
  const card = page.locator('.lecture-insight-card').filter({ has: toggle });
  await toggle.click();
  await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  await expect(page.locator('.course-profile')).toHaveCount(0);
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'My progress', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await expect(card.locator('.lecture-daily-chart > div')).toHaveCount(7);
  await expect(card.locator('.lecture-detail-metrics')).toContainText('2 / 4');
  await expect(card.locator('.lecture-detail-metrics')).toContainText('1 min');
  await expect(card.locator('.lecture-chart-heading').first()).toContainText('3 min played');
  expect(
    await card
      .locator('.lecture-timeline i')
      .evaluateAll((nodes) => nodes.map((n) => (n as HTMLElement).style.height)),
  ).toEqual([...Array(6).fill('100%'), ...Array(6).fill('0%')]);
  await toggle.click();
  await expect(card.locator('.lecture-insight-expansion')).not.toBeVisible();
  await toggle.click();
  const playlistToggle = page.getByRole('button', {
    name: `View insights for ${playlist.title}`,
    exact: true,
  });
  const list = page.locator('.lecture-insight-card').filter({ has: playlistToggle });
  await playlistToggle.click();
  await expect(list.locator('.playlist-coverage-row')).toHaveCount(2);
  await expect(list.locator('.coverage-row-heading strong')).toHaveText(['50%', '75%']);
  await expect(
    list.getByRole('heading', { name: 'Where you’ve watched', exact: true }),
  ).toBeVisible();
  await expect(list.locator('.playlist-numbered-timeline > div > span')).toHaveText(['01', '02']);
  expect(
    await list
      .locator('.playlist-numbered-track i')
      .evaluateAll((nodes) => nodes.map((n) => (n as HTMLElement).style.height)),
  ).toEqual(['50%', '75%']);
  await page.getByRole('button', { name: 'Last 30 days', exact: true }).click();
  await expect(list.locator('.lecture-daily-chart > div')).toHaveCount(30);
  await expect(card.locator('.lecture-daily-chart > div')).toHaveCount(30);
  await page.getByRole('button', { name: 'Last 7 days', exact: true }).click();
  await list.scrollIntoViewIfNeeded();
  await expect
    .poll(() =>
      list.locator('.lecture-insight-expansion').evaluate((el) => el.getAnimations().length),
    )
    .toBe(0);
  await page.screenshot({ path: 'artifacts/lecture-insights-mobile.png', fullPage: true });
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
});
test('old progress stays visible and new viewing creates durable per-video daily history', async ({
  page,
}) => {
  await setup(page, false);
  await stats(page);
  const toggle = page.getByRole('button', {
    name: `View insights for ${single.title}`,
    exact: true,
  });
  const card = page.locator('.lecture-insight-card').filter({ has: toggle });
  await toggle.click();
  await expect(card.locator('.lecture-history-caption')).toHaveText(
    'Daily history starts with your next watch.',
  );
  await expect(card.locator('.lecture-chart-heading').first()).toContainText('0 min played');
  await expect(card.locator('.lecture-timeline i').first()).toHaveCSS('height', '72px');
  await page.locator('.mobile-nav').getByRole('button', { name: 'Reels', exact: true }).click();
  await expect
    .poll(() =>
      page.evaluate(() => {
        const state = JSON.parse(localStorage.getItem('microgram.v1')!);
        return Object.values(state.videoActivity?.['aaaaaaaaaaa'] ?? {}).reduce(
          (sum: number, n) => sum + Number(n),
          0,
        );
      }),
    )
    .toBeGreaterThan(0.4);
  await page.locator('.native-video').evaluate((v: HTMLVideoElement) => v.pause());
  await stats(page);
  await toggle.click();
  await expect(card.locator('.lecture-history-caption')).toHaveText(
    'Video time played, including replays.',
  );
  const activity = await page.evaluate(
    () => JSON.parse(localStorage.getItem('microgram.v1')!).videoActivity,
  );
  expect(activity.bbbbbbbbbbb).toBeUndefined();
  await page.reload();
  await toggle.click();
  await expect(card.locator('.lecture-history-caption')).toHaveText(
    'Video time played, including replays.',
  );
});

test('Expand all and Collapse all control every lecture while individual rows still toggle', async ({
  page,
}) => {
  await setup(page);
  await stats(page);
  await page.getByRole('button', { name: 'Expand all', exact: true }).click();
  await expect(page.locator('.lecture-insight-toggle[aria-expanded="true"]')).toHaveCount(2);
  await expect(page.locator('.lecture-insight-card.is-open .lecture-detail')).toHaveCount(2);
  await page.getByRole('button', { name: 'Collapse all', exact: true }).click();
  await expect(page.locator('.lecture-insight-toggle[aria-expanded="false"]')).toHaveCount(2);
  await expect(page.locator('.lecture-insight-expansion').first()).not.toBeVisible();
  await page
    .getByRole('button', { name: `View insights for ${single.title}`, exact: true })
    .click();
  await expect(page.locator('.lecture-insight-toggle[aria-expanded="true"]')).toHaveCount(1);
  await page.getByRole('button', { name: 'Expand all', exact: true }).click();
  await expect(page.locator('.lecture-insight-toggle[aria-expanded="true"]')).toHaveCount(2);
});

test('numbered coverage for a long playlist scrolls inside its chart without widening the phone page', async ({
  page,
}) => {
  const longCourse: Course = {
    ...playlist,
    title: 'A longer course',
    kind: 'playlist',
    videos: Array.from({ length: 60 }, (_, i) => ({
      ...a,
      id: `v${String(i).padStart(10, '0')}`,
      title: `Lecture ${i + 1}`,
    })),
  };
  await setup(page, true, longCourse);
  await stats(page);
  await page
    .getByRole('button', { name: `View insights for ${longCourse.title}`, exact: true })
    .click();
  const chart = page.getByRole('region', {
    name: 'Playlist coverage by lecture number',
    exact: true,
  });
  await chart.scrollIntoViewIfNeeded();
  await expect(chart.locator('.playlist-numbered-track')).toHaveCount(60);
  expect(await chart.evaluate((el) => el.scrollWidth > el.clientWidth)).toBe(true);
  await chart.evaluate((el) => {
    el.scrollLeft = el.scrollWidth;
  });
  await expect(chart.locator('.playlist-numbered-timeline > div > span').last()).toHaveText('60');
  await expect(chart.locator('.playlist-numbered-timeline > div > span').last()).toBeInViewport();
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
});
