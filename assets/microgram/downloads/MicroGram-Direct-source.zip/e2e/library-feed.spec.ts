import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial, starter } from '../src/storage';

test('YouTube-style library shows video and playlist cards, real metadata, watched ratios and working options', async ({
  page,
}) => {
  const playlist = {
    ...starter,
    id: 'PL1234567890',
    sample: false,
    title: 'Linear algebra — complete course',
    channel: 'Course curator',
    importedAt: Date.now(),
    videos: [starter.videos[0], { ...starter.videos[0], id: 'aaaaaaaaaaa', duration: 120 }],
  };
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Alex' },
    courses: [starter, playlist],
    progress: { fNk_zzaMoSs: Array.from({ length: 180 }, (_, i) => i) },
  });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({
      json: {
        videos: [
          {
            id: starter.videos[0].id,
            channel: '3Blue1Brown',
            views: '12938018',
            publishedAt: '2016-08-06T00:05:49Z',
            avatar:
              'https://yt3.ggpht.com/ytc/AIdro_nFzZFPLxPZRHcE3SSwzdrbuWqfoWYwLAu0_2iO6blQYAU=s240-c-k-c0x00ffffff-no-rj',
            thumbnail: 'https://i.ytimg.com/vi/fNk_zzaMoSs/maxresdefault.jpg',
          },
        ],
        playlists: [{ id: playlist.id, channel: 'Course curator' }],
      },
    }),
  );
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await expect(page.locator('.youtube-feed-card')).toHaveCount(2);
  await expect(page.locator('.topbar')).toHaveCount(0);
  await expect(page.getByLabel('Search your library')).toHaveCount(0);
  await expect(page.getByText('12.9M', { exact: false })).toBeVisible();
  const first = page.locator('.youtube-feed-card').first();
  await expect(first.locator('.feed-channel-avatar img')).toHaveAttribute(
    'alt',
    '3Blue1Brown channel',
  );
  await expect(first.locator('.feed-duration')).toHaveText('9:52');
  await expect(first.locator('[role="progressbar"]')).toHaveAttribute('aria-valuenow', '3');
  await expect(first.locator('[role="progressbar"]')).toHaveAttribute('aria-valuemax', '10');
  const fill = (await first.locator('.feed-watch-progress i').boundingBox())!;
  const track = (await first.locator('.feed-watch-progress').boundingBox())!;
  expect(fill.width / track.width).toBeCloseTo(0.3, 2);
  await expect(page.locator('.feed-playlist-badge')).toHaveText('2 videos');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: 'artifacts/library-youtube-mobile.png', fullPage: true });
  const touch = await page.context().newCDPSession(page);
  const title = (await first.locator('.feed-title').boundingBox())!;
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: title.x + 20, y: title.y + 8 }],
  });
  await expect(first).toHaveClass(/touch-highlight/);
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: title.x + 20, y: title.y - 45 }],
  });
  await expect(first).toHaveClass(/touch-highlight/);
  await page.screenshot({ path: 'artifacts/library-touch-highlight.png' });
  await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await expect(first).not.toHaveClass(/touch-highlight/);
  await expect(page.locator('.course-profile')).toHaveCount(0);
  await touch.detach();
  await page.locator('.feed-options summary').first().click();
  await expect(
    page.getByRole('button', { name: 'Remove from library', exact: true }),
  ).toBeVisible();
  await page.screenshot({ path: 'artifacts/library-options-mobile.png' });
  await page
    .locator('.feed-options-scrim')
    .first()
    .click({ position: { x: 20, y: 20 } });
  await expect(page.locator('.feed-options[open]')).toHaveCount(0);
  await page.getByRole('button', { name: 'Playlists', exact: true }).click();
  await expect(page.locator('.youtube-feed-card')).toHaveCount(1);
  await page.getByRole('button', { name: 'All', exact: true }).click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await expect(page.locator('.course-profile-header h1')).toHaveText(starter.title);
  await page.getByRole('button', { name: 'Back to library', exact: true }).first().click();
  await page.getByRole('button', { name: 'Search library', exact: true }).click();
  await page.getByLabel('Search your library').fill('no such lecture');
  await expect(page.getByText('No matching lectures')).toBeVisible();
  await page.getByLabel('Search your library').fill('');
  await page.getByRole('button', { name: 'Close library search' }).click();
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: 'artifacts/library-youtube-desktop.png', fullPage: true });
  await page.locator('.feed-options summary').first().click();
  await page.getByRole('button', { name: 'Remove from library', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Remove', exact: true }).click();
  await expect(page.locator('.youtube-feed-card')).toHaveCount(1);
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(stored.progress.fNk_zzaMoSs).toHaveLength(180);
});
