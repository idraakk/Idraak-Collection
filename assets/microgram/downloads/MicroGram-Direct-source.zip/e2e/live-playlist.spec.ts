import { setupName } from './setupName';
import { test, expect } from '@playwright/test';

test('live playlist import returns to Library and persists its own playlist card', async ({
  page,
}) => {
  test.skip(!process.env.LIVE_PLAYLIST_URL, 'Opt-in live API check; consumes YouTube quota.');
  test.setTimeout(150000);
  await page.setViewportSize({ width: 390, height: 844 });
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Add videos', exact: true }).click();
  await page.getByLabel('YouTube link').fill(process.env.LIVE_PLAYLIST_URL!);
  const imported = page.waitForResponse(
    (r) => r.url().endsWith('/api/import') && r.request().method() === 'POST',
  );
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  const response = await imported;
  const data = await response.json();
  expect(response.status(), data.error).toBe(200);
  await expect(page.locator('.youtube-library')).toBeVisible({ timeout: 30000 });
  await expect(page.getByRole('dialog')).toHaveCount(0);
  const card = page.locator('.youtube-feed-card').filter({ hasText: data.course.title });
  await expect(card.locator('.feed-playlist-badge')).toHaveText(
    `${data.course.videos.length} videos`,
  );
  await expect(card.locator('.feed-duration')).toBeVisible();
  await expect
    .poll(async () =>
      page.evaluate(
        (id) =>
          JSON.parse(localStorage.getItem('microgram.v1')!).courses.some(
            (c: { id: string }) => c.id === id,
          ),
        data.course.id,
      ),
    )
    .toBe(true);
  await page.reload();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await expect(card).toBeVisible();
  await page.screenshot({ path: 'artifacts/live-playlist-import.png', fullPage: true });
  expect(errors).toEqual([]);
});
