import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial, starter } from '../src/storage';
import { readFile } from 'node:fs/promises';

test('Back returns tabs to Home, nested views unwind, and only profile/reel entries animate', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (state) => {
      localStorage.setItem('microgram.v1', JSON.stringify(state));
      (window as any).entryAnimations = [];
      const animate = Element.prototype.animate;
      Element.prototype.animate = function (frames: any, options: any) {
        if (
          options?.duration === 190 &&
          Array.isArray(frames) &&
          frames[0]?.transform === 'translate3d(16%,0,0)' &&
          (this.tagName === 'MAIN' || this.classList.contains('reel-stage'))
        )
          (window as any).entryAnimations.push('shared-page-open');
        return animate.call(this, frames, options);
      };
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      progress: { fNk_zzaMoSs: Array.from({ length: 30 }, (_, i) => i) },
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
  await setupName(page);
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.goBack();
  await expect(nav.getByRole('button', { name: 'Learning feed', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await nav.getByRole('button', { name: 'Saved moments', exact: true }).click();
  await nav.getByRole('button', { name: 'My progress', exact: true }).click();
  await page.goBack();
  await expect(nav.getByRole('button', { name: 'Learning feed', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  expect(await page.evaluate(() => (window as any).entryAnimations)).toHaveLength(0);
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await expect.poll(() => page.evaluate(() => (window as any).entryAnimations.length)).toBe(1);
  await expect(page.locator('.profile-actions .primary')).toHaveCSS(
    'background-color',
    'rgb(255, 78, 148)',
  );
  await expect(page.locator('.tile-watch-progress i').first()).toHaveCSS(
    'background-color',
    'rgb(255, 78, 148)',
  );
  await expect(page.locator('.youtube-link-label')).toHaveCSS('color', 'rgb(255, 78, 148)');
  await expect(page.getByText('A little learning goes a long way.', { exact: true })).toHaveCount(
    0,
  );
  const bar = page.locator('.tile-watch-progress').first();
  await expect(bar).toHaveAttribute('aria-valuenow', '50');
  const rect = (await bar.boundingBox())!,
    fill = (await bar.locator('i').boundingBox())!;
  expect(fill.width / rect.width).toBeCloseTo(0.5, 1);
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await page.screenshot({ path: 'artifacts/profile-refined.png', fullPage: true });
  await page.getByLabel('Filter reels by lecture').click();
  await expect(page.getByRole('group', { name: 'Lectures' })).toBeVisible();
  await page.getByRole('group', { name: 'Lectures' }).getByRole('button').nth(1).click();
  await expect(page.getByLabel('Filter reels by lecture')).toContainText('Lecture 1');
  await expect(page.getByRole('group', { name: 'Lectures' })).toBeHidden();

  await page.getByRole('button', { name: /Play reel 1:/ }).click();
  await expect.poll(() => page.evaluate(() => (window as any).entryAnimations.length)).toBe(2);
  await page.goBack();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await page.goBack();
  await expect(nav.getByRole('button', { name: 'Learning feed', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await page.goBack();
  await expect(page).toHaveURL('about:blank');
});

test('rapid nested Back presses and repeated profile exits never skip Library or replay the profile', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    consent: true,
  });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  for (let i = 0; i < 3; i++) {
    await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
    await page.getByRole('button', { name: /Play reel 1:/ }).click();
    await expect(page.locator('.app')).toHaveClass(/immersive-mode/);
    await page.evaluate(() => {
      window.addEventListener('popstate', () => setTimeout(() => history.back(), 0), {
        once: true,
      });
      history.back();
    });
    await expect(page.locator('.youtube-library')).toBeVisible();
    await expect(page.locator('.profile-exit-snapshot')).toHaveCount(0);
    await expect(page.locator('.course-profile')).toHaveCount(0);
    await expect(
      page.locator('.mobile-nav').getByRole('button', { name: 'My library', exact: true }),
    ).toHaveAttribute('aria-current', 'page');
  }
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await expect(page.locator('.profile-exit-snapshot')).toHaveCount(0);
  await page.goBack();
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Learning feed', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
});
