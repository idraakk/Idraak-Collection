import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, type ScreenNote } from '../src/storage';
test.setTimeout(60000);
const id = (i: number) => `v${String(i).padStart(10, '0')}`;
const courses = Array.from({ length: 18 }, (_, i) => ({
  id: id(i),
  kind: 'video' as const,
  title: `Lecture ${i}`,
  channel: 'Teacher',
  importedAt: Date.now(),
  videos: [
    {
      id: id(i),
      title: `Lecture ${i}`,
      channel: 'Teacher',
      duration: 600,
      thumbnail: '/local-cover.svg',
      local: true,
    },
  ],
}));
const captures: ScreenNote[] = courses.flatMap((c, i) =>
  Array.from({ length: i === 10 ? 14 : 1 }, (_, j) => ({
    id: `capture-${i}-${j}`,
    videoId: c.id,
    videoTitle: c.title,
    channel: c.channel,
    courseId: c.id,
    courseTitle: c.title,
    playlist: false,
    time: j * 15,
    createdAt: 100 - i,
    label: `Idea ${i}-${j}`,
    note: 'A useful observation',
    captureRotation: 0 as const,
    captureViewport: 'portrait' as const,
  })),
);
async function setup(page: Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses,
      screenNotes: captures,
      saved: courses.map((c) => `${c.id}:60:0`),
      notes: Object.fromEntries(
        courses.map((c) => [`${c.id}:60:0`, 'An observation worth remembering. '.repeat(6)]),
      ),
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => {
    const range = r
      .request()
      .headers()
      .range?.match(/bytes=(\d+)-(\d*)/);
    const start = Number(range?.[1] ?? 0),
      end = range?.[2] ? Number(range[2]) : body.length - 1;
    return r.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'Accept-Ranges': 'bytes',
        ...(range ? { 'Content-Range': `bytes ${start}-${end}/${body.length}` } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.goto('/');
  await page.evaluate(async (notes) => {
    const path = '/src/screenNotes.ts';
    const { putScreenImages } = await import(path);
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 180;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#23323a';
    ctx.fillRect(0, 0, 320, 180);
    const blob = await new Promise<Blob>((resolve) =>
      canvas.toBlob((b) => resolve(b!), 'image/jpeg'),
    );
    await putScreenImages(notes.map((n) => ({ id: n.id, blob })));
  }, captures);
}
async function saved(page: Page, section: 'Screen Notes' | 'Notes' | 'Reels') {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await page.getByRole('tab', { name: new RegExp(`^${section}`) }).click();
}
async function settled(page: Page) {
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
}
async function closeTo(page: Page, y: number) {
  await settled(page);
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeCloseTo(y, 0);
}
test('Saved order, thumbnail-only opening, outside taps and Back dismiss menus before navigation', async ({
  page,
}) => {
  await setup(page);
  await saved(page, 'Screen Notes');
  expect(await page.getByRole('tab').allTextContents()).toEqual([
    'Screen Notes31',
    'Notes18',
    'Reels18',
  ]);
  const album = page.locator('main .screen-lecture-card').filter({ hasText: /^.*Lecture 10/ });
  await album.locator('.screen-album-title').click();
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(18);
  const cover = album.getByRole('button', {
    name: 'Open Lecture 10 Screen Notes album',
    exact: true,
  });
  const options = album.getByRole('button', { name: 'Album options: Lecture 10', exact: true });
  await options.click();
  await cover.click();
  await expect(page.getByRole('menu')).toHaveCount(0);
  await expect(page.locator('main .screen-note-card')).toHaveCount(0);
  await options.click();
  await page.goBack();
  await expect(page.getByRole('menu')).toHaveCount(0);
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(18);
  await cover.click();
  await settled(page);
  const photo = page.locator('main .screen-note-open').first();
  await photo.focus();
  await page.keyboard.press('Shift+F10');
  await expect(page.getByRole('menu', { name: 'Photo options' })).toBeVisible();
  // Tap the same photo outside its now two-action context menu.
  await photo.click({ position: { x: 8, y: 8 } });
  await expect(page.getByRole('menu')).toHaveCount(0);
  await expect(page.locator('.screen-full-surface')).toHaveCount(0);
  await photo.click();
  await expect(page.locator('.screen-full-surface')).toBeVisible();
  await page.goBack();
  await settled(page);
  await photo.focus();
  await page.keyboard.press('Shift+F10');
  await page.goBack();
  await expect(page.getByRole('menu')).toHaveCount(0);
  await expect(page.locator('main .screen-note-card')).toHaveCount(14);
  await page.goBack();
  await settled(page);
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(18);
});

test('the last item on every scrolling phone page clears the bottom tabs, including album photo labels', async ({
  page,
}) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  async function clearBottom(selector: string) {
    await settled(page);
    await page.evaluate(() =>
      window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'instant' }),
    );
    const rect = (await page.locator(selector).last().boundingBox())!;
    const tabs = (await nav.boundingBox())!;
    expect(rect.y).toBeGreaterThanOrEqual(0);
    expect(rect.y + rect.height, selector).toBeLessThanOrEqual(tabs.y - 12);
  }
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await clearBottom('.feed-video-info');
  await page.getByRole('button', { name: 'Open Lecture 17 profile', exact: true }).click();
  await clearBottom('.profile-reel-tile');
  await saved(page, 'Screen Notes');
  await clearBottom('.screen-album-info');
  await page
    .getByRole('button', { name: 'Open Lecture 10 Screen Notes album', exact: true })
    .click();
  await clearBottom('.screen-card-copy');
  await expect(page.locator('.screen-collection-heading h2')).toHaveCSS('font-size', '17px');
  await page.screenshot({ path: 'artifacts/album-last-photo-clearance.png' });
  await page.goBack();
  await settled(page);
  await page.getByRole('tab', { name: /^Notes/ }).dispatchEvent('click');
  await clearBottom('.saved-note-list article');
  await page.getByRole('tab', { name: /^Reels/ }).dispatchEvent('click');
  await clearBottom('.saved-reel-tile');
  await nav.getByRole('button', { name: 'My progress', exact: true }).click();
  await clearBottom('.insight-method');
  await nav.getByRole('button', { name: 'Learning feed', exact: true }).click();
  await clearBottom('.app-footer');
  await page.getByRole('button', { name: 'Open your settings', exact: true }).click();
  await clearBottom('.fineprint');
});

test('searches animate their results without disturbing input, while Saved tabs fill the phone width', async ({
  page,
}) => {
  await setup(page);
  await page.evaluate(() => {
    (window as any).searchAnimations = [];
    const animate = Element.prototype.animate;
    Element.prototype.animate = function (frames, options) {
      if (this.classList.contains('search-results')) (window as any).searchAnimations.push(options);
      return animate.call(this, frames, options);
    };
  });
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: 'Search library', exact: true }).click();
  const input = page.getByLabel('Search your library');
  await input.fill('Lecture 17');
  await expect(page.locator('.youtube-feed-card')).toHaveCount(1);
  await expect(input).toBeFocused();
  await input.fill('missing');
  await expect(
    page.getByRole('heading', { name: 'No matching lectures', exact: true }),
  ).toBeVisible();
  const count = await page.evaluate(() => (window as any).searchAnimations.length);
  expect(count).toBeGreaterThanOrEqual(2);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await input.fill('Lecture 1');
  expect(await page.evaluate(() => (window as any).searchAnimations.length)).toBe(count);
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await nav.getByRole('button', { name: 'Saved moments', exact: true }).click();
  const tabs = page.getByRole('tablist', { name: 'Saved sections' });
  const bounds = (await tabs.boundingBox())!;
  expect(bounds.x).toBeCloseTo(0, 0);
  expect(bounds.width).toBeCloseTo(390, 0);
  const header = (await page.locator('.saved-page .utility-heading').boundingBox())!;
  expect(bounds.y - header.y - header.height).toBeLessThanOrEqual(10);
  await page.getByLabel('Search screen notes').fill('Lecture 10');
  await expect(page.locator('.screen-lecture-card')).toHaveCount(1);
  expect(await page.evaluate(() => (window as any).searchAnimations.length)).toBeGreaterThan(count);
  await page
    .getByRole('button', { name: 'Open Lecture 10 Screen Notes album', exact: true })
    .click();
  await page.getByRole('button', { name: 'Search this album', exact: true }).click();
  const search = page.getByLabel("Search this album's photos");
  const before = await page.evaluate(() => (window as any).searchAnimations.length);
  await search.fill('Idea 10-13');
  await expect(page.locator('.screen-note-card')).toHaveCount(1);
  await expect(search).toBeFocused();
  expect(await page.evaluate(() => (window as any).searchAnimations.length)).toBeGreaterThan(
    before,
  );
  await page.goBack();
  await settled(page);
  await page.setViewportSize({ width: 320, height: 740 });
  const narrow = (await tabs.boundingBox())!;
  expect(narrow.x).toBeCloseTo(0, 0);
  expect(narrow.width).toBeCloseTo(320, 0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(320);
});
test('Library returns to the exact clicked item through UI Back, browser Back and refresh', async ({
  page,
}) => {
  await setup(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  const open = page.getByRole('button', { name: 'Open Lecture 12 profile', exact: true });
  await open.scrollIntoViewIfNeeded();
  const y = await page.evaluate(() => scrollY);
  expect(y).toBeGreaterThan(1000);
  const top = (await open.boundingBox())!.y;
  await open.click();
  await settled(page);
  expect(await page.evaluate(() => scrollY)).toBe(0);
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await closeTo(page, y);
  expect((await open.boundingBox())!.y).toBeCloseTo(top, 0);
  await open.click();
  await settled(page);
  await page.reload();
  await expect(page.locator('main .course-profile')).toBeVisible();
  await page.goBack();
  await closeTo(page, y);
  await open.click();
  await settled(page);
  const rates = await page.locator('main').evaluate((el) => el.getAnimations().length);
  expect(rates).toBe(0);
  await page.locator('.profile-reel-tile').first().click();
  await expect(page.locator('.native-video')).toBeVisible();
  await settled(page);
  await page.goBack();
  await settled(page);
  await expect(page.locator('main .course-profile')).toBeVisible();
  await page.goBack();
  await closeTo(page, y);
});
test('Saved album, photo grid, text notes and saved reels retain independent scroll positions', async ({
  page,
}) => {
  await setup(page);
  await saved(page, 'Screen Notes');
  const cover = page.getByRole('button', {
    name: 'Open Lecture 10 Screen Notes album',
    exact: true,
  });
  await cover.scrollIntoViewIfNeeded();
  const albumsY = await page.evaluate(() => scrollY);
  expect(albumsY).toBeGreaterThan(1000);
  await cover.click();
  await settled(page);
  const photo = page.locator('main .screen-note-open').nth(10);
  await photo.scrollIntoViewIfNeeded();
  const photosY = await page.evaluate(() => scrollY);
  expect(photosY).toBeGreaterThan(0);
  await photo.click();
  await settled(page);
  await page.goBack();
  await closeTo(page, photosY);
  await page.goBack();
  await closeTo(page, albumsY);
  await cover.click();
  await closeTo(page, photosY);
  await page.goBack();
  await closeTo(page, albumsY);
  await page.getByRole('tab', { name: /^Notes/ }).dispatchEvent('click');
  const note = page.getByRole('button', { name: 'Open note', exact: true }).nth(9);
  await note.scrollIntoViewIfNeeded();
  const notesY = await page.evaluate(() => scrollY);
  await note.click();
  await page.getByRole('button', { name: 'Done', exact: true }).click();
  await closeTo(page, notesY);
  await page.getByRole('tab', { name: /^Reels/ }).dispatchEvent('click');
  const reel = page.locator('.saved-reel-tile').nth(15);
  await reel.scrollIntoViewIfNeeded();
  const reelsY = await page.evaluate(() => scrollY);
  await reel.click();
  await expect(page.locator('.native-video')).toBeVisible();
  await settled(page);
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Reels', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await page.goBack();
  await expect(page.locator('.native-video')).toHaveCount(0);
  await closeTo(page, reelsY);
  await page.getByRole('tab', { name: /^Screen Notes/ }).dispatchEvent('click');
  await closeTo(page, albumsY);
  await page.getByRole('tab', { name: /^Notes/ }).dispatchEvent('click');
  await closeTo(page, notesY);
  await page.getByRole('tab', { name: /^Reels/ }).dispatchEvent('click');
  await closeTo(page, reelsY);
});

test('Library, Settings and photo pages share Saved motion settings while tabs stay instant', async ({
  page,
}) => {
  await setup(page);
  await page.evaluate(() => {
    (window as any).motions = [];
    const original = Element.prototype.animate;
    Element.prototype.animate = function (frames: any, options: any) {
      if (
        (this.tagName === 'MAIN' ||
          this.classList.contains('saved-page') ||
          this.classList.contains('screen-review-modal')) &&
        Array.isArray(frames) &&
        frames[0]?.transform
      )
        (window as any).motions.push({
          target: this.tagName === 'MAIN' ? 'page' : 'photo',
          frames,
          duration: options?.duration,
          easing: options?.easing,
        });
      return original.call(this, frames, options);
    };
  });
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  expect(await page.evaluate(() => (window as any).motions.length)).toBe(0);
  await page.getByRole('button', { name: 'Open Lecture 0 profile', exact: true }).click();
  await settled(page);
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await settled(page);
  await nav.getByRole('button', { name: 'Learning feed', exact: true }).click();
  await page.getByRole('button', { name: 'Open your settings', exact: true }).click();
  await settled(page);
  await page.goBack();
  await settled(page);
  await saved(page, 'Screen Notes');
  await page
    .getByRole('button', { name: 'Open Lecture 0 Screen Notes album', exact: true })
    .click();
  await settled(page);
  await page.locator('main .screen-note-open').first().click();
  await settled(page);
  await page.goBack();
  await settled(page);
  const motions = await page.evaluate(() => (window as any).motions);
  expect(motions.length).toBeGreaterThanOrEqual(6);
  expect(
    motions.every((m: any) => m.duration === 190 && m.easing === 'cubic-bezier(.22,.75,.25,1)'),
  ).toBe(true);
  expect(
    motions.filter((m: any) => m.frames[0].transform === 'translate3d(16%,0,0)').length,
  ).toBeGreaterThanOrEqual(3);
  expect(
    motions.filter((m: any) => m.frames[0].transform === 'translate3d(-4%,0,0)').length,
  ).toBeGreaterThanOrEqual(3);
});
