import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial } from '../src/storage';

test('auto fit and rotation follow real dimensions, preserve manual choices and orient gallery thumbnails', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const portrait = await readFile('artifacts/personal-test.mp4');
  const landscape = await readFile('artifacts/landscape-test.mp4');
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  await page.route('**/api/media/*/file*', (r) =>
    r.fulfill({
      contentType: 'video/mp4',
      body: r.request().url().includes('landscape01') ? landscape : portrait,
    }),
  );
  const course = {
    id: 'mixed-layout',
    title: 'Mixed orientations',
    channel: 'My videos',
    importedAt: Date.now(),
    videos: [
      {
        id: 'landscape01',
        title: 'Landscape lecture',
        channel: 'My videos',
        duration: 35,
        thumbnail: '/local-cover.svg',
        local: true,
      },
      {
        id: 'portrait001',
        title: 'Portrait lesson',
        channel: 'My videos',
        duration: 40,
        thumbnail: '/local-cover.svg',
        local: true,
      },
    ],
  };
  await page.addInitScript((state) => localStorage.setItem('microgram.v1', JSON.stringify(state)), {
    ...initial,
    profile: { name: 'Alex' },
    courses: [course],
    seconds: 15,
    consent: true,
  });
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const app = page.locator('.app'),
    video = page.locator('.native-video');
  await expect(app).toHaveClass(/video-fit/);
  await expect(app).toHaveClass(/video-rotated/);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.videoWidth)).toBe(320);
  await expect(video).toHaveCSS('object-fit', 'contain');
  await page.screenshot({ path: 'artifacts/auto-fit-landscape.png' });
  await page.setViewportSize({ width: 844, height: 390 });
  await expect(app).not.toHaveClass(/video-rotated/);
  const landscapeNav = (await page.locator('.mobile-nav').boundingBox())!;
  expect(landscapeNav.y + landscapeNav.height).toBeLessThanOrEqual(390);
  const stage = (await page.locator('.reel-stage').boundingBox())!;
  expect(stage.y + stage.height).toBeCloseTo(landscapeNav.y, 0);
  await page.setViewportSize({ width: 390, height: 844 });
  await expect(app).toHaveClass(/video-rotated/);
  await page.getByRole('button', { name: 'Restore horizontal video' }).click();
  await page.getByRole('button', { name: 'Fill screen' }).click();
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(app).not.toHaveClass(/video-rotated/);
  await expect(app).not.toHaveClass(/video-fit/);
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open Mixed orientations profile', exact: true }).click();
  await page.getByRole('button', { name: /^Play reel 4:/ }).click();
  await expect(page.locator('.reel-counter')).toHaveText('4 / 6');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.videoWidth)).toBe(180);
  await expect(app).toHaveClass(/video-fit/);
  await expect(app).not.toHaveClass(/video-rotated/);
  await page.screenshot({ path: 'artifacts/auto-fit-portrait.png' });
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await expect(video).toHaveCount(0);
  await expect(page.locator('.today-home')).toBeVisible();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await expect(app).not.toHaveClass(/immersive-mode/);
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Saved moments', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await expect(video).toHaveCount(0);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await expect(page.locator('.oriented-thumbnail').first()).toHaveClass(/thumbnail-rotated/);
  await expect(page.locator('.oriented-thumbnail').nth(3)).not.toHaveClass(/thumbnail-rotated/);
  await page.screenshot({ path: 'artifacts/oriented-profile.png', fullPage: true });
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(saved.courses[0].videos[0].width).toBe(320);
  expect(saved.courses[0].videos[1].height).toBe(320);
});
