import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { resolve } from 'node:path';

test('personal MP4 import, native overlay playback, swipe seeking, loop, notes and persistence', async ({
  page,
  request,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(() => {
    document.documentElement.requestFullscreen = async () => {
      document.documentElement.dataset.fullscreenRequested = 'yes';
    };
  });
  test.setTimeout(90000);
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Add videos', exact: true }).click();
  await page.getByRole('button', { name: '15 seconds', exact: true }).click();
  await page.getByLabel('Import local MP4').setInputFiles(resolve('artifacts/personal-test.mp4'));
  await expect(page.locator('.course-profile-header h1')).toHaveText('personal-test', {
    timeout: 25000,
  });
  await expect(page.locator('.profile-reel-tile')).toHaveCount(3);
  await page.getByRole('button', { name: /Play reel 2:/ }).click();
  await page.getByRole('button', { name: 'Enable personal playback' }).click();
  const video = page.locator('video.native-video');
  await expect(video).toBeVisible();
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThanOrEqual(15);
  expect(await page.locator('iframe').count()).toBe(0);
  const source = await video.getAttribute('src');
  const range = await request.get(source!, { headers: { Range: 'bytes=0-100' } });
  expect(range.status()).toBe(206);
  expect(range.headers()['cache-control']).toBe('no-store');
  expect((await range.body()).length).toBe(101);
  const box = await video.boundingBox();
  expect(box?.width).toBe(390);
  const navigation = page.locator('.mobile-nav');
  await expect(navigation).toBeVisible();
  const navBox = (await navigation.boundingBox())!;
  expect(box!.y + box!.height).toBeCloseTo(navBox.y, 0);
  expect(navBox.y + navBox.height).toBeLessThanOrEqual(844);
  expect(
    await page.evaluate(() => document.documentElement.dataset.fullscreenRequested),
  ).toBeUndefined();
  await expect(navigation.getByRole('button', { name: 'Reels', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  const save = await page.getByRole('button', { name: 'Save moment', exact: true }).boundingBox();
  expect(save!.x + save!.width).toBeLessThanOrEqual(box!.width);
  await video.evaluate((v) => v.setAttribute('data-preserved', 'yes'));
  await page.screenshot({ path: 'artifacts/personal-fullscreen.png' });
  const touch = (y: number) => ({ identifier: 1, clientX: 180, clientY: y });
  await video.dispatchEvent('touchstart', { touches: [touch(550)], changedTouches: [touch(550)] });
  await video.dispatchEvent('touchmove', { touches: [touch(280)], changedTouches: [touch(280)] });
  await page.screenshot({ path: 'artifacts/personal-swipe.png' });
  await video.dispatchEvent('touchend', { touches: [], changedTouches: [touch(280)] });
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect(video).toHaveAttribute('data-preserved', 'yes');
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThanOrEqual(30);
  await video.evaluate((v: HTMLVideoElement) => {
    v.currentTime = 39.95;
  });
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime)).toBeLessThan(32);
  await expect(page.getByRole('button', { name: 'Fill screen' })).toBeVisible();
  await expect(page.locator('.app')).not.toHaveClass(/video-rotated/);
  await page.getByRole('button', { name: 'Fill screen' }).click();
  await expect(page.locator('.app')).not.toHaveClass(/video-fit/);
  await page.getByRole('button', { name: 'Fit whole video' }).click();
  await expect(page.locator('.app')).toHaveClass(/video-fit/);
  await page.getByRole('button', { name: 'Rotate video vertically' }).click();
  await expect(page.locator('.app')).toHaveClass(/video-rotated/);
  await page.getByRole('button', { name: 'Add a note', exact: true }).click();
  await expect(video).toBeAttached();
  await page.getByLabel('Your takeaway').fill('Personal reel note');
  await page.getByRole('button', { name: 'Done', exact: true }).click();
  await expect(video).toBeVisible();
  await page.getByRole('button', { name: 'Exit fullscreen reels' }).click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.reload();
  await page.locator('.mobile-nav').getByRole('button', { name: 'Library' }).click();
  await expect(page.getByRole('heading', { name: 'personal-test' })).toBeVisible();
});

test('download failure stays visible and retries only on request', async ({ page }) => {
  await page.route('**/api/media/*/status', (r) =>
    r.fulfill({
      json: { state: 'error', error: 'YouTube blocked this download. Import an MP4 instead.' },
    }),
  );
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await page.getByRole('button', { name: 'Enable personal playback' }).click();
  await expect(page.getByRole('alert')).toContainText('YouTube blocked');
  await expect(page.getByRole('button', { name: 'Try again' })).toBeVisible();
});

test('media serving supports seeking and refuses invalid IDs', async ({ request }) => {
  expect((await request.post('/api/media/invalid/prepare')).status()).toBe(400);
  const state = await request.get('/api/media/aaaaaaaaaaa/status');
  expect(await state.json()).toEqual({ state: 'missing' });
});
