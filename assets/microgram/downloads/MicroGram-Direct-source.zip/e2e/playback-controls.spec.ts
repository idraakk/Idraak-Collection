import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial } from '../src/storage';

test('speed persists, holding temporarily boosts, captions follow seeks, timeline meets navigation', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  await page.route('**/api/media/*/file*', (r) => {
    const range = r
      .request()
      .headers()
      .range?.match(/bytes=(\d+)-(\d*)/);
    const start = Number(range?.[1] ?? 0);
    const end = range?.[2] ? Number(range[2]) : body.length - 1;
    return r.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'Accept-Ranges': 'bytes',
        ...(range ? { 'Content-Range': `bytes ${start}-${end}/${body.length}` } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.route('**/api/media/*/captions*', (r) =>
    r.fulfill({
      json: r.request().url().includes('language=')
        ? {
            vtt: 'WEBVTT\n\n00:00:00.000 --> 00:00:14.900\nFirst reel caption\n\n00:00:15.000 --> 00:00:29.900\nSecond reel caption\n',
          }
        : { tracks: [{ language: 'en', label: 'English' }] },
    }),
  );
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 15,
      courses: [
        {
          id: 'speed-test',
          title: 'Speed test',
          channel: 'Test',
          importedAt: Date.now(),
          videos: [
            {
              id: 'speedtest01',
              title: 'Playback controls',
              channel: 'Test',
              duration: 40,
              thumbnail: '/local-cover.svg',
            },
          ],
        },
      ],
    },
  );
  await page.goto('/');
  await setupName(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const video = page.locator('.native-video');
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await expect(page.locator('.sound-toggle')).toHaveCount(0);
  await video.evaluate((v: HTMLVideoElement) => v.pause());
  await expect(page.getByRole('button', { name: 'Mute video', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Mute video', exact: true }).click();
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.muted)).toBe(true);
  await page.getByRole('button', { name: 'Unmute video', exact: true }).click();
  await page.mouse.click(90, 350);
  await expect(page.locator('.sound-toggle')).toHaveCount(0);
  await expect(page.locator('#reel-speed-slot .playback-settings-toggle')).toBeVisible();
  const rate = () => video.evaluate((v: HTMLVideoElement) => v.playbackRate);
  await page.getByRole('button', { name: 'Playback speed and captions' }).click();
  await page.locator('summary[aria-label="Playback speed"]').click();
  await page
    .getByRole('group', { name: 'Playback speed', exact: true })
    .getByRole('button', { name: '1.5×', exact: true })
    .click();
  await expect.poll(rate).toBe(1.5);
  await page.getByRole('button', { name: 'Load YouTube captions' }).click();
  await page.locator('summary[aria-label="Caption language"]').click();
  await page
    .getByRole('group', { name: 'Caption language' })
    .getByRole('button', { name: 'English', exact: true })
    .click();
  await expect(page.locator('.video-captions')).toContainText('First reel caption');
  await expect(page.getByText('Hold the video for temporary 2×.')).toHaveCount(0);
  await page.locator('.reels-heading').click();
  await expect(page.locator('.playback-settings-panel')).toHaveCount(0);
  await page.mouse.move(150, 350);
  await page.mouse.down();
  await expect.poll(rate).toBe(2);
  await page.mouse.up();
  await expect.poll(rate).toBe(1.5);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
  const touch = await page.context().newCDPSession(page);
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: 150, y: 350 }],
  });
  await expect.poll(rate).toBe(2);
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: 190, y: 190 }],
  });
  await expect.poll(rate).toBe(2);
  await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await expect.poll(rate).toBe(1.5);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: 150, y: 350 }],
  });
  await expect.poll(rate).toBe(2);
  await touch.send('Input.dispatchTouchEvent', { type: 'touchCancel', touchPoints: [] });
  await expect.poll(rate).toBe(1.5);
  await touch.detach();
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect.poll(rate).toBe(1.5);
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThanOrEqual(15);
  await expect(page.locator('.video-captions')).toContainText('Second reel caption');
  const bar = (await page.locator('.playback-timeline').boundingBox())!;
  const nav = (await page.locator('.mobile-nav').boundingBox())!;
  expect(bar.y + bar.height).toBeCloseTo(nav.y, 0);
  await page.screenshot({ path: 'artifacts/playback-controls.png' });
  await expect(page.locator('.creator-avatar img')).toHaveAttribute('src', '/local-cover.svg');
  await page.getByRole('button', { name: 'Rotate video vertically' }).click();
  await expect(page.locator('.caption-plane')).toHaveCSS('transform', /matrix\(0, 1, -1, 0,/);
  await page.screenshot({ path: 'artifacts/rotated-captions.png' });
  await page.getByRole('button', { name: 'Restore horizontal video' }).click();
  await page.mouse.dblclick(150, 350);
  await expect(page.locator('.app')).toHaveClass(/reel-controls-hidden/);
  await expect(page.locator('.reel-rail')).toBeHidden();
  await expect(page.locator('.immersive-toolbar')).toBeHidden();
  await expect(page.locator('.playback-timeline')).toBeVisible();
  await expect(page.locator('.mobile-nav')).toBeVisible();
  const quietTouch = await page.context().newCDPSession(page);
  await quietTouch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: 150, y: 300 }],
  });
  await quietTouch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: 150, y: 550 }],
  });
  await quietTouch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await expect(page.locator('.app')).toHaveClass(/reel-controls-hidden/);
  await page.screenshot({ path: 'artifacts/quiet-reels.png' });
  for (let i = 0; i < 2; i++) {
    await quietTouch.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [{ x: 150, y: 350 }],
    });
    await quietTouch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  }
  await quietTouch.detach();
  await expect(page.locator('.app')).not.toHaveClass(/reel-controls-hidden/);
  await expect(page.locator('.reel-rail')).toBeVisible();
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(page.locator('.app')).not.toHaveClass(/reel-controls-hidden/);
  // Dragging cancels a pending hold and must not leave 2x latched.
  await page.mouse.move(150, 350);
  await page.mouse.down();
  await page.mouse.move(150, 280);
  await page.waitForTimeout(450);
  await expect.poll(rate).toBe(1.5);
  await page.mouse.up();
  await page.getByRole('button', { name: 'Playback speed and captions' }).click();
  await page.locator('summary[aria-label="Caption language"]').click();
  await page
    .getByRole('group', { name: 'Caption language' })
    .getByRole('button', { name: 'Off', exact: true })
    .click();
  await expect(page.locator('.video-captions')).toHaveCount(0);
  // Scrub in both directions without changing reels or awarding skipped coverage.
  await video.evaluate((v: HTMLVideoElement) => v.pause());
  const scrubber = page.getByRole('slider', { name: 'Reel playback position' });
  const box = (await scrubber.boundingBox())!;
  await page.evaluate(() => window.dispatchEvent(new Event('pagehide')));
  const before = await page.evaluate(
    () => JSON.parse(localStorage.getItem('microgram.v1')!).progress,
  );
  await page.mouse.move(box.x + box.width * 0.25, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.45, box.y + box.height / 2, { steps: 4 });
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => !v.seeking && v.currentTime > 21))
    .toBe(true);
  await page.mouse.move(box.x + box.width * 0.75, box.y + box.height / 2, { steps: 8 });
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => !v.seeking && v.currentTime > 25))
    .toBe(true);
  await page.mouse.up();
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThan(25);
  await page.mouse.click(box.x + box.width * 0.2, box.y + box.height / 2);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime)).toBeLessThan(20);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.paused)).toBe(true);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  expect(
    await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!).progress),
  ).toEqual(before);
  const scrubTouch = await page.context().newCDPSession(page);
  await scrubTouch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: box.x + box.width * 0.2, y: box.y + box.height / 2 }],
  });
  await scrubTouch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: box.x + box.width * 0.6, y: box.y + box.height / 2 }],
  });
  await scrubTouch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await scrubTouch.detach();
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.currentTime))
    .toBeGreaterThan(22);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(page.getByRole('button', { name: 'Share this moment' })).toHaveCount(0);
  await page.reload();
  await expect(page.locator('.app')).toHaveClass(/immersive-mode/);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect.poll(rate).toBe(1.5);
});
