import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial } from '../src/storage';
const video = {
  id: 'aaaaaaaaaaa',
  title: 'Existing top lecture',
  channel: 'Teacher',
  duration: 60,
  thumbnail: 'https://i.ytimg.com/vi/aaaaaaaaaaa/hqdefault.jpg',
};
const existing = {
  id: video.id,
  title: video.title,
  channel: video.channel,
  importedAt: Date.now(),
  videos: [video],
};
const playlist = {
  id: 'PL1234567890',
  title: 'New playlist',
  channel: 'Teacher',
  importedAt: Date.now(),
  videos: [video],
};
async function setup(page: import('@playwright/test').Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    courses: [existing],
    notes: { keep: 'Keep this note' },
    progress: { aaaaaaaaaaa: [0, 1] },
  });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Add videos' }).click();
  await page.getByLabel('YouTube link').fill('https://youtube.com/playlist?list=PL1234567890');
}
test('playlist remains distinct from its existing first video and re-import updates its own entry', async ({
  page,
}) => {
  await setup(page);
  await page.route('**/api/import', (r) => r.fulfill({ json: { course: playlist, skipped: 0 } }));
  await expect(page.locator('.import-source-preview')).toContainText('Playlist link');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.course-profile')).toHaveCount(0);
  await expect(page.locator('.youtube-feed-card')).toHaveCount(2);
  await expect(page.locator('.youtube-feed-card').first()).toContainText('New playlist');
  await expect(page.locator('.feed-playlist-badge')).toHaveText('1 videos');
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(saved.courses.map((c: { id: string }) => c.id)).toEqual([playlist.id, video.id]);
  expect(saved.courses[0].kind).toBe('playlist');
  expect(saved.notes.keep).toBe('Keep this note');
  await page.getByRole('button', { name: 'Add videos' }).click();
  await page.getByLabel('YouTube link').fill('https://youtube.com/playlist?list=PL1234567890');
  await expect(page.locator('.import-source-preview')).toContainText('Playlist link');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('status')).toContainText('Updated playlist: New playlist');
  await expect(page.locator('.youtube-feed-card')).toHaveCount(2);
});
test('mismatched response and failed persistence keep import open instead of opening the existing top video', async ({
  page,
}) => {
  await setup(page);
  await page.route('**/api/import', (r) => r.fulfill({ json: { course: existing } }));
  await expect(page.locator('.import-source-preview')).toContainText('Playlist link');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('alert')).toContainText('different video or playlist');
  await page.route('**/api/import', (r) => r.fulfill({ json: { course: playlist } }));
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new DOMException('Full', 'QuotaExceededError');
    };
  });
  await expect(page.locator('.import-source-preview')).toContainText('Playlist link');
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  await expect(page.getByRole('alert')).toContainText('could not save');
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.locator('.course-profile')).toHaveCount(0);
});
