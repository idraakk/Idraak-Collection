import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, starter, localDate } from '../src/storage';
async function metadata(page: Page) {
  await page.route('https://i.ytimg.com/**', async (r) =>
    r.fulfill({ contentType: 'image/svg+xml', body: await readFile('public/local-cover.svg') }),
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/storage', (r) =>
    r.fulfill({ json: { entries: [], used: 0, free: 5 * 1024 ** 3, limit: 10 * 1024 ** 3 } }),
  );
}
async function settings(page: Page) {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open your settings' }).click();
}
test('first launch saves a name and Home shows an interactive pink learning year', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await metadata(page);
  const today = localDate();
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    { ...initial, activity: { [today]: 720 } },
  );
  await page.goto('/');
  const name = page.getByRole('dialog', { name: 'What should we call you?', exact: true });
  await expect(name).toBeVisible();
  await name.getByLabel('Your name').fill('Idraak');
  await name.getByRole('button', { name: 'Continue', exact: true }).click();
  await expect(page.locator('.today-intro')).toContainText('Idraak');
  const cell = page.locator('.heatmap-cells [data-level="4"]');
  await expect(cell).toHaveCSS('background-color', 'rgb(255, 78, 148)');
  await cell.click();
  await expect(page.locator('.heatmap-footer')).toContainText('12 video minutes');
  await expect(page.locator('.heatmap-goal')).toHaveText('10 min daily goal');
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.getByRole('menuitemradio', { name: '30 minutes', exact: true }).click();
  const todayCell = page.locator(`.heatmap-cells [title="${today}: 12 video minutes"]`);
  await expect(todayCell).toHaveAttribute('data-level', '2');
  await expect(page.locator('.heatmap-goal')).toHaveText('30 min daily goal');
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.getByRole('menuitemradio', { name: '5 minutes', exact: true }).click();
  await expect(todayCell).toHaveAttribute('data-level', '4');
  await expect(page.getByRole('button', { name: 'Open your settings' })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: 'artifacts/home-personal-heatmap.png', fullPage: true });
  await page.reload();
  await expect(name).toHaveCount(0);
  await expect(page.locator('.today-intro')).toContainText('Idraak');
  await expect(page.locator('.heatmap-goal')).toHaveText('5 min daily goal');
  await expect(page.locator('.app-footer')).toBeVisible();
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await page.goBack();
  await expect(page.getByRole('menu', { name: 'Daily learning goal', exact: true })).toHaveCount(0);
  await expect(page.locator('.today-home')).toBeVisible();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My progress', exact: true })
    .click();
  await expect(page.getByRole('button', { name: 'Open your settings' })).toHaveCount(0);
  await expect(page.locator('.app-footer')).toHaveCount(0);
});
test('export and restore round-trip every data category, and reset removes profile plus all learning state', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await metadata(page);
  const seed = {
    ...initial,
    profile: { name: 'Alex' },
    consent: true,
    courses: [{ ...starter, reelSeconds: 15 }],
    saved: ['fNk_zzaMoSs:15:0'],
    notes: { 'fNk_zzaMoSs:15:0': 'Backed up idea' },
    progress: { fNk_zzaMoSs: [0, 1, 2] },
    playbackSpeeds: { fNk_zzaMoSs: 1.5 },
    screenNoteRotations: { fNk_zzaMoSs: 90 },
    profileLectures: { [starter.id]: 'fNk_zzaMoSs' },
    activity: { [localDate()]: 600 },
    videoActivity: { fNk_zzaMoSs: { [localDate()]: 30 } },
    last: { [starter.id]: 1 },
    home: {
      minutes: 5,
      intention: 'Understand vectors',
      reflections: { [localDate()]: 'A reflection' },
    },
  };
  await page.addInitScript((s) => {
    if (!localStorage.getItem('microgram.v1')) {
      localStorage.setItem('microgram.v1', JSON.stringify(s));
      localStorage.setItem('microgram.playback-speed', '2');
      localStorage.setItem('microgram.extra-cache', 'old');
    }
  }, seed);
  let serverClears = 0;
  await page.route('**/api/media/storage/clear', (r) => {
    serverClears++;
    return r.fulfill({ json: { removed: 0, freed: 0, skipped: 0 } });
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'Daily learning goal', exact: true }).click();
  await expect(page.getByRole('menu', { name: 'Daily learning goal' })).toBeVisible();
  await page.screenshot({ path: 'artifacts/goal-themed-menu.png' });
  await page.getByRole('menuitemradio', { name: '15 minutes', exact: true }).click();
  await settings(page);
  await expect(page.getByRole('heading', { name: 'Reel duration', exact: true })).toHaveCount(0);
  await expect(page.locator('.setting-goal-value')).toHaveText('15 min/day');
  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export', exact: true }).click();
  const file = await downloaded;
  const backup = JSON.parse(await readFile((await file.path())!, 'utf8'));
  expect(backup.profile.name).toBe('Alex');
  expect(backup.courses[0].reelSeconds).toBe(15);
  expect(backup.notes).toEqual(seed.notes);
  expect(backup.home).toEqual(seed.home);
  expect(backup.videoActivity).toEqual(seed.videoActivity);
  expect(backup.playbackSpeeds).toEqual(seed.playbackSpeeds);
  expect(backup.screenNoteRotations).toEqual(seed.screenNoteRotations);
  expect(backup.profileLectures).toEqual(seed.profileLectures);
  expect(backup.goal).toBe(15);
  await page.getByRole('button', { name: 'Clear data', exact: true }).click();
  await expect(
    page.getByRole('checkbox', { name: 'Also clear eligible server downloads' }),
  ).not.toBeChecked();
  await page.getByRole('button', { name: 'Permanently clear data', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'What should we call you?' })).toBeVisible();
  const erased = await page.evaluate(() => ({
    state: JSON.parse(localStorage.getItem('microgram.v1')!),
    legacy: localStorage.getItem('microgram.playback-speed'),
    extra: localStorage.getItem('microgram.extra-cache'),
  }));
  expect(erased.legacy).toBeNull();
  expect(erased.extra).toBeNull();
  expect(erased.state.videoActivity).toBeUndefined();
  expect(serverClears).toBe(0);
  for (const key of [
    'profile',
    'home',
    'playbackSpeeds',
    'lastPlayback',
    'screenNoteRotations',
    'profileLectures',
  ])
    expect(erased.state[key]).toBeUndefined();
  for (const key of ['notes', 'progress', 'activity', 'last'])
    expect(erased.state[key]).toEqual({});
  expect(erased.state.saved).toEqual([]);
  expect(erased.state.courses).toEqual([]);
  await page.reload();
  await expect(page.getByRole('dialog', { name: 'What should we call you?' })).toBeVisible();
  await page.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await settings(page);
  await page.locator('input[type="file"][accept="application/json"]').setInputFiles({
    name: 'backup.json',
    mimeType: 'application/json',
    buffer: Buffer.from(JSON.stringify(backup)),
  });
  await expect(page.getByRole('status')).toContainText('restored');
  await page.reload();
  const restored = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(restored).toEqual(backup);
});
test('import length belongs to its course and never changes an existing lecture', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await metadata(page);
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    consent: true,
    courses: [{ ...starter, reelSeconds: 15, videos: [{ ...starter.videos[0], duration: 40 }] }],
  });
  await page.route('**/api/import', (r) =>
    r.fulfill({
      json: {
        course: {
          ...starter,
          id: 'PLduration123',
          sample: false,
          title: 'New lecture playlist',
          importedAt: Date.now(),
          videos: [{ ...starter.videos[0], id: 'bbbbbbbbbbb', duration: 40 }],
        },
        skipped: 0,
      },
    }),
  );
  await page.goto('/');
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: 'Add videos' }).click();
  await page.getByLabel('YouTube link').fill('https://youtube.com/playlist?list=PLduration123');
  await page.locator('.duration-options').getByRole('button', { name: /^30/ }).click();
  await page.getByRole('button', { name: 'Create my learning feed' }).click();
  const state = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(state.courses[0].reelSeconds).toBe(30);
  expect(state.courses[1].reelSeconds).toBe(15);
  await page.getByRole('button', { name: 'Open New lecture playlist profile' }).click();
  await expect(page.locator('.profile-reel-tile')).toHaveCount(2);
  await page.getByRole('button', { name: 'Back to library' }).click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await expect(page.locator('.profile-reel-tile')).toHaveCount(3);
});
test('quick cache checks never flash preparation; real preparation stays visible', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await metadata(page);
  await page.addInitScript(
    (s) => {
      localStorage.setItem('microgram.v1', JSON.stringify(s));
      (window as any).preparingShown = 0;
      new MutationObserver((entries) => {
        for (const entry of entries)
          for (const node of entry.addedNodes)
            if (
              (node as HTMLElement).matches?.('.media-status') &&
              node.textContent?.includes('Preparing your lecture')
            )
              (window as any).preparingShown++;
      }).observe(document, { childList: true, subtree: true });
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [{ ...starter, videos: [{ ...starter.videos[0], duration: 40 }] }],
    },
  );
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  let slow = false;
  await page.route('**/api/media/*/status', async (r) => {
    await new Promise((resolve) => setTimeout(resolve, 650));
    return r.fulfill({ json: { state: slow ? 'downloading' : 'ready' } });
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.locator('.native-video')).toBeVisible();
  expect(await page.evaluate(() => (window as any).preparingShown)).toBe(0);
  await page.goBack();
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.locator('.native-video')).toBeVisible();
  expect(await page.evaluate(() => (window as any).preparingShown)).toBe(0);
  await page.goBack();
  slow = true;
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.getByRole('heading', { name: 'Preparing your lecture' })).toBeVisible();
  slow = false;
  await expect(page.locator('.native-video')).toBeVisible();
});

test('browser transition signals do not add an app slide, and phone Back uses the note close path', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await metadata(page);
  await page.addInitScript(
    (s) => {
      localStorage.setItem('microgram.v1', JSON.stringify(s));
      window.addEventListener(
        'popstate',
        (e) => Object.defineProperty(e, 'hasUAVisualTransition', { value: true }),
        { capture: true },
      );
      (window as any).appSlides = [];
      document.addEventListener('animationstart', (e) => {
        if (['profile-slide-out', 'page-slide-in'].includes(e.animationName))
          (window as any).appSlides.push(e.animationName);
      });
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [{ ...starter, reelSeconds: 15, videos: [{ ...starter.videos[0], duration: 40 }] }],
    },
  );
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  await page.goto('/');
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await page.getByRole('button', { name: /Play reel 1:/ }).click();
  await page.getByRole('button', { name: 'Add a note', exact: true }).click();
  await page.getByLabel('Your takeaway').fill('Back follows Done');
  await page.goBack();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.notes-exit-snapshot')).toHaveCount(1);
  await expect(page.locator('.notes-exit-snapshot')).toHaveCount(0);
  await page.goBack();
  await expect(page.locator('.course-profile')).toBeVisible();
  const before = await page.evaluate(() => (window as any).appSlides.length);
  await page.goBack();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await expect(page.locator('.profile-exit-snapshot')).toHaveCount(0);
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
  expect(await page.evaluate(() => (window as any).appSlides.length)).toBe(before);
});
