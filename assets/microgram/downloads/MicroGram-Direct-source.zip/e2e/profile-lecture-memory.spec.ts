import { test, expect } from '@playwright/test';
import { initial } from '../src/storage';
test('each playlist remembers its selected lecture across Back, reopening and refresh', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const video = {
    id: 'aaaaaaaaaaa',
    title: 'Lecture A1',
    channel: 'Teacher',
    duration: 30,
    thumbnail: '/local-cover.svg',
  };
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [
        {
          id: 'playlist-a',
          title: 'Course A',
          channel: 'Teacher',
          importedAt: Date.now(),
          reelSeconds: 15,
          videos: [video, { ...video, id: 'bbbbbbbbbbb', title: 'Lecture A2' }],
        },
        {
          id: 'playlist-b',
          title: 'Course B',
          channel: 'Teacher',
          importedAt: Date.now(),
          reelSeconds: 15,
          videos: [
            { ...video, id: 'ccccccccccc', title: 'Lecture B1' },
            { ...video, id: 'ddddddddddd', title: 'Lecture B2' },
          ],
        },
      ],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.goto('/');
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open Course A profile', exact: true }).click();
  const picker = page.locator('summary[aria-label="Filter reels by lecture"]');
  await picker.click();
  await page
    .getByRole('group', { name: 'Lectures' })
    .getByRole('button')
    .filter({ hasText: 'Lecture A2' })
    .click();
  await expect(picker).toContainText('Lecture 2');
  await expect(page.locator('.profile-reel-tile')).toHaveCount(2);
  await page.goBack();
  await page.getByRole('button', { name: 'Open Course B profile', exact: true }).click();
  await expect(picker).toContainText('All lectures');
  await picker.click();
  await page
    .getByRole('group', { name: 'Lectures' })
    .getByRole('button')
    .filter({ hasText: 'Lecture B1' })
    .click();
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await page.getByRole('button', { name: 'Open Course A profile', exact: true }).click();
  await expect(picker).toContainText('Lecture 2');
  await expect(page.locator('.profile-reel-tile').first()).toContainText('Lecture A2');
  await page.reload();
  await expect(picker).toContainText('Lecture 2');
  await page.goBack();
  await page.getByRole('button', { name: 'Open Course B profile', exact: true }).click();
  await expect(picker).toContainText('Lecture 1');
  await picker.click();
  await page
    .getByRole('group', { name: 'Lectures' })
    .getByRole('button')
    .filter({ hasText: 'All lectures' })
    .click();
  await expect(page.locator('.profile-reel-tile')).toHaveCount(4);
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await page.getByRole('button', { name: 'Open Course B profile', exact: true }).click();
  await expect(picker).toContainText('All lectures');
});
