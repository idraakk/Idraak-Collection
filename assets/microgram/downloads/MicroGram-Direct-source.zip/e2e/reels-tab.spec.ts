import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, starter } from '../src/storage';

test('Reels tab resumes the last lecture, bounds swipes to it and survives reload', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 15,
      courses: [
        starter,
        {
          ...starter,
          id: 'playlist-test',
          title: 'Two lectures',
          videos: [
            { ...starter.videos[0], duration: 40 },
            { ...starter.videos[0], id: 'secondvideo', title: 'Second lecture', duration: 40 },
          ],
        },
      ],
      lastPlayback: { courseId: 'playlist-test', videoId: 'secondvideo', start: 15 },
    },
  );
  await page.goto('/');
  await setupName(page);
  const nav = page.locator('.mobile-nav');
  await expect(nav.getByRole('button')).toHaveCount(5);
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await nav.getByRole('button', { name: 'Reels', exact: true }).click();
  await expect(page.locator('.app')).toHaveClass(/immersive-mode/);
  await expect(nav.getByRole('button', { name: 'Reels', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await expect(page.locator('.native-video')).toHaveAttribute('src', /secondvideo/);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page.keyboard.press('ArrowUp');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await page.keyboard.press('ArrowUp');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect
    .poll(() =>
      page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!).lastPlayback.start),
    )
    .toBe(30);
  await page.screenshot({ path: 'artifacts/reels-tab.png' });
  await page.goBack();
  await expect(nav.getByRole('button', { name: 'Learning feed', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await page.reload();
  await nav.getByRole('button', { name: 'Reels', exact: true }).click();
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect(page.locator('.native-video')).toHaveAttribute('src', /secondvideo/);
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  // Library retains the profile that was open before entering Reels.
  await expect(page.locator('.course-profile h1')).toHaveText(starter.title);
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await expect(page.locator('.youtube-library')).toBeVisible();
});
