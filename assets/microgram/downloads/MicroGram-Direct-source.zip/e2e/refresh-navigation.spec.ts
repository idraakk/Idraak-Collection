import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial, starter } from '../src/storage';
import { readFile } from 'node:fs/promises';
async function setup(page: import('@playwright/test').Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 15,
      courses: [{ ...starter, videos: [{ ...starter.videos[0], duration: 40 }] }],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/storage', (r) =>
    r.fulfill({ json: { entries: [], used: 0, free: 5 * 1024 ** 3, limit: 10 * 1024 ** 3 } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
  await setupName(page);
}
test('Library, profile and reel survive refresh with neutral chrome and existing Back parents', async ({
  page,
}) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.reload();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await expect(nav.getByRole('button', { name: 'My library', exact: true })).toHaveCSS(
    'color',
    'rgb(245, 245, 245)',
  );
  await page.getByRole('button', { name: `Open ${starter.title} profile` }).click();
  await expect(page.locator('.profile-completion > strong')).toHaveCSS(
    'color',
    'rgb(224, 224, 224)',
  );
  await expect(page.locator('.tile-watch-progress i').first()).toHaveCSS(
    'background-color',
    'rgb(255, 78, 148)',
  );
  await page.reload();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.getByRole('button', { name: /Play reel 2:/ }).click();
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  const rotate = page
    .locator('.immersive-toolbar button')
    .filter({ has: page.locator('svg.lucide-rotate-cw') });
  if ((await rotate.getAttribute('aria-pressed')) !== 'true') await rotate.click();
  await expect(rotate).toHaveCSS('color', 'rgb(224, 224, 224)');
  await expect(page.locator('#reel-speed-slot svg')).toHaveClass(/lucide-gauge/);
  await expect(page.locator('.completion-check svg')).toHaveClass(/lucide-circle-check/);
  await expect(page.locator('#reel-speed-slot button')).toHaveCSS('border-top-width', '0px');
  await page.screenshot({ path: 'artifacts/reel-outline-controls.png' });
  await page.reload();
  await expect(page.locator('.app')).toHaveClass(/immersive-mode/);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page.goBack();
  await expect(page.locator('.course-profile')).toBeVisible();
  await expect(page.locator('.app')).not.toHaveClass(/immersive-mode/);
  await page.goBack();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
  await page.goBack();
  await expect(page).toHaveURL('about:blank');
});
test('Settings Back returns to Home, including after refresh', async ({ page }) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'Learning feed', exact: true }).click();
  await page.getByRole('button', { name: 'Open your settings' }).click();
  await page.reload();
  await expect(page.locator('.settings-page')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
  await page.reload();
  await expect(page.locator('.today-home')).toBeVisible();
  await page.goBack();
  await expect(page).toHaveURL('about:blank');
});
