import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, type ScreenNote } from '../src/storage';

const video = {
  id: 'aaaaaaaaaaa',
  title: 'A lecture to revisit',
  channel: 'Teacher',
  duration: 40,
  thumbnail: '/local-cover.svg',
  width: 960,
  height: 540,
};
const course = {
  id: 'lecture',
  title: video.title,
  channel: video.channel,
  videos: [video],
  importedAt: Date.now(),
  reelSeconds: 15 as const,
};
const base: ScreenNote = {
  id: 'later',
  videoId: video.id,
  videoTitle: video.title,
  channel: video.channel,
  courseId: course.id,
  courseTitle: course.title,
  playlist: false,
  time: 28,
  createdAt: 1,
  label: 'The later idea',
  note: '',
};
const captures = [
  base,
  { ...base, id: 'earlier', time: 4, createdAt: 3, label: 'The first idea' },
  { ...base, id: 'middle', time: 12, createdAt: 2, label: 'The middle idea' },
];
async function setup(page: Page, reelSeconds: 15 | 30 = 15) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [{ ...course, reelSeconds }],
      screenNotes: captures,
      notes: { 'aaaaaaaaaaa:15:1': 'Remember this explanation' },
      saved: ['aaaaaaaaaaa:15:0', 'aaaaaaaaaaa:15:2'],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => {
    const range = r
      .request()
      .headers()
      .range?.match(/bytes=(\d+)-(\d*)/);
    const start = Number(range?.[1] ?? 0),
      end = range?.[2] ? Number(range[2]) : body.length - 1;
    return r.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'Accept-Ranges': 'bytes',
        ...(range ? { 'Content-Range': `bytes ${start}-${end}/${body.length}` } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.goto('/');
  await page.evaluate(async (notes) => {
    const path = '/src/screenNotes.ts';
    const { putScreenImages } = await import(path);
    const canvas = document.createElement('canvas');
    canvas.width = 960;
    canvas.height = 540;
    const c = canvas.getContext('2d')!;
    c.fillStyle = '#33212b';
    c.fillRect(0, 0, 960, 540);
    const blob = await new Promise<Blob>((resolve) =>
      canvas.toBlob((b) => resolve(b!), 'image/jpeg'),
    );
    await putScreenImages(notes.map((n) => ({ id: n.id, blob })));
  }, captures);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
}
const native = (page: Page) => page.locator('.native-video');
async function pausedAt(page: Page, time: number) {
  await expect
    .poll(() => native(page).evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await expect.poll(() => native(page).evaluate((v: HTMLVideoElement) => v.paused)).toBe(true);
  await expect
    .poll(() =>
      native(page).evaluate((v: HTMLVideoElement, at) => Math.abs(v.currentTime - at), time),
    )
    .toBeLessThan(0.15);
}
async function playingNear(page: Page, time: number) {
  await expect
    .poll(() => native(page).evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await expect.poll(() => native(page).evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
  const at = await native(page).evaluate((v: HTMLVideoElement) => v.currentTime);
  expect(at).toBeGreaterThanOrEqual(time);
  expect(at).toBeLessThan(time + 5);
}
test('Screen Notes default to chronological numbered photos; a capture opens its paused moment in Saved', async ({
  page,
}) => {
  await setup(page);
  await expect(page.getByRole('tab', { name: /^Screen Notes/ })).toHaveAttribute(
    'aria-selected',
    'true',
  );
  await page
    .getByRole('button', { name: `Open ${video.title} Screen Notes album`, exact: true })
    .click();
  await expect(page.locator('.screen-card-copy h3')).toHaveText([
    '1. The first idea',
    '2. The middle idea',
    '3. The later idea',
  ]);
  await page.getByRole('button', { name: 'Search this album', exact: true }).click();
  await page.getByLabel("Search this album's photos").fill('later');
  await expect(page.locator('.screen-card-copy h3')).toHaveText('3. The later idea');
  await page.getByLabel("Search this album's photos").fill('');
  const tile = page.locator('.screen-note-open').last();
  await tile.dispatchEvent('contextmenu');
  await page.getByRole('menuitem', { name: 'Open reel at this frame', exact: true }).click();
  await pausedAt(page, 28);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 1');
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Saved moments', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowUp');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 1');
  await pausedAt(page, 28);
  await expect(page.getByRole('button', { name: 'Continue lecture', exact: true })).toHaveCSS(
    'color',
    'rgb(255, 78, 148)',
  );
  await page.screenshot({ path: 'artifacts/saved-capture-playback.png' });
  await page.reload();
  await pausedAt(page, 28);
  await page.goBack();
  await expect(page.locator('.screen-note-card')).toHaveCount(3);
  await expect(page.locator('.screen-lecture-card')).toHaveCount(0);
});
test('Capture and text-note moments offer Play and continue the full lecture at the same time in Reels', async ({
  page,
}) => {
  await setup(page);
  await page
    .getByRole('button', { name: `Open ${video.title} Screen Notes album`, exact: true })
    .click();
  await page.locator('.screen-note-open').last().dispatchEvent('contextmenu');
  await page.getByRole('menuitem', { name: 'Open reel at this frame', exact: true }).click();
  await pausedAt(page, 28);
  await page.getByRole('button', { name: 'Play this saved reel', exact: true }).click();
  await expect.poll(() => native(page).evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Reels', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  expect(
    await native(page).evaluate((v: HTMLVideoElement) => v.currentTime),
  ).toBeGreaterThanOrEqual(28);
  await page.keyboard.press('ArrowUp');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await page.getByRole('button', { name: 'Back to Screen Notes lectures', exact: true }).click();
  await page.getByRole('tab', { name: /^Notes/ }).click();
  await page.getByRole('button', { name: /^Watch note video:/ }).click();
  await playingNear(page, 15);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 1');
  await page.keyboard.press('ArrowDown');
  await playingNear(page, 15);
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await playingNear(page, 15);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
});

test('continuing an older note retains its timestamp when the lecture uses a different reel duration', async ({
  page,
}) => {
  await setup(page, 30);
  await page.getByRole('tab', { name: /^Notes/ }).click();
  await page.getByRole('button', { name: /^Watch note video:/ }).click();
  await playingNear(page, 15);
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await playingNear(page, 15);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 2');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 2');
  await expect.poll(() => native(page).evaluate((v: HTMLVideoElement) => v.paused)).toBe(false);
});

test('Notes autoplay, Continue gently cues Reels, and Back retains the Saved parent through a refreshed nested profile', async ({
  page,
}) => {
  await setup(page);
  await page.getByRole('tab', { name: /^Notes/ }).click();
  await page.getByRole('button', { name: /^Watch note video:/ }).click();
  await playingNear(page, 15);
  await expect(page.locator('.reel-profile-link')).toHaveCount(0);
  await page.evaluate(() => {
    (window as any).continuationAnimations = [];
    const animate = Element.prototype.animate;
    Element.prototype.animate = function (frames, options) {
      if (this.matches('.immersive-toolbar,.mobile-nav .selected .nav-icon'))
        (window as any).continuationAnimations.push(options);
      return animate.call(this, frames, options);
    };
  });
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  const cues = await page.evaluate(() => (window as any).continuationAnimations);
  expect(cues.length).toBeGreaterThanOrEqual(2);
  expect(cues.every((cue: { duration: number }) => cue.duration === 260)).toBe(true);
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Reels', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await page.reload();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page.goBack();
  await expect(
    page.locator('.mobile-nav').getByRole('button', { name: 'Saved moments', exact: true }),
  ).toHaveAttribute('aria-current', 'page');
  await expect(native(page)).toHaveCount(0);
  await expect(page.locator('.saved-note-list')).toContainText('Remember this explanation');
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
});

test('a paused frame returns to its Saved album flow after choosing another reel in the nested profile', async ({
  page,
}) => {
  await setup(page);
  await page
    .getByRole('button', { name: `Open ${video.title} Screen Notes album`, exact: true })
    .click();
  await page.locator('.screen-note-open').last().dispatchEvent('contextmenu');
  await page.getByRole('menuitem', { name: 'Open reel at this frame', exact: true }).click();
  await pausedAt(page, 28);
  await expect(page.locator('.reel-profile-link')).toHaveCount(0);
  await page.getByRole('button', { name: 'Continue lecture', exact: true }).click();
  await pausedAt(page, 28);
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await page.getByRole('button', { name: /^Play reel 1:/ }).click();
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await page.goBack();
  await expect(native(page)).toHaveCount(0);
  await expect(page.locator('.screen-note-card')).toHaveCount(3);
  await page.goBack();
  await expect(page.locator('.screen-lecture-card')).toHaveCount(1);
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
});

test('the main Reels title opens a nested profile; choosing a reel returns to Reels without an extra Back layer', async ({
  page,
}) => {
  await setup(page);
  await page.locator('.mobile-nav').getByRole('button', { name: 'Reels', exact: true }).click();
  await expect(page.locator('.reel-counter')).toHaveText('1 / 3');
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.getByRole('button', { name: /^Play reel 3:/ }).click();
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect(page.locator('.course-profile')).toHaveCount(0);
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await page.getByRole('button', { name: 'Back to reels', exact: true }).click();
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
});

test('Library-opened reels expose the title link and return to their lecture profile', async ({
  page,
}) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: `Open ${course.title} profile`, exact: true }).click();
  await page.getByRole('button', { name: /^Play reel 2:/ }).click();
  await expect(nav.getByRole('button', { name: 'Reels', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await expect(native(page)).toHaveCount(0);
  await expect(nav.getByRole('button', { name: 'My library', exact: true })).toHaveAttribute(
    'aria-current',
    'page',
  );
  await page.getByRole('button', { name: /^Play reel 3:/ }).click();
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await page.reload();
  await page
    .getByRole('button', { name: `Open ${course.title} learning profile`, exact: true })
    .click();
  await expect(page.locator('.course-profile')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.youtube-library')).toBeVisible();
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
});
