import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, schema } from '../src/storage';
const a = {
  id: 'aaaaaaaaaaa',
  title: 'Lecture Alpha',
  channel: 'Teacher',
  duration: 40,
  thumbnail: '/local-cover.svg',
};
const b = { ...a, id: 'bbbbbbbbbbb', title: 'Lecture Beta' };
const course = {
  id: 'PLtest123456',
  title: 'Two lectures',
  channel: 'Teacher',
  importedAt: Date.now(),
  videos: [a, b],
};
async function setup(page: import('@playwright/test').Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (s) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(s));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      seconds: 60,
      courses: [course, { ...course, id: 'other-entry', title: 'Alpha elsewhere', videos: [a] }],
      saved: [
        'aaaaaaaaaaa:15:0',
        'aaaaaaaaaaa:15:0',
        'bbbbbbbbbbb:15:0',
        'aaaaaaaaaaa:15:2',
        'aaaaaaaaaaa:30:1',
      ],
      notes: { 'aaaaaaaaaaa:15:1': 'A standalone idea' },
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => r.fulfill({ contentType: 'video/mp4', body }));
  await page.goto('/');
  await setupName(page);
}
async function selectSpeed(page: import('@playwright/test').Page, name: string) {
  await page.getByRole('button', { name: 'Playback speed and captions' }).click();
  await page.locator('summary[aria-label="Playback speed"]').click();
  await page
    .getByRole('group', { name: 'Playback speed', exact: true })
    .getByRole('button', { name, exact: true })
    .click();
  await page.locator('.reels-heading').click();
}
test('Saved deduplicates moments, plays in Saved, preserves lengths and keeps lecture speeds independent', async ({
  page,
}) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  const saved = nav.getByRole('button', { name: 'Saved moments', exact: true });
  await saved.click();
  await page.getByRole('tab', { name: /^Reels/ }).click();
  await expect(page.locator('.saved-reel-tile')).toHaveCount(3);
  await page.screenshot({ path: 'artifacts/saved-grid.png' });
  await page
    .getByRole('button', { name: 'Watch saved reel: Lecture Alpha, 0:00', exact: true })
    .click();
  const video = page.locator('.native-video');
  await expect(saved).toHaveAttribute('aria-current', 'page');
  await expect(nav.getByRole('button', { name: 'Reels', exact: true })).not.toHaveAttribute(
    'aria-current',
    'page',
  );
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect
    .poll(() => video.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await selectSpeed(page, '2×');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(2);
  await page.keyboard.press('ArrowUp');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 3');
  await expect(video).toHaveAttribute('src', /bbbbbbbbbbb/);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(1);
  await page.keyboard.press('ArrowDown');
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(2);
  await page.goBack();
  await page
    .getByRole('button', { name: 'Watch saved reel: Lecture Beta, 0:00', exact: true })
    .click();
  await expect(video).toHaveAttribute('src', /bbbbbbbbbbb/);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(1);
  await page.goBack();
  await page
    .getByRole('button', { name: 'Watch saved reel: Lecture Alpha, 0:00', exact: true })
    .click();
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect(video).toHaveAttribute('src', /aaaaaaaaaaa/);
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(2);
  await page.reload();
  await expect(saved).toHaveAttribute('aria-current', 'page');
  await expect(page.locator('.app')).toHaveClass(/immersive-mode/);
  await expect(page.locator('.reel-counter')).toHaveText('3 / 3');
  await expect.poll(() => video.evaluate((v: HTMLVideoElement) => v.playbackRate)).toBe(2);
  await page.goBack();
  await expect(page.locator('.saved-reel-grid')).toBeVisible();
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(schema.safeParse(stored).success).toBe(true);
});
test('Standalone notes have their own list and animate from the highlighted Notes control', async ({
  page,
}) => {
  await setup(page);
  const nav = page.locator('.mobile-nav');
  await nav.getByRole('button', { name: 'Saved moments', exact: true }).click();
  await page.getByRole('tab', { name: /^Notes/ }).click();
  await expect(page.locator('.saved-note-list > article')).toHaveCount(1);
  await expect(page.locator('.saved-note-list')).toContainText('A standalone idea');
  await page.screenshot({ path: 'artifacts/saved-notes.png' });
  await page.getByRole('button', { name: 'Open note', exact: true }).click();
  await expect(page.locator('.native-video')).toHaveCount(0);
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByLabel('Your takeaway')).toHaveValue('A standalone idea');
  await page.getByLabel('Your takeaway').fill('An edited idea');
  await page.screenshot({ path: 'artifacts/reel-note-dialog.png' });
  await page.goBack();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.notes-exit-snapshot')).toHaveCount(1);
  await expect(page.locator('.saved-note-list')).toContainText('An edited idea');
  await expect(page.locator('.notes-exit-snapshot')).toHaveCount(0);
  await page.getByRole('button', { name: /Watch note video: Lecture Alpha/ }).click();
  await expect(page.locator('.notes-control')).toHaveClass(/is-saved/);
  await expect(page.locator('.notes-control')).toHaveCSS('color', 'rgb(255, 78, 148)');
  await page.getByRole('button', { name: 'Add a note', exact: true }).click();
  await expect(page.getByLabel('Your takeaway')).toHaveValue('An edited idea');
  await page.getByRole('button', { name: 'Done', exact: true }).click();
  await page.goBack();
  await expect(page.locator('.saved-note-list')).toContainText('An edited idea');
  await page.getByRole('tab', { name: /Reels/ }).click();
  await expect(page.locator('.saved-reel-tile')).toHaveCount(3);
});
test('Tab changes and tab Back have no slide animations; profile Back still animates', async ({
  page,
}) => {
  await setup(page);
  await page.evaluate(() => {
    (window as any).pageMotions = [];
    document.addEventListener('animationstart', (e) => {
      if (['page-slide-in', 'profile-slide-out'].includes(e.animationName))
        (window as any).pageMotions.push(e.animationName);
    });
  });
  const nav = page.locator('.mobile-nav');
  for (const name of ['My library', 'Saved moments', 'My progress']) {
    await nav.getByRole('button', { name, exact: true }).click();
    await page.goBack();
    await expect(page.locator('.today-home')).toBeVisible();
  }
  expect(await page.evaluate(() => (window as any).pageMotions)).toEqual([]);
  await nav.getByRole('button', { name: 'My library', exact: true }).click();
  await page.getByRole('button', { name: 'Open Two lectures profile', exact: true }).click();
  await page.getByRole('button', { name: 'Back to library', exact: true }).click();
  await expect(page.locator('.profile-exit-snapshot')).toHaveCount(0);
  await expect(page.locator('main')).toHaveAttribute('data-saved-motion', 'back');
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await page.goBack();
  await expect(page.locator('.today-home')).toBeVisible();
  await expect(page.locator('.page-slide-in,.profile-exit-snapshot')).toHaveCount(0);
});
