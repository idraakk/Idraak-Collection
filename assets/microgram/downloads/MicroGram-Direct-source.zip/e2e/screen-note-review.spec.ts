import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial, type ScreenNote } from '../src/storage';

const base: ScreenNote = {
  id: 'note-one',
  videoId: 'aaaaaaaaaaa',
  videoTitle: 'Vectors and linear combinations',
  channel: 'Math studio',
  courseId: 'math',
  courseTitle: 'Linear algebra',
  playlist: true,
  time: 12,
  createdAt: 1,
  captureRotation: 90,
  captureViewport: 'portrait',
  label: 'Vectors have direction',
  note:
    'An arrow describes both magnitude and direction. Keep the two ideas together. '.repeat(8) +
    '\n#revision #linearalgebra',
};
const notes: ScreenNote[] = [
  base,
  {
    ...base,
    id: 'note-two',
    time: 38,
    createdAt: 2,
    label: 'Building a linear combination',
    note: 'Scale each vector, then add them.',
  },
  { ...base, id: 'note-three', time: 75, createdAt: 3, label: 'The span of two vectors', note: '' },
  {
    ...base,
    id: 'other-note',
    videoId: 'bbbbbbbbbbb',
    videoTitle: 'Matrices as transformations',
    label: 'A transformation',
    createdAt: 4,
  },
];
async function collection(page: Page) {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await page.getByRole('tab', { name: /Screen Notes/ }).click();
}
async function seedAlbum(page: Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    { ...initial, profile: { name: 'Alex' }, courses: [], screenNotes: notes },
  );
  await page.goto('/');
  await page.evaluate(async (notes) => {
    const module = '/src/screenNotes.ts';
    const { putScreenImages } = await import(module);
    const images = [];
    for (let i = 0; i < notes.length; i++) {
      const canvas = document.createElement('canvas');
      canvas.width = 960;
      canvas.height = 540;
      const c = canvas.getContext('2d')!;
      c.fillStyle = ['#19282e', '#302534', '#222e29', '#262337'][i];
      c.fillRect(0, 0, 960, 540);
      c.strokeStyle = '#ffffff0d';
      c.lineWidth = 1;
      for (let x = 0; x < 960; x += 40) {
        c.beginPath();
        c.moveTo(x, 0);
        c.lineTo(x, 540);
        c.stroke();
      }
      for (let y = 0; y < 540; y += 40) {
        c.beginPath();
        c.moveTo(0, y);
        c.lineTo(960, y);
        c.stroke();
      }
      c.fillStyle = '#fff';
      c.font = '600 28px sans-serif';
      c.fillText(notes[i].label, 45, 65);
      c.strokeStyle = '#ff4e94';
      c.lineWidth = 5;
      c.beginPath();
      c.moveTo(290, 400);
      c.lineTo(650 - i * 25, 170 + i * 35);
      c.lineTo(620 - i * 25, 175 + i * 35);
      c.moveTo(650 - i * 25, 170 + i * 35);
      c.lineTo(640 - i * 25, 200 + i * 35);
      c.stroke();
      c.fillStyle = '#ffadc9';
      c.font = '24px sans-serif';
      c.fillText(`v${i + 1} = (${3 - i}, 2)`, 660, 300);
      const blob = await new Promise<Blob>((resolve) =>
        canvas.toBlob((b) => resolve(b!), 'image/jpeg', 0.86),
      );
      images.push({ id: notes[i].id, blob });
    }
    await putScreenImages(images);
  }, notes);
  await collection(page);
}
test('full-width albums open a phone-aligned photo viewer with persistent lecture rotation and expandable captions', async ({
  page,
}) => {
  await seedAlbum(page);
  const album = page.locator('.screen-lecture-card').filter({ hasText: base.videoTitle });
  await expect(album.locator('.screen-album-photo')).toHaveCount(3);
  const albumBox = (await album.boundingBox())!;
  expect(albumBox.x).toBeCloseTo(0, 0);
  expect(albumBox.width).toBeCloseTo(390, 0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  await page.screenshot({ path: 'artifacts/screen-note-albums.png', animations: 'disabled' });
  await album.click();
  const cards = page.locator('.screen-note-card');
  await expect(cards).toHaveCount(3);
  const boxes = await cards.evaluateAll((nodes) =>
    nodes.map((n) => ({
      x: n.getBoundingClientRect().x,
      y: n.getBoundingClientRect().y,
      width: n.getBoundingClientRect().width,
    })),
  );
  expect(boxes[0].y).toBeCloseTo(boxes[1].y, 0);
  expect(boxes[0].width).toBeGreaterThan(190);
  await expect(cards.first().locator('.screen-card-frame')).toHaveCSS('border-radius', '0px');
  const photo = (await cards.first().locator('.screen-card-frame').boundingBox())!;
  const label = (await cards.first().locator('h3').boundingBox())!;
  expect(label.y).toBeGreaterThanOrEqual(photo.y + photo.height);
  await page.screenshot({ path: 'artifacts/screen-note-album-grid.png', animations: 'disabled' });
  await cards.first().click();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await expect(page.locator('.screen-full-surface')).toBeVisible();
  await expect(page.locator('.screen-note-editor')).toHaveCount(0);
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 1 of 3');
  await expect(page.locator('.screen-full-surface')).toHaveCSS('transform', 'none');
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'true');
  expect((await page.locator('.screen-full-header').boundingBox())!.y).toBeCloseTo(0, 0);
  expect(
    (await page.getByRole('button', { name: 'Previous screen note' }).boundingBox())!.x,
  ).toBeLessThan(15);
  expect(
    (await page.getByRole('button', { name: 'Next screen note' }).boundingBox())!.x,
  ).toBeGreaterThan(335);
  const description = page.getByRole('button', { name: 'Captured note description' });
  const collapsed = (await description.boundingBox())!.height;
  await description.click();
  await expect(description).toHaveAttribute('aria-expanded', 'true');
  expect((await description.boundingBox())!.height).toBeGreaterThan(collapsed);
  await expect(description).toContainText('#revision #linearalgebra');
  await description.click();
  await page.screenshot({ path: 'artifacts/screen-note-fullscreen.png', animations: 'disabled' });
  const history = await page.evaluate(() => window.history.length);
  const touch = await page.context().newCDPSession(page);
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchStart',
    touchPoints: [{ x: 300, y: 300 }],
  });
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x: 90, y: 300 }],
  });
  await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await touch.detach();
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 2 of 3');
  await expect(page.locator('.screen-full-caption')).toContainText(notes[1].label);
  expect(await page.evaluate(() => window.history.length)).toBe(history);
  await page.getByRole('button', { name: 'Next screen note' }).click();
  await expect(page.locator('.screen-photo-deck')).toHaveAttribute('data-settling', 'true');
  await page.getByRole('button', { name: 'Rotate photo', exact: true }).click();
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'false');
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 3 of 3');
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'false');
  await expect(page.getByRole('button', { name: 'Next screen note' })).toBeDisabled();
  await page.keyboard.press('ArrowLeft');
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 2 of 3');
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 3 of 3');
  await page.getByRole('button', { name: 'Edit note', exact: true }).click();
  await expect(page.getByLabel('Label optional', { exact: true })).toHaveValue(notes[2].label);
  await page.goBack();
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 3 of 3');
  await page.goBack();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(cards).toHaveCount(3);
  await page.reload();
  await cards.first().click();
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'false');
  await page.getByRole('button', { name: 'Close screen notes viewer' }).click();
  await page.goBack();
  await expect(page.locator('.screen-lecture-card')).toHaveCount(2);
  await page
    .locator('.screen-lecture-card')
    .filter({ hasText: 'Matrices as transformations' })
    .click();
  await page.locator('.screen-note-card').click();
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'true');
});

test('an opened album has its own cover header and expandable search without collection chrome', async ({
  page,
}) => {
  await seedAlbum(page);
  await page
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  await expect(
    page.locator('.saved-sections,.saved-page .utility-heading,.screen-playlists'),
  ).toHaveCount(0);
  await expect(page.locator('.screen-collection-heading h2')).toHaveText(base.videoTitle);
  await expect(
    page.getByRole('heading', { name: 'Screen Notes Library', exact: true }),
  ).toBeVisible();
  const heading = (await page.locator('.screen-album-library-heading').boundingBox())!;
  const title = (await page.locator('.screen-collection-heading').boundingBox())!;
  expect(title.y).toBeGreaterThan(heading.y + heading.height);
  await expect(page.locator('.screen-album-avatar img')).toBeVisible();
  await expect(page.getByLabel("Search this album's photos")).not.toBeVisible();
  await page.getByRole('button', { name: 'Search this album', exact: true }).click();
  await expect(page.getByLabel("Search this album's photos")).toBeFocused();
  await page.getByLabel("Search this album's photos").fill('combination');
  await expect(page.locator('.screen-note-card')).toHaveCount(1);
  await expect(page.locator('.screen-card-copy h3')).toHaveText('2. Building a linear combination');
  await page.getByRole('button', { name: 'Close album search', exact: true }).click();
  await expect(page.locator('.screen-note-card')).toHaveCount(3);
  await expect
    .poll(() =>
      page.locator('.album-search-panel').evaluate((el) => el.getBoundingClientRect().height),
    )
    .toBe(0);
  await page.screenshot({
    path: 'artifacts/screen-note-album-identity.png',
    animations: 'disabled',
  });
  await page.goBack();
  await expect(page.locator('.saved-sections')).toBeVisible();
  await expect(page.locator('.screen-lecture-card')).toHaveCount(2);
});

test('double-click zooms and pans a photo without changing notes, then restores normal photo swiping', async ({
  page,
}) => {
  await seedAlbum(page);
  await page
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  await page.locator('.screen-note-open').first().click();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  const deck = page.getByRole('group', { name: 'Screen note photo', exact: true });
  const active = deck.locator('.screen-photo-slide[aria-hidden="false"] .screen-photo-zoom');
  await expect
    .poll(() => active.locator('img').evaluate((el: HTMLImageElement) => el.naturalWidth))
    .toBeGreaterThan(0);
  await deck.dblclick({ position: { x: 195, y: 400 } });
  await expect(deck).toHaveAttribute('data-zoom', '2.5');
  await page.waitForTimeout(330);
  await expect(page.locator('.screen-full-surface')).not.toHaveClass(/screen-chrome-hidden/);
  await page.mouse.move(195, 400);
  await page.mouse.down();
  await page.mouse.move(315, 520, { steps: 8 });
  await page.mouse.up();
  const matrix = await active.evaluate((el) => {
    const m = new DOMMatrixReadOnly(getComputedStyle(el).transform);
    return { x: m.m41, y: m.m42 };
  });
  expect(matrix.x).toBeGreaterThan(100);
  expect(matrix.y).toBeGreaterThan(100);
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 1 of 3');
  await deck.dblclick({ position: { x: 195, y: 400 } });
  await expect(deck).toHaveAttribute('data-zoom', '1');
  await page.mouse.move(300, 400);
  await page.mouse.down();
  await page.mouse.move(80, 400, { steps: 8 });
  await page.mouse.up();
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 2 of 3');
  await page.keyboard.press('+');
  await expect(deck).toHaveAttribute('data-zoom', '2.5');
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 2 of 3');
  await page.getByRole('button', { name: 'Next screen note', exact: true }).click();
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 3 of 3');
  await expect(deck).toHaveAttribute('data-zoom', '1');
});

test('phone double taps zoom in both photo orientations and touch drags pan within the image', async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    hasTouch: true,
    isMobile: true,
  });
  const page = await context.newPage();
  try {
    await seedAlbum(page);
    await page
      .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
      .click();
    await page.locator('.screen-note-open').first().click();
    await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
    const deck = page.locator('.screen-photo-deck');
    await expect
      .poll(() =>
        deck
          .locator('.screen-photo-slide[aria-hidden="false"] img')
          .evaluate((el: HTMLImageElement) => el.naturalWidth),
      )
      .toBeGreaterThan(0);
    await page.touchscreen.tap(195, 420);
    await page.touchscreen.tap(195, 420);
    await expect(deck).toHaveAttribute('data-zoom', '2.5');
    const cdp = await context.newCDPSession(page);
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [{ x: 195, y: 420 }],
    });
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchMove',
      touchPoints: [{ x: 270, y: 510 }],
    });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 1 of 3');
    const zoom = deck.locator('.screen-photo-slide[aria-hidden="false"] .screen-photo-zoom');
    expect(
      await zoom.evaluate((el) => new DOMMatrixReadOnly(getComputedStyle(el).transform).m41),
    ).toBeGreaterThan(60);
    await page.touchscreen.tap(195, 420);
    await page.touchscreen.tap(195, 420);
    await expect(deck).toHaveAttribute('data-zoom', '1');
    await page.getByRole('button', { name: 'Rotate photo', exact: true }).click();
    await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'false');
    await page.touchscreen.tap(195, 420);
    await page.touchscreen.tap(195, 420);
    await expect(deck).toHaveAttribute('data-zoom', '2.5');
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [{ x: 195, y: 420 }],
    });
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchMove',
      touchPoints: [{ x: 290, y: 570 }],
    });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    expect(
      await zoom.evaluate((el) => new DOMMatrixReadOnly(getComputedStyle(el).transform).m42),
    ).toBeCloseTo(0, 0);
  } finally {
    await context.close();
  }
});

test('captures remember actual reel orientation and the full-screen viewer adapts when the phone turns', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const lecture = {
    id: 'landscape01',
    title: 'A landscape lecture',
    channel: 'Teacher',
    duration: 35,
    thumbnail: '/local-cover.svg',
    local: true,
  };
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [
        {
          id: 'landscape',
          title: 'A landscape lecture',
          channel: 'Teacher',
          importedAt: Date.now(),
          videos: [lecture],
        },
      ],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/landscape-test.mp4');
  await page.route('**/api/media/*/file*', (r) => {
    const range = r
      .request()
      .headers()
      .range?.match(/bytes=(\d+)-(\d*)/);
    const start = Number(range?.[1] ?? 0),
      end = range?.[2] ? Number(range[2]) : body.length - 1;
    return r.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'Accept-Ranges': 'bytes',
        ...(range ? { 'Content-Range': `bytes ${start}-${end}/${body.length}` } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await expect(page.locator('.app')).toHaveClass(/video-rotated/);
  const v = page.locator('.native-video');
  await expect
    .poll(() => v.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await v.evaluate((v: HTMLVideoElement) => v.pause());
  await page.getByRole('button', { name: 'Capture screen note' }).click();
  await page.getByLabel('Label optional', { exact: true }).fill('A wide diagram');
  await page.getByRole('button', { name: 'Save screen note', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  const saved = await page.evaluate(
    () => JSON.parse(localStorage.getItem('microgram.v1')!).screenNotes[0],
  );
  expect(saved.captureRotation).toBe(90);
  expect(saved.captureViewport).toBe('portrait');
  await collection(page);
  await page.locator('.screen-lecture-card').click();
  const img = page.locator('.screen-note-card img');
  await expect(img).toBeVisible();
  expect(await img.evaluate((i: HTMLImageElement) => i.naturalWidth > i.naturalHeight)).toBe(true);
  await page.locator('.screen-note-card').click();
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'true');
  await page.setViewportSize({ width: 844, height: 390 });
  await expect(page.locator('.screen-full-surface')).toHaveAttribute('data-turned', 'false');
  await expect(page.getByRole('button', { name: 'Previous screen note' })).toBeDisabled();
  await expect(page.getByRole('button', { name: 'Next screen note' })).toBeDisabled();
  await page.keyboard.press('ArrowRight');
  await expect(page.locator('.screen-photo-count')).toHaveAttribute('aria-label', 'Photo 1 of 1');
  await page.screenshot({
    path: 'artifacts/screen-note-landscape-viewer.png',
    animations: 'disabled',
  });
  await page.getByRole('button', { name: 'Edit note', exact: true }).click();
  await page.getByLabel('Label optional', { exact: true }).fill('Edited wide diagram');
  await page.getByRole('button', { name: 'Save changes' }).click();
  await expect(page.locator('.screen-full-caption')).toContainText('Edited wide diagram');
  await page.getByRole('button', { name: 'Close screen notes viewer', exact: true }).click();
  await expect(page.locator('.screen-note-card')).toContainText('Edited wide diagram');
});

test('album menu is delete-only and long press deletes a single capture only after confirmation', async ({
  page,
}) => {
  await seedAlbum(page);
  const album = page.locator('.screen-lecture-card').filter({ hasText: base.videoTitle });
  await album
    .getByRole('button', { name: `Album options: ${base.videoTitle}`, exact: true })
    .click();
  await expect(page.getByRole('menuitem')).toHaveCount(1);
  await expect(
    page.getByRole('menuitem', { name: 'Delete all images', exact: true }),
  ).toBeVisible();
  await expect(page.getByRole('menu')).not.toContainText(/Share|Save/);
  await page.screenshot({ path: 'artifacts/screen-album-options.png', animations: 'disabled' });
  await page.keyboard.press('Escape');
  await album
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  const cards = page.locator('main .screen-note-card');
  await expect(cards).toHaveCount(3);
  await expect(page.locator('main .screen-image-save')).toHaveCount(0);
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  const button = cards.first().locator('.screen-note-open');
  const box = (await button.boundingBox())!;
  await page.mouse.move(box.x + box.width * 0.5, box.y + 35);
  await page.mouse.down();
  await page.waitForTimeout(560);
  await page.mouse.up();
  await expect(page.getByRole('menu', { name: 'Photo options' })).toBeVisible();
  await page.screenshot({ path: 'artifacts/screen-photo-delete-menu.png', animations: 'disabled' });
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await page.getByRole('menuitem', { name: 'Delete photo', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Delete this photo?' })).toBeVisible();
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(cards).toHaveCount(3);
  await button.focus();
  await page.keyboard.press('Shift+F10');
  await page.getByRole('menuitem', { name: 'Delete photo', exact: true }).click();
  await page
    .getByRole('dialog', { name: 'Delete this photo?' })
    .getByRole('button', { name: 'Delete photo', exact: true })
    .click();
  await expect(cards).toHaveCount(2);
  expect(
    await page.evaluate(async () => {
      const path = '/src/screenNotes.ts';
      const { getScreenImage } = await import(path);
      return Boolean(await getScreenImage('note-one'));
    }),
  ).toBe(false);
  await page.getByRole('button', { name: 'Back to Screen Notes lectures', exact: true }).click();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await album
    .getByRole('button', { name: `Album options: ${base.videoTitle}`, exact: true })
    .click();
  await page.getByRole('menuitem', { name: 'Delete all images', exact: true }).click();
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(2);
  await album
    .getByRole('button', { name: `Album options: ${base.videoTitle}`, exact: true })
    .click();
  await page.getByRole('menuitem', { name: 'Delete all images', exact: true }).click();
  await page
    .getByRole('dialog', { name: 'Delete this Screen Notes album?' })
    .getByRole('button', { name: 'Delete all images', exact: true })
    .click();
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(1);
  await expect(page.locator('main .screen-lecture-card')).toContainText(
    'Matrices as transformations',
  );
});

test('whole Saved page animates both ways without vertical settling or stale snapshots', async ({
  page,
}) => {
  await seedAlbum(page);
  const album = page.locator('main .screen-lecture-card').filter({ hasText: base.videoTitle });
  const saved = page.locator('main .saved-page');
  await album
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  const frames = await saved.evaluate(async (el) => {
    const out = [];
    for (let i = 0; i < 18; i++) {
      const heading = el.querySelector('.screen-collection-heading')!.getBoundingClientRect();
      const grid = el.querySelector('.screen-note-grid')!.getBoundingClientRect();
      out.push({
        y: heading.y,
        gridY: grid.y,
        x: heading.x,
        scroll: scrollY,
        animations: el.getAnimations().length,
        motion: (el as HTMLElement).dataset.savedMotion,
      });
      await new Promise(requestAnimationFrame);
    }
    return out;
  });
  expect(frames.some((f) => f.motion === 'open' && f.animations > 0)).toBe(true);
  expect(Math.max(...frames.map((f) => f.y)) - Math.min(...frames.map((f) => f.y))).toBeLessThan(1);
  expect(
    Math.max(...frames.map((f) => f.gridY)) - Math.min(...frames.map((f) => f.gridY)),
  ).toBeLessThan(1);
  expect(frames.some((f) => f.x > frames[frames.length - 1].x + 1)).toBe(true);
  expect(frames.every((f) => f.scroll === 0)).toBe(true);
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await page.getByRole('button', { name: 'Back to Screen Notes lectures', exact: true }).click();
  await expect(saved).toHaveAttribute('data-saved-motion', 'back');
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await expect(saved).not.toHaveAttribute('data-saved-motion');
  await album
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await page.goBack();
  await expect(saved).toHaveAttribute('data-saved-motion', 'back');
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(2);
  // A new tab must never inherit an outgoing Saved page overlay.
  await album
    .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
    .click();
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await expect(page.locator('main .saved-page')).not.toHaveAttribute('data-saved-motion');
});

test('scroll gestures cancel long press, rapid Back cleans up, and reduced motion stays instant', async ({
  page,
}) => {
  await seedAlbum(page);
  const open = () =>
    page
      .getByRole('button', { name: `Open ${base.videoTitle} Screen Notes album`, exact: true })
      .click();
  await open();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  const tile = page.locator('main .screen-note-open').first();
  const rect = (await tile.boundingBox())!;
  const touch = await page.context().newCDPSession(page);
  const x = rect.x + rect.width / 2,
    y = rect.y + 30;
  await touch.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  await touch.send('Input.dispatchTouchEvent', {
    type: 'touchMove',
    touchPoints: [{ x, y: y - 45 }],
  });
  await page.waitForTimeout(560);
  await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await touch.detach();
  await expect(page.getByRole('menu', { name: 'Photo options' })).toHaveCount(0);
  await tile.click();
  await expect(page.locator('.screen-full-surface')).toBeVisible();
  await page.goBack();
  await page.goBack();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await open();
  await page.goBack();
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(2);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await open();
  await expect(page.locator('main .screen-note-card')).toHaveCount(3);
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
  expect(await page.locator('main .saved-page').evaluate((el) => el.getAnimations().length)).toBe(
    0,
  );
  await page.goBack();
  await expect(page.locator('main .screen-lecture-card')).toHaveCount(2);
  await expect(page.locator('.saved-motion-snapshot')).toHaveCount(0);
});
