import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { initial } from '../src/storage';

test.setTimeout(90000);
const video = {
  id: 'aaaaaaaaaaa',
  title: 'Vectors and intuition',
  channel: 'Teacher',
  duration: 40,
  thumbnail: '/local-cover.svg',
};
async function setup(page: Page) {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    (state) => {
      if (!localStorage.getItem('microgram.v1'))
        localStorage.setItem('microgram.v1', JSON.stringify(state));
    },
    {
      ...initial,
      profile: { name: 'Alex' },
      consent: true,
      courses: [
        {
          id: 'playlist',
          kind: 'playlist',
          title: 'Math foundations',
          channel: 'Teacher',
          importedAt: Date.now(),
          reelSeconds: 15,
          videos: [video, { ...video, id: 'bbbbbbbbbbb', title: 'Another lecture' }],
        },
      ],
    },
  );
  await page.route('**/api/library-metadata', (r) =>
    r.fulfill({ json: { videos: [], playlists: [] } }),
  );
  await page.route('**/api/media/*/status', (r) => r.fulfill({ json: { state: 'ready' } }));
  const body = await readFile('artifacts/personal-test.mp4');
  await page.route('**/api/media/*/file*', (r) => {
    const range = r
      .request()
      .headers()
      .range?.match(/bytes=(\d+)-(\d*)/);
    const start = Number(range?.[1] ?? 0);
    const end = range?.[2] ? Number(range[2]) : body.length - 1;
    return r.fulfill({
      status: range ? 206 : 200,
      contentType: 'video/mp4',
      headers: {
        'Accept-Ranges': 'bytes',
        ...(range ? { 'Content-Range': `bytes ${start}-${end}/${body.length}` } : {}),
      },
      body: body.subarray(start, end + 1),
    });
  });
  await page.goto('/');
}
async function capture(page: Page, time: number, label: string, text = '') {
  const v = page.locator('.native-video');
  await expect
    .poll(() => v.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await v.evaluate((v: HTMLVideoElement, time) => {
    v.pause();
    v.currentTime = time;
  }, time);
  await expect.poll(() => v.evaluate((v: HTMLVideoElement) => v.seeking)).toBe(false);
  await expect.poll(() => v.evaluate((v: HTMLVideoElement) => v.currentTime)).toBeCloseTo(time, 1);
  await page.getByRole('button', { name: 'Capture screen note' }).click();
  await expect(page.getByRole('dialog')).toContainText('Keep this moment');
  await expect(page.locator('.screen-note-full-frame img')).toBeVisible();
  await page.getByLabel('Label', { exact: false }).fill(label);
  await page.getByLabel('Note optional', { exact: true }).fill(text);
  await page.screenshot({ path: 'artifacts/screen-note-capture.png', animations: 'disabled' });
  await page.getByRole('button', { name: 'Save screen note', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect.poll(() => v.evaluate((v: HTMLVideoElement) => v.paused)).toBe(true);
}
async function openCollection(page: Page) {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Saved moments', exact: true })
    .click();
  await page.getByRole('tab', { name: /Screen Notes/ }).click();
}
async function settings(page: Page) {
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open your settings' }).click();
}
test('captures exact frames, groups by lecture and playlist, edits and confirms deletion without playing a reel', async ({
  page,
}) => {
  await setup(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await capture(page, 7.25, 'A vector is an arrow', 'Remember the direction, not just the length.');
  // Capture a second moment from the same lecture and a third from another lecture.
  await capture(page, 10, 'The second example');
  // Use the Library profile to select the second lecture rather than depending on swipe timing.
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'My library', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open Math foundations profile', exact: true }).click();
  const tiles = page.locator('.profile-reel-tile');
  await tiles.last().click();
  await capture(page, 32, 'An idea from lecture two');
  await openCollection(page);
  await expect(page.locator('.screen-lecture-card')).toHaveCount(2);
  await expect(page.locator('.screen-playlists')).toContainText('Math foundations');
  await page.screenshot({ path: 'artifacts/screen-notes-lectures.png', animations: 'disabled' });
  await page.locator('.screen-lecture-card').filter({ hasText: 'Vectors and intuition' }).click();
  await expect(page.locator('.screen-note-card')).toHaveCount(2);
  await expect(page.locator('.screen-note-card').first()).toContainText('A vector is an arrow');
  await page.screenshot({ path: 'artifacts/screen-notes-grid.png', animations: 'disabled' });
  await page.locator('.screen-note-card').first().click();
  await expect(page.locator('.native-video')).toHaveCount(0);
  await page.getByRole('button', { name: 'Edit note', exact: true }).click();
  await expect(page.getByLabel('Label', { exact: false })).toHaveValue('A vector is an arrow');
  await page.getByLabel('Label', { exact: false }).fill('Direction matters');
  await page.getByRole('button', { name: 'Save changes' }).click();
  await page.reload();
  await expect(page.locator('.screen-note-card')).toHaveCount(2);
  await expect(page.locator('.screen-note-card').first()).toContainText('Direction matters');
  await page.getByRole('button', { name: 'Search this album', exact: true }).click();
  await page.getByLabel("Search this album's photos").fill('direction');
  await expect(page.locator('.screen-note-card')).toHaveCount(1);
  await page.getByLabel("Search this album's photos").fill('');
  await page.locator('.screen-note-card').first().click();
  await page.goBack();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.screen-note-card')).toHaveCount(2);
  await page.locator('.screen-note-card').first().click();
  await page.getByRole('button', { name: 'Edit note', exact: true }).click();
  await page.getByRole('button', { name: 'Delete screen note', exact: true }).click();
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(page.getByLabel('Label', { exact: false })).toHaveValue('Direction matters');
  await page.getByRole('button', { name: 'Delete screen note', exact: true }).click();
  await page
    .getByRole('dialog', { name: 'Delete this Screen Note?' })
    .getByRole('button', { name: 'Delete screen note', exact: true })
    .click();
  await expect(page.locator('.screen-note-card')).toHaveCount(1);
  await page.goBack();
  await expect(page.locator('.screen-lecture-card')).toHaveCount(2);
  expect(
    await page.evaluate(async () => {
      const path = '/src/screenNotes.ts';
      const { getScreenImage } = await import(path);
      const notes = JSON.parse(localStorage.getItem('microgram.v1')!).screenNotes;
      return (await getScreenImage(notes[0].id))?.type;
    }),
  ).toBe('image/jpeg');
});

test('backs up and restores images, clears all device captures, and rejects missing image backups', async ({
  page,
}) => {
  await setup(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await capture(page, 5.5, 'Keep this formula', 'A useful revision note');
  await settings(page);
  const download = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export', exact: true }).click();
  const backup = JSON.parse(await readFile((await (await download).path())!, 'utf8'));
  const id = backup.screenNotes[0].id;
  expect(backup.screenNotes[0].time).toBeCloseTo(5.5, 1);
  expect(backup.screenNoteImages[id]).toMatch(/^data:image\/jpeg;base64,/);
  await page.getByRole('button', { name: 'Clear data', exact: true }).click();
  await page.getByRole('button', { name: 'Permanently clear data', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'What should we call you?' })).toBeVisible();
  expect(
    await page.evaluate(async (id) => {
      const path = '/src/screenNotes.ts';
      const { getScreenImage } = await import(path);
      return Boolean(await getScreenImage(id));
    }, id),
  ).toBe(false);
  await page.getByRole('button', { name: 'Close dialog', exact: true }).click();
  await settings(page);
  const input = page.locator('input[type=file][accept="application/json"]');
  await input.setInputFiles({
    name: 'incomplete.json',
    mimeType: 'application/json',
    buffer: Buffer.from(JSON.stringify({ ...backup, screenNoteImages: {} })),
  });
  await expect(page.getByRole('status')).toContainText('missing or invalid');
  expect(
    await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!).screenNotes ?? []),
  ).toEqual([]);
  await input.setInputFiles({
    name: 'backup.json',
    mimeType: 'application/json',
    buffer: Buffer.from(JSON.stringify(backup)),
  });
  await expect(page.getByRole('status')).toContainText('restored');
  await openCollection(page);
  await page.locator('.screen-lecture-card').click();
  await expect(page.locator('.screen-note-card')).toContainText('Keep this formula');
  await expect(page.locator('.screen-note-card img')).toBeVisible();
  expect(
    await page
      .locator('.screen-note-card img')
      .evaluate((img: HTMLImageElement) => img.naturalWidth),
  ).toBeGreaterThan(0);
});

test('capture storage failure keeps the unsaved frame and reports an actionable error', async ({
  page,
}) => {
  await setup(page);
  await page.getByRole('button', { name: 'Play this reel' }).click();
  const v = page.locator('.native-video');
  await expect
    .poll(() => v.evaluate((v: HTMLVideoElement) => v.readyState))
    .toBeGreaterThanOrEqual(2);
  await v.evaluate((v: HTMLVideoElement) => v.pause());
  await page.getByRole('button', { name: 'Capture screen note' }).click();
  await page.getByLabel('Label', { exact: false }).fill('Do not lose this draft');
  await page.evaluate(() => {
    indexedDB.open = () => {
      throw new DOMException('Denied', 'SecurityError');
    };
  });
  await page.getByRole('button', { name: 'Save screen note', exact: true }).click();
  await expect(page.getByRole('alert')).toBeVisible();
  await expect(page.getByLabel('Label', { exact: false })).toHaveValue('Do not lose this draft');
  expect(
    await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!).screenNotes ?? []),
  ).toEqual([]);
});
