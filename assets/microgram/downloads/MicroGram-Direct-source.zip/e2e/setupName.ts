import { expect, type Page } from '@playwright/test';
export async function setupName(page: Page) {
  await expect(page.locator('.app')).toBeVisible();
  const dialog = page.getByRole('dialog', { name: 'What should we call you?', exact: true });
  if (await dialog.isVisible()) {
    await dialog.getByLabel('Your name').fill('Alex');
    await dialog.getByRole('button', { name: 'Continue', exact: true }).click();
  }
}
