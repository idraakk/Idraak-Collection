import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
import { initial, starter } from '../src/storage';
test('storage cleanup preserves progress and originals, with readable phone controls', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const state = {
    ...initial,
    profile: { name: 'Alex' },
    progress: { fNk_zzaMoSs: [0, 1, 2] },
    notes: { note: 'Keep me' },
    saved: ['saved'],
    courses: [starter],
  };
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), state);
  let entries = [
    { id: 'fNk_zzaMoSs', bytes: 1024 ** 2, kind: 'download', protected: false },
    { id: 'uploaded001', bytes: 1024 ** 2, kind: 'upload', protected: false },
  ];
  await page.route('**/api/media/storage', (r) =>
    r.fulfill({
      json: {
        entries,
        used: entries.length * 1024 ** 2,
        limit: 10 * 1024 ** 3,
        free: 30 * 1024 ** 3,
      },
    }),
  );
  await page.route('**/api/media/storage/clear', (r) => {
    entries = entries.filter((e) => e.kind !== 'download');
    return r.fulfill({ json: { freed: 1024 ** 2, removed: 1, skipped: 1 } });
  });
  await page.goto('/');
  await setupName(page);
  await page
    .locator('.mobile-nav')
    .getByRole('button', { name: 'Learning feed', exact: true })
    .click();
  await page.getByRole('button', { name: 'Open your settings' }).click();
  await page.getByRole('button', { name: 'Clear temporary cache', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Confirm deletion' }).click();
  await expect(page.getByRole('status')).toContainText('Freed 1.0 MB');
  await expect(page.getByText('Uploaded original', { exact: false })).toBeVisible();
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1')!));
  expect(stored.progress).toEqual(state.progress);
  expect(stored.notes).toEqual(state.notes);
  expect(stored.saved).toEqual(state.saved);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.locator('.storage-panel').screenshot({ path: 'artifacts/storage-mobile.png' });
  await page.getByRole('button', { name: 'Delete file for Video uploaded001' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Cancel' }).click();
  await expect(page.getByText('Uploaded original', { exact: false })).toBeVisible();
});
test('playlist cleanup excludes videos shared with another playlist', async ({ page }) => {
  let ids: string[] = [];
  await page.addInitScript((s) => localStorage.setItem('microgram.v1', JSON.stringify(s)), {
    ...initial,
    profile: { name: 'Alex' },
    courses: [starter, { ...starter, id: 'another-course', title: 'Another playlist' }],
  });
  await page.route('**/api/media/storage/clear', (r) => {
    ids = r.request().postDataJSON().ids;
    return r.fulfill({ json: { freed: 0, removed: 0, skipped: 0 } });
  });
  await page.goto('/');
  await setupName(page);
  await page.locator('.sidebar').getByRole('button', { name: 'My library', exact: true }).click();
  await page.locator('.feed-options summary').first().click();
  await expect(page.getByRole('checkbox').first()).toBeChecked();
  await page.getByRole('button', { name: 'Clear downloaded videos', exact: true }).first().click();
  await page
    .getByRole('dialog')
    .getByRole('button', { name: 'Clear downloads', exact: true })
    .click();
  await expect(page.getByRole('status')).toContainText('Shared');
  expect(ids).toEqual([]);
});
