import { setupName } from './setupName';
import { test, expect } from '@playwright/test';
test('drag reveals the next card, snaps back, and commits only one reel', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await setupName(page);
  const card = page.locator('.reel-card');
  const current = page.locator('.reel-current-panel');
  const start = async (y: number) =>
    card.dispatchEvent('touchstart', { touches: [{ identifier: 0, clientX: 10, clientY: y }] });
  const drag = async (y: number) =>
    card.dispatchEvent('touchmove', { touches: [{ identifier: 0, clientX: 10, clientY: y }] });
  const end = async (y: number) =>
    card.dispatchEvent('touchend', {
      changedTouches: [{ identifier: 0, clientX: 10, clientY: y }],
    });
  await start(600);
  await drag(380);
  expect(await current.evaluate((el) => new DOMMatrix(getComputedStyle(el).transform).m42)).toBe(
    -220,
  );
  await expect(page.locator('.reel-adjacent-panel')).toHaveCount(1);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 10');
  await page.screenshot({ path: 'artifacts/swipe-in-progress.png' });
  await end(380);
  await expect(page.locator('.reel-counter')).toHaveText('2 / 10');
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await start(400);
  await drag(375);
  await end(375);
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await expect(page.locator('.reel-counter')).toHaveText('2 / 10');
  await start(400);
  await drag(590);
  await end(590);
  await expect(page.locator('.reel-counter')).toHaveText('1 / 10');
  await start(400);
  await drag(600);
  expect(
    await current.evaluate((el) => new DOMMatrix(getComputedStyle(el).transform).m42),
  ).toBeLessThan(50);
  await end(600);
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 10');
});
test('cancelled gestures and reduced motion do not leave a displaced reel', async ({ page }) => {
  await page.goto('/');
  await setupName(page);
  const card = page.locator('.reel-card');
  await card.dispatchEvent('touchstart', {
    touches: [{ identifier: 0, clientX: 10, clientY: 500 }],
  });
  await card.dispatchEvent('touchmove', {
    touches: [{ identifier: 0, clientX: 10, clientY: 300 }],
  });
  await card.dispatchEvent('touchcancel');
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
  await expect(page.locator('.reel-counter')).toHaveText('1 / 10');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.getByRole('button', { name: 'Next reel', exact: true }).click();
  await expect(page.locator('.reel-counter')).toHaveText('2 / 10');
  await expect(page.locator('.reel-viewport')).toHaveAttribute('data-moving', 'false');
});
