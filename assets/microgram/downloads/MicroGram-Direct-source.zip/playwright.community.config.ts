import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './community-service/browser-tests',
  globalSetup: './scripts/community-test-build.ts',
  testMatch: 'community.spec.ts',
  workers: 1,
  use: {
    baseURL: 'https://microgram.test',
    serviceWorkers: 'block',
    headless: true,
    launchOptions: { channel: process.env.PLAYWRIGHT_CHANNEL || 'msedge' },
    viewport: { width: 412, height: 915 },
    screenshot: 'only-on-failure',
  },
});
