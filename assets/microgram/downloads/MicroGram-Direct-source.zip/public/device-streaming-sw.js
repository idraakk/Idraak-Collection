/* Device cache. Relay is only used when the operator explicitly enables it. */
const CHUNK = 1024 * 1024;
const DEFAULT_LIMIT = 250 * 1024 * 1024;
const DB = 'microgram.video-chunks.v1';
const relaySources = new Set();
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
function database() {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open(DB, 2);
    r.onupgradeneeded = () => {
      if (!r.result.objectStoreNames.contains('chunks'))
        r.result.createObjectStore('chunks', { keyPath: 'key' });
      if (!r.result.objectStoreNames.contains('originals'))
        r.result.createObjectStore('originals', { keyPath: 'id' });
      if (!r.result.objectStoreNames.contains('settings')) r.result.createObjectStore('settings');
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function tx(store, mode, work) {
  const db = await database();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const r = work(t.objectStore(store));
    t.oncomplete = () => {
      db.close();
      resolve(r?.result);
    };
    t.onabort = t.onerror = () => {
      db.close();
      reject(t.error);
    };
  });
}
let serial = Promise.resolve();
let generation = 0;
function locked(work) {
  const next = serial.then(work, work);
  serial = next.catch(() => {});
  return next;
}
const json = (value, status = 200) =>
  new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } });
async function limit() {
  return (await tx('settings', 'readonly', (s) => s.get('limit'))) ?? DEFAULT_LIMIT;
}
async function trim(max) {
  const rows = await tx('chunks', 'readonly', (s) => s.getAll());
  let used = rows.reduce((n, r) => n + r.blob.size, 0);
  for (const row of rows.sort((a, b) => a.at - b.at)) {
    if (used <= max) break;
    await tx('chunks', 'readwrite', (s) => s.delete(row.key));
    used -= row.blob.size;
  }
}
async function storage(request, path) {
  return locked(async () => {
    const originalId = /^\/api\/media\/storage\/([\w-]{11})$/.exec(path);
    if (
      originalId &&
      request.method === 'DELETE' &&
      new URL(request.url).searchParams.get('confirm') === 'delete-original'
    ) {
      await tx('originals', 'readwrite', (s) => s.delete(originalId[1]));
      return json({ deleted: true });
    }
    if (path.endsWith('/clear')) {
      generation++;
      const { ids } = await request.json();
      const rows = await tx('chunks', 'readonly', (s) => s.getAll());
      let freed = 0;
      const removed = new Set();
      for (const r of rows)
        if (!ids || ids.includes(r.id)) {
          await tx('chunks', 'readwrite', (s) => s.delete(r.key));
          freed += r.blob.size;
          removed.add(r.id);
        }
      return json({ freed, removed: removed.size, skipped: 0 });
    }
    if (path.endsWith('/limit')) {
      const { gib } = await request.json();
      if (!Number.isFinite(gib) || gib < 0.125 || gib > 4)
        return new Response('Invalid cache limit', { status: 400 });
      await tx('settings', 'readwrite', (s) => s.put(gib * 1024 ** 3, 'limit'));
      await trim(await limit());
    }
    const rows = await tx('chunks', 'readonly', (s) => s.getAll());
    const entries = new Map();
    for (const r of rows) {
      const item = entries.get(r.id) || { id: r.id, bytes: 0, kind: 'download', protected: false };
      item.bytes += r.blob.size;
      entries.set(r.id, item);
    }
    const estimate = await navigator.storage.estimate();
    const originals = await tx('originals', 'readonly', (s) => s.getAll());
    for (const original of originals)
      entries.set(original.id, {
        id: original.id,
        bytes: original.blob.size,
        kind: 'upload',
        protected: false,
      });
    return json({
      used: rows.reduce((n, r) => n + r.blob.size, 0),
      limit: await limit(),
      free: Math.max(0, (estimate.quota || 0) - (estimate.usage || 0)),
      entries: [...entries.values()],
      downloading: false,
      device: true,
    });
  });
}
async function media(request, id) {
  const epoch = generation;
  const original = await tx('originals', 'readonly', (s) => s.get(id));
  const range = request.headers.get('Range') || 'bytes=0-';
  const match = /^bytes=(\d+)-(\d*)$/.exec(range);
  if (!match) return new Response(null, { status: 416 });
  const start = Number(match[1]);
  const aligned = Math.floor(start / CHUNK) * CHUNK;
  const key = `${id}:${aligned}`;
  let cached = original
    ? {
        blob: original.blob.slice(aligned, aligned + CHUNK),
        total: original.blob.size,
        original: true,
      }
    : await tx('chunks', 'readonly', (s) => s.get(key));
  if (!cached) {
    const source = await fetch(`/api/stream/${id}/source`, { signal: request.signal });
    if (!source.ok) return new Response('Stream unavailable', { status: 502 });
    const { url, relay } = await source.json();
    const options = {
      mode: 'cors',
      credentials: 'omit',
      headers: { Range: `bytes=${aligned}-${aligned + CHUNK - 1}` },
      signal: request.signal,
    };
    let upstream;
    try {
      if (!relaySources.has(id)) upstream = await fetch(url, options);
    } catch (e) {
      if (!relay || request.signal.aborted) throw e;
    }
    if ((!upstream || upstream.status !== 206 || !upstream.headers.get('Content-Range')) && relay) {
      await upstream?.body?.cancel();
      upstream = await fetch(`/api/stream/${id}/bytes`, { ...options, credentials: 'same-origin' });
      if (upstream.status === 206) relaySources.add(id);
    }
    if (!upstream) throw new Error('Direct source unavailable');
    const contentRange = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(
      upstream.headers.get('Content-Range') || '',
    );
    if (
      upstream.status !== 206 ||
      !contentRange ||
      Number(contentRange[1]) !== aligned ||
      Number(contentRange[2]) - aligned + 1 > CHUNK
    ) {
      await upstream.body?.cancel();
      return new Response('Source does not support browser range streaming', { status: 502 });
    }
    const blob = await upstream.blob();
    cached = { key, id, blob, total: Number(contentRange[3]), at: Date.now() };
    await locked(async () => {
      try {
        if (epoch !== generation) return;
        await trim(Math.max(0, (await limit()) - blob.size));
        await tx('chunks', 'readwrite', (s) => s.put(cached));
      } catch {
        /* Playback may continue without persistence when device storage is unavailable. */
      }
    });
  } else if (!cached.original) {
    cached.at = Date.now();
    await locked(async () => {
      if (epoch === generation && (await tx('chunks', 'readonly', (s) => s.get(key))))
        await tx('chunks', 'readwrite', (s) => s.put(cached));
    });
  }
  const end = Math.min(
    match[2] ? Number(match[2]) : Infinity,
    aligned + cached.blob.size - 1,
    cached.total - 1,
  );
  if (end < start) return new Response(null, { status: 416 });
  const body = cached.blob.slice(start - aligned, end - aligned + 1, 'video/mp4');
  return new Response(body, {
    status: 206,
    headers: {
      'Content-Type': 'video/mp4',
      'Accept-Ranges': 'bytes',
      'Content-Range': `bytes ${start}-${end}/${cached.total}`,
      'Content-Length': String(body.size),
      'Cache-Control': 'no-store',
    },
  });
}

const pendingChunks = new Map();
async function adaptiveMedia(request, id, format, version) {
  const BLOCK =
    self.location.hostname.endsWith('.ts.net') && self.location.port !== '8443'
      ? 256 * 1024
      : CHUNK;
  const epoch = generation;
  const match = /^bytes=(\d+)-(\d+)$/.exec(request.headers.get('Range') || '');
  if (!match) return new Response(null, { status: 416 });
  const start = Number(match[1]),
    requestedEnd = Number(match[2]);
  if (
    !Number.isSafeInteger(requestedEnd) ||
    requestedEnd < start ||
    requestedEnd - start > 32 * CHUNK
  )
    return new Response(null, { status: 416 });
  async function chunk(offset) {
    const key = `${id}:dash:${format}:${version}:b${BLOCK}:${offset}`;
    let item = await tx('chunks', 'readonly', (s) => s.get(key));
    if (item) {
      void locked(async () => {
        try {
          if (epoch === generation && (await tx('chunks', 'readonly', (s) => s.get(key))))
            await tx('chunks', 'readwrite', (s) => s.put({ ...item, at: Date.now() }));
        } catch {}
      });
      return item;
    }
    const pendingKey = `${epoch}:${key}`;
    if (pendingChunks.has(pendingKey)) return pendingChunks.get(pendingKey);
    const work = (async () => {
      let response;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          response = await fetch(request.url, {
            headers: { Range: `bytes=${offset}-${offset + BLOCK - 1}` },
            credentials: 'same-origin',
            signal: AbortSignal.timeout(90000),
          });
          if (response.status === 206) break;
          if (![429, 500, 502, 503, 504].includes(response.status)) break;
          await response.body?.cancel();
        } catch (e) {
          if (attempt === 2) throw e;
        }
        await new Promise((r) => setTimeout(r, 300 * 2 ** attempt));
      }
      const range = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(response?.headers.get('Content-Range') || '');
      if (
        !response ||
        response.status !== 206 ||
        !range ||
        Number(range[1]) !== offset ||
        Number(range[2]) - offset + 1 > BLOCK
      ) {
        await response?.body?.cancel();
        throw new Error('Video chunk unavailable');
      }
      const blob = await response.blob();
      if (blob.size !== Number(range[2]) - offset + 1) throw new Error('Incomplete video chunk');
      item = { key, id, blob, total: Number(range[3]), at: Date.now() };
      await locked(async () => {
        try {
          if (epoch !== generation) return;
          await trim(Math.max(0, (await limit()) - blob.size));
          await tx('chunks', 'readwrite', (s) => s.put(item));
        } catch {}
      });
      return item;
    })();
    pendingChunks.set(pendingKey, work);
    try {
      return await work;
    } finally {
      pendingChunks.delete(pendingKey);
    }
  }
  const firstOffset = Math.floor(start / BLOCK) * BLOCK;
  let current = await chunk(firstOffset);
  const end = Math.min(requestedEnd, current.total - 1);
  if (start > end) return new Response(null, { status: 416 });
  let cursor = start,
    cancelled = false;
  const stream = new ReadableStream(
    {
      async pull(controller) {
        try {
          if (cancelled || request.signal.aborted) {
            controller.close();
            return;
          }
          const aligned = Math.floor(cursor / BLOCK) * BLOCK;
          if (aligned !== firstOffset || cursor !== start) current = await chunk(aligned);
          const partEnd = Math.min(end + 1, aligned + current.blob.size);
          if (partEnd <= cursor) throw new Error('Invalid chunk length');
          const bytes = await current.blob.slice(cursor - aligned, partEnd - aligned).arrayBuffer();
          if (cancelled) return;
          controller.enqueue(new Uint8Array(bytes));
          cursor = partEnd;
          if (cursor > end) controller.close();
        } catch (e) {
          if (!cancelled) controller.error(e);
        }
      },
      cancel() {
        cancelled = true;
      },
    },
    { highWaterMark: 0 },
  );
  return new Response(stream, {
    status: 206,
    headers: {
      'Content-Type': format.startsWith('140') ? 'audio/mp4' : 'video/mp4',
      'Content-Length': String(end - start + 1),
      'Content-Range': `bytes ${start}-${end}/${current.total}`,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store',
    },
  });
}

self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (u.origin !== self.location.origin) return;
  const track = /^\/api\/stream\/([\w-]{11})\/track\/([\w-]{1,32})$/.exec(u.pathname);
  if (track) {
    e.respondWith(
      adaptiveMedia(e.request, track[1], track[2], u.searchParams.get('version') || '').catch(
        () => new Response('Video chunk unavailable', { status: 502 }),
      ),
    );
    return;
  }
  if (u.pathname.startsWith('/api/media/storage')) {
    e.respondWith(
      storage(e.request, u.pathname).catch(() =>
        json({ error: 'Device video storage unavailable.' }, 503),
      ),
    );
    return;
  }
  const upload = /^\/api\/media\/([\w-]{11})\/upload$/.exec(u.pathname);
  if (upload && e.request.method === 'POST') {
    e.respondWith(
      (async () => {
        const blob = await e.request.blob();
        if (blob.size > 2 * 1024 ** 3) return json({ error: 'File exceeds 2 GB.' }, 400);
        await tx('originals', 'readwrite', (s) => s.put({ id: upload[1], blob }));
        return json({ stored: true });
      })().catch(() => json({ error: 'Not enough device storage to import this file.' }, 507)),
    );
    return;
  }
  const m = /^\/api\/media\/([\w-]{11})\/(file|status|prepare|keepalive)$/.exec(u.pathname);
  if (!m) return;
  e.respondWith(
    m[2] === 'file'
      ? media(e.request, m[1]).catch(
          () =>
            new Response('Direct streaming failed. Source CORS, expiry or network error.', {
              status: 502,
            }),
        )
      : Promise.resolve(
          m[2] === 'keepalive' ? new Response(null, { status: 204 }) : json({ state: 'ready' }),
        ),
  );
});
