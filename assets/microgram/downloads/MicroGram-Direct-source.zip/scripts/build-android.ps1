param([switch]$LiveTest)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$taskJdkRoot=Join-Path $projectRoot '.tools/jdk'
$taskJdk=if(Test-Path -LiteralPath $taskJdkRoot){Get-ChildItem -LiteralPath $taskJdkRoot -Directory | Where-Object {Test-Path (Join-Path $_.FullName 'bin/java.exe')} | Select-Object -First 1}
if($taskJdk){$env:JAVA_HOME=$taskJdk.FullName}
if(-not $env:JAVA_HOME){throw 'Install Java 21 or provide the workspace JDK under .tools/jdk.'}
$taskSdk=Join-Path $projectRoot '.tools/android-sdk'
if(Test-Path -LiteralPath $taskSdk){$env:ANDROID_SDK_ROOT=$taskSdk}
elseif(-not $env:ANDROID_SDK_ROOT -and $env:ANDROID_HOME){$env:ANDROID_SDK_ROOT=$env:ANDROID_HOME}
if(-not $env:ANDROID_SDK_ROOT){throw 'Install Android SDK and set ANDROID_SDK_ROOT.'}
$env:GRADLE_USER_HOME=Join-Path $projectRoot '.tools/gradle'
# Quotes embedded in Windows PATH break Gradle's forked JVM arguments.
$env:Path=$env:Path.Replace('"','')
$env:VITE_DEVICE_STREAMING='true'
& npm.cmd run build
if($LASTEXITCODE -ne 0){throw 'Frontend build failed.'}
& npx.cmd cap sync android
if($LASTEXITCODE -ne 0){throw 'Android sync failed.'}
$taskAssets=Join-Path $projectRoot 'android/app/src/main/assets/public/assets'
Get-ChildItem -LiteralPath $taskAssets -File | Where-Object {$_.Extension -in @('.gz','.br')} | ForEach-Object {Remove-Item -LiteralPath $_.FullName}

$taskGradleArgs=@('-p','android',':app:assembleDebug',':app:testDebugUnitTest','--no-daemon','--console=plain')
if($LiveTest){$taskGradleArgs+='-Dmicrogram.live=true'}
& (Join-Path $projectRoot 'android/gradlew.bat') @taskGradleArgs
if($LASTEXITCODE -ne 0){throw 'Android build or native tests failed.'}
New-Item -ItemType Directory -Path (Join-Path $projectRoot 'artifacts') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $projectRoot 'android/app/build/outputs/apk/debug/app-debug.apk') -Destination (Join-Path $projectRoot 'artifacts/Microgram.apk') -Force
Write-Output 'APK: artifacts/Microgram.apk'
