import { execFileSync } from 'node:child_process';
export default function build() {
  execFileSync(
    process.execPath,
    ['node_modules/vite/bin/vite.js', 'build', '--outDir', '.tools/community-test-dist'],
    {
      env: {
        ...process.env,
        VITE_COMMUNITY_URL: 'https://community.example',
        VITE_DEVICE_STREAMING: 'false',
      },
      stdio: 'inherit',
    },
  );
}
