import { readdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { brotliCompressSync, gzipSync, constants } from 'node:zlib';
const dir = resolve('dist/assets');
let count = 0;
for (const name of await readdir(dir)) {
  if (!/\.(js|css|svg)$/.test(name)) continue;
  const data = await readFile(resolve(dir, name));
  if (data.length < 1024) continue;
  await writeFile(
    resolve(dir, name + '.br'),
    brotliCompressSync(data, { params: { [constants.BROTLI_PARAM_QUALITY]: 5 } }),
  );
  await writeFile(resolve(dir, name + '.gz'), gzipSync(data, { level: 6 }));
  count++;
}
console.log(`Prepared compressed copies of ${count} assets.`);
