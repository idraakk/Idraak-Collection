#!/usr/bin/env bash
set -euo pipefail

curl_source() {
  curl --fail --silent --show-error --location --retry 3 --output "$1" "$2"
}

mkdir -p .tools/dependency-sources
curl_source .tools/NewPipeExtractor-v0.26.5-source.zip \
  https://codeload.github.com/TeamNewPipe/NewPipeExtractor/zip/refs/tags/v0.26.5
nanojson=e9d656ddb49a412a5a0a5d5ef20ca7ef09549996
curl_source ".tools/dependency-sources/nanojson-$nanojson.zip" \
  "https://codeload.github.com/TeamNewPipe/nanojson/zip/$nanojson"

maven_source() {
  local group=$1 artifact=$2 version=$3
  local filename="$artifact-$version-sources.jar"
  curl_source ".tools/dependency-sources/$filename" \
    "https://repo.maven.apache.org/maven2/${group//.//}/$artifact/$version/$filename"
}

maven_source org.jsoup jsoup 1.22.2
maven_source com.google.code.findbugs jsr305 3.0.2
maven_source com.google.protobuf protobuf-javalite 4.35.1
maven_source org.mozilla rhino 1.8.1
maven_source org.mozilla rhino-engine 1.8.1
