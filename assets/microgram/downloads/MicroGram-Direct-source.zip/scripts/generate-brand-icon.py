"""Rebuild vector and launcher assets from the existing OFL Manrope font.
Requires Pillow and fonttools (local tooling under .tools/branding/python is supported).
The reference composition is a black circle and two pink lines: micro / gram.
"""
from pathlib import Path
import sys, shutil
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / '.tools/branding/python'))
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.recordingPen import DecomposingRecordingPen, RecordingPen
from PIL import Image, ImageDraw, ImageFont
font = TTFont(ROOT / 'node_modules/@fontsource/manrope/files/manrope-latin-800-normal.woff2')
font.flavor = None
work = ROOT / '.tools/branding'; work.mkdir(parents=True, exist_ok=True)
font.save(work / 'manrope-800.ttf')
glyphs = font.getGlyphSet(); cmap = font.getBestCmap()
words = ['micro', 'gram.']
def circle(pen,cx,cy,r):
    k=r*0.5522847498
    pen.moveTo((cx+r,cy));pen.curveTo((cx+r,cy+k),(cx+k,cy+r),(cx,cy+r));pen.curveTo((cx-k,cy+r),(cx-r,cy+k),(cx-r,cy));pen.curveTo((cx-r,cy-k),(cx-k,cy-r),(cx,cy-r));pen.curveTo((cx+k,cy-r),(cx+r,cy-k),(cx+r,cy));pen.closePath()
def contours(name):
    recording=DecomposingRecordingPen(glyphs);glyphs[name].draw(recording)
    result=[];current=[]
    for operation in recording.value:
        current.append(operation)
        if operation[0] in ('closePath','endPath'):
            part=RecordingPen();part.value=current;bound=BoundsPen(glyphs);part.replay(bound);result.append((part,bound.bounds));current=[]
    return result
def glyph(char,pen):
    name=cmap[ord(char)]
    if char not in ('i','.'):
        glyphs[name].draw(pen);return
    parts=contours(name);dot=max(parts,key=lambda part:part[1][3])
    for part,box in parts:
        if part is not dot[0]:part.replay(pen)
    box=dot[1];circle(pen,(box[0]+box[2])/2,(box[1]+box[3])/2,(box[2]-box[0])*(0.75 if char=='.' else 0.5))
def outline(word, pen, scale=1, x=0, baseline=0):
    advance = 0
    for char in word:
        name = cmap[ord(char)]
        glyph(char,TransformPen(pen, (scale,0,0,-scale,x+advance*scale,baseline)))
        advance += font['hmtx'][name][0]
def bounds(word):
    pen=BoundsPen(glyphs); outline(word,pen); return pen.bounds
boxes=[bounds(word) for word in words]
scale=780/max(box[2]-box[0] for box in boxes)
heights=[(box[3]-box[1])*scale for box in boxes]
top=(1024-sum(heights)-12)/2
paths=[]; layout=[]
for word,box,height in zip(words,boxes,heights):
    x=(1024-(box[2]-box[0])*scale)/2-box[0]*scale
    baseline=top-box[1]*scale
    pen=SVGPathPen(glyphs); outline(word,pen,scale,x,baseline)
    paths.append(pen.getCommands()); layout.append((word,x,baseline)); top+=height+12
pink='#ff4e94'
colored=[('#ffffff',paths[0]),(pink,paths[1])]
for word,x,baseline in layout:
    advance=0
    for char in word:
        if char in ('i','.'):
            box=max(contours(cmap[ord(char)]),key=lambda part:part[1][3])[1]
            pen=SVGPathPen(glyphs)
            circle(TransformPen(pen,(scale,0,0,-scale,x+advance*scale,baseline)),(box[0]+box[2])/2,(box[1]+box[3])/2,(box[2]-box[0])*(0.75 if char=='.' else 0.5))
            colored.append((pink if char=='i' else '#ffffff',pen.getCommands()))
        advance+=font['hmtx'][cmap[ord(char)]][0]

svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><circle cx="512" cy="512" r="512" fill="#000"/>'+''.join(f'<path fill="{color}" d="{path}"/>' for color,path in colored)+'</svg>'
(ROOT/'public/icon.svg').write_text(svg)
def vector(factor,offset,circle=False):
    result='<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">'
    if circle: result+='<path android:fillColor="#000000" android:pathData="M54,0 A54,54 0,1 1,54,108 A54,54 0,1 1,54,0 Z"/>'
    result+=f'<group android:scaleX="{factor}" android:scaleY="{factor}" android:translateX="{offset}" android:translateY="{offset}">'
    result+=''.join(f'<path android:fillColor="{color}" android:pathData="{path}"/>' for color,path in colored)
    return result+'</group></vector>'
res=ROOT/'android/app/src/main/res'
(res/'drawable/microgram_mark.xml').write_text(vector(72/1024,18))
heavyFont,heavyGlyphs,heavyCmap=font,glyphs,cmap
font=TTFont(ROOT/'node_modules/@fontsource/manrope/files/manrope-latin-500-normal.woff2');glyphs=font.getGlyphSet();cmap=font.getBestCmap()
signature=SVGPathPen(glyphs)
creditScale=0.036
creditX=902-sum(font['hmtx'][cmap[ord(c)]][0] for c in 'by Idraak')*creditScale
outline('by ',signature,creditScale,creditX,790)
nameX=creditX+sum(font['hmtx'][cmap[ord(c)]][0] for c in 'by ')*creditScale
name=SVGPathPen(glyphs);outline('Idraak',name,creditScale,nameX,790)
font,glyphs,cmap=heavyFont,heavyGlyphs,heavyCmap
credit=f'<path fill="#777777" d="{signature.getCommands()}"/><path fill="#eeeeee" d="{name.getCommands()}"/>'
brand=svg.replace('<circle cx="512" cy="512" r="512" fill="#000"/>','<rect width="1024" height="1024" fill="#000"/>')
(ROOT/'public/brand-post.svg').write_text(brand)
splash=vector(80/1024,14).replace('108dp','288dp')
splash=splash.replace('</group>',f'<path android:fillColor="#777777" android:pathData="{signature.getCommands()}"/><path android:fillColor="#eeeeee" android:pathData="{name.getCommands()}"/></group>')
(res/'drawable/microgram_splash.xml').write_text(splash)
for name in ['ic_launcher','ic_launcher_round']:
    (res/f'mipmap-anydpi/{name}.xml').write_text(vector(108/1024,0,True))
    (res/f'mipmap-anydpi-v26/{name}.xml').write_text('<?xml version="1.0" encoding="utf-8"?><adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@drawable/microgram_mark"/></adaptive-icon>')
(res/'values/ic_launcher_background.xml').write_text('<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#000000</color></resources>')
image=Image.new('RGBA',(1024,1024)); draw=ImageDraw.Draw(image); draw.ellipse((0,0,1023,1023),fill='#000000')
face=ImageFont.truetype(str(work/'manrope-800.ttf'),round(font['head'].unitsPerEm*scale))
for word,x,baseline in layout:
    advance=0
    for char in word:
        at=x+advance*scale
        draw.text((round(at),round(baseline)),char,font=face,anchor='ls',fill=('#ffffff' if word=='micro' else pink))
        if char in ('i','.'):
            box=max(contours(cmap[ord(char)]),key=lambda part:part[1][3])[1]
            rect=(at+box[0]*scale,baseline-box[3]*scale,at+box[2]*scale,baseline-box[1]*scale)
            draw.rectangle((rect[0]-1,rect[1]-1,rect[2]+1,rect[3]+1),fill='#000000')
            cx=(rect[0]+rect[2])/2;cy=(rect[1]+rect[3])/2;r=(rect[2]-rect[0])*(0.75 if char=='.' else 0.5)
            draw.ellipse((cx-r,cy-r,cx+r,cy+r),fill=('#ffffff' if char=='.' else pink))
        advance+=font['hmtx'][cmap[ord(char)]][0]
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    for name in ['ic_launcher','ic_launcher_round']:
        image.resize((size,size),Image.Resampling.LANCZOS).save(res/f'mipmap-{density}/{name}.png')
    full=round(size*108/48); fg=Image.new('RGBA',(full,full)); inner=round(full*72/108)
    fg.paste(image.resize((inner,inner),Image.Resampling.LANCZOS),((full-inner)//2,(full-inner)//2))
    fg.save(res/f'mipmap-{density}/ic_launcher_foreground.png')
image.save(ROOT/'public/icon-1024.png')
for size in [192,512]: image.resize((size,size),Image.Resampling.LANCZOS).save(ROOT/f'public/icon-{size}.png')
notice=ROOT/'public/font-notices'; notice.mkdir(exist_ok=True)
shutil.copyfile(ROOT/'node_modules/@fontsource/manrope/LICENSE',notice/'Manrope-OFL.txt')
print('Generated black-circle MicroGram icons with vector wordmark and branded pink.')
