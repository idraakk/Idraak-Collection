param([switch]$SkipBuild)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
if (-not $SkipBuild) {
  $env:VITE_DEVICE_STREAMING = 'true'
  & npm.cmd run build
  if ($LASTEXITCODE -ne 0) { throw 'Streaming build failed.' }
}
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class MicroGramAwake {
 [DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint flags);
}
"@
try {
  [MicroGramAwake]::SetThreadExecutionState([uint32]2147483649) | Out-Null
  & node (Join-Path $PSScriptRoot 'laptop-host.mjs')
  if ($LASTEXITCODE -ne 0) { throw 'Laptop host stopped with an error.' }
} finally { [MicroGramAwake]::SetThreadExecutionState([uint32]2147483648) | Out-Null }
