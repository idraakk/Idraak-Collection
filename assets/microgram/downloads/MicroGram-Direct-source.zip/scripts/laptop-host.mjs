import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { register } from 'tsx/esm/api';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
const folder = resolve(root, '.hosting');
await mkdir(folder, { recursive: true });
const configFile = resolve(folder, 'config.json');
let config;
try {
  config = JSON.parse(await readFile(configFile, 'utf8'));
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
  config = { requirePassword: false, password: randomBytes(18).toString('base64url'), port: 3003 };
  await writeFile(configFile, JSON.stringify(config, null, 2));
}
if (config.requirePassword && (typeof config.password !== 'string' || config.password.length < 12))
  throw new Error('Local hosting password must have at least 12 characters.');
process.env.STREAMING_MODE = 'device';
process.env.STREAM_RELAY = 'true';
process.env.HOST = '127.0.0.1';
process.env.PORT = String(config.port || 3003);
// Funnel terminates HTTPS and forwards directly to this loopback listener.
process.env.TRUST_PROXY_HOPS = '1';
process.env.FRIENDS_PASSWORD = config.requirePassword ? config.password : '';
process.env.MEDIA_PYTHON = resolve(root, '.venv/Scripts/python.exe');
console.log(`MicroGram laptop host: http://localhost:${process.env.PORT}`);
console.log(
  config.requirePassword
    ? 'Login enabled; credentials are in .hosting/config.json.'
    : 'Public access enabled; no login required.',
);
register();
await import('../server/index.ts');
await writeFile(
  resolve(folder, 'server.json'),
  JSON.stringify({ pid: process.pid, root, port: Number(process.env.PORT) }),
);
