"""Package tracked and new project sources, excluding private data and build output.

Requires the pinned upstream source ZIP at .tools/NewPipeExtractor-v0.26.5-source.zip.
Optional dependency sources in .tools/dependency-sources are bundled as well.
"""
from pathlib import Path
import hashlib
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
upstream = root / '.tools/NewPipeExtractor-v0.26.5-source.zip'
if not upstream.is_file():
    raise SystemExit('Download the pinned source ZIP from https://codeload.github.com/TeamNewPipe/NewPipeExtractor/zip/refs/tags/v0.26.5 first.')
artifact = root / 'artifacts/MicroGram-Direct-source.zip'
artifact.parent.mkdir(exist_ok=True)
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=root).decode().split('\0')
excluded = {'.git', '.tools', '.hosting', '.media', '.venv', 'node_modules', 'dist', 'artifacts', 'personal-app'}
with zipfile.ZipFile(artifact, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(set(names)):
        path = Path(name)
        if not name or any(part in excluded for part in path.parts):
            continue
        if any(part.startswith(('.env', '.dev.vars')) or part == '.wrangler' for part in path.parts) or path.name in {'streaming.env', 'local.properties'} or path.suffix in {'.jks', '.keystore', '.apk'}:
            continue
        source = root / path
        if source.is_file():
            archive.write(source, path.as_posix())
    archive.write(upstream, 'third-party/' + upstream.name, compress_type=zipfile.ZIP_STORED)
    for source in sorted((root / '.tools/dependency-sources').glob('*')):
        if source.is_file():
            archive.write(source, 'third-party/' + source.name, compress_type=zipfile.ZIP_STORED)
    archive.write(root / 'android/app/src/main/assets/licenses/NewPipeExtractor-GPL-3.0.txt', 'COPYING-GPL-3.0.txt')
    archive.writestr('DISTRIBUTION-NOTICE.txt', 'MicroGram Android Direct links NewPipeExtractor. The combined Android edition is distributed under GPL-3.0-or-later. Original component MIT and third-party notices are retained. See android/NEWPIPE-NOTICE.md and docs/ANDROID_DIRECT.md.\n')
print(f'{artifact.name}: {artifact.stat().st_size} bytes')
print('SHA256:', hashlib.sha256(artifact.read_bytes()).hexdigest())
