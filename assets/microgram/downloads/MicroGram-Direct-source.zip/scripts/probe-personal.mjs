import { chromium } from '@playwright/test';
const browser = await chromium.launch({channel:'msedge'});
try {
 const page = await browser.newPage({viewport:{width:390,height:844}});
 await page.goto('http://127.0.0.1:5174');
 await page.getByRole('button',{name:'Play this reel'}).click();
 await page.getByRole('button',{name:'Enable personal playback'}).click();
 const video=page.locator('video.native-video');
 await video.waitFor();
 await page.waitForFunction(()=>document.querySelector('video.native-video')?.currentTime>2);
 await page.screenshot({path:'artifacts/personal-youtube-cached.png'});
 const before=await video.evaluate(v=>({time:v.currentTime,width:v.videoWidth,height:v.videoHeight,paused:v.paused}));
 await page.keyboard.press('ArrowDown');
 await page.waitForFunction(()=>document.querySelector('video.native-video')?.currentTime>60);
 console.log(JSON.stringify({before,after:await video.evaluate(v=>({time:v.currentTime,paused:v.paused})),iframes:await page.locator('iframe').count()}));
} finally {await browser.close();}
