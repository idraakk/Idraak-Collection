import { chromium } from '@playwright/test';
const browser = await chromium.launch({ channel: process.env.PLAYWRIGHT_CHANNEL || undefined });
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  await page.goto(process.env.PROBE_URL || 'http://127.0.0.1:5173');
  await page.getByRole('button', { name: 'Play this reel' }).click();
  await page.getByRole('button', { name: 'Enable YouTube playback' }).click();
  await page.waitForTimeout(8000);
  const frame = page.frames().find((f) => f.url().includes('youtube.com/embed'));
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('microgram.v1') || '{}'));
  console.log(
    JSON.stringify({
      embeddedFrame: !!frame,
      playerMessage: await page.locator('.player-shell').innerText(),
      watchedSeconds: saved.progress?.fNk_zzaMoSs?.length ?? 0,
      youtubeText: frame ? (await frame.locator('body').innerText()).slice(0, 800) : null,
    }),
  );
  const originalIframe = await page.locator('.youtube-player iframe').elementHandle();
  await page.getByRole('button', { name: 'Next reel', exact: true }).click();
  await page.waitForTimeout(3500);
  console.log(
    JSON.stringify({
      sameIframe: await originalIframe?.evaluate((el) => el.isConnected),
      reel: await page.locator('.reel-counter').innerText(),
      controlsHidden: (await page.locator('.youtube-player iframe').getAttribute('src'))?.includes(
        'controls=0',
      ),
      videoTime: frame
        ? await frame
            .locator('video')
            .evaluate((video) => video.currentTime)
            .catch(() => null)
        : null,
    }),
  );
  await page.screenshot({ path: 'artifacts/youtube-playback.png', fullPage: true });
} finally {
  await browser.close();
}
