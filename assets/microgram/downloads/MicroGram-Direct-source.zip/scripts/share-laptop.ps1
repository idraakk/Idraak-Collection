$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$config=Get-Content -LiteralPath (Join-Path $projectRoot '.hosting/config.json') -Raw | ConvertFrom-Json
$tailscale=Join-Path $env:ProgramFiles 'Tailscale/tailscale.exe'
if(-not (Test-Path -LiteralPath $tailscale)){throw 'Install Tailscale and sign in first.'}
$status=& $tailscale status --json | ConvertFrom-Json
if($status.BackendState -ne 'Running'){throw 'Tailscale is not connected. Open Tailscale, sign in, and approve this laptop first.'}
try { $health=Invoke-RestMethod -Uri "http://127.0.0.1:$($config.port)/api/health" -TimeoutSec 5 } catch {throw 'Start the laptop host before sharing: npm.cmd run host:laptop'}
& $tailscale funnel --bg --https=443 "http://127.0.0.1:$($config.port)"
if($LASTEXITCODE -ne 0){throw 'Funnel setup needs attention. Follow the Tailscale approval link shown above.'}
& $tailscale funnel status
