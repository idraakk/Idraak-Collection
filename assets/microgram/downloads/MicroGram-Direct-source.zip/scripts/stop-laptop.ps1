$ErrorActionPreference='Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$stateFile=Join-Path $projectRoot '.hosting/server.json'
if(Test-Path -LiteralPath $stateFile){
 $hostState=Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
 $hostProcess=Get-CimInstance Win32_Process -Filter "ProcessId = $($hostState.pid)"
 if($hostProcess){
  $entry=Join-Path $projectRoot 'scripts/laptop-host.mjs'
  if(-not $hostProcess.CommandLine.Contains($entry)){throw 'Process does not match this MicroGram host; refusing to stop it.'}
  Stop-Process -Id $hostState.pid
 }
 Remove-Item -LiteralPath $stateFile
}
Write-Output 'MicroGram laptop server stopped. To remove its public tunnel, run: tailscale funnel --https=443 off'
