import json, sys
import yt_dlp

video_id, language = sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ''
with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True, 'skip_download': True,
                     'socket_timeout': 15, 'retries': 1, 'cachedir': False,
                     'extractor_args': {'youtube': {'skip': ['translated_subs']}}}) as ydl:
    info = ydl.extract_info('https://www.youtube.com/watch?v=' + video_id, download=False)
    tracks = {}
    for automatic, source in [(False, info.get('subtitles', {})), (True, info.get('automatic_captions', {}))]:
        for code, formats in source.items():
            if code == 'live_chat' or code in tracks:
                continue
            item = next((f for f in formats if f.get('ext') == 'vtt'), None)
            if item:
                tracks[code] = {'language': code, 'label': item.get('name', code) + (' (auto)' if automatic else ''), 'url': item['url']}
    if not language:
        print(json.dumps({'tracks': [{k: v for k, v in t.items() if k != 'url'} for t in tracks.values()]}))
    elif language not in tracks:
        print(json.dumps({'error': 'This caption language is no longer available.'}))
    else:
        with ydl.urlopen(tracks[language]['url']) as response:
            data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise ValueError('Caption track is too large')
        text = data.decode('utf-8-sig')
        if not text.startswith('WEBVTT'):
            raise ValueError('Unsupported caption format')
        print(json.dumps({'vtt': text}))
