import { Router } from 'express';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { resolve } from 'node:path';
import rateLimit from 'express-rate-limit';

export const captions = Router();
let active = 0;
const cache = new Map<string, { at: number; data: object }>();
captions.use(
  '/:id/captions',
  rateLimit({ windowMs: 60000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false }),
);
captions.get('/:id/captions', async (req, res) => {
  const language = req.query.language ?? '';
  if (
    !/^[\w-]{11}$/.test(req.params.id) ||
    typeof language !== 'string' ||
    !/^[\w.-]{0,40}$/.test(language)
  ) {
    res.status(400).json({ error: 'Invalid caption request.' });
    return;
  }
  const key = `${req.params.id}:${language}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < 30 * 60_000) {
    res.json(cached.data);
    return;
  }
  if (active >= 2) {
    res.status(429).json({ error: 'Captions are busy. Try again shortly.' });
    return;
  }
  active++;
  try {
    const { stdout } = await promisify(execFile)(
      process.env.MEDIA_PYTHON || resolve('.venv/Scripts/python.exe'),
      [resolve('server/captions.py'), req.params.id, language],
      { windowsHide: true, timeout: 90000, maxBuffer: 4 * 1024 * 1024 },
    );
    const data = JSON.parse(stdout);
    if (data.error) {
      res.status(404).json(data);
      return;
    }
    // Bounded, short-lived memory cache; no subtitle files accumulate on disk.
    if (cache.size >= 20) cache.delete(cache.keys().next().value!);
    cache.set(key, { at: Date.now(), data });
    res.json(data);
  } catch {
    res.status(502).json({
      error: 'YouTube captions are unavailable for this video right now. Try again later.',
    });
  } finally {
    active--;
  }
});
