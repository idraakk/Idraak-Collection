import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { RequestHandler } from 'express';
export const compressedAssets: RequestHandler = (req, res, next) => {
  if (
    !['GET', 'HEAD'].includes(req.method) ||
    !/^\/assets\/[\w.-]+\.(js|css|svg)$/.test(req.path)
  ) {
    next();
    return;
  }
  const file = resolve('dist', req.path.slice(1));
  const encoding = req.acceptsEncodings('br', 'gzip', 'identity');
  const suffix = encoding === 'br' ? '.br' : encoding === 'gzip' ? '.gz' : '';
  res.vary('Accept-Encoding');
  if (!suffix || !existsSync(file + suffix)) {
    next();
    return;
  }
  res.set({
    'Content-Encoding': String(encoding),
    'Cache-Control': 'public, max-age=31536000, immutable',
  });
  res.type(file).sendFile(file + suffix);
};
