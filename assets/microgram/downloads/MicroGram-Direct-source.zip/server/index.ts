import { compressedAssets } from './compressedAssets';
import 'dotenv/config';
import { media } from './media';
import { streaming } from './streaming';
import { captions } from './captions';
import { libraryMetadata } from './libraryMetadata';
import express from 'express';
import { createHash, timingSafeEqual } from 'node:crypto';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { resolve } from 'node:path';
import { ImportError, importYouTube } from './youtube';
const app = express();
app.disable('x-powered-by');
// Only enable a known number of trusted reverse-proxy hops on managed hosting.
if (/^[1-3]$/.test(process.env.TRUST_PROXY_HOPS || ''))
  app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS));
if (process.env.FRIENDS_PASSWORD)
  app.use((req, res, next) => {
    if (req.path === '/api/health') {
      next();
      return;
    }
    const digest = (value: string) => createHash('sha256').update(value).digest();
    const expected = `Basic ${Buffer.from(`friends:${process.env.FRIENDS_PASSWORD}`).toString('base64')}`;
    if (timingSafeEqual(digest(req.get('authorization') || ''), digest(expected))) next();
    else
      res
        .set('WWW-Authenticate', 'Basic realm="MicroGram friends", charset="UTF-8"')
        .status(401)
        .send('Sign in with your MicroGram friends password.');
  });
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        'script-src': ["'self'", 'https://www.youtube.com', 'https://s.ytimg.com'],
        'frame-src': ['https://www.youtube.com', 'https://www.youtube-nocookie.com'],
        'img-src': [
          "'self'",
          'data:',
          'blob:',
          'https://i.ytimg.com',
          'https://yt3.ggpht.com',
          'https://yt3.googleusercontent.com',
          // Creator posts accept validated HTTPS images; no remote executable content.
          ...(process.env.VITE_COMMUNITY_URL ? ['https:'] : []),
        ],
        'media-src': ["'self'", 'blob:', ...(process.env.VITE_COMMUNITY_URL ? ['https:'] : [])],
        'style-src': ["'self'", "'unsafe-inline'"],
        'connect-src': [
          "'self'",
          ...(process.env.STREAMING_MODE === 'device' ? ['https://*.googlevideo.com'] : []),
          ...(process.env.VITE_COMMUNITY_URL ? [new URL(process.env.VITE_COMMUNITY_URL).origin] : []),
        ],
        'upgrade-insecure-requests': null,
      },
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }),
);
const origins = (
  process.env.ALLOWED_ORIGINS ?? 'https://localhost,http://localhost,http://127.0.0.1:5173'
).split(',');
app.use(cors({ origin: origins }));
if (process.env.STREAMING_MODE === 'device') {
  app.use('/api/stream', streaming);
  app.use('/api/media', captions);
  app.use('/api/media', (_req, res) =>
    res.status(503).json({
      error: 'Device streaming requires HTTPS and an active device cache. Reload the app.',
    }),
  );
} else app.use('/api/media', media);
app.use(express.json({ limit: '4kb' }));
app.use('/api/library-metadata', libraryMetadata);
app.get('/api/health', (_req, res) =>
  res.json({ status: 'ok', youtubeConfigured: !!process.env.YOUTUBE_API_KEY }),
);
app.use(
  '/api/import',
  rateLimit({
    windowMs: 60 * 60 * 1000,
    limit: 15,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: { error: 'Import limit reached. Please try again in an hour.' },
  }),
);
let activeImports = 0;
app.post('/api/import', async (req, res) => {
  const parsed = z.object({ url: z.string().max(2048) }).safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'A YouTube URL is required.' });
    return;
  }
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) {
    res.status(503).json({
      error:
        'Video and playlist imports are not configured yet. For local setup, add YOUTUBE_API_KEY to the project’s .env file and restart the development server. See README.md for setup steps.',
    });
    return;
  }
  if (activeImports >= 4) {
    res.status(503).json({ error: 'Imports are busy. Please try again shortly.' });
    return;
  }
  activeImports++;
  try {
    res.json(await importYouTube(parsed.data.url, key));
  } catch (error) {
    res
      .status(error instanceof ImportError ? error.status : 400)
      .json({ error: error instanceof Error ? error.message : 'Import failed.' });
  } finally {
    activeImports--;
  }
});
app.use(compressedAssets);
app.use('/assets', express.static(resolve('dist/assets'), { maxAge: '1y', immutable: true }));
app.use(express.static(resolve('dist')));
app.get('/{*path}', (_req, res) => res.sendFile(resolve('dist/index.html')));
app.use(
  (error: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    res.status(400).json({ error: 'Invalid request.' });
  },
);
app.listen(Number(process.env.PORT ?? 3001), process.env.HOST || '0.0.0.0', () =>
  console.log(`MicroGram API listening on port ${process.env.PORT ?? 3001}`),
);
