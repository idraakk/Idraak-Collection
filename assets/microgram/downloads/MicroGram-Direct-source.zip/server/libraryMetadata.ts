import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';

export type LibraryMetadata = {
  id: string;
  channel: string;
  avatar?: string;
  thumbnail?: string;
  views?: string;
  publishedAt?: string;
};
type Item = {
  id: string;
  snippet: {
    channelId?: string;
    channelTitle?: string;
    publishedAt?: string;
    thumbnails?: Record<string, { url: string }>;
  };
  statistics?: { viewCount?: string };
};
export async function fetchLibraryMetadata(
  videoIds: string[],
  playlistIds: string[],
  key: string,
  request: typeof fetch = fetch,
) {
  async function api(endpoint: string, ids: string[], part: string): Promise<Item[]> {
    if (!ids.length) return [];
    const url = new URL(`https://www.googleapis.com/youtube/v3/${endpoint}`);
    url.search = new URLSearchParams({ id: ids.join(','), part, key }).toString();
    const response = await request(url, { signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error('Creator details are temporarily unavailable.');
    return (await response.json()).items ?? [];
  }
  const [videos, playlists] = await Promise.all([
    api('videos', videoIds, 'snippet,statistics'),
    api('playlists', playlistIds, 'snippet'),
  ]);
  const channels = [
    ...new Set(
      [...videos, ...playlists].flatMap((v) => (v.snippet.channelId ? [v.snippet.channelId] : [])),
    ),
  ];
  const channelItems = await api('channels', channels, 'snippet');
  const avatars = new Map(
    channelItems.map((c) => [
      c.id,
      c.snippet.thumbnails?.medium?.url ?? c.snippet.thumbnails?.default?.url,
    ]),
  );
  const safeImage = (url?: string) => {
    if (!url) return undefined;
    try {
      const u = new URL(url);
      return u.protocol === 'https:' &&
        ['yt3.ggpht.com', 'yt3.googleusercontent.com', 'i.ytimg.com'].includes(u.hostname)
        ? url
        : undefined;
    } catch {
      return undefined;
    }
  };
  const map = (v: Item): LibraryMetadata => ({
    id: v.id,
    channel: v.snippet.channelTitle ?? '',
    avatar: safeImage(avatars.get(v.snippet.channelId ?? '')),
    thumbnail: safeImage(v.snippet.thumbnails?.maxres?.url ?? v.snippet.thumbnails?.high?.url),
    views: v.statistics?.viewCount,
    publishedAt: v.snippet.publishedAt,
  });
  return { videos: videos.map(map), playlists: playlists.map(map) };
}
export const libraryMetadata = Router();
const cache = new Map<
  string,
  { at: number; data: Awaited<ReturnType<typeof fetchLibraryMetadata>> }
>();
let active = 0;
libraryMetadata.post(
  '/',
  rateLimit({ windowMs: 60000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false }),
  async (req, res) => {
    const parsed = z
      .object({
        videoIds: z.array(z.string().regex(/^[\w-]{11}$/)).max(20),
        playlistIds: z.array(z.string().regex(/^[\w-]{10,100}$/)).max(20),
      })
      .safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid library metadata request.' });
      return;
    }
    const key = process.env.YOUTUBE_API_KEY;
    if (!key) {
      res.status(503).json({ error: 'Creator details need YouTube API setup.' });
      return;
    }
    const identity = JSON.stringify(parsed.data);
    const old = cache.get(identity);
    if (old && Date.now() - old.at < 3600000) {
      res.json(old.data);
      return;
    }
    if (active >= 3) {
      res.status(429).json({ error: 'Creator details are busy. Try again later.' });
      return;
    }
    active++;
    try {
      const data = await fetchLibraryMetadata(parsed.data.videoIds, parsed.data.playlistIds, key);
      if (cache.size >= 100) cache.delete(cache.keys().next().value!);
      cache.set(identity, { at: Date.now(), data });
      res.json(data);
    } catch {
      res.status(502).json({ error: 'Creator details are temporarily unavailable.' });
    } finally {
      active--;
    }
  },
);
