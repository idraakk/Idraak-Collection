import { Router, json } from 'express';
import { mediaBudget, mediaFormat, maxMediaFile } from './mediaBudget';
import { MediaCache } from './mediaCache';
import { captions } from './captions';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, stat, readdir, rename, unlink } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { resolve } from 'node:path';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const directory = resolve('.media');
const python = process.env.MEDIA_PYTHON || resolve('.venv/Scripts/python.exe');
const maxFile = maxMediaFile;
const cache = new MediaCache(directory);
const jobs = new Map<string, { state: string; error?: string }>();
let active = false;
function clearStorageErrors() {
  for (const [id, job] of jobs)
    if (job.state === 'error' && /storage|space|cache|disk/i.test(job.error ?? '')) jobs.delete(id);
}
const valid = (id: string) => /^[\w-]{11}$/.test(id);
const file = (id: string) => resolve(directory, `${id}.mp4`);
async function exists(id: string) {
  return stat(file(id))
    .then((s) => s.size > 0)
    .catch(() => false);
}
async function download(id: string) {
  const pending = resolve(directory, `${id}.pending.mp4`);
  try {
    let budget = mediaBudget();
    try {
      const probe = await promisify(execFile)(
        python,
        [
          '-m',
          'yt_dlp',
          '--ignore-config',
          '--no-playlist',
          '--no-cache-dir',
          '--socket-timeout',
          '15',
          '--retries',
          '1',
          '--js-runtimes',
          `node:${process.execPath}`,
          '-f',
          mediaFormat,
          '--dump-single-json',
          '--',
          `https://www.youtube.com/watch?v=${id}`,
        ],
        { windowsHide: true, timeout: 60000, maxBuffer: 16 * 1024 * 1024 },
      );
      budget = mediaBudget(JSON.parse(probe.stdout));
    } catch {
      /* Some sources omit size metadata. Use a bounded fallback and recheck the finished file. */
    }
    await cache.reserve(id, budget.expected, budget.scratch);
    const { stdout } = await promisify(execFile)(python, [
      '-c',
      'import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())',
    ]);
    await new Promise<void>((done, fail) => {
      const child = spawn(
        python,
        [
          '-m',
          'yt_dlp',
          '--ignore-config',
          '--no-playlist',
          '--no-progress',
          '--no-cache-dir',
          '--socket-timeout',
          '30',
          '--retries',
          '2',
          '--max-filesize',
          String(maxFile),
          '--match-filter',
          'duration <= 86400',
          '--js-runtimes',
          `node:${process.execPath}`,
          '--ffmpeg-location',
          stdout.trim(),
          '-f',
          mediaFormat,
          '--merge-output-format',
          'mp4',
          '--remux-video',
          'mp4',
          '-o',
          pending,
          '--',
          `https://www.youtube.com/watch?v=${id}`,
        ],
        { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] },
      );
      let detail = '';
      let checking = false;
      const diskGuard = setInterval(async () => {
        if (checking) return;
        checking = true;
        try {
          const storage = await cache.snapshot();
          if (storage.free < 256 * 1024 ** 2) {
            child.kill();
            fail(
              new Error(
                'The server disk is almost full. Free disk space in Settings and try again.',
              ),
            );
          }
        } catch {
          /* The download process still reports disk-write errors. */
        } finally {
          checking = false;
        }
      }, 2000);
      child.stderr.on('data', (chunk) => {
        detail = (detail + chunk.toString()).slice(-1500);
      });
      const timeout = setTimeout(() => {
        clearInterval(diskGuard);
        child.kill();
        fail(new Error('Download timed out after 30 minutes.'));
      }, 30 * 60_000);
      child.on('error', (error) => {
        clearTimeout(timeout);
        clearInterval(diskGuard);
        fail(error);
      });
      child.on('close', (code) => {
        clearTimeout(timeout);
        clearInterval(diskGuard);
        if (code === 0) done();
        else
          fail(
            new Error(
              detail.includes('No space left') || detail.includes('Errno 28')
                ? 'The server disk is full. Free disk space in Settings and try again.'
                : detail.includes('Sign in') || detail.includes('403')
                  ? 'YouTube blocked this download. Import an MP4 file instead; no login or access restrictions are bypassed.'
                  : 'The video could not be downloaded. It may be unavailable or unsupported. Try again or import an MP4 file.',
            ),
          );
      });
    });
    const info = await stat(pending);
    if (!info.size || info.size > maxFile)
      throw new Error('The video exceeds the 2 GB per-file limit.');
    // Pending bytes are already on disk. Recheck the actual cache budget before publishing.
    await cache.reserve(id, info.size, 0);
    await rename(pending, file(id));
    await cache.finish(id, 'download');
    jobs.delete(id);
  } catch (error) {
    jobs.set(id, {
      state: 'error',
      error: error instanceof Error ? error.message : 'Download failed.',
    });
    // Only remove temporary files for this validated video ID, never another cache entry.
    for (const name of await readdir(directory).catch(() => [])) {
      if (name.startsWith(`${id}.pending.`)) await unlink(resolve(directory, name)).catch(() => {});
    }
  } finally {
    await cache.finish(id);
    active = false;
  }
}

export const media = Router();
media.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  const origin = req.get('origin');
  if (origin && new URL(origin).host !== req.get('host')) {
    res.status(403).json({ error: 'Use this private server from its own app address.' });
    return;
  }
  next();
});
media.use(captions);
media.use('/storage', json({ limit: '16kb' }));
media.get('/storage', async (_req, res) => {
  res.json(await cache.snapshot());
});
media.post('/storage/clear', async (req, res) => {
  const ids = req.body?.ids;
  if (
    ids !== undefined &&
    (!Array.isArray(ids) ||
      ids.length > 1000 ||
      ids.some((id) => typeof id !== 'string' || !valid(id)))
  ) {
    res.status(400).json({ error: 'Invalid video list.' });
    return;
  }
  const result = await cache.clear(ids);
  clearStorageErrors();
  res.json(result);
});
media.post('/storage/limit', async (req, res) => {
  try {
    await cache.setLimit(req.body?.gib);
    clearStorageErrors();
    res.json(await cache.snapshot());
  } catch (e) {
    res.status(409).json({ error: e instanceof Error ? e.message : 'Could not change limit.' });
  }
});
media.delete('/storage/:id', async (req, res) => {
  if (req.query.confirm !== 'delete-original' || !valid(req.params.id)) {
    res.sendStatus(400);
    return;
  }
  try {
    await cache.deleteOriginal(req.params.id);
    jobs.delete(req.params.id);
    res.json({ deleted: true });
  } catch (e) {
    res.status(409).json({ error: e instanceof Error ? e.message : 'Could not delete file.' });
  }
});
media.post('/:id/keepalive', async (req, res) => {
  if (!valid(req.params.id)) {
    res.sendStatus(400);
    return;
  }
  await cache.touch(req.params.id);
  res.sendStatus(204);
});
media.get('/:id/status', async (req, res) => {
  if (!valid(req.params.id)) {
    res.sendStatus(400);
    return;
  }
  res.json(
    (await exists(req.params.id))
      ? { state: 'ready' }
      : jobs.get(req.params.id)?.state === 'ready'
        ? { state: 'missing' }
        : (jobs.get(req.params.id) ?? { state: 'missing' }),
  );
});
media.post('/:id/prepare', async (req, res) => {
  const id = req.params.id;
  if (!valid(id)) {
    res.sendStatus(400);
    return;
  }
  if (await exists(id)) {
    res.json({ state: 'ready' });
    return;
  }
  if (jobs.get(id)?.state === 'downloading') {
    res.json({ state: 'downloading' });
    return;
  }
  if (active) {
    res.status(429).json({ error: 'Another video is being prepared. Please try again shortly.' });
    return;
  }
  active = true;
  jobs.set(id, { state: 'downloading' });
  void download(id);
  res.status(202).json({ state: 'downloading' });
});
media.get('/:id/file', async (req, res) => {
  if (!valid(req.params.id)) {
    res.sendStatus(400);
    return;
  }
  await cache.touch(req.params.id);
  await cache.hold(req.params.id);
  res.once('close', () => {
    void cache.release(req.params.id);
  });
  if (!(await exists(req.params.id))) {
    res.sendStatus(404);
    return;
  }
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(file(req.params.id), { dotfiles: 'allow' });
});
media.post('/:id/upload', async (req, res) => {
  const id = req.params.id;
  if (!valid(id) || req.get('content-type') !== 'video/mp4') {
    res.sendStatus(400);
    return;
  }
  if (active) {
    res.status(429).json({ error: 'Another video is being prepared. Try again shortly.' });
    return;
  }
  if (await exists(id)) {
    res.status(409).json({ error: 'This file ID already exists.' });
    return;
  }
  if (active) {
    res.status(429).json({ error: 'Another video is being prepared.' });
    return;
  }
  active = true;
  const temporary = resolve(directory, `${id}.upload`);
  try {
    const length = Number(req.get('content-length'));
    if (!Number.isFinite(length) || length <= 0 || length > maxFile)
      throw new Error('MP4 files must be smaller than 2 GB.');
    await cache.reserve(id, length, length);
    let size = 0;
    await pipeline(
      req,
      new Transform({
        transform(chunk, _encoding, cb) {
          size += chunk.length;
          cb(size > maxFile ? new Error('MP4 files must be smaller than 2 GB.') : null, chunk);
        },
      }),
      createWriteStream(temporary, { flags: 'wx' }),
    );
    if (!size) throw new Error('The file is empty.');
    await rename(temporary, file(id));
    await cache.finish(id, 'upload');
    res.status(201).json({ state: 'ready' });
  } catch (error) {
    await unlink(temporary).catch(() => {});
    if (!res.destroyed)
      res.status(400).json({ error: error instanceof Error ? error.message : 'Upload failed.' });
  } finally {
    await cache.finish(id);
    active = false;
  }
});
