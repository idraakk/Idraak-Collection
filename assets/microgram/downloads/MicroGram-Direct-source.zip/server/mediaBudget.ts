const MiB = 1024 ** 2;
export const maxMediaFile = 2 * 1024 ** 3;
export const mediaFormat = 'bv*[vcodec^=avc1][height<=1080]+ba[acodec^=mp4a]/b[ext=mp4]';
type Format = { filesize?: number; filesize_approx?: number; tbr?: number };
type Info = Format & {
  duration?: number;
  requested_formats?: Format[];
  requested_downloads?: Format[];
};
/** Estimates affect admission only; completed size is checked again before promotion. */
export function mediaBudget(info: Info = {}) {
  const parts = info.requested_formats ?? info.requested_downloads ?? [info];
  const duration = Number(info.duration) || 0;
  const estimated = parts.reduce((sum, part) => {
    const size =
      part.filesize ||
      part.filesize_approx ||
      (duration > 0 && part.tbr ? (duration * part.tbr * 1000) / 8 : 0);
    return sum + (Number.isFinite(size) && size > 0 ? size : 256 * MiB);
  }, 0);
  const expected = Math.min(maxMediaFile, Math.max(32 * MiB, Math.ceil(estimated * 1.2)));
  return { expected, scratch: expected * 2 };
}
