import {
  mkdir,
  readFile,
  writeFile,
  rename,
  readdir,
  lstat,
  unlink,
  statfs,
} from 'node:fs/promises';
import { resolve } from 'node:path';
export const GiB = 1024 ** 3;
export const validMediaId = (id: string) => /^[\w-]{11}$/.test(id);
type RecordEntry = { kind: 'download' | 'upload'; used: number };
type Manifest = { limit: number; files: Record<string, RecordEntry> };
export type CacheEntry = {
  id: string;
  bytes: number;
  kind: 'download' | 'upload' | 'legacy';
  used: number;
  protected: boolean;
};
export class MediaCache {
  private data: Manifest = { limit: 10 * GiB, files: {} };
  private initialized = false;
  private tail: Promise<unknown> = Promise.resolve();
  private leases = new Map<string, number>();
  private transfers = new Set<string>();
  private streams = new Map<string, number>();
  constructor(
    readonly directory: string,
    private freeSpace = async () => {
      const s = await statfs(directory);
      return s.bavail * s.bsize;
    },
    private now = Date.now,
  ) {}
  path(id: string) {
    if (!validMediaId(id)) throw new Error('Invalid video ID.');
    return resolve(this.directory, `${id}.mp4`);
  }
  private async locked<T>(action: () => Promise<T>): Promise<T> {
    const task = this.tail.then(async () => {
      await mkdir(this.directory, { recursive: true });
      if (!this.initialized) {
        try {
          const data = JSON.parse(await readFile(resolve(this.directory, 'storage.json'), 'utf8'));
          if (
            [2, 5, 10, 20].includes(data.limit / GiB) &&
            data.files &&
            typeof data.files === 'object'
          ) {
            this.data.limit = data.limit;
            for (const [id, entry] of Object.entries(data.files) as [string, RecordEntry][]) {
              if (
                validMediaId(id) &&
                ['download', 'upload'].includes(entry?.kind) &&
                Number.isFinite(entry.used)
              )
                this.data.files[id] = entry;
            }
          }
        } catch {
          /* Unclassified existing files stay protected; never infer ownership. */
        }
        this.initialized = true;
      }
      return action();
    });
    this.tail = task.catch(() => {});
    return task;
  }
  private async save() {
    const p = resolve(this.directory, 'storage.json');
    await writeFile(p + '.tmp', JSON.stringify(this.data));
    await rename(p + '.tmp', p);
  }
  private busy(id: string) {
    return (
      this.transfers.has(id) ||
      (this.streams.get(id) ?? 0) > 0 ||
      (this.leases.get(id) ?? 0) > this.now()
    );
  }
  async hold(id: string) {
    return this.locked(async () => {
      this.path(id);
      this.streams.set(id, (this.streams.get(id) ?? 0) + 1);
    });
  }
  async release(id: string) {
    return this.locked(async () => {
      this.streams.set(id, Math.max(0, (this.streams.get(id) ?? 0) - 1));
    });
  }
  private async entries(): Promise<CacheEntry[]> {
    const result: CacheEntry[] = [];
    for (const name of await readdir(this.directory)) {
      if (!/^[\w-]{11}\.mp4$/.test(name)) continue;
      const s = await lstat(resolve(this.directory, name));
      if (!s.isFile() || s.isSymbolicLink()) continue;
      const id = name.slice(0, -4),
        meta = this.data.files[id];
      result.push({
        id,
        bytes: s.size,
        kind: meta?.kind ?? 'legacy',
        used: meta?.used ?? s.mtimeMs,
        protected: this.busy(id),
      });
    }
    return result;
  }
  private async remove(entry: CacheEntry) {
    await unlink(this.path(entry.id));
    delete this.data.files[entry.id];
  }
  async snapshot() {
    return this.locked(async () => {
      const entries = await this.entries();
      return {
        entries,
        limit: this.data.limit,
        used: entries.reduce((n, e) => n + e.bytes, 0),
        free: await this.freeSpace(),
        downloading: this.transfers.size > 0,
      };
    });
  }
  async touch(id: string) {
    return this.locked(async () => {
      this.path(id);
      this.leases.set(id, this.now() + 90_000);
      const entry = this.data.files[id];
      if (entry && this.now() - entry.used > 30_000) {
        entry.used = this.now();
        await this.save();
      }
    });
  }
  async reserve(id: string, expected: number, scratch: number) {
    return this.locked(async () => {
      this.path(id);
      // Clean only abandoned temporary files with validated names, never uploads or completed originals.
      for (const name of await readdir(this.directory)) {
        if (
          !/^[\w-]{11}\.(?:pending\..+|upload)$/.test(name) ||
          this.transfers.has(name.slice(0, 11))
        )
          continue;
        const p = resolve(this.directory, name),
          s = await lstat(p);
        if (s.isFile() && !s.isSymbolicLink() && this.now() - s.mtimeMs > 24 * 60 * 60 * 1000)
          await unlink(p);
      }
      const entries = await this.entries();
      let used = entries.reduce((n, e) => n + e.bytes, 0),
        free = await this.freeSpace();
      const victims: CacheEntry[] = [];
      for (const entry of entries
        .filter((e) => e.kind === 'download' && !e.protected && e.id !== id)
        .sort((a, b) => a.used - b.used)) {
        if (used + expected <= this.data.limit && free >= scratch + GiB) break;
        victims.push(entry);
        used -= entry.bytes;
        free += entry.bytes;
      }
      if (used + expected > this.data.limit)
        throw new Error(
          'Not enough cache space. Increase the video cache limit in Settings or remove unneeded downloads. Active videos and originals are protected.',
        );
      if (free < scratch + GiB)
        throw new Error(
          `Not enough server disk space. ${(free / GiB).toFixed(1)} GB is free; about ${((scratch + GiB) / GiB).toFixed(1)} GB is needed including temporary files and a safety margin. Clear downloads or free space on the server drive. Increasing the cache limit will not free disk space.`,
        );
      for (const entry of victims) await this.remove(entry);
      this.transfers.add(id);
      await this.save();
    });
  }
  async finish(id: string, kind?: 'download' | 'upload') {
    return this.locked(async () => {
      this.transfers.delete(id);
      if (kind) {
        this.data.files[id] = { kind, used: this.now() };
        this.leases.set(id, this.now() + 90_000);
        await this.save();
      }
    });
  }
  async clear(ids?: string[]) {
    return this.locked(async () => {
      if (ids?.some((id) => !validMediaId(id))) throw new Error('Invalid video ID.');
      let freed = 0,
        removed = 0,
        skipped = 0;
      for (const entry of await this.entries()) {
        if (ids && !ids.includes(entry.id)) continue;
        if (entry.kind !== 'download' || entry.protected) {
          skipped++;
          continue;
        }
        await this.remove(entry);
        freed += entry.bytes;
        removed++;
      }
      await this.save();
      return { freed, removed, skipped };
    });
  }
  async deleteOriginal(id: string) {
    return this.locked(async () => {
      this.path(id);
      const entry = (await this.entries()).find((e) => e.id === id);
      if (!entry) return;
      if (entry.protected)
        throw new Error(
          'This video is active. Close its player on all devices and try again after 90 seconds.',
        );
      await this.remove(entry);
      await this.save();
    });
  }
  async setLimit(gib: number) {
    return this.locked(async () => {
      if (this.transfers.size)
        throw new Error(
          'Wait for the current download or upload to finish before changing the limit.',
        );
      if (![2, 5, 10, 20].includes(gib)) throw new Error('Choose a supported cache limit.');
      const entries = await this.entries();
      let used = entries.reduce((n, e) => n + e.bytes, 0);
      const victims: CacheEntry[] = [];
      for (const e of entries
        .filter((e) => e.kind === 'download' && !e.protected)
        .sort((a, b) => a.used - b.used)) {
        if (used <= gib * GiB) break;
        victims.push(e);
        used -= e.bytes;
      }
      if (used > gib * GiB)
        throw new Error(
          'Protected files exceed that limit. Delete unneeded originals explicitly or choose a larger limit.',
        );
      for (const e of victims) await this.remove(e);
      this.data.limit = gib * GiB;
      await this.save();
    });
  }
}
