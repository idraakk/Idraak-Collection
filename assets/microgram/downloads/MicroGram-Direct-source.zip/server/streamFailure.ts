export class StreamSourceError extends Error {
  constructor(
    public readonly reason: string,
    message: string,
    public readonly retryable: boolean,
  ) {
    super(message);
  }
}
export function streamFailure(error: unknown): StreamSourceError {
  const e = error as {
    stderr?: string;
    message?: string;
    code?: string;
    signal?: string;
    killed?: boolean;
  };
  const text = `${e.stderr || ''} ${e.message || ''}`;
  if (/sign in to confirm.*(?:bot|human)|not a bot|HTTP Error 429|too many requests/i.test(text))
    return new StreamSourceError(
      'source_blocked',
      'YouTube is blocking playback requests from this hosting server. Importing links can still work, but streaming is currently unavailable from this host.',
      false,
    );
  if (e.code === 'ENOENT' || /No module named yt_dlp/i.test(text))
    return new StreamSourceError(
      'resolver_missing',
      'The hosting server is missing its video resolver. Check the Docker deployment and MEDIA_PYTHON setting.',
      false,
    );
  if (e.signal === 'SIGKILL')
    return new StreamSourceError(
      'resolver_killed',
      'The hosting server stopped the video resolver. Check Render logs for memory or resource limits.',
      false,
    );
  if (
    /private video|video unavailable|sign in to confirm your age|members.only|not available in your country/i.test(
      text,
    )
  )
    return new StreamSourceError(
      'video_restricted',
      'This video is private, restricted or unavailable to the hosting server.',
      false,
    );
  if (/no supported javascript runtime|challenge solving failed/i.test(text))
    return new StreamSourceError(
      'resolver_runtime',
      'The server could not resolve YouTube playback. Check the installed JavaScript runtime and resolver dependencies.',
      false,
    );
  if (e.killed || /timed? ?out|ETIMEDOUT/i.test(text))
    return new StreamSourceError(
      'resolver_timeout',
      'The hosting server timed out while resolving this video. Please try again shortly.',
      true,
    );
  return new StreamSourceError(
    'resolver_failed',
    'YouTube could not provide this lecture. It may be unavailable or temporarily blocking requests. Try again shortly.',
    true,
  );
}
