import { streamFailure, StreamSourceError } from './streamFailure';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
export type Track = {
  format_id: string;
  url: string;
  vcodec: string;
  acodec: string;
  height?: number;
  width?: number;
  tbr?: number;
  filesize?: number;
  language?: string;
  ext?: string;
  protocol?: string;
  version: string;
};
export type Source = {
  duration: number;
  tracks: Track[];
  audio: Track | undefined;
  videos: Track[];
};
const run = promisify(execFile);
const cache = new Map<string, { expires: number; source: Source }>();
const pending = new Map<string, Promise<Source>>();
let active = 0;
const queue: Array<() => void> = [];
async function acquire() {
  if (active < 2) {
    active++;
    return;
  }
  if (queue.length >= 16) throw new Error('Many lectures are loading. Please retry shortly.');
  await new Promise<void>((r) => queue.push(r));
}
function release() {
  const next = queue.shift();
  if (next) next();
  else active--;
}
export function invalidateSource(id: string) {
  cache.delete(id);
}
export async function getSource(id: string): Promise<Source> {
  if (!/^[\w-]{11}$/.test(id)) throw new Error('Invalid video ID.');
  const hit = cache.get(id);
  if (hit && hit.expires > Date.now()) return hit.source;
  if (pending.has(id)) return pending.get(id)!;
  const work = (async () => {
    await acquire();
    try {
      const { stdout } = await run(
        process.env.MEDIA_PYTHON ||
          (process.platform === 'win32' ? resolve('.venv/Scripts/python.exe') : 'python3'),
        [
          '-m',
          'yt_dlp',
          '--ignore-config',
          '--no-playlist',
          '--no-cache-dir',
          '--socket-timeout',
          '15',
          '--retries',
          '2',
          '--js-runtimes',
          `node:${process.execPath}`,
          '-f',
          'bv[vcodec^=avc1][height<=1080]+ba[acodec^=mp4a]/b[ext=mp4]',
          '--dump-single-json',
          '--',
          `https://www.youtube.com/watch?v=${id}`,
        ],
        { windowsHide: true, timeout: 60000, maxBuffer: 16 * 1024 * 1024 },
      );
      const info = JSON.parse(stdout);
      const tracks: Track[] = (info.formats || [])
        .filter((f: any) => {
          try {
            const u = new URL(f.url);
            return (
              /^[\w-]{1,32}$/.test(f.format_id) &&
              u.protocol === 'https:' &&
              u.hostname.endsWith('.googlevideo.com') &&
              f.protocol === 'https' &&
              ['mp4', 'm4a'].includes(f.ext)
            );
          } catch {
            return false;
          }
        })
        .map((f: any) => ({
          format_id: f.format_id,
          url: f.url,
          vcodec: f.vcodec,
          acodec: f.acodec,
          height: f.height,
          width: f.width,
          tbr: f.tbr,
          filesize: f.filesize,
          language: f.language,
          version: createHash('sha256')
            .update(
              JSON.stringify([
                f.format_id,
                f.filesize,
                f.vcodec,
                f.acodec,
                f.language,
                info.duration,
              ]),
            )
            .digest('hex')
            .slice(0, 16),
        }));
      const audioId = info.requested_formats?.find((f: any) => f.vcodec === 'none')?.format_id;
      const audio =
        tracks.find((f) => f.format_id === audioId) ||
        tracks.find((f) => f.vcodec === 'none' && f.acodec?.startsWith('mp4a'));
      const videos = tracks
        .filter(
          (f) =>
            f.vcodec?.startsWith('avc1') &&
            f.acodec === 'none' &&
            f.height &&
            f.height <= 1080 &&
            f.height >= 360,
        )
        .sort((a, b) => (b.height || 0) - (a.height || 0));
      const selected = [...new Map(videos.map((f) => [f.height, f])).values()].slice(0, 4);
      if (!Number.isFinite(info.duration) || info.duration <= 0 || info.duration > 86400)
        throw new Error('Unsupported lecture duration.');
      const source = { duration: info.duration, tracks, audio, videos: selected };
      if (cache.size >= 100) cache.delete(cache.keys().next().value!);
      const expiration = Math.min(
        ...tracks.map((f) => Number(new URL(f.url).searchParams.get('expire')) * 1000 || Infinity),
      );
      cache.set(id, { source, expires: Math.min(Date.now() + 30 * 60000, expiration - 60000) });
      return source;
    } catch (e) {
      if (e instanceof Error && e.message.startsWith('Unsupported')) throw e;
      const failure = streamFailure(e);
      console.warn('[stream-resolver]', { videoId: id, reason: failure.reason });
      throw failure;
    } finally {
      release();
    }
  })();
  pending.set(id, work);
  try {
    return await work;
  } finally {
    pending.delete(id);
  }
}
export function mp4Index(data: Buffer) {
  let pos = 0;
  while (pos + 8 <= data.length) {
    let size = data.readUInt32BE(pos);
    const type = data.toString('ascii', pos + 4, pos + 8);
    let header = 8;
    if (size === 1) {
      if (pos + 16 > data.length) break;
      const large = data.readBigUInt64BE(pos + 8);
      if (large > BigInt(Number.MAX_SAFE_INTEGER)) break;
      size = Number(large);
      header = 16;
    }
    if (size < header) break;
    if (type === 'sidx') {
      if (pos === 0 || size > 4 * 1024 * 1024) break;
      return { initEnd: pos - 1, indexStart: pos, indexEnd: pos + size - 1 };
    }
    pos += size;
  }
  throw new Error('This video format has no supported segment index.');
}
export async function trackResponse(
  id: string,
  format: string,
  range: string,
  signal: AbortSignal,
  version?: string,
) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const source = await getSource(id);
    const track = source.tracks.find((f) => f.format_id === format);
    if (!track || (version && version !== track.version))
      throw new Error('Stream format changed. Reopen this lecture.');
    let response: Response;
    try {
      response = await fetch(track.url, { headers: { Range: range }, signal, redirect: 'error' });
    } catch (e) {
      if (signal.aborted || attempt) throw e;
      continue;
    }
    if (response.status === 206) return response;
    await response.body?.cancel();
    if ((response.status === 403 || response.status === 410) && !attempt) {
      invalidateSource(id);
      continue;
    }
    throw new Error(`Video source returned ${response.status}. Retry playback.`);
  }
  throw new Error('Stream unavailable.');
}
const indexes = new Map<string, ReturnType<typeof mp4Index>>();
const pendingIndexes = new Map<string, Promise<ReturnType<typeof mp4Index>>>();
async function index(id: string, t: Track) {
  const key = `${id}:${t.version}`;
  if (indexes.has(key)) return indexes.get(key)!;
  if (pendingIndexes.has(key)) return pendingIndexes.get(key)!;
  const work = (async () => {
    for (let attempt = 0; ; attempt++) {
      try {
        // Each probe gets its own deadline, including reading the response body.
        const response = await trackResponse(
          id,
          t.format_id,
          'bytes=0-65535',
          AbortSignal.timeout(25000),
          t.version,
        );
        const data = Buffer.from(await response.arrayBuffer());
        if (data.length > 65536) throw new Error('Invalid index response.');
        const result = mp4Index(data);
        if (indexes.size >= 400) indexes.delete(indexes.keys().next().value!);
        indexes.set(key, result);
        return result;
      } catch (error) {
        if (attempt === 1) throw error;
        await new Promise((resolve) => setTimeout(resolve, 350));
      }
    }
  })();
  pendingIndexes.set(key, work);
  try {
    return await work;
  } finally {
    pendingIndexes.delete(key);
  }
}
const xml = (s: unknown) =>
  String(s).replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]!,
  );
async function buildManifest(id: string) {
  const source = await getSource(id);
  if (!source.audio || !source.videos.length)
    throw new Error('HD video and audio are unavailable for this lecture.');
  async function representation(t: Track, audio = false) {
    const idx = await index(id, t);
    return `<Representation id="${xml(t.format_id)}" bandwidth="${Math.max(1, Math.round((t.tbr || 128) * 1000))}" codecs="${xml(audio ? t.acodec : t.vcodec)}" ${audio ? '' : `width="${t.width}" height="${t.height}"`}><BaseURL>/api/stream/${id}/track/${t.format_id}?version=${t.version}</BaseURL><SegmentBase indexRange="${idx.indexStart}-${idx.indexEnd}"><Initialization range="0-${idx.initEnd}"/></SegmentBase></Representation>`;
  }
  // Start every quality, but do not hold a playable lecture behind one slow
  // optional CDN probe. Successful late probes still warm the index cache.
  const usable = new Map<number, string>();
  const videoJobs = source.videos.map((t, order) =>
    representation(t).then((value) => {
      usable.set(order, value);
      return value;
    }),
  );
  const allVideos = Promise.allSettled(videoJobs);
  const [audio] = await Promise.all([
    representation(source.audio, true),
    Promise.any(videoJobs).catch(() => {
      throw new Error('No playable HD segment index was available.');
    }),
  ]);
  await Promise.race([allVideos, new Promise((resolve) => setTimeout(resolve, 500))]);
  const videoXml = [...usable.entries()]
    .sort(([a], [b]) => a - b)
    .map(([, value]) => value)
    .join('');
  return `<?xml version="1.0"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" minBufferTime="PT1.5S" mediaPresentationDuration="PT${source.duration}S"><Period><AdaptationSet contentType="video" mimeType="video/mp4" segmentAlignment="true">${videoXml}</AdaptationSet><AdaptationSet contentType="audio" mimeType="audio/mp4">${audio}</AdaptationSet></Period></MPD>`;
}

const pendingManifests = new Map<string, Promise<string>>();
export async function manifest(id: string): Promise<string> {
  if (!/^[\w-]{11}$/.test(id)) throw new Error('Invalid video ID.');
  const existing = pendingManifests.get(id);
  if (existing) return existing;
  const work = (async () => {
    try {
      return await buildManifest(id);
    } catch (error) {
      if (error instanceof StreamSourceError && !error.retryable) throw error;
      // A cold CDN/probe failure is not proof that HD is unavailable. Do the
      // fresh-source retry here instead of making the user leave and reopen.
      invalidateSource(id);
      await new Promise((resolve) => setTimeout(resolve, 500));
      return buildManifest(id);
    }
  })();
  pendingManifests.set(id, work);
  try {
    return await work;
  } finally {
    pendingManifests.delete(id);
  }
}
