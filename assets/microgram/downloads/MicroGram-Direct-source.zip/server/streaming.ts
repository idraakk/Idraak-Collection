import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { getSource, manifest, trackResponse } from './streamSources';
export async function resolveStream(id: string) {
  const s = await getSource(id);
  const t = s.tracks.find((t) => t.format_id === '18');
  if (!t) throw new Error('Combined stream unavailable.');
  return t.url;
}
export const streaming = Router();
const resolveLimit = rateLimit({
  windowMs: 60000,
  limit: 120,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
});
streaming.get('/:id/source', resolveLimit, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  try {
    res.json({
      url: await resolveStream(String(req.params.id)),
      relay: process.env.STREAM_RELAY === 'true',
    });
  } catch (e) {
    res.status(502).json({ error: (e as Error).message });
  }
});
streaming.get('/:id/manifest.mpd', resolveLimit, async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (process.env.STREAM_RELAY !== 'true') {
    res
      .status(503)
      .json({ error: 'HD browser playback requires the streaming relay to be enabled.' });
    return;
  }
  try {
    const body = await manifest(String(req.params.id));
    res.set('Cache-Control', 'private, max-age=60').type('application/dash+xml').send(body);
  } catch (e) {
    res.status(502).json({ error: (e as Error).message });
  }
});
const bytesLimit = rateLimit({
  windowMs: 60000,
  limit: 1200,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
});
streaming.get(['/:id/bytes', '/:id/track/:format'], bytesLimit, async (req, res) => {
  if (process.env.STREAM_RELAY !== 'true') {
    res.sendStatus(404);
    return;
  }
  const range = /^bytes=(\d+)-(\d+)$/.exec(req.get('range') || '');
  if (
    !range ||
    !Number.isSafeInteger(Number(range[2])) ||
    Number(range[2]) < Number(range[1]) ||
    Number(range[2]) - Number(range[1]) >= 1024 * 1024
  ) {
    res.sendStatus(416);
    return;
  }
  const format = String(req.params.format || '18');
  if (!/^[\w-]{1,32}$/.test(format)) {
    res.sendStatus(400);
    return;
  }
  const abort = new AbortController();
  res.once('close', () => abort.abort());
  const timer = setTimeout(() => abort.abort(), 90000);
  try {
    const upstream = await trackResponse(
      String(req.params.id),
      format,
      req.get('range')!,
      abort.signal,
      typeof req.query.version === 'string' ? req.query.version : undefined,
    );
    const length = Number(upstream.headers.get('content-length'));
    const returned = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(upstream.headers.get('content-range') || '');
    if (!length || length > 1024 * 1024 || !returned || returned[1] !== range[1]) {
      await upstream.body?.cancel();
      res.sendStatus(502);
      return;
    }
    res.status(206).set({
      'Content-Type': format.startsWith('140') ? 'audio/mp4' : 'video/mp4',
      'Content-Range': upstream.headers.get('content-range')!,
      'Content-Length': String(length),
      'Cache-Control': 'no-store',
    });
    await pipeline(Readable.fromWeb(upstream.body as never), res);
  } catch (e) {
    if (!res.headersSent) res.status(502).json({ error: (e as Error).message });
    else res.destroy();
  } finally {
    clearTimeout(timer);
  }
});
