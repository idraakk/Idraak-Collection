import { parseDuration, parseYouTubeUrl, type Course, type Video } from '../src/core';
type Item = {
  id: string;
  snippet: {
    title: string;
    channelTitle: string;
    thumbnails?: Record<string, { url: string }>;
    resourceId?: { videoId: string };
  };
  contentDetails?: { duration: string };
  status?: { embeddable: boolean };
};
type Response = { items: Item[]; nextPageToken?: string };
export class ImportError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}
export async function importYouTube(
  input: string,
  key: string,
  request: typeof fetch = fetch,
): Promise<{ course: Course; skipped: number }> {
  const source = parseYouTubeUrl(input);
  async function api(endpoint: string, params: Record<string, string>): Promise<Response> {
    const url = new URL(`https://www.googleapis.com/youtube/v3/${endpoint}`);
    url.search = new URLSearchParams({ ...params, key }).toString();
    let response: globalThis.Response;
    try {
      response = await request(url, { signal: AbortSignal.timeout(15000) });
    } catch {
      throw new ImportError('YouTube could not be reached. Please try again.', 502);
    }
    if (!response.ok)
      throw new ImportError(
        response.status === 403
          ? 'YouTube access or quota is unavailable. Try again later.'
          : 'YouTube could not load this link. Check that it is public.',
        502,
      );
    return response.json() as Promise<Response>;
  }
  let ids: string[] = [];
  let title = '';
  let channel = '';
  if (source.kind === 'playlist') {
    const metadata = await api('playlists', { part: 'snippet', id: source.id });
    if (!metadata.items.length)
      throw new ImportError('This playlist is private, unavailable, or empty.', 404);
    title = metadata.items[0].snippet.title;
    channel = metadata.items[0].snippet.channelTitle;
    let next: string | undefined;
    do {
      const page = await api('playlistItems', {
        part: 'snippet',
        playlistId: source.id,
        maxResults: '50',
        ...(next ? { pageToken: next } : {}),
      });
      ids.push(
        ...page.items.flatMap((item) =>
          item.snippet.resourceId?.videoId ? [item.snippet.resourceId.videoId] : [],
        ),
      );
      next = page.nextPageToken;
      if (next && ids.length >= 1000)
        throw new ImportError(
          'Please split playlists larger than 1,000 videos into smaller playlists.',
        );
    } while (next);
  } else ids = [source.id];
  const videos: Video[] = [];
  const unique = [...new Set(ids)];
  for (let i = 0; i < unique.length; i += 50) {
    const page = await api('videos', {
      part: 'snippet,contentDetails,status',
      id: unique.slice(i, i + 50).join(','),
    });
    for (const item of page.items) {
      const duration = parseDuration(item.contentDetails?.duration ?? '');
      if (!duration || duration > 86400 || !item.status?.embeddable) continue;
      videos.push({
        id: item.id,
        title: item.snippet.title,
        channel: item.snippet.channelTitle,
        duration,
        thumbnail: `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`,
      });
    }
  }
  const ordered = unique.flatMap((id) => {
    const video = videos.find((v) => v.id === id);
    return video ? [video] : [];
  });
  if (!ordered.length)
    throw new ImportError(
      'No playable videos were found. Private videos, live streams, and videos with embedding disabled cannot be imported.',
      404,
    );
  return {
    course: {
      kind: source.kind,
      id: source.id,
      title: title || ordered[0].title,
      channel: channel || ordered[0].channel,
      videos: ordered,
      importedAt: Date.now(),
    },
    skipped: ids.length - ordered.length,
  };
}
