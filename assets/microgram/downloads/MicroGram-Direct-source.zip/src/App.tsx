import { ProfilePhoto } from './ProfilePhoto';
import { screenNoteGroups } from './screenNotes';
import { primeLibraryCovers } from './coverWarmup';
import { primeScreenSources } from './screenImageSources';
import { ReelOverlay } from './ReelOverlay';
import { ReelSponsor } from './community/Community';
import { ReplyThread } from './community/Replies';
import type { CommunityPost } from './community/schema';
import { getFrameDimensions, useFrameDimensions } from './reelFrames';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { activityYear } from './activityHeatmap';
import { recordAnalyticsWatch, useAppAnalytics } from './appAnalytics';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  BarChart3,
  Bookmark,
  BookOpen,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  Clock3,
  CircleCheck,
  Clapperboard,
  Download,
  GraduationCap,
  Layers3,
  Link2,
  LoaderCircle,
  Maximize2,
  RotateCw,
  MoreHorizontal,
  Play,
  Plus,
  Search,
  Settings2,
  Sparkles,
  Target,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  clock,
  complete,
  DURATIONS,
  parseYouTubeUrl,
  recordInterval,
  segments,
  watched,
  type Course,
  type Segment,
  type Video,
} from './core';
import {
  initial,
  load,
  localDate,
  persist,
  schema,
  expireMetadata,
  clearDeviceStorage,
  type State,
  type ScreenNote,
} from './storage';
import { ScreenNoteEditor } from './CapturedNotes';
import { ScreenNoteReview, type ScreenReviewMode } from './ScreenNoteReview';
import {
  putScreenImages,
  removeScreenImage,
  clearScreenImages,
  pruneScreenImages,
  screenNotesBackup,
  readScreenNotesBackup,
  SCREEN_NOTE_LIMIT,
} from './screenNotes';
import { exportBackup, clearTemporaryBackups } from './native';
import { App as NativeApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { Player, prepared, type PlayerControls } from './Player';
import { StoragePanel } from './StoragePanel';
import { autoRotate, defaultVideoFit, PlaybackLayout, useViewport } from './videoLayout';
import { LocalImport } from './LocalImport';
import { Insights } from './ProgressInsights';
import { Saved } from './Saved';
import { savedMoments, resolveMoment, idsForMoment, type SavedMoment } from './savedMoments';
import { NotesDialog, type NotesDialogControls } from './NotesDialog';
import { Home } from './Home';
import { deviceStreaming } from './deviceStreaming';
import { androidDirect } from './androidDirect';
import { primeCourse } from './reelOpenings';
import { CourseProfile } from './CourseProfile';
import { LibraryFeed, clearLibraryMetadataCache } from './LibraryFeed';
import {
  readNavigation,
  saveNavigation,
  type AppView,
  type SavedReturn,
  type ReelProfileReturn,
} from './navigationState';
import { useBrowserBack } from './useBrowserBack';
import { flushSync } from 'react-dom';
import { clearProfileExit } from './profileTransition';
import { dismissActiveMenu } from './dismissibleMenu';
import {
  prepareSavedTransition,
  finishSavedTransition,
  cancelSavedTransition,
} from './savedTransition';
import { ReelPager, type ReelPagerControl } from './ReelPager';
type View = AppView;
const nav = [
  { id: 'feed', label: 'Learning feed', icon: Play },
  { id: 'library', label: 'My library', icon: Layers3 },
  { id: 'reels', label: 'Reels', icon: Clapperboard },
  { id: 'saved', label: 'Saved moments', icon: Bookmark },
  { id: 'progress', label: 'My progress', icon: BarChart3 },
] as const;
function Logo() {
  return (
    <div className="brand">
      <img className="brand-icon" src="/icon.svg?v=2" alt="" />
      <span>
        microgram<span className="brand-dot">.</span>
      </span>
    </div>
  );
}
function Diagram() {
  return (
    <svg
      className="diagram"
      viewBox="0 0 480 330"
      role="img"
      aria-label="A two-dimensional vector on a coordinate grid"
    >
      <defs>
        <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
          <path d="M32 0H0V32" fill="none" stroke="#ffffff" strokeOpacity=".07" />
        </pattern>
        <marker id="arrowlime" markerWidth="9" markerHeight="9" refX="6" refY="3" orient="auto">
          <path d="M0 0L6 3L0 6" fill="none" stroke="#a78bfa" strokeWidth="1.5" />
        </marker>
      </defs>
      <rect x="20" y="20" width="440" height="290" fill="url(#grid)" />
      <path d="M45 250H440M135 300V30" stroke="#808080" strokeWidth="1.3" />
      <path d="M135 250L350 92" stroke="#a78bfa" strokeWidth="3" markerEnd="url(#arrowlime)" />
      <path
        d="M350 92V250H135"
        stroke="#a78bfa"
        strokeOpacity=".45"
        strokeDasharray="5 7"
        fill="none"
      />
      <circle cx="135" cy="250" r="5" fill="#a78bfa" />
      <text x="360" y="88" fill="#a78bfa" fontSize="24" fontFamily="Georgia" fontStyle="italic">
        v
      </text>
      <text x="240" y="277" fill="#a8a8a8" fontSize="14">
        3
      </text>
      <text x="365" y="181" fill="#a8a8a8" fontSize="14">
        2
      </text>
      <text x="435" y="274" fill="#a8a8a8" fontSize="14">
        x
      </text>
      <text x="113" y="38" fill="#a8a8a8" fontSize="14">
        y
      </text>
      <text x="109" y="274" fill="#a8a8a8" fontSize="14">
        0
      </text>
      <g transform="translate(42 45)">
        <rect
          width="68"
          height="67"
          rx="8"
          fill="#a78bfa"
          fillOpacity=".05"
          stroke="#a78bfa"
          strokeOpacity=".2"
        />
        <text x="13" y="40" fill="#a78bfa" fontSize="18" fontFamily="Georgia">
          v =
        </text>
        <path d="M49 12H44V54H49M59 12H64V54H59" fill="none" stroke="#a78bfa" />
        <text x="50" y="29" fill="#a78bfa" fontSize="13">
          3
        </text>
        <text x="50" y="47" fill="#a78bfa" fontSize="13">
          2
        </text>
      </g>
    </svg>
  );
}
export default function App() {
  const analytics = useAppAnalytics();
  const [state, setState] = useState<State>(load);
  const [progressFirst, setProgressFirst] = useState(() => activityYear(state.activity, state.goal).active > 0);
  const [restoredRoute] = useState(() => {
    const route = readNavigation(state);
    if (route.view === 'saved' && route.savedSection === 'reels') {
      const active = route.savedQueueIds[route.index];
      const ids = savedMoments(state, 'reels').map((item) => item.segment.id);
      return { ...route, savedQueueIds: ids, index: Math.max(0, ids.indexOf(active)) };
    }
    return route;
  });
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    const changed = (e: Event) => setConfirmationOpen((e as CustomEvent<boolean>).detail);
    const menuChanged = (e: Event) => setMenuOpen((e as CustomEvent<boolean>).detail);
    window.addEventListener('microgram-menu', menuChanged);
    window.addEventListener('microgram-confirmation', changed);
    return () => {
      window.removeEventListener('microgram-confirmation', changed);
      window.removeEventListener('microgram-menu', menuChanged);
    };
  }, []);
  useEffect(() => {
    const timer = setTimeout(() => {
      primeLibraryCovers(state.courses);
      primeScreenSources(
        screenNoteGroups(state.screenNotes ?? [])
          .slice(0, 6)
          .flatMap(({ items }) => items.slice(0, 3).map((note) => note.id)),
      );
    }, 80);
    return () => clearTimeout(timer);
  }, [state.courses, state.screenNotes]);
  const [view, setView] = useState<View>(restoredRoute.view);
  const [courseId, setCourseId] = useState(restoredRoute.courseId);
  const [index, setIndex] = useState(
    restoredRoute.view === 'saved' &&
      restoredRoute.immersive &&
      restoredRoute.savedSection !== 'reels'
      ? 0
      : restoredRoute.index,
  );
  const [savedSection, setSavedSection] = useState<'reels' | 'notes' | 'screens'>(
    restoredRoute.savedSection,
  );
  const [savedScreenVideo, setSavedScreenVideo] = useState<string | null>(
    restoredRoute.savedScreenVideo ?? null,
  );
  const scrollPositions = useRef<Record<string, number>>(restoredRoute.scrollPositions ?? {});
  const pendingScroll = useRef<number | null>(null);
  useEffect(() => () => cancelSavedTransition(), []);
  function selectSavedAlbum(videoId: string | null, animate = true) {
    if (videoId === savedScreenVideo) return;
    rememberPosition();
    const target =
      scrollPositions.current[videoId ? `saved:screens:${videoId}` : 'saved:screens'] ?? 0;
    pendingScroll.current = target;
    if (animate) prepareSavedTransition(videoId ? 'open' : 'back', target);
    setSavedScreenVideo(videoId);
  }
  const [screenDraft, setScreenDraft] = useState<{ note: ScreenNote; frame?: Blob } | null>(null);
  const [screenMode, setScreenMode] = useState<ScreenReviewMode>('fullscreen');
  const [savedQueue, setSavedQueue] = useState<Segment[]>(() =>
    (restoredRoute.savedSection === 'reels'
      ? restoredRoute.savedQueueIds
      : restoredRoute.savedQueueIds.slice(restoredRoute.index, restoredRoute.index + 1)
    ).flatMap((id) => {
      const item = resolveMoment(id, state.courses);
      return item ? [item.segment] : [];
    }),
  );
  const [savedPlayback, setSavedPlayback] = useState(restoredRoute.savedPlayback);
  const [flowEntry, setFlowEntry] = useState<{ id: string; time: number; paused: boolean } | null>(
    null,
  );
  const [savedReturn, setSavedReturn] = useState<SavedReturn | undefined>(
    restoredRoute.savedReturn,
  );
  const [reelsProfile, setReelsProfile] = useState<ReelProfileReturn | undefined>(
    restoredRoute.reelsProfile,
  );
  const [continuationCue, setContinuationCue] = useState(0);
  const savedScroll = useRef(0);
  const notesDialog = useRef<NotesDialogControls | null>(null);
  const bookmarkedMoments = useMemo(
    () => savedMoments(state, 'reels'),
    [state.saved, state.notes, state.courses],
  );
  const notedMoments = useMemo(() => savedMoments(state, 'notes'), [state.notes, state.courses]);
  const [reelVideoId, setReelVideoId] = useState(restoredRoute.reelVideoId);
  const [adActive, setAdActive] = useState(false);
  const [playing, setPlaying] = useState(
    restoredRoute.immersive &&
      (restoredRoute.view !== 'saved' || savedQueue.length > 0) &&
      state.consent,
  );
  const [videoPlaying, setVideoPlaying] = useState(false);
  const playbackControls = useRef<PlayerControls | null>(null);
  const pendingPlayback = useRef(false);
  const profileScroll = useRef(restoredRoute.profileScroll);
  const libraryProfile = useRef<string | null>(restoredRoute.libraryProfile);
  const profileTrigger = useRef<HTMLElement | null>(null);
  const [ended, setEnded] = useState(false);
  const [modal, setModal] = useState<
    'import' | 'notes' | 'screen' | 'screen-review' | 'privacy' | 'delete' | 'name' | null
  >(() => (state.profile?.name ? null : 'name'));
  useEffect(() => {
    if (modal !== 'screen' && modal !== 'screen-review') setScreenDraft(null);
  }, [modal]);
  const [profileName, setProfileName] = useState(state.profile?.name ?? '');
  const [profileUsername, setProfileUsername] = useState(state.profile?.username ?? '');
  const [profilePhoto, setProfilePhoto] = useState(state.profile?.photo);
  const [clearServerDownloads, setClearServerDownloads] = useState(false);
  const [importSeconds, setImportSeconds] = useState<State['seconds']>(60);
  const [standaloneNote, setStandaloneNote] = useState<Segment | null>(null);
  const notesOrigin = useRef<DOMRect | null>(null);
  const [url, setUrl] = useState('');
  const importSource = useMemo(() => {
    try {
      return parseYouTubeUrl(url);
    } catch {
      return null;
    }
  }, [url]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [focus, setFocus] = useState(false);
  const [immersive, setImmersive] = useState(
    restoredRoute.immersive && (restoredRoute.view !== 'saved' || savedQueue.length > 0),
  );
  const [controlsHidden, setControlsHidden] = useState(restoredRoute.controlsHidden);
  const scrollKey = immersive
    ? `player:${view}`
    : view === 'reels' && reelsProfile
      ? `reels-profile:${courseId}`
      : view === 'profile'
        ? `profile:${courseId}`
        : view === 'saved'
          ? `saved:${savedSection}${savedSection === 'screens' && savedScreenVideo ? `:${savedScreenVideo}` : ''}`
          : view;
  const currentScrollKey = useRef(scrollKey);
  currentScrollKey.current = scrollKey;
  function rememberPosition() {
    scrollPositions.current[currentScrollKey.current] = window.scrollY;
  }
  function targetPosition(key: string) {
    return scrollPositions.current[key] ?? 0;
  }
  const [communityThread, setCommunityThread] = useState<{ post: CommunityPost; enabled: boolean }>();
  const communityOrigin = useRef<{ scroll: number; trigger: HTMLElement | null }>({ scroll: 0, trigger: null });
  function openCommunityThread(post: CommunityPost, enabled: boolean) {
    const scroll = window.scrollY;
    communityOrigin.current = { scroll, trigger: document.activeElement instanceof HTMLElement ? document.activeElement : null };
    queuePage('open', scroll, 'main', '.community-thread');
    setCommunityThread({ post, enabled });
  }
  function closeCommunityThread(animate = true) {
    queuePage('back', communityOrigin.current.scroll, '.community-thread', 'main', animate);
    setCommunityThread(undefined);
  }
  function queuePage(
    direction: 'open' | 'back',
    scroll: number,
    source = 'main',
    target = 'main',
    animate = true,
  ) {
    pendingScroll.current = scroll;
    if (animate) prepareSavedTransition(direction, scroll, { source, target });
    else cancelSavedTransition();
  }
  useLayoutEffect(() => {
    if (pendingScroll.current !== null) {
      window.scrollTo({ top: pendingScroll.current, behavior: 'instant' });
      pendingScroll.current = null;
    }
    finishSavedTransition();
    if (!communityThread && communityOrigin.current.trigger) {
      communityOrigin.current.trigger.focus({ preventScroll: true });
      communityOrigin.current.trigger = null;
    }
  }, [scrollKey, modal, screenMode, communityThread]);

  useLayoutEffect(() => {
    const frame = requestAnimationFrame(() => window.scrollTo(0, restoredRoute.scrollY));
    return () => cancelAnimationFrame(frame);
  }, [restoredRoute]);
  const currentRoute = useRef(() => {});
  currentRoute.current = () =>
    saveNavigation({
      view,
      courseId,
      index,
      reelVideoId,
      immersive,
      libraryProfile: libraryProfile.current,
      profileScroll: profileScroll.current,
      scrollY: window.scrollY,
      controlsHidden,
      savedSection,
      savedScreenVideo,
      savedQueueIds: savedQueue.map((r) => r.id),
      savedPlayback,
      savedReturn,
      reelsProfile,
      scrollPositions: scrollPositions.current,
    });
  useLayoutEffect(() => {
    currentRoute.current();
  });
  useLayoutEffect(() => {
    if (!continuationCue || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const stage = document.querySelector<HTMLElement>('.reel-stage');
    if (!stage) return;
    stage.dataset.flowTransition = 'continue';
    const animations = [
      ...document.querySelectorAll<HTMLElement>(
        '.immersive-toolbar,.reel-top,.reel-rail,.reel-bottom,.mobile-nav .selected .nav-icon',
      ),
    ].map((node) =>
      node.animate(
        [
          { opacity: 0.35, transform: 'translateY(10px)' },
          { opacity: 1, transform: 'translateY(0)' },
        ],
        { duration: 260, easing: 'cubic-bezier(.22,.75,.25,1)' },
      ),
    );
    const timer = setTimeout(() => delete stage.dataset.flowTransition, 270);
    return () => {
      clearTimeout(timer);
      delete stage.dataset.flowTransition;
      animations.forEach((animation) => animation.cancel());
    };
  }, [continuationCue]);
  useEffect(() => {
    let scrollSave: ReturnType<typeof setTimeout> | undefined;
    const save = () => {
      clearTimeout(scrollSave);
      rememberPosition();
      currentRoute.current();
    };
    const scroll = () => {
      rememberPosition();
      clearTimeout(scrollSave);
      scrollSave = setTimeout(() => currentRoute.current(), 150);
    };
    window.addEventListener('pagehide', save);
    window.addEventListener('scroll', scroll, { passive: true });
    return () => {
      clearTimeout(scrollSave);
      window.removeEventListener('pagehide', save);
      window.removeEventListener('scroll', scroll);
    };
  }, []);
  const [rotationOverride, setRotationOverride] = useState<{ id: string; rotated: boolean } | null>(
    null,
  );
  const stageRef = useRef<HTMLDivElement>(null);
  const [stageSize, setStageSize] = useState({ width: 0, height: 0 });
  useLayoutEffect(() => {
    const element = stageRef.current;
    if (!element) return;
    const observer = new ResizeObserver(([entry]) => {
      if (entry.contentRect.width && entry.contentRect.height) setStageSize(entry.contentRect);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [playing, immersive, view]);
  const viewport = useViewport();
  useFrameDimensions();
  const file = useRef<HTMLInputElement>(null);
  const pager = useRef<ReelPagerControl | null>(null);
  const [transitioning, setTransitioning] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const course = state.courses.find((c) => c.id === courseId) ?? state.courses[0];
  const courseReels = useMemo(
    () => (course ? segments(course, state.seconds) : []),
    [course, state.seconds],
  );
  const reels = useMemo(
    () =>
      view === 'saved' && immersive
        ? savedQueue
        : view === 'reels'
          ? courseReels.filter((r) => r.video.id === reelVideoId)
          : courseReels,
    [courseReels, view, reelVideoId, immersive, savedQueue],
  );
  const safeIndex = Math.min(index, Math.max(0, reels.length - 1));
  const reel = reels[safeIndex];
  useEffect(() => {
    if (!playing || adActive || !reel || !course) return;
    setState((s) => ({
      ...s,
      lastPlayback: { courseId: course.id, videoId: reel.video.id, start: reel.start },
      last: {
        ...s.last,
        [course.id]: Math.max(
          0,
          courseReels.findIndex(
            (r) => r.video.id === reel.video.id && r.start <= reel.start && r.end > reel.start,
          ),
        ),
      },
    }));
  }, [playing, adActive, reel?.id, course?.id]);
  const rotated =
    state.videoLayouts?.[reel?.video.id ?? '']?.rotated ??
    (rotationOverride && rotationOverride.id === reel?.video.id
      ? rotationOverride.rotated
      : autoRotate(
          reel?.video.width ?? getFrameDimensions(reel?.video.id ?? '')?.width ?? 16,
          reel?.video.height ?? getFrameDimensions(reel?.video.id ?? '')?.height ?? 9,
          viewport.width,
          viewport.height,
        ));
  const resolveLayout = (video: Video) => {
    const preference = state.videoLayouts?.[video.id];
    const rotation =
      video.id === reel?.video.id
        ? rotated
        : (preference?.rotated ??
          autoRotate(
            video.width ?? getFrameDimensions(video.id)?.width ?? 16,
            video.height ?? getFrameDimensions(video.id)?.height ?? 9,
            viewport.width,
            viewport.height,
          ));
    return {
      rotated: rotation,
      fit:
        preference?.fit ??
        defaultVideoFit(
          video.width ?? getFrameDimensions(video.id)?.width ?? 16,
          video.height ?? getFrameDimensions(video.id)?.height ?? 9,
          stageSize.width || viewport.width,
          stageSize.height || viewport.height - 64,
          rotation,
        ),
    };
  };
  const fit = reel ? resolveLayout(reel.video).fit : true;
  const totalCompleted = reels.filter((r) => complete(r, state.progress)).length;
  const reelCompleted = reel ? complete(reel, state.progress) : false;
  const todaySeconds = state.activity[localDate()] ?? 0;
  const todayMinutes = Math.floor(todaySeconds / 60);
  const videoReels = reel ? reels.filter((r) => r.video.id === reel.video.id) : [];
  const videoDone = videoReels.filter((r) => complete(r, state.progress)).length;
  function startPlayback() {
    setFlowEntry(null);
    rememberPosition();
    if (view !== 'reels') queuePage('open', 0, 'main', '.reel-stage');
    setImmersive(true);
    setPlaying(true);
    setEnded(false);
  }
  function exitPlayback(animate = true, restoreSaved = true) {
    if (view === 'reels' && savedReturn && restoreSaved) {
      const key = `saved:${savedReturn.section}${savedReturn.section === 'screens' && savedReturn.screenVideo ? `:${savedReturn.screenVideo}` : ''}`;
      queuePage('back', targetPosition(key), '.reel-stage', 'main', animate !== false);
      setSavedSection(savedReturn.section);
      setSavedScreenVideo(savedReturn.screenVideo);
      setView('saved');
      setImmersive(false);
      setPlaying(false);
      setFlowEntry(null);
      setSavedReturn(undefined);
      return;
    }
    const destination = view === 'reels' ? 'feed' : view;
    const key =
      destination === 'profile'
        ? `profile:${courseId}`
        : destination === 'saved'
          ? `saved:${savedSection}${savedSection === 'screens' && savedScreenVideo ? `:${savedScreenVideo}` : ''}`
          : destination;
    queuePage(
      'back',
      targetPosition(key),
      '.reel-stage',
      'main',
      animate !== false && view !== 'reels',
    );
    setImmersive(false);
    setPlaying(false);
    if (view === 'reels') {
      setView('feed');
      setIndex(
        Math.max(
          0,
          courseReels.findIndex((r) => r.id === reel?.id),
        ),
      );
    }
    if (view === 'profile') profileTrigger.current?.focus({ preventScroll: true });
  }
  useLayoutEffect(() => {
    if (!immersive) return;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = overflow;
    };
  }, [immersive]);
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        persist(state);
      } catch {
        setToast('Device storage is full. Export your progress in Settings.');
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [state]);
  const latestState = useRef(state);
  latestState.current = state;
  useEffect(() => {
    const flush = () => {
      try {
        persist(latestState.current);
      } catch {}
    };
    window.addEventListener('pagehide', flush);
    const timer = setInterval(flush, 2000);
    const expiry = setInterval(() => setState((s) => expireMetadata(s)), 60000);
    return () => {
      window.removeEventListener('pagehide', flush);
      clearInterval(timer);
      clearInterval(expiry);
    };
  }, []);
  function handleBack(context?: { browserTransition?: boolean }) {
    if (confirmationOpen) {
      const dialog = document.querySelector<HTMLDialogElement>('.confirm-dialog[open]');
      if (dialog?.dataset.busy === 'true') return false;
      dialog?.close();
      setConfirmationOpen(false);
      return true;
    }
    if (communityThread) {
      closeCommunityThread(!context?.browserTransition);
      return true;
    }
    const feedback = document.querySelector<HTMLDialogElement>('.community-feedback-dialog[open]');
    if (feedback) { feedback.close(); return true; }
    if (dismissActiveMenu()) return true;
    if (modal) {
      if (busy) return false;
      if (modal === 'screen-review' && screenMode === 'edit') {
        changeScreenMode('fullscreen', !context?.browserTransition);
        return true;
      }
      if (modal === 'screen-review') {
        closeScreenViewer(!context?.browserTransition);
        return true;
      }
      if (modal === 'notes' && notesDialog.current) notesDialog.current.close();
      else closeModal(!context?.browserTransition);
    } else if (view === 'reels' && reelsProfile) closeReelsProfile(!context?.browserTransition);
    else if (immersive) exitPlayback(!context?.browserTransition);
    else if (view === 'saved' && savedSection === 'screens' && savedScreenVideo)
      selectSavedAlbum(null, !context?.browserTransition);
    else if (view === 'settings') changeView('feed', true, !context?.browserTransition);
    else if (view === 'profile') backToLibrary(!context?.browserTransition);
    else if (focus) setFocus(false);
    else if (view !== 'feed') changeView('feed');
    else return false;
    return true;
  }
  useBrowserBack(
    (view === 'reels'
      ? (savedReturn
          ? 2 + Number(savedReturn.section === 'screens' && Boolean(savedReturn.screenVideo))
          : 1) + Number(Boolean(reelsProfile))
      : view === 'profile'
        ? 2
        : view === 'feed'
          ? 0
          : 1) +
      Number(immersive && view !== 'reels') +
      Number(focus) +
      Number(Boolean(modal)) +
      Number(Boolean(communityThread)) +
      Number(modal === 'screen-review' && screenMode === 'edit') +
      Number(view === 'saved' && savedSection === 'screens' && Boolean(savedScreenVideo)) +
      Number(confirmationOpen) +
      Number(menuOpen),
    handleBack,
    Capacitor.isNativePlatform(),
  );
  const backState = useRef({ handleBack, modal });
  backState.current = { handleBack, modal };
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const background = NativeApp.addListener('appStateChange', ({ isActive }) => {
      if (isActive) {
        const { activity, goal } = latestState.current;
        setProgressFirst(activityYear(activity, goal).active > 0);
        window.dispatchEvent(new Event('microgram:resume'));
      }
      else {
        setPlaying(false);
        try {
          persist(latestState.current);
        } catch {}
      }
    });
    const back = NativeApp.addListener('backButton', () => {
      let handled = false;
      flushSync(() => {
        handled = backState.current.handleBack();
      });
      if (!handled && !backState.current.modal && !document.querySelector('.confirm-dialog[open]')) void NativeApp.minimizeApp();
    });
    return () => {
      void background.then((l) => l.remove());
      void back.then((l) => l.remove());
    };
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(''), 2000);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if (!modal) {
      pendingPlayback.current = false;
      return;
    }
    if (!immersive) setPlaying(false);
    else if (videoPlaying) playbackControls.current?.togglePlay();
    returnFocus.current = document.activeElement as HTMLElement;
    const timer = setTimeout(
      () => modalRef.current?.querySelector<HTMLElement>('input,button,textarea')?.focus(),
      30,
    );
    return () => {
      clearTimeout(timer);
      returnFocus.current?.focus({ preventScroll: true });
    };
  }, [modal]);
  const commitMove = (delta: number) => {
    const next = Math.max(0, Math.min(reels.length - 1, safeIndex + delta));
    if (next === safeIndex) return;
    if (view === 'saved') setSavedPlayback(undefined);
    setFlowEntry(null);
    const moment = reels[next];
    const selected =
      view === 'saved'
        ? state.courses.find((c) => c.videos.some((v) => v.id === moment.video.id))
        : course;
    setIndex(next);
    setEnded(false);
    if (selected) {
      setCourseId(selected.id);
      const position = Math.max(
        0,
        segments(selected, state.seconds).findIndex(
          (r) => r.video.id === moment.video.id && r.start <= moment.start && r.end > moment.start,
        ),
      );
      setState((s) => ({ ...s, last: { ...s.last, [selected.id]: position } }));
    }
  };
  const move = (delta: number) => pager.current?.navigate(delta);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      const { key, code, ctrlKey, altKey, metaKey, shiftKey } = event;
      const target = event.target;
      if (
        event.defaultPrevented ||
        event.isComposing ||
        modal ||
        confirmationOpen ||
        communityThread ||
        document.querySelector('dialog[open]') ||
        (target instanceof Element &&
          target.closest('input, textarea, select, [contenteditable], [role="textbox"]'))
      ) return;

      if (key === 'Escape' && (immersive || view === 'feed')) {
        if (dismissActiveMenu()) {
          event.preventDefault();
          return;
        }
        if (immersive) exitPlayback();
        else setFocus(false);
        return;
      }

      if (!immersive || !reel || adActive || menuOpen || altKey || metaKey ||
          document.querySelector('.playback-settings-panel, [role="menu"]')) return;
      const space = key === ' ' || code === 'Space';
      let action: (() => void) | undefined;
      if (space && ctrlKey && !shiftKey) {
        action = () => stageRef.current?.querySelector<HTMLButtonElement>('.screen-capture')?.click();
      } else if (!ctrlKey && !shiftKey) {
        if (key === 'ArrowDown') action = () => move(1);
        if (key === 'ArrowUp') action = () => move(-1);
        if (space) action = () => playbackControls.current?.togglePlay();
      } else if (!ctrlKey && shiftKey) {
        const buttons: Record<string, string> = {
          KeyC: '.screen-capture',
          KeyS: '.save-control',
          KeyN: '.notes-control',
          KeyF: '[aria-label="Fill screen"], [aria-label="Fit whole video"]',
          KeyR: '[aria-label="Rotate video vertically"], [aria-label="Restore horizontal video"]',
          KeyP: '.playback-settings-toggle',
          KeyQ: '.quality-toggle',
        };
        const selector = buttons[code];
        if (selector) action = () => stageRef.current?.querySelector<HTMLButtonElement>(selector)?.click();
        if (key === 'ArrowLeft') action = () => playbackControls.current?.seekBy(-5);
        if (key === 'ArrowRight') action = () => playbackControls.current?.seekBy(5);
        if (code === 'KeyM') action = () => playbackControls.current?.toggleMute();
        if (code === 'KeyH') action = () => setControlsHidden((hidden) => !hidden);
      }
      if (!action) return;
      event.preventDefault();
      if (!event.repeat && !transitioning) action();
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  });
  function openProfile(c: Course) {
    rememberPosition();
    profileScroll.current = targetPosition(`profile:${c.id}`);
    queuePage('open', profileScroll.current);
    libraryProfile.current = c.id;
    clearProfileExit();
    setCourseId(c.id);
    setIndex(state.last[c.id] ?? 0);
    setPlaying(false);
    setEnded(false);
    setFocus(false);
    setView('profile');
  }
  function openProfileReel(reelIndex: number) {
    rememberPosition();
    if (!course) return;
    if (view === 'reels' && reelsProfile) {
      const selected = courseReels[reelIndex];
      if (!selected) return;
      queuePage('back', 0, 'main', '.reel-stage');
      const flow = courseReels.filter((r) => r.video.id === selected.video.id);
      setReelVideoId(selected.video.id);
      setIndex(flow.findIndex((r) => r.id === selected.id));
      setFlowEntry(null);
      setReelsProfile(undefined);
      setImmersive(true);
      setPlaying(state.consent);
      setEnded(false);
      return;
    }
    profileScroll.current = window.scrollY;
    profileTrigger.current = document.activeElement as HTMLElement;
    setIndex(reelIndex);
    setState((s) => ({ ...s, last: { ...s.last, [course.id]: reelIndex } }));
    if (!state.consent) {
      pendingPlayback.current = true;
      setModal('privacy');
      return;
    }
    startPlayback();
  }
  function openReelsTab() {
    if (view === 'reels' && immersive) return;
    if (view === 'reels' && reelsProfile) {
      closeReelsProfile(false);
      return;
    }
    setFlowEntry(null);
    rememberPosition();
    cancelSavedTransition();
    pendingScroll.current = 0;
    clearProfileExit();
    const recent = state.lastPlayback;
    const target =
      state.courses.find(
        (c) => c.id === recent?.courseId && c.videos.some((v) => v.id === recent.videoId),
      ) ?? course;
    if (!target) {
      changeView('library');
      setToast('Add a lecture to start watching reels.');
      return;
    }
    const list = segments(target, state.seconds);
    const remembered =
      recent?.courseId === target.id
        ? list.find(
            (r) => r.video.id === recent.videoId && r.start <= recent.start && r.end > recent.start,
          )
        : undefined;
    const resume = remembered ?? list[Math.min(state.last[target.id] ?? 0, list.length - 1)];
    const videoList = list.filter((r) => r.video.id === resume.video.id);
    setCourseId(target.id);
    setReelVideoId(resume.video.id);
    setIndex(videoList.findIndex((r) => r.id === resume.id));
    setView('reels');
    setFocus(false);
    setEnded(false);
    setImmersive(true);
    if (!state.consent) {
      setPlaying(false);
      pendingPlayback.current = true;
      setModal('privacy');
    } else setPlaying(true);
  }
  function openSaved(item: SavedMoment, showNote = false) {
    rememberPosition();
    if (showNote) {
      notesOrigin.current = document.activeElement?.getBoundingClientRect() ?? null;
      setStandaloneNote(item.segment);
      setModal('notes');
      return;
    }
    openSavedReel(
      item.course,
      item.segment,
      item.segment.start,
      false,
      savedSection === 'reels' ? bookmarkedMoments.map((entry) => entry.segment) : undefined,
    );
  }
  function openSavedReel(
    targetCourse: Course,
    segment: Segment,
    time: number,
    paused: boolean,
    queue: Segment[] = [segment],
  ) {
    rememberPosition();
    savedScroll.current = window.scrollY;
    setSavedQueue(queue);
    setSavedPlayback({ time, paused });
    setCourseId(targetCourse.id);
    setIndex(
      Math.max(
        0,
        queue.findIndex((entry) => entry.id === segment.id),
      ),
    );
    setView('saved');
    setFocus(false);
    setEnded(false);
    if (!state.consent) {
      pendingPlayback.current = true;
      setModal('privacy');
      return;
    }
    queuePage('open', 0, 'main .saved-page', '.reel-stage');
    setImmersive(true);
    setPlaying(true);
  }
  function openScreenReel(note: ScreenNote) {
    const target =
      state.courses.find(
        (c) => c.id === note.courseId && c.videos.some((v) => v.id === note.videoId),
      ) ?? state.courses.find((c) => c.videos.some((v) => v.id === note.videoId));
    const segment =
      target &&
      segments(target, state.seconds).find(
        (r) => r.video.id === note.videoId && r.start <= note.time && r.end > note.time,
      );
    if (!target || !segment) {
      setToast('This lecture is no longer in your Library. Import it again to open this moment.');
      return;
    }
    openSavedReel(target, segment, note.time, true);
  }
  function continueSavedLecture() {
    if (!reel || !course) return;
    const flow = courseReels.filter((r) => r.video.id === reel.video.id);
    if (!flow.length) return;
    const playback = playbackControls.current?.getPlayback() ?? {
      time: savedPlayback?.time ?? reel.start,
      paused: false,
    };
    const position = Math.max(
      0,
      flow.findIndex((r) => r.start <= playback.time && r.end > playback.time),
    );
    setFlowEntry({ id: flow[position].id, ...playback });
    rememberPosition();
    cancelSavedTransition();
    pendingScroll.current = 0;
    setReelVideoId(reel.video.id);
    setIndex(position);
    setView('reels');
    setSavedReturn({
      courseId: course.id,
      segmentId: reel.id,
      ...playback,
      section: savedSection,
      screenVideo: savedScreenVideo,
    });
    setSavedPlayback(undefined);
    setContinuationCue((cue) => cue + 1);
    setEnded(false);
  }
  function openReelsProfile() {
    if (view === 'saved' || !immersive || !reel || !course) return;
    if (view === 'profile') {
      exitPlayback();
      return;
    }
    if (view !== 'reels') {
      openProfile(course);
      setImmersive(false);
      return;
    }
    const playback = playbackControls.current?.getPlayback() ?? { time: reel.start, paused: false };
    queuePage('open', targetPosition(`reels-profile:${course.id}`), '.reel-stage', 'main');
    setReelsProfile({ videoId: reel.video.id, start: reel.start, ...playback });
    setImmersive(false);
    setPlaying(false);
    setFocus(false);
  }
  function closeReelsProfile(animate = true) {
    if (!reelsProfile) return;
    rememberPosition();
    queuePage('back', 0, 'main', '.reel-stage', animate !== false);
    const flow = courseReels.filter((r) => r.video.id === reelsProfile.videoId);
    const at = Math.max(
      0,
      flow.findIndex((r) => r.start <= reelsProfile.start && r.end > reelsProfile.start),
    );
    if (flow[at]) {
      setReelVideoId(reelsProfile.videoId);
      setIndex(at);
      setFlowEntry({ id: flow[at].id, time: reelsProfile.time, paused: reelsProfile.paused });
    }
    setReelsProfile(undefined);
    setImmersive(true);
    setPlaying(state.consent);
  }
  function backToLibrary(animate = true) {
    rememberPosition();
    queuePage('back', targetPosition('library'), 'main', 'main', animate !== false);
    clearProfileExit();
    libraryProfile.current = null;
    setView('library');
    setPlaying(false);
    setFocus(false);
  }
  function changeView(v: View, nested = false, animate = true) {
    rememberPosition();
    cancelSavedTransition();
    document.querySelectorAll('.notes-exit-snapshot').forEach((node) => node.remove());
    clearProfileExit();
    if (v !== 'reels') {
      setSavedReturn(undefined);
      setReelsProfile(undefined);
    }
    if (v === 'library' && libraryProfile.current && (immersive || view !== 'profile')) {
      const previousCourse = state.courses.find((c) => c.id === libraryProfile.current);
      if (previousCourse) {
        exitPlayback(false, false);
        setCourseId(previousCourse.id);
        setIndex(state.last[previousCourse.id] ?? 0);
        setView('profile');
        setFocus(false);
        pendingScroll.current = targetPosition(`profile:${previousCourse.id}`);
        return;
      }
    }
    if (v === 'library') libraryProfile.current = null;
    if (v === 'reels') {
      openReelsTab();
      return;
    }

    clearProfileExit();
    if (immersive) exitPlayback(false, false);
    const targetKey =
      v === 'saved'
        ? `saved:${savedSection}${savedSection === 'screens' && savedScreenVideo ? `:${savedScreenVideo}` : ''}`
        : v;
    if (nested)
      queuePage(
        v === 'settings' ? 'open' : 'back',
        targetPosition(targetKey),
        'main',
        'main',
        animate,
      );
    else {
      cancelSavedTransition();
      pendingScroll.current = targetPosition(targetKey);
    }
    setView(v);
    setPlaying(false);
    setFocus(false);
  }
  function changeDuration(seconds: State['seconds']) {
    setImportSeconds(seconds);
  }
  async function importCourse(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    let source: ReturnType<typeof parseYouTubeUrl>;
    try {
      source = parseYouTubeUrl(url);
    } catch (e) {
      setError((e as Error).message);
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL ?? ''}/api/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
        signal: AbortSignal.timeout(120000),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? 'Import failed.');
      const candidate = schema.parse({
        ...initial,
        courses: [{ ...result.course, kind: source.kind, reelSeconds: importSeconds }],
      }).courses[0];
      if (candidate.id !== source.id)
        throw new Error(
          'The server returned a different video or playlist. Nothing was added. Please retry.',
        );
      const previous = latestState.current;
      const updating = previous.courses.some((c) => c.id === candidate.id);
      const next = {
        ...previous,
        courses: [candidate, ...previous.courses.filter((c) => c.id !== candidate.id)],
      };
      if (next.courses.length > 100)
        throw new Error(
          'Your library has reached 100 entries. Remove an entry before importing another.',
        );
      try {
        persist(next);
      } catch {
        throw new Error(
          'This device could not save the playlist. Free browser storage or export your progress before trying again.',
        );
      }
      libraryProfile.current = null;
      setState(next);
      primeCourse(candidate, importSeconds);
      setCourseId(candidate.id);
      setIndex(0);
      setView('library');
      setImmersive(false);
      setFocus(false);
      setPlaying(false);
      setEnded(false);
      setModal(null);
      setUrl('');
      window.scrollTo(0, 0);
      setToast(
        `${updating ? 'Updated' : 'Added'} ${source.kind}: ${candidate.title} · ${candidate.videos.length} ${candidate.videos.length === 1 ? 'video' : 'videos'}${result.skipped ? ` · ${result.skipped} unavailable or duplicate videos skipped` : ''}`,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not import. Check your connection.');
    } finally {
      setBusy(false);
    }
  }
  const savedIds = useMemo(
    () => (reel ? idsForMoment(reel, state.saved, state.courses) : []),
    [reel?.id, state.saved, state.courses],
  );
  const saved = savedIds.length > 0;
  const noteMoment = standaloneNote ?? reel;
  const noteIds = useMemo(
    () => (noteMoment ? idsForMoment(noteMoment, Object.keys(state.notes), state.courses) : []),
    [noteMoment?.id, state.notes, state.courses],
  );
  const noteTargetId =
    noteMoment && state.notes[noteMoment.id]?.trim()
      ? noteMoment.id
      : (noteIds.find((id) => state.notes[id].trim()) ?? noteMoment?.id);
  const reelNote = noteTargetId ? (state.notes[noteTargetId] ?? '') : '';
  function updateReelNote(value: string) {
    if (!noteTargetId) return;
    setState((s) => ({ ...s, notes: { ...s.notes, [noteTargetId]: value } }));
  }
  function toggleSaved() {
    if (!reel) return;
    setState((s) => ({
      ...s,
      saved: saved ? s.saved.filter((id) => !savedIds.includes(id)) : [...s.saved, reel.id],
    }));
    setToast(saved ? 'Moment removed from saved.' : 'Moment saved for a second look.');
  }
  function tick(previous: number, current: number, playbackRate: number) {
    if (!reel) return;
    const elapsed = (current - previous) / playbackRate;
    if (elapsed > 0 && elapsed <= 2.5) recordAnalyticsWatch(elapsed);
    setState((s) => {
      const progress = recordInterval(s.progress, reel.video.id, previous, current);
      if (progress === s.progress) return s;
      const delta = Math.max(0, Math.min(2.5, current - previous));
      const day = localDate();
      return {
        ...s,
        progress,
        activity: { ...s.activity, [day]: (s.activity[day] ?? 0) + delta },
        videoActivity: {
          ...s.videoActivity,
          [reel.video.id]: {
            ...s.videoActivity?.[reel.video.id],
            [day]: (s.videoActivity?.[reel.video.id]?.[day] ?? 0) + delta,
          },
        },
      };
    });
  }
  function captureScreenNote(
    frame: Blob,
    time: number,
    segment: Segment,
    layout: { captureRotation: 0 | 90; captureViewport: 'portrait' | 'landscape' },
  ) {
    const source =
      state.courses.find(
        (c) => c.id === courseId && c.videos.some((v) => v.id === segment.video.id),
      ) ?? state.courses.find((c) => c.videos.some((v) => v.id === segment.video.id));
    if (!source) {
      setToast('This lecture is no longer in your library.');
      return;
    }
    if ((state.screenNotes?.length ?? 0) >= SCREEN_NOTE_LIMIT) {
      setToast(
        'You have 500 Screen Notes. Export a backup and remove some captures before adding more.',
      );
      return;
    }
    const id = `frame-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
    setScreenDraft({
      frame,
      note: {
        id,
        videoId: segment.video.id,
        videoTitle: segment.video.title,
        channel: segment.video.channel,
        courseId: source.id,
        courseTitle: source.title,
        playlist: source.kind === 'playlist' || source.videos.length > 1,
        time,
        createdAt: Date.now(),
        ...layout,
        label: '',
        note: '',
      },
    });
    setError('');
    setModal('screen');
  }
  async function saveScreenNote(note: ScreenNote, keepOpen = false) {
    setBusy(true);
    setError('');
    try {
      const current = latestState.current;
      const existing = current.screenNotes ?? [];
      if (!existing.some((n) => n.id === note.id) && existing.length >= SCREEN_NOTE_LIMIT)
        throw new Error('Screen Notes is full. Remove a capture before saving another.');
      if (screenDraft?.frame) await putScreenImages([{ id: note.id, blob: screenDraft.frame }]);
      const next = {
        ...latestState.current,
        screenNotes: [
          note,
          ...(latestState.current.screenNotes ?? []).filter((n) => n.id !== note.id),
        ],
      };
      persist(next);
      latestState.current = next;
      setState(next);
      if (keepOpen) {
        setScreenDraft({ note });
        changeScreenMode('fullscreen');
        setToast('Screen Note updated.');
      } else {
        setModal(null);
        setScreenDraft(null);
        setToast('Screen Note saved. Find it in Saved → Screen Notes.');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save this Screen Note.');
    } finally {
      setBusy(false);
    }
  }
  async function deleteScreenNote() {
    if (!screenDraft) return;
    return deleteScreenCapture(screenDraft.note.id);
  }
  async function deleteScreenCapture(id: string) {
    const next = {
      ...latestState.current,
      screenNotes: (latestState.current.screenNotes ?? []).filter((n) => n.id !== id),
    };
    persist(next);
    latestState.current = next;
    setState(next);
    setModal(null);
    setScreenDraft(null);
    if (!next.screenNotes.some((n) => n.videoId === savedScreenVideo)) setSavedScreenVideo(null);
    try {
      await removeScreenImage(id);
      setToast('Screen Note deleted.');
    } catch {
      setToast(
        'Note removed. Its image could not be cleared; try Clear data in Settings to retry cleanup.',
      );
    }
  }
  async function deleteScreenAlbum(videoId: string) {
    const current = latestState.current;
    const removed = (current.screenNotes ?? []).filter((n) => n.videoId === videoId);
    const next = {
      ...current,
      screenNotes: (current.screenNotes ?? []).filter((n) => n.videoId !== videoId),
    };
    persist(next);
    latestState.current = next;
    setState(next);
    if (savedScreenVideo === videoId) setSavedScreenVideo(null);
    const results = await Promise.allSettled(removed.map((n) => removeScreenImage(n.id)));
    setToast(
      results.some((r) => r.status === 'rejected')
        ? 'Album removed. Some device images could not be cleared; use Clear data in Settings to retry.'
        : 'Screen Notes album deleted.',
    );
  }
  async function exportData() {
    try {
      await exportBackup(
        JSON.stringify(await screenNotesBackup(state), null, 2),
        `microgram-${localDate()}.json`,
      );
      setToast('Backup ready. Keep it somewhere safe.');
    } catch (e) {
      setToast(
        e instanceof Error ? e.message : 'Export cancelled or unavailable. Please try again.',
      );
    }
  }
  async function restore(file: File) {
    try {
      if (file.size > 100_000_000) throw new Error('Backup is too large (maximum 100 MB).');
      const { state: data, images } = await readScreenNotesBackup(JSON.parse(await file.text()));
      if (images.length) await putScreenImages(images, true);
      persist(data);
      latestState.current = data;
      setState(data);
      setCourseId(data.courses[0]?.id ?? '');
      setIndex(0);
      setPlaying(false);
      setImmersive(false);
      setSavedQueue([]);
      setSavedReturn(undefined);
      setReelsProfile(undefined);
      setFlowEntry(null);
      setSavedScreenVideo(null);
      setScreenDraft(null);
      libraryProfile.current = null;
      setView('settings');
      if (!data.profile?.name) setModal('name');
      setProfileName(data.profile?.name ?? '');
      setProfileUsername(data.profile?.username ?? '');
      setProfilePhoto(data.profile?.photo);
      setToast('Your learning space has been restored.');
      void pruneScreenImages((data.screenNotes ?? []).map((n) => n.id)).catch(() => {});
    } catch (e) {
      setToast(
        e instanceof Error && !(e instanceof SyntaxError) && !('issues' in e)
          ? e.message
          : 'This is not a valid MicroGram backup (maximum 100 MB).',
      );
    }
  }
  async function clearLearningSpace() {
    setBusy(true);
    setError('');
    try {
      if (clearServerDownloads) {
        const response = await fetch(
          `${import.meta.env.VITE_API_BASE_URL ?? ''}/api/media/storage/clear`,
          { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' },
        );
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not clear server downloads.');
      }
      await clearTemporaryBackups();
      await clearScreenImages();
      clearDeviceStorage();
      prepared.clear();
      clearLibraryMetadataCache();
      clearProfileExit();
      document.querySelectorAll('.notes-exit-snapshot').forEach((node) => node.remove());
      const cleared: State = { ...initial, courses: [] };
      persist(cleared);
      latestState.current = cleared;
      setState(cleared);
      libraryProfile.current = null;
      scrollPositions.current = {};
      profileScroll.current = 0;
      savedScroll.current = 0;
      setPlaying(false);
      setVideoPlaying(false);
      setImmersive(false);
      setFocus(false);
      setControlsHidden(false);
      setIndex(0);
      setCourseId('');
      setReelVideoId('');
      setSavedQueue([]);
      setSavedSection('screens');
      setSavedReturn(undefined);
      setReelsProfile(undefined);
      setFlowEntry(null);
      setSavedPlayback(undefined);
      setSavedScreenVideo(null);
      setScreenDraft(null);
      setStandaloneNote(null);
      setRotationOverride(null);
      setProfileName('');
      setProfileUsername('');
      setProfilePhoto(undefined);
      setImportSeconds(60);
      setUrl('');
      setView('feed');
      setModal('name');
      setToast('Your name and all learning data on this device have been cleared.');
      window.scrollTo(0, 0);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not clear your learning space.');
    } finally {
      setBusy(false);
    }
  }
  const openImport = () => {
    setError('');
    setModal('import');
  };
  function closeModal(animate = true) {
    if (busy) return;
    if (modal === 'screen-review' && screenMode === 'edit') changeScreenMode('fullscreen', animate);
    else if (modal === 'screen-review') closeScreenViewer(animate);
    else {
      queuePage('back', window.scrollY, '.modal', immersive ? '.reel-stage' : 'main', animate);
      setModal(null);
    }
  }
  function openScreenViewer(note: ScreenNote) {
    rememberPosition();
    queuePage('open', window.scrollY, 'main .saved-page', '.screen-review-modal');
    setError('');
    setScreenDraft({ note });
    setScreenMode('fullscreen');
    setModal('screen-review');
  }
  function closeScreenViewer(animate = true) {
    queuePage(
      'back',
      targetPosition(currentScrollKey.current),
      '.screen-review-modal',
      'main .saved-page',
      animate,
    );
    setModal(null);
  }
  function changeScreenMode(mode: ScreenReviewMode, animate = true) {
    if (mode === screenMode) return;
    queuePage(
      mode === 'edit' ? 'open' : 'back',
      window.scrollY,
      '.screen-review-modal',
      '.screen-review-modal',
      animate,
    );
    setScreenMode(mode);
  }
  return (
    <div
      className={`app personal-edition ${controlsHidden ? 'reel-controls-hidden' : ''} ${fit ? 'video-fit' : ''} ${focus ? 'focus-mode' : ''} ${immersive ? 'immersive-mode' : ''} ${rotated ? 'video-rotated' : ''} ${Capacitor.isNativePlatform() ? 'native-app' : ''}`}
    >
      {analytics.available && analytics.preference === null && view === 'feed' && !modal && !communityThread && (
        <aside className="analytics-choice" aria-label="Optional usage analytics">
          <strong>Help improve MicroGram?</strong>
          <p>Share app opens and time spent, including reel playback, using a random install ID. Your learning content stays on this device.</p>
          <div className="setting-actions">
            <button className="button secondary" onClick={() => analytics.choose(false)}>No thanks</button>
            <button className="button primary" onClick={() => analytics.choose(true)}>Share usage</button>
          </div>
        </aside>
      )}
      <aside className="sidebar" inert={Boolean(communityThread)}>
        <Logo />
        <div className="workspace-label">YOUR LEARNING SPACE</div>
        <nav>
          {nav.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`nav-item ${(immersive ? id === (view === 'saved' ? 'saved' : 'reels') : view === id || (view === 'profile' && id === 'library')) ? 'active' : ''}`}
              onClick={() => changeView(id)}
            >
              <Icon size={20} />
              <span>{label}</span>
              {id === 'saved' && state.saved.length > 0 && <small>{state.saved.length}</small>}
              {(view === id || (view === 'profile' && id === 'library')) && <i />}
            </button>
          ))}
        </nav>
        <button className="import-side" onClick={openImport}>
          <Plus size={19} /> Import a playlist
        </button>
        <div className="sidebar-bottom">
          <div className="little-card">
            <span className="little-icon">
              <Sparkles size={17} />
            </span>
            <strong>Small steps. Big ideas.</strong>
            <p>
              You don’t need more time.
              <br />
              Just a little momentum.
            </p>
            <div className="mini-path">
              <i />
              <i />
              <i />
              <i />
              <i />
              <span>↗</span>
            </div>
          </div>
          <button
            className={`nav-item ${view === 'settings' ? 'active' : ''}`}
            onClick={() => changeView('settings', true)}
          >
            <Settings2 size={19} /> Settings
          </button>
          <div className="profile">
            <span className="avatar">
              <img src={state.profile?.photo || '/avatar-placeholder.svg'} alt="Your profile" />
            </span>
            <div>
              <strong>{state.profile?.name?.trim() || 'User'}</strong>
              <small>Stored on this device</small>
            </div>
            <span className="online-dot" />
          </div>
        </div>
      </aside>
      <div className="main-shell" inert={Boolean(communityThread)}>
        <main>
          {view === 'feed' && !immersive && (
            <Home
              state={state}
              progressFirst={progressFirst}
              onStart={openReelsTab}
              onImport={openImport}
              onSettings={() => changeView('settings', true)}
              onPrivacy={() => setModal('privacy')}
              onOpenReplies={openCommunityThread}
              onGoal={(goal) => setState((s) => ({ ...s, goal }))}
            />
          )}
          {((view === 'reels' && !reelsProfile) || immersive) && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    <span /> A LITTLE WISER, EVERY SCROLL
                  </div>
                  <h1>
                    Your daily dose of <em>discovery.</em>
                  </h1>
                  <p>Big lectures. Bite-sized moments. Real progress.</p>
                </div>
                <button
                  className={`button subtle focus-toggle ${focus ? 'selected' : ''}`}
                  onClick={() => setFocus(!focus)}
                >
                  <Maximize2 size={16} />
                  {focus ? 'Exit focus' : 'Focus mode'}
                </button>
              </div>
              {course && reel ? (
                <div className="learning-layout">
                  <section className="feed-column">
                    <div className="feed-tabs">
                      <button className="selected">
                        Continue learning <span />
                      </button>
                      <button onClick={() => changeView('library')}>My playlists</button>
                      <span className="feed-tabs-end">
                        <span className="live-dot" /> YOUR PACE
                      </span>
                    </div>
                    <button
                      className="mobile-journey"
                      onClick={() => changeView('progress', view === 'settings')}
                      aria-label="View detailed learning progress"
                    >
                      <span>
                        <CheckCheck size={13} />
                        <strong>
                          {videoDone}/{videoReels.length}
                        </strong>{' '}
                        lecture reels
                      </span>
                      <span>
                        <strong>
                          {totalCompleted}/{reels.length}
                        </strong>{' '}
                        playlist reels <ChevronRight size={13} />
                      </span>
                    </button>
                    <div className="reel-stage" ref={stageRef}>
                      {view === 'reels' && <ReelSponsor onActive={setAdActive} reelKey={`${reel.video.id}:${reel.start}`} />}
                      {immersive && (
                        <div className="immersive-toolbar">
                          <button onClick={() => exitPlayback()} aria-label="Exit fullscreen reels">
                            <ArrowLeft size={22} />
                            <span>Back</span>
                          </button>
                          <div className="reels-heading">
                            <span>Reels</span>
                            <div
                              className={`reels-watched${totalCompleted > 0 ? ' has-progress' : ''}`}
                              role="status"
                              aria-label={`${totalCompleted} of ${reels.length} reels watched in this ${course.videos.length > 1 ? 'playlist' : 'lecture'}`}
                            >
                              <strong>
                                {totalCompleted}
                                <span>/{reels.length}</span>
                              </strong>
                              <small>watched</small>
                            </div>
                          </div>
                          <button
                            aria-label={fit ? 'Fill screen' : 'Fit whole video'}
                            onClick={() =>
                              setState((s) => ({
                                ...s,
                                videoLayouts: {
                                  ...s.videoLayouts,
                                  [reel.video.id]: {
                                    ...s.videoLayouts?.[reel.video.id],
                                    fit: !fit,
                                  },
                                },
                              }))
                            }
                          >
                            <Maximize2 size={21} />
                            <span>{fit ? 'Fill' : 'Fit'}</span>
                          </button>
                          <button
                            onClick={() =>
                              setState((s) => ({
                                ...s,
                                videoLayouts: {
                                  ...s.videoLayouts,
                                  [reel.video.id]: {
                                    ...s.videoLayouts?.[reel.video.id],
                                    rotated: !rotated,
                                  },
                                },
                              }))
                            }
                            aria-label={
                              rotated ? 'Restore horizontal video' : 'Rotate video vertically'
                            }
                            aria-pressed={rotated}
                          >
                            <RotateCw size={21} />
                            <span>{rotated ? 'Horizontal' : 'Rotate'}</span>
                          </button>
                        </div>
                      )}
                      <PlaybackLayout.Provider
                        value={{ videoId: reel.video.id, rotated, fit, resolve: resolveLayout }}
                      >
                        <ReelPager
                          index={safeIndex}
                          reels={reels}
                          controlRef={pager}
                          onNavigate={commitMove}
                          onBusy={setTransitioning}
                          onPrepare={(next) => playbackControls.current?.prepareReel(next)}
                          renderPreview={
                            immersive
                              ? (segment, at) => (
                                  <ReelOverlay
                                    segment={segment}
                                    index={at}
                                    total={reels.length}
                                    profileLink={view !== 'saved'}
                                    profileTitle={course.title}
                                    onContinue={view === 'saved' ? () => {} : undefined}
                                    preview
                                  />
                                )
                              : undefined
                          }
                        >
                          <article className="reel-card">
                            {immersive && (
                              <ReelOverlay
                                segment={reel}
                                index={safeIndex}
                                total={reels.length}
                                profileLink={view !== 'saved'}
                                profileTitle={course.title}
                                onProfile={openReelsProfile}
                                onContinue={view === 'saved' ? continueSavedLecture : undefined}
                              />
                            )}
                            {!immersive && (
                              <div className="reel-top">
                                <span className="topic-tag">
                                  <GraduationCap size={13} />
                                  {course.sample ? 'STARTER LECTURE' : 'YOUR PLAYLIST'}
                                </span>
                                <span className="reel-counter">
                                  {safeIndex + 1}
                                  <span> / {reels.length}</span>
                                </span>
                              </div>
                            )}
                            <div className="lesson-label">
                              <span>
                                LECTURE {reel.videoIndex + 1} <i /> REEL {reel.index + 1}
                              </span>
                              <h2>{reel.video.title}</h2>
                              <p>
                                {course.sample
                                  ? 'A new perspective is just one small step away.'
                                  : course.title}
                              </p>
                            </div>
                            {playing && !adActive ? (
                              <Player
                                nearbyReels={reels.slice(Math.max(0, safeIndex - 5), safeIndex + 6)}
                                preloadReels={view === 'reels'}
                                entryKey={view === 'saved' ? 'saved' : 'flow'}
                                initialTime={
                                  view === 'saved'
                                    ? savedPlayback?.time
                                    : flowEntry?.id === reel.id
                                      ? flowEntry.time
                                      : undefined
                                }
                                initiallyPaused={
                                  view === 'saved'
                                    ? savedPlayback?.paused
                                    : flowEntry?.id === reel.id && flowEntry.paused
                                }
                                singleReel={
                                  view === 'saved' && immersive && savedSection !== 'reels'
                                }
                                quality={state.videoQualities?.[reel.video.id] ?? 'high'}
                                qualityFor={(id) => state.videoQualities?.[id] ?? 'high'}
                                setQuality={(quality) =>
                                  setState((s) => ({
                                    ...s,
                                    videoQualities: {
                                      ...s.videoQualities,
                                      [reel.video.id]: quality,
                                    },
                                  }))
                                }
                                speed={state.playbackSpeeds?.[reel.video.id] ?? 1}
                                setSpeed={(speed) =>
                                  setState((s) => ({
                                    ...s,
                                    playbackSpeeds: {
                                      ...s.playbackSpeeds,
                                      [reel.video.id]: speed as 1 | 1.25 | 1.5 | 1.75 | 2,
                                    },
                                  }))
                                }
                                onOpenSettings={() => changeView('settings', true)}
                                onCapture={captureScreenNote}
                                onCaptureError={setToast}
                                controlsHidden={controlsHidden}
                                onToggleControls={() => setControlsHidden((v) => !v)}
                                controlRef={playbackControls}
                                onPlaybackChange={(active) => {
                                  setVideoPlaying(active);
                                  if (active && modal) playbackControls.current?.togglePlay();
                                }}
                                segment={reel}
                                onDimensions={(width, height) => {
                                  if (reel.video.width === width && reel.video.height === height)
                                    return;
                                  setState((s) => ({
                                    ...s,
                                    courses: s.courses.map((c) => ({
                                      ...c,
                                      videos: c.videos.map((v) =>
                                        v.id === reel.video.id ? { ...v, width, height } : v,
                                      ),
                                    })),
                                  }));
                                }}
                                onTick={tick}
                                onEnd={() => {
                                  setEnded(false);
                                }}
                                onDuration={(duration) => {
                                  if (Math.abs(duration - reel.video.duration) > 1)
                                    setState((s) => ({
                                      ...s,
                                      courses: s.courses.map((c) => ({
                                        ...c,
                                        videos: c.videos.map((v) =>
                                          v.id === reel.video.id ? { ...v, duration } : v,
                                        ),
                                      })),
                                    }));
                                }}
                              />
                            ) : (
                              <button
                                className="lesson-preview"
                                onClick={() => {
                                  if (!state.consent) {
                                    setModal('privacy');
                                    return;
                                  }
                                  startPlayback();
                                }}
                                aria-label="Play this reel"
                              >
                                {course.sample ? (
                                  <Diagram />
                                ) : (
                                  <img src={reel.video.thumbnail} alt="Lecture thumbnail" />
                                )}
                                <span className="play-overlay">
                                  <Play size={24} fill="currentColor" />
                                </span>
                                <span className="preview-caption">
                                  {course.sample
                                    ? 'Preview illustration · Play cached lecture'
                                    : 'Play in your personal player'}
                                </span>
                              </button>
                            )}
                            {!immersive && (
                              <div className="reel-bottom">
                                <div
                                  className={`creator-row${immersive ? ' compact-reel-caption' : ''}`}
                                >
                                  <span className="creator-avatar" title={reel.video.channel}>
                                    <img
                                      src={reel.video.thumbnail}
                                      alt=""
                                      onError={(e) => {
                                        e.currentTarget.onerror = null;
                                        e.currentTarget.src = '/local-cover.svg';
                                      }}
                                    />
                                  </span>
                                  <div>
                                    <strong>
                                      {immersive ? (
                                        view !== 'saved' ? (
                                          <button
                                            className="compact-reel-title reel-profile-link"
                                            title={reel.video.title}
                                            aria-label={`Open ${course.title} learning profile`}
                                            onClick={openReelsProfile}
                                          >
                                            {reel.video.title}
                                          </button>
                                        ) : (
                                          <span
                                            className="compact-reel-title"
                                            title={reel.video.title}
                                          >
                                            {reel.video.title}
                                          </span>
                                        )
                                      ) : (
                                        <>
                                          {reel.video.channel} <span className="verified">✓</span>
                                        </>
                                      )}
                                    </strong>
                                    <small>Original lecture on YouTube</small>
                                  </div>
                                  <a
                                    href={`https://www.youtube.com/watch?v=${reel.video.id}&t=${reel.start}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    aria-label="Open original lecture on YouTube"
                                  >
                                    <ArrowRight size={18} />
                                  </a>
                                </div>
                                <div className="segment-meta">
                                  <span>
                                    <Clock3 size={13} /> {clock(reel.start)}–{clock(reel.end)}
                                  </span>
                                  {view === 'saved' && immersive ? (
                                    <button
                                      className="continue-lecture"
                                      onClick={continueSavedLecture}
                                    >
                                      Continue lecture
                                    </button>
                                  ) : (
                                    <span>{Math.ceil(reel.end - reel.start)} second reel</span>
                                  )}
                                </div>
                                <div className="segment-progress">
                                  <i
                                    style={{
                                      width: `${Math.min(100, watched(reel, state.progress) * 100)}%`,
                                    }}
                                  />
                                </div>
                                <div className="reel-foot">
                                  <span>
                                    {complete(reel, state.progress) ? (
                                      <>
                                        <CheckCheck size={15} /> One little win, earned.
                                      </>
                                    ) : ended ? (
                                      'Replay to finish, or keep exploring.'
                                    ) : (
                                      'One idea at a time. You’ve got this.'
                                    )}
                                  </span>
                                  {ended ? (
                                    <button
                                      onClick={() => {
                                        setPlaying(false);
                                        setEnded(false);
                                      }}
                                    >
                                      Replay ↺
                                    </button>
                                  ) : (
                                    <span className="swipe-hint">
                                      SCROLL TO EXPLORE <ArrowDown size={12} />
                                    </span>
                                  )}
                                </div>
                              </div>
                            )}
                          </article>
                        </ReelPager>
                      </PlaybackLayout.Provider>
                      <div className="reel-rail">
                        {immersive && (
                          <div
                            className={`reel-completion${reelCompleted ? ' is-complete' : ''}`}
                            role="img"
                            aria-label={
                              reelCompleted
                                ? 'This reel is watched'
                                : 'This reel is not yet completed'
                            }
                            title={
                              reelCompleted
                                ? 'Watched · progress saved'
                                : 'Watch this reel to complete it'
                            }
                          >
                            <div className="completion-check">
                              <CircleCheck size={28} />
                            </div>
                            <span>{reelCompleted ? 'Watched' : 'Watching'}</span>
                          </div>
                        )}
                        <div id="reel-speed-slot" />
                        <div id="reel-quality-slot" />
                        <button
                          className={`save-control${saved ? ' is-saved' : ''}`}
                          onClick={toggleSaved}
                          aria-label={saved ? 'Unsave moment' : 'Save moment'}
                        >
                          <Bookmark size={22} fill={saved ? 'currentColor' : 'none'} />
                          <span>{saved ? 'Saved' : 'Save'}</span>
                        </button>
                        <button
                          className={`notes-control${reelNote ? ' is-saved' : ''}`}
                          onClick={(e) => {
                            notesOrigin.current = e.currentTarget.getBoundingClientRect();
                            setStandaloneNote(null);
                            setModal('notes');
                          }}
                          aria-label="Add a note"
                          aria-pressed={Boolean(reelNote)}
                        >
                          <BookOpen size={22} fill={reelNote ? 'currentColor' : 'none'} />
                          <span>Notes</span>
                        </button>
                        <div className="rail-divider" />
                        <button
                          disabled={safeIndex === 0 || transitioning}
                          onClick={() => move(-1)}
                          aria-label="Previous reel"
                          className="circle-button"
                        >
                          <ArrowUp size={20} />
                        </button>
                        <button
                          disabled={safeIndex === reels.length - 1 || transitioning}
                          onClick={() => move(1)}
                          aria-label="Next reel"
                          className="circle-button"
                        >
                          <ArrowDown size={20} />
                        </button>
                      </div>
                    </div>
                    <div className="below-reel">
                      <span>
                        <span className="key">↑</span>
                        <span className="key">↓</span> or swipe to explore
                      </span>
                      <span>
                        <span className="little-green-dot" /> Progress saves automatically
                      </span>
                    </div>
                  </section>
                  <aside className="right-panel">
                    <section className="panel journey-panel">
                      <div className="panel-title">
                        <span>Your learning journey</span>
                        <span className="icon-muted">
                          <Layers3 size={17} />
                        </span>
                      </div>
                      <div className="course-cover">
                        <span className="cover-art">
                          {course.sample ? (
                            <>
                              <span>Linear</span>
                              <span>
                                algebra<span className="cover-dot">.</span>
                              </span>
                              <svg viewBox="0 0 120 90">
                                <path
                                  d="M10 80L52 10L110 50L70 85Z M10 80L110 50M52 10L70 85"
                                  stroke="#a78bfa"
                                  fill="none"
                                  strokeWidth="1.2"
                                />
                              </svg>
                            </>
                          ) : (
                            <img src={course.videos[0]?.thumbnail} alt="Playlist cover" />
                          )}
                        </span>
                      </div>
                      <h3>{course.title}</h3>
                      <p className="muted course-by">
                        {course.channel} <span>•</span> {course.videos.length} lecture
                        {course.videos.length !== 1 ? 's' : ''}
                      </p>
                      <div className="progress-label">
                        <span>Playlist progress</span>
                        <strong>{Math.round((totalCompleted / reels.length) * 100)}%</strong>
                      </div>
                      <div className="progress-bar">
                        <i style={{ width: `${(totalCompleted / reels.length) * 100}%` }} />
                      </div>
                      <p className="count-caption">
                        <strong>{totalCompleted}</strong> of {reels.length} reels completed
                      </p>
                      <div className="current-lecture">
                        <div className="lecture-icon">
                          <Play size={15} />
                        </div>
                        <div>
                          <small>CURRENT LECTURE</small>
                          <strong>{reel.video.title}</strong>
                          <span>
                            {videoDone} / {videoReels.length} reels watched
                          </span>
                        </div>
                      </div>
                      <button className="text-button" onClick={() => openProfile(course)}>
                        View playlist <ArrowRight size={15} />
                      </button>
                    </section>
                    <section className="panel goal-panel">
                      <div className="panel-title">
                        <span>
                          <Target size={17} /> A little, every day
                        </span>
                        <span className="goal-icon">✦</span>
                      </div>
                      <p>Your {state.goal}-minute daily goal</p>
                      <div className="goal-blocks">
                        {Array.from({ length: 10 }, (_, i) => (
                          <i
                            key={i}
                            className={
                              (todaySeconds / (state.goal * 60)) * 10 >= i + 1 ? 'filled' : ''
                            }
                          />
                        ))}
                      </div>
                      <div className="goal-caption">
                        <strong>
                          {todayMinutes} <span>/ {state.goal} min</span>
                        </strong>
                        <span>
                          {todayMinutes >= state.goal ? 'You did it!' : 'Keep showing up'}
                        </span>
                      </div>
                    </section>
                    <div className="quote">
                      <span>“</span>
                      <p>
                        It’s not about having time.
                        <br />
                        It’s about making a little.
                      </p>
                      <small>MAKE YOUR SCROLL COUNT.</small>
                    </div>
                  </aside>
                </div>
              ) : (
                <Empty
                  title="Your next chapter starts here."
                  text="Add a YouTube lecture or playlist and turn it into a feed of little wins."
                  action={openImport}
                />
              )}
            </>
          )}
          {(view === 'profile' || (view === 'reels' && reelsProfile)) && course && (
            <div hidden={immersive}>
              <CourseProfile
                key={`${course.id}:${course.reelSeconds ?? state.seconds}`}
                course={course}
                seconds={course.reelSeconds ?? state.seconds}
                progress={state.progress}
                saved={state.saved}
                last={state.last[course.id] ?? 0}
                onBack={view === 'reels' ? closeReelsProfile : backToLibrary}
                backLabel={view === 'reels' ? 'Back to reels' : 'Back to library'}
                onPlay={openProfileReel}
                selectedLecture={state.profileLectures?.[course.id] ?? 'all'}
                onLectureChange={(lectureId) =>
                  setState((s) => ({
                    ...s,
                    profileLectures: { ...s.profileLectures, [course.id]: lectureId },
                  }))
                }
              />
            </div>
          )}
          {view === 'library' && (
            <LibraryFeed
              courses={state.courses}
              seconds={state.seconds}
              progress={state.progress}
              onOpen={openProfile}
              onImport={openImport}
              onRemove={(c, cleared) => {
                setState((s) => ({ ...s, courses: s.courses.filter((item) => item.id !== c.id) }));
                setToast(
                  cleared
                    ? 'Removed from library. Eligible downloads cleared; shared, active and original files kept.'
                    : 'Removed from library. Viewing history is kept.',
                );
              }}
            />
          )}
          {view === 'saved' && (
            <Saved
              courses={state.courses}
              reels={bookmarkedMoments}
              notes={notedMoments}
              section={savedSection}
              onSection={(section) => {
                rememberPosition();
                pendingScroll.current = window.scrollY;
                setSavedSection(section);
              }}
              onOpen={openSaved}
              screenNotes={state.screenNotes ?? []}
              onDeleteAlbum={deleteScreenAlbum}
              onDeletePhoto={deleteScreenCapture}
              selectedScreenVideo={savedScreenVideo}
              onScreenVideo={selectSavedAlbum}
              onScreenNote={openScreenViewer}
              onPlayScreenNote={openScreenReel}
              hidden={immersive}
            />
          )}
          {view === 'progress' && <Insights state={state} />}
          {view === 'settings' && (
            <section className="settings-page" aria-label="App settings">
              <header className="utility-heading">
                <div>
                  <h1>Settings</h1>
                  <p>Your profile, learning data and device storage.</p>
                </div>
                <button
                  className="utility-icon"
                  aria-label="Back to Home"
                  onClick={() => changeView('feed', true)}
                >
                  <ArrowLeft size={22} />
                </button>
              </header>
              <div className="settings-panel panel">
                <div className="setting-row">
                  <div>
                    <h3>Your profile</h3>
                    <div className="settings-profile">
                      <img
                        src={state.profile?.photo || '/avatar-placeholder.svg'}
                        alt="Your profile"
                      />
                      <div>
                        <strong>{state.profile?.name?.trim() || 'User'}</strong>
                        {state.profile?.username?.trim() && <p>@{state.profile.username.trim()}</p>}
                      </div>
                    </div>
                  </div>
                  <button
                    className="button secondary"
                    onClick={() => {
                      setProfileName(state.profile?.name ?? '');
                      setProfileUsername(state.profile?.username ?? '');
                      setProfilePhoto(state.profile?.photo);
                      setError('');
                      setModal('name');
                    }}
                  >
                    Edit profile
                  </button>
                </div>
                <div className="setting-row">
                  <div>
                    <h3>Daily learning goal</h3>
                    <p>Set on Home. Used for your heat map and Insights.</p>
                  </div>
                  <span className="setting-goal-value">{state.goal} min/day</span>
                </div>
                <div className="setting-row">
                  <div>
                    <h3>Your data belongs to you</h3>
                    <p>
                      Your profile, library, saved reels, notes, Screen Notes, settings and progress
                      stay on this device. Export includes captured images, but not video files or
                      cached video parts. Restore replaces your current learning data.
                    </p>
                  </div>
                  <div className="setting-actions">
                    <button className="button secondary" onClick={exportData}>
                      <Download size={16} /> Export
                    </button>
                    <button className="button secondary" onClick={() => file.current?.click()}>
                      <Upload size={16} /> Restore
                    </button>
                    <input
                      ref={file}
                      hidden
                      type="file"
                      accept="application/json"
                      onChange={(e) => {
                        if (e.target.files?.[0]) void restore(e.target.files[0]);
                        e.target.value = '';
                      }}
                    />
                  </div>
                </div>
                {analytics.available && (
                  <div className="setting-row">
                    <div>
                      <h3>Usage analytics</h3>
                      <p>Share app opens and time spent using a random install ID. You can turn sharing off at any time.</p>
                    </div>
                    <button className="button secondary" aria-pressed={analytics.preference === 'on'} onClick={() => analytics.choose(analytics.preference !== 'on')}>
                      {analytics.preference === 'on' ? 'Sharing on' : 'Sharing off'}
                    </button>
                  </div>
                )}
                <div className="setting-row">
                  <div>
                    <h3>YouTube playback & privacy</h3>
                    <p>
                      {deviceStreaming
                        ? 'Video parts are streamed on demand and temporarily cached on this device. New parts require internet.'
                        : 'Videos stream from the server cache. Downloading new lectures requires internet.'}
                    </p>
                  </div>
                  <button className="button secondary" onClick={() => setModal('privacy')}>
                    Details <ArrowRight size={15} />
                  </button>
                </div>
                <div className="setting-row">
                  <div>
                    <h3>Clear this learning space</h3>
                    <p>
                      Resets your profile, library, saved reels, notes, captured images and
                      progress. You can also clear temporary video parts. Imported video files are
                      managed separately below.
                    </p>
                  </div>
                  <button
                    className="button danger"
                    onClick={() => {
                      setError('');
                      setClearServerDownloads(false);
                      setModal('delete');
                    }}
                  >
                    <Trash2 size={16} /> Clear data
                  </button>
                </div>
              </div>
              <StoragePanel courses={state.courses} onNotify={setToast} />
              <p className="fineprint">
                MicroGram version 1.0 · Independent learning companion. Not affiliated with YouTube
                or Instagram.
              </p>
            </section>
          )}
        </main>
      </div>
      {communityThread && <ReplyThread post={communityThread.post} profile={state.profile} enabled={communityThread.enabled} onClose={() => closeCommunityThread()} />}
      <nav className="mobile-nav" aria-label="Main navigation" inert={Boolean(communityThread)}>
        {nav.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            aria-label={label}
            className={
              (
                immersive
                  ? id === (view === 'saved' ? 'saved' : 'reels')
                  : view === id || (view === 'profile' && id === 'library')
              )
                ? 'selected'
                : ''
            }
            aria-current={
              (
                immersive
                  ? id === (view === 'saved' ? 'saved' : 'reels')
                  : view === id || (view === 'profile' && id === 'library')
              )
                ? 'page'
                : undefined
            }
            onClick={() => {
              if (!(immersive && view === 'reels' && id === 'reels')) changeView(id);
            }}
          >
            <span className="nav-icon">
              {id === 'feed' && !immersive && view === 'feed' ? (
                <svg width="26" height="26" viewBox="0 0 24 24" aria-hidden="true">
                  <rect x="2" y="2" width="20" height="20" rx="6" fill="currentColor" />
                  <path d="M10 7.5 17 12l-7 4.5Z" fill="#25292e" />
                </svg>
              ) : (
                <Icon size={26} />
              )}
            </span>
            <span className="nav-label">
              {id === 'feed'
                ? 'Learn'
                : id === 'library'
                  ? 'Library'
                  : id === 'reels'
                    ? 'Reels'
                    : id === 'saved'
                      ? 'Saved'
                      : 'Progress'}
            </span>
          </button>
        ))}
      </nav>
      {toast && (
        <div className="toast" role="status">
          <Check size={17} />
          {toast}
          <button aria-label="Dismiss notification" onClick={() => setToast('')}>
            <X size={15} />
          </button>
        </div>
      )}
      {modal === 'notes' && noteMoment && (
        <NotesDialog
          controlRef={notesDialog}
          segment={noteMoment}
          origin={notesOrigin.current}
          value={reelNote}
          onChange={updateReelNote}
          onClose={() => {
            setModal(null);
            setStandaloneNote(null);
          }}
        />
      )}
      {modal && modal !== 'notes' && (
        <div
          className={`modal-backdrop ${modal === 'screen-review' && screenMode === 'fullscreen' ? 'screen-full-backdrop' : ''}`}
          onClick={(e) => {
            if (e.target === e.currentTarget) closeModal();
          }}
        >
          <div
            className={`modal ${modal === 'import' ? 'import-surface' : ''} ${modal === 'screen' ? 'screen-note-modal' : ''} ${modal === 'screen-review' ? `screen-review-modal ${screenMode === 'fullscreen' ? 'is-fullscreen' : ''}` : ''}`}
            ref={modalRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                e.preventDefault();
                e.stopPropagation();
                closeModal();
              }
              if (e.key === 'Tab') {
                const els = Array.from(
                  modalRef.current?.querySelectorAll<HTMLElement>(
                    'button:not(:disabled),input,textarea,select,a[href]',
                  ) ?? [],
                ).filter((el) => !el.closest('[inert]') && el.getClientRects().length > 0);
                if (!els?.length) return;
                const first = els[0],
                  last = els[els.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                  e.preventDefault();
                  last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                  e.preventDefault();
                  first.focus();
                }
              }
            }}
          >
            {!(modal === 'screen-review' && screenMode === 'fullscreen') && (
              <button
                className="modal-close"
                disabled={busy}
                onClick={() => closeModal()}
                aria-label="Close dialog"
              >
                <X size={20} />
              </button>
            )}
            {modal === 'screen-review' && screenDraft && (
              <>
                <ScreenNoteReview
                  note={screenDraft.note}
                  notes={state.screenNotes ?? []}
                  mode={screenMode}
                  onMode={changeScreenMode}
                  onClose={() => closeScreenViewer()}
                  rotation={state.screenNoteRotations?.[screenDraft.note.videoId]}
                  onRotation={(rotation) =>
                    setState((s) => ({
                      ...s,
                      screenNoteRotations: {
                        ...s.screenNoteRotations,
                        [screenDraft.note.videoId]: rotation,
                      },
                    }))
                  }
                  onSelect={(note) => {
                    setError('');
                    setScreenDraft({ note });
                  }}
                  busy={busy}
                  onSave={(note) => saveScreenNote(note, true)}
                  onDelete={deleteScreenNote}
                />
                {error && (
                  <p className="screen-note-error" role="alert">
                    {error}
                  </p>
                )}
              </>
            )}
            {modal === 'screen' && screenDraft && (
              <>
                <ScreenNoteEditor
                  key={screenDraft.note.id}
                  draft={screenDraft.note}
                  frame={screenDraft.frame}
                  existing={!screenDraft.frame}
                  busy={busy}
                  onSave={saveScreenNote}
                  onDelete={deleteScreenNote}
                />
                {error && (
                  <p className="screen-note-error" role="alert">
                    {error}
                  </p>
                )}
              </>
            )}
            {modal === 'name' && (
              <>
                <span className="modal-symbol">
                  <Sparkles size={25} />
                </span>
                <h2 id="modal-title">What should we call you?</h2>
                <p>A name to make your learning space yours. It stays on this device.</p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const name = profileName.trim().replace(/\s+/g, ' ');
                    if (!name) return;
                    try {
                      const username = profileUsername.trim().replace(/^@/, '');
                      if (!/^[a-zA-Z0-9_.]{1,30}$/.test(username)) {
                        setError(
                          'Use up to 30 letters, numbers, dots or underscores for your username.',
                        );
                        return;
                      }
                      const next = {
                        ...state,
                        profile: {
                          name,
                          username,
                          ...(profilePhoto ? { photo: profilePhoto } : {}),
                        },
                      };
                      persist(next);
                      latestState.current = next;
                      setState(next);
                      setError('');
                      setModal(null);
                    } catch {
                      setError(
                        'Your name could not be saved. Free some device storage and try again.',
                      );
                    }
                  }}
                >
                  <ProfilePhoto value={profilePhoto} onChange={setProfilePhoto} />
                  <label className="field-label" htmlFor="profile-name">
                    Your name
                  </label>
                  <input
                    id="profile-name"
                    autoComplete="given-name"
                    maxLength={60}
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="Your name"
                  />
                  <label className="field-label" htmlFor="profile-username">
                    Username
                  </label>
                  <input
                    required
                    id="profile-username"
                    autoComplete="username"
                    maxLength={31}
                    value={profileUsername}
                    onChange={(e) => setProfileUsername(e.target.value)}
                    placeholder="@yourname"
                    autoCapitalize="none"
                    spellCheck={false}
                  />
                  {error && (
                    <p className="form-error" role="alert">
                      {error}
                    </p>
                  )}
                  <button
                    className="button primary full"
                    type="submit"
                    disabled={!profileName.trim() || !profileUsername.trim()}
                  >
                    Continue <ArrowRight size={16} />
                  </button>
                </form>
              </>
            )}
            {modal === 'import' && (
              <>
                <span className="modal-symbol">
                  <Link2 size={25} />
                </span>
                <h2 id="modal-title">Add a video</h2>
                <p>
                  Paste a public YouTube playlist or video. We’ll make it a sequence of bite-sized
                  learning moments.
                </p>
                <form onSubmit={importCourse}>
                  <label className="field-label" htmlFor="youtube-url">
                    YouTube link
                  </label>
                  <input
                    autoFocus
                    id="youtube-url"
                    type="url"
                    required
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://www.youtube.com/playlist?list=…"
                  />
                  {importSource && (
                    <div className="import-source-preview">
                      <Check size={14} />
                      <span>
                        {importSource.kind === 'playlist'
                          ? 'Playlist link · all available lectures will be imported'
                          : 'Single video link · add a playlist URL to import its lectures'}
                      </span>
                    </div>
                  )}
                  <label className="field-label">Reel length for this import</label>
                  <div className="duration-options">
                    {DURATIONS.map((n) => (
                      <button
                        type="button"
                        key={n}
                        onClick={() => changeDuration(n)}
                        className={importSeconds === n ? 'selected' : ''}
                      >
                        {n}
                        <span>seconds</span>
                        {n === 60 && <small>POPULAR</small>}
                      </button>
                    ))}
                  </div>
                  {error && (
                    <div className="form-error" role="alert">
                      {error}
                    </div>
                  )}
                  <button className="button primary full" disabled={busy} type="submit">
                    {busy ? (
                      <>
                        <LoaderCircle size={17} className="spin" /> Building your learning feed…
                      </>
                    ) : (
                      <>
                        Create my learning feed <ArrowRight size={18} />
                      </>
                    )}
                  </button>
                </form>
                <LocalImport
                  onBusy={setBusy}
                  onImported={(imported) => {
                    const candidate = { ...imported, reelSeconds: importSeconds };
                    setState((s) => ({ ...s, courses: [candidate, ...s.courses] }));
                    setCourseId(candidate.id);
                    setIndex(0);
                    setView('profile');
                    setModal(null);
                    setToast('Your video is ready.');
                  }}
                />
                <small className="modal-fineprint">
                  {androidDirect
                    ? 'Video parts stream directly to this device and use a limited temporary cache. Only save content you own or have permission to save.'
                    : 'Personal edition: videos download on first play and stay in your local cache. Only download content you own or have permission to save.'}
                </small>
              </>
            )}
            {modal === 'privacy' && (
              <>
                <span className="modal-symbol">
                  <BookOpen size={25} />
                </span>
                <h2 id="modal-title">Playback &amp; privacy</h2>
                <p className="privacy-intro">
                  Your learning stays on this device. Here’s how video playback works.
                </p>
                <div className="privacy-copy">
                  <section>
                    <h3>Your library is local</h3>
                    <p>
                      Your profile, progress, saved reels, notes and captured images are stored on
                      this device. There is no account or cloud sync. Export a backup in Settings
                      before clearing app data.
                    </p>
                  </section>
                  <section>
                    <h3>{androidDirect ? 'Videos stream to your phone' : 'How videos load'}</h3>
                    <p>
                      {androidDirect
                        ? 'The app requests video information and streams video parts directly from YouTube to your phone. Temporary parts use a limited cache and can be fetched again. New parts need internet. Imported MP4 files are stored separately.'
                        : deviceStreaming
                          ? 'Video parts stream on demand and use temporary storage. Depending on the website setup, requests may pass through its relay. New parts need internet.'
                          : 'Videos are prepared on the connected computer or server, then streamed to this device. New videos need internet.'}
                    </p>
                  </section>
                  <section>
                    <h3>Posts and messages</h3>
                    <p>
                      When creator updates are configured, Home checks for new posts online and
                      keeps a temporary copy for offline reading. The content host and media
                      providers receive normal network requests. Views are counted once per post
                      using a random installation ID. Public replies include your display name,
                      username and reply text. Private feedback and any reply contact you enter
                      go to Idraak and are retained for up to 90 days. Your learning history stays
                      on this device.
                    </p>
                  </section>
                  <section>
                    <h3>What this switch controls</h3>
                    <p>
                      It allows video playback in MicroGram. It is not an Android permission or a
                      YouTube sign-in. Turning it off stops playback; imports, video information and
                      thumbnails can still make network requests.
                    </p>
                  </section>
                  <p className="privacy-source-note">
                    Video information and thumbnails come from YouTube and Google. Streaming
                    availability depends on the source. Only save content you own or have permission
                    to save.
                  </p>
                </div>
                <div className="privacy-playback-state" role="status">
                  <span className={state.consent ? 'enabled' : ''} />
                  Playback is {state.consent ? 'enabled' : 'disabled'}
                </div>
                {state.consent ? (
                  <>
                    <button className="button primary full" onClick={() => setModal(null)}>
                      Done
                    </button>
                    <button
                      className="text-button full"
                      onClick={() => {
                        setState((s) => ({ ...s, consent: false }));
                        setPlaying(false);
                        pendingPlayback.current = false;
                        setModal(null);
                      }}
                    >
                      Disable playback
                    </button>
                  </>
                ) : (
                  <button
                    className="button primary full"
                    onClick={() => {
                      const resume = pendingPlayback.current;
                      pendingPlayback.current = false;
                      setState((s) => ({ ...s, consent: true }));
                      setModal(null);
                      if (resume) startPlayback();
                    }}
                  >
                    Enable playback <Play size={16} />
                  </button>
                )}
              </>
            )}
            {modal === 'delete' && (
              <>
                <span className="modal-symbol">
                  <Trash2 size={25} />
                </span>
                <h2 id="modal-title">Clear your learning space?</h2>
                <p>
                  This deletes your profile, library, notes, Screen Note images, saved reels, watch
                  history, reflections, activity, playback speeds, and preferences from this device.
                  Export a backup first if you want to keep them.
                </p>
                <label className="clear-download-choice">
                  <input
                    type="checkbox"
                    checked={clearServerDownloads}
                    disabled={busy}
                    onChange={(e) => setClearServerDownloads(e.target.checked)}
                  />
                  {deviceStreaming
                    ? 'Also clear temporary video parts on this device'
                    : 'Also clear eligible server downloads'}
                </label>
                <p className="reset-storage-note">
                  {deviceStreaming
                    ? 'Temporary video parts stay unless selected above. Imported video originals remain; delete them individually in Video storage. Exported backups outside the app are not deleted.'
                    : 'Server video files stay unless selected above. Shared/active files and uploaded originals stay protected. Exported backups outside the app are not deleted.'}
                </p>
                {error && (
                  <p className="form-error" role="alert">
                    {error}
                  </p>
                )}
                <button className="button secondary full" onClick={exportData}>
                  Export a backup
                </button>
                <button
                  className="button danger full"
                  disabled={busy}
                  onClick={() => void clearLearningSpace()}
                >
                  Permanently clear data
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
function PageHeading({ eyebrow, title, text }: { eyebrow: string; title: string; text: string }) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">
          <span />
          {eyebrow}
        </div>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
    </div>
  );
}
function Empty({
  title,
  text,
  action,
  actionLabel = 'Import from YouTube',
}: {
  title: string;
  text: string;
  action: () => void;
  actionLabel?: string;
}) {
  return (
    <section className="empty-state">
      <span className="modal-symbol">
        <Sparkles size={28} />
      </span>
      <h2>{title}</h2>
      <p>{text}</p>
      <button className="button primary" onClick={action}>
        {actionLabel}
        <ArrowRight size={17} />
      </button>
    </section>
  );
}
