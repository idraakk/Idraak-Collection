import { cachedScreenSource, screenImageSource } from './screenImageSources';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowLeft, Camera, Check, Clock3, ImageOff, Layers3, Search, Trash2 } from 'lucide-react';
import { clock, type Course } from './core';
import type { ScreenNote } from './storage';
import { screenNoteGroups } from './screenNotes';
import { ConfirmAction } from './ConfirmAction';
import { ScreenAlbumActions, ScreenNoteTile } from './ScreenImageActions';
import { SearchResults } from './SearchResults';

function useFrame(id: string, frame?: Blob) {
  const [result, setResult] = useState(() => ({ id, source: frame ? '' : cachedScreenSource(id) }));
  useEffect(() => {
    let active = true;
    let owned = '';
    const load = async () => {
      const source = frame ? (owned = URL.createObjectURL(frame)) : await screenImageSource(id);
      if (active) setResult({ id, source });
    };
    setResult({ id, source: frame ? '' : cachedScreenSource(id) });
    void load();
    const changed = (event: Event) => {
      const ids = (event as CustomEvent<string[] | undefined>).detail;
      if (!ids || ids.includes(id)) void load();
    };
    window.addEventListener('microgram-screen-images', changed);
    return () => {
      active = false;
      if (owned) URL.revokeObjectURL(owned);
      window.removeEventListener('microgram-screen-images', changed);
    };
  }, [id, frame]);
  return result.id === id ? result.source : '';
}
export function ScreenFrame({
  note,
  frame,
  onDimensions,
}: {
  note: ScreenNote;
  frame?: Blob;
  onDimensions?: (width: number, height: number) => void;
}) {
  const source = useFrame(note.id, frame);
  return source ? (
    <img
      src={source}
      draggable={false}
      onLoad={(e) => onDimensions?.(e.currentTarget.naturalWidth, e.currentTarget.naturalHeight)}
      alt={`Captured frame at ${clock(note.time)} from ${note.videoTitle}`}
    />
  ) : (
    <div className="screen-frame-missing">
      <ImageOff size={24} />
      <span>Frame unavailable</span>
    </div>
  );
}
export function ScreenNoteEditor({
  draft,
  frame,
  existing,
  busy,
  onSave,
  onDelete,
}: {
  draft: ScreenNote;
  frame?: Blob;
  existing: boolean;
  busy: boolean;
  onSave: (note: ScreenNote) => Promise<void>;
  onDelete: () => Promise<void>;
}) {
  const [label, setLabel] = useState(draft.label);
  const [note, setNote] = useState(draft.note);
  const [confirm, setConfirm] = useState(false);
  return (
    <form
      className="screen-note-editor"
      onSubmit={(e) => {
        e.preventDefault();
        void onSave({ ...draft, label: label.trim(), note });
      }}
    >
      <span className="utility-kicker">SCREEN NOTES</span>
      <h2 id="modal-title">{existing ? 'Your captured moment' : 'Keep this moment'}</h2>
      <div className="screen-editor-meta">
        <Clock3 size={14} />
        <span>{clock(draft.time)}</span>
        <span>{draft.videoTitle}</span>
      </div>
      <div className="screen-note-full-frame">
        <ScreenFrame note={draft} frame={frame} />
      </div>
      <label htmlFor="screen-note-label">
        Label <span>optional</span>
      </label>
      <input
        id="screen-note-label"
        value={label}
        maxLength={120}
        onChange={(e) => setLabel(e.target.value)}
        placeholder="e.g. The formula I want to remember"
      />
      <label htmlFor="screen-note-text">
        Note <span>optional</span>
      </label>
      <textarea
        id="screen-note-text"
        value={note}
        maxLength={5000}
        rows={3}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Why is this moment useful?"
      />
      <div className="screen-editor-actions">
        {existing && (
          <button
            type="button"
            className="screen-delete"
            aria-label="Delete screen note"
            disabled={busy}
            onClick={() => setConfirm(true)}
          >
            <Trash2 size={19} />
          </button>
        )}
        <button className="button primary" type="submit" disabled={busy}>
          {busy ? 'Saving…' : existing ? 'Save changes' : 'Save screen note'} <Check size={17} />
        </button>
      </div>
      {confirm && (
        <ConfirmAction
          title="Delete this Screen Note?"
          description="This removes the captured image, label and note from this device. Your lecture and other notes stay saved."
          action="Delete screen note"
          onClose={() => setConfirm(false)}
          onConfirm={onDelete}
        />
      )}
    </form>
  );
}
export function ScreenNotes({
  courses,
  notes,
  selectedVideo,
  onSelect,
  onOpen,
  onDeleteAlbum,
  onDeletePhoto,
  onPlay,
}: {
  courses: Course[];
  notes: ScreenNote[];
  selectedVideo: string | null;
  onSelect: (video: string | null) => void;
  onOpen: (note: ScreenNote) => void;
  onDeleteAlbum: (videoId: string) => Promise<void>;
  onDeletePhoto: (id: string) => Promise<void>;
  onPlay: (note: ScreenNote) => void;
}) {
  const [query, setQuery] = useState('');
  const [albumQuery, setAlbumQuery] = useState('');
  const [albumSearch, setAlbumSearch] = useState(false);
  const searchInput = useRef<HTMLInputElement>(null);
  useLayoutEffect(() => {
    setAlbumSearch(false);
    setAlbumQuery('');
  }, [selectedVideo]);
  useLayoutEffect(() => {
    if (albumSearch) searchInput.current?.focus({ preventScroll: true });
  }, [albumSearch]);
  const [playlist, setPlaylist] = useState<string | null>(null);
  const openAlbum = onSelect;
  const playlists = [
    ...new Map(notes.filter((n) => n.playlist).map((n) => [n.courseId, n.courseTitle])).entries(),
  ];
  const filtered = notes.filter(
    (n) =>
      (!playlist || n.courseId === playlist) &&
      `${n.label} ${n.note} ${n.videoTitle} ${n.courseTitle} ${n.channel}`
        .toLowerCase()
        .includes(query.trim().toLowerCase()),
  );
  const groups = screenNoteGroups(filtered);
  const selected = selectedVideo ? notes.find((n) => n.videoId === selectedVideo) : undefined;
  const albumNotes = notes
    .filter((n) => n.videoId === selectedVideo)
    .sort((a, b) => a.time - b.time || a.createdAt - b.createdAt || a.id.localeCompare(b.id));
  const serials = new Map(albumNotes.map((note, index) => [note.id, index + 1]));
  const albumResults = albumNotes.filter((n) =>
    `${n.label} ${n.note}`.toLowerCase().includes(albumQuery.trim().toLowerCase()),
  );
  const cover = courses.flatMap((c) => c.videos).find((v) => v.id === selectedVideo);
  return (
    <div
      id="saved-screen-panel"
      role="tabpanel"
      aria-labelledby={selectedVideo ? undefined : 'saved-screen-tab'}
      aria-label={
        selectedVideo ? `${selected?.videoTitle ?? 'Lecture'} Screen Notes album` : undefined
      }
      className="screen-notes-collection"
    >
      {!!notes.length && !selectedVideo && (
        <>
          <label className="screen-notes-search">
            <Search size={17} />
            <input
              aria-label="Search screen notes"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Find a label, idea or lecture"
            />
          </label>
          {!!playlists.length && (
            <div className="screen-playlists" aria-label="Filter Screen Notes by playlist">
              <button aria-pressed={!playlist} onClick={() => setPlaylist(null)}>
                All lectures
              </button>
              {playlists.map(([id, title]) => (
                <button
                  key={id}
                  aria-pressed={playlist === id}
                  onClick={() => {
                    setPlaylist(id);
                    onSelect(null);
                  }}
                >
                  <Layers3 size={13} />
                  {title}
                </button>
              ))}
            </div>
          )}
        </>
      )}
      {selectedVideo ? (
        <div className="screen-album-page">
          <header className="screen-album-library-heading">
            <button aria-label="Back to Screen Notes lectures" onClick={() => onSelect(null)}>
              <ArrowLeft size={22} />
            </button>
            <h1>Screen Notes Library</h1>
            <button
              aria-label={albumSearch ? 'Close album search' : 'Search this album'}
              aria-expanded={albumSearch}
              aria-controls="screen-album-search"
              onClick={() => {
                setAlbumSearch((v) => !v);
                setAlbumQuery('');
              }}
            >
              <Search size={21} />
            </button>
          </header>
          <div className="screen-collection-heading">
            <div className="screen-album-avatar" aria-hidden="true">
              {cover ? (
                <img
                  src={cover.thumbnail}
                  alt=""
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = '/local-cover.svg';
                  }}
                />
              ) : (
                selected && <ScreenFrame note={selected} />
              )}
            </div>
            <div className="screen-album-heading-copy">
              <h2>{selected?.videoTitle ?? 'Lecture captures'}</h2>
              <span>
                {albumNotes.length} frames · {selected?.channel}
              </span>
            </div>
          </div>
          <div
            id="screen-album-search"
            className={`album-search-panel${albumSearch ? ' is-open' : ''}`}
            aria-hidden={!albumSearch}
            inert={!albumSearch}
          >
            <div className="album-search-inner">
              <label className="screen-notes-search">
                <Search size={17} />
                <input
                  ref={searchInput}
                  aria-label="Search this album's photos"
                  placeholder="Search labels and notes"
                  value={albumQuery}
                  onChange={(e) => setAlbumQuery(e.target.value)}
                />
              </label>
            </div>
          </div>
          <SearchResults query={albumQuery}>
            <div className="screen-note-grid">
              {albumResults.map((note) => (
                <ScreenNoteTile
                  key={note.id}
                  note={note}
                  onOpen={() => onOpen(note)}
                  onDelete={onDeletePhoto}
                  onPlay={() => onPlay(note)}
                >
                  <div className="screen-card-frame">
                    <ScreenFrame note={note} />
                    <span>{clock(note.time)}</span>
                  </div>
                  <div className="screen-card-copy">
                    <h3>
                      <span className="screen-photo-number">{serials.get(note.id)}.</span>{' '}
                      {note.label || `Frame at ${clock(note.time)}`}
                    </h3>
                    {note.note && <p>{note.note}</p>}
                  </div>
                </ScreenNoteTile>
              ))}
            </div>
            {!albumResults.length && (
              <p className="screen-no-results">No captures match your search.</p>
            )}
          </SearchResults>
        </div>
      ) : (
        <SearchResults query={query}>
          <div className="screen-lecture-grid">
            {groups.map(({ videoId, items }) => (
              <article key={videoId} className="screen-lecture-card">
                <button
                  className="screen-album-cover-button"
                  aria-label={`Open ${items[0].videoTitle} Screen Notes album`}
                  onClick={() => openAlbum(videoId)}
                >
                  <div className="screen-lecture-cover screen-album-cover">
                    <div className="screen-album-stack" aria-hidden="true">
                      {Array.from({ length: 3 }, (_, i) => items[Math.min(i, items.length - 1)])
                        .reverse()
                        .map((note, i, photos) => (
                          <div
                            className="screen-album-photo"
                            key={`${note.id}-${i}`}
                            style={
                              { '--album-depth': photos.length - i - 1 } as React.CSSProperties
                            }
                          >
                            <ScreenFrame note={note} />
                          </div>
                        ))}
                    </div>
                    <span>
                      <Camera size={14} />
                      {items.length}
                    </span>
                  </div>
                </button>
                <div className="screen-album-info">
                  <div className="screen-album-title">
                    <h2>{items[0].videoTitle}</h2>
                    <p>
                      {items.length} {items.length === 1 ? 'capture' : 'captures'} ·{' '}
                      {items[0].channel}
                    </p>
                    {items[0].playlist && (
                      <small>
                        <Layers3 size={12} />
                        {items[0].courseTitle}
                      </small>
                    )}
                  </div>
                  <ScreenAlbumActions
                    notes={notes.filter((n) => n.videoId === videoId)}
                    onDelete={onDeleteAlbum}
                  />
                </div>
              </article>
            ))}
          </div>
          {!!notes.length && !groups.length && (
            <p className="screen-no-results">No Screen Notes match your search.</p>
          )}
        </SearchResults>
      )}
      {!notes.length && (
        <div className="saved-empty">
          <Camera size={30} />
          <h2>Keep the frame that makes it click</h2>
          <p>
            Pause a reel and tap the camera. Your captures, labels and ideas will be grouped by
            lecture here.
          </p>
        </div>
      )}
    </div>
  );
}
