import { useRef, useState } from 'react';
import { Check, ChevronDown } from 'lucide-react';
import { useDismissibleMenu } from './dismissibleMenu';
const durationLabel = (minutes: number) =>
  minutes >= 60 && minutes % 60 === 0
    ? `${minutes / 60} ${minutes === 60 ? 'hour' : 'hours'}`
    : `${minutes} minutes`;
export function ChoiceMenu({
  label,
  value,
  choices,
  onChange,
  formatLabel = durationLabel,
}: {
  formatLabel?: (value: number) => string;
  label: string;
  value: number;
  choices: number[];
  onChange: (value: number) => void;
}) {
  const [open, setOpen] = useState(false);
  const host = useRef<HTMLDivElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  useDismissibleMenu(open, menu, () => {
    setOpen(false);
    host.current
      ?.querySelector<HTMLButtonElement>('.choice-trigger')
      ?.focus({ preventScroll: true });
  });
  return (
    <div
      className="choice-menu"
      ref={host}
      onKeyDown={(e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          setOpen(false);
          host.current?.querySelector<HTMLButtonElement>('.choice-trigger')?.focus();
        }
        if (e.key === 'Tab') setOpen(false);
        if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) {
          e.preventDefault();
          const focusOption = () => {
            const options = Array.from(
              host.current?.querySelectorAll<HTMLButtonElement>('[role=menuitemradio]') ?? [],
            );
            const current = options.indexOf(document.activeElement as HTMLButtonElement);
            const next =
              e.key === 'Home'
                ? 0
                : e.key === 'End'
                  ? options.length - 1
                  : current < 0
                    ? Math.max(0, choices.indexOf(value))
                    : (current + (e.key === 'ArrowUp' ? -1 : 1) + options.length) % options.length;
            options[next]?.focus();
          };
          if (!open) {
            setOpen(true);
            requestAnimationFrame(focusOption);
          } else focusOption();
        }
      }}
    >
      <button
        className="choice-trigger"
        aria-label={label}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        {formatLabel(value)}
        <ChevronDown size={15} />
      </button>
      {open && (
        <div ref={menu} className="choice-options" role="menu" aria-label={label}>
          {choices.map((n) => (
            <button
              key={n}
              role="menuitemradio"
              aria-checked={n === value}
              onClick={() => {
                onChange(n);
                setOpen(false);
                host.current?.querySelector<HTMLButtonElement>('.choice-trigger')?.focus();
              }}
            >
              {formatLabel(n)}
              {n === value && <Check size={14} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
