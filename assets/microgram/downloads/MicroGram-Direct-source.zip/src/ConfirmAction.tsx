import { useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Trash2 } from 'lucide-react';
export function ConfirmAction({
  title,
  description,
  action,
  onConfirm,
  onClose,
}: {
  title: string;
  description: string;
  action: string;
  onConfirm: () => Promise<void>;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useLayoutEffect(() => {
    dialog.current?.showModal();
    window.dispatchEvent(new CustomEvent('microgram-confirmation', { detail: true }));
    return () => {
      window.dispatchEvent(new CustomEvent('microgram-confirmation', { detail: false }));
    };
  }, []);
  return createPortal(
    <dialog
      ref={dialog}
      className="confirm-dialog"
      data-busy={busy}
      aria-labelledby="confirm-title"
      onCancel={(e) => {
        if (busy) e.preventDefault();
      }}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget && !busy) dialog.current?.close();
      }}
    >
      <div className="confirm-content">
        <span className="confirm-symbol">
          <Trash2 size={23} />
        </span>
        <h2 id="confirm-title">{title}</h2>
        <p>{description}</p>
        {error && <p role="alert">{error}</p>}
        <div className="confirm-actions">
          <button autoFocus disabled={busy} onClick={() => dialog.current?.close()}>
            Cancel
          </button>
          <button
            className="confirm-primary"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              setError('');
              try {
                await onConfirm();
                onClose();
              } catch (e) {
                setError(e instanceof Error ? e.message : 'Please try again.');
              } finally {
                setBusy(false);
              }
            }}
          >
            {busy ? 'Working…' : action}
          </button>
        </div>
      </div>
    </dialog>,
    document.body,
  );
}
