import { useEffect, useMemo, useState } from 'react';
import { primeVideo } from './reelOpenings';
import {
  ArrowLeft,
  ArrowUpRight,
  Bookmark,
  Check,
  Clapperboard,
  ChevronDown,
  Play,
} from 'lucide-react';
import { clock, complete, segments, watched, type Course, type Progress } from './core';
import { OrientedThumbnail } from './OrientedThumbnail';

export function CourseProfile({
  course,
  seconds,
  progress,
  saved,
  last,
  onBack,
  onPlay,
  selectedLecture,
  onLectureChange,
  backLabel = 'Back to library',
}: {
  course: Course;
  seconds: number;
  progress: Progress;
  saved: string[];
  last: number;
  onBack: () => void;
  onPlay: (index: number) => void;
  selectedLecture: string;
  onLectureChange: (lectureId: string) => void;
  backLabel?: string;
}) {
  const selectedIndex = course.videos.findIndex((v) => v.id === selectedLecture);
  const filter = selectedIndex < 0 ? 'all' : String(selectedIndex);
  useEffect(() => {
    const video = course.videos[Math.max(0, selectedIndex)];
    if (video) primeVideo(video, course.reelSeconds ?? seconds);
  }, [course.id, selectedLecture, seconds]);
  const [limit, setLimit] = useState(60);
  const reels = useMemo(() => segments(course, seconds), [course, seconds]);
  const completed = useMemo(
    () => new Set(reels.filter((r) => complete(r, progress)).map((r) => r.id)),
    [reels, progress],
  );
  const savedIds = useMemo(() => new Set(saved), [saved]);
  const indexed = reels.map((reel, index) => ({ reel, index }));
  const filtered =
    filter === 'all' ? indexed : indexed.filter(({ reel }) => reel.videoIndex === Number(filter));
  const next = Math.max(
    0,
    reels.findIndex((r) => !completed.has(r.id)),
  );
  const resume = Math.min(last, reels.length - 1);
  const percent = Math.round((completed.size / reels.length) * 100);
  const source =
    course.sample || course.id === course.videos[0].id
      ? `https://www.youtube.com/watch?v=${course.videos[0].id}`
      : `https://www.youtube.com/playlist?list=${course.id}`;
  return (
    <section className="course-profile" aria-label={`${course.title} learning profile`}>
      <div className="profile-topline">
        <button onClick={onBack} aria-label={backLabel}>
          <ArrowLeft size={22} />
        </button>
        <Clapperboard size={18} />
      </div>
      <header className="course-profile-header">
        <div className="course-avatar-ring">
          <div className="course-avatar">
            <img
              src={course.videos[0].thumbnail}
              alt=""
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = '/local-cover.svg';
              }}
            />
          </div>
        </div>
        <div className="course-profile-details">
          <div className="profile-channel">
            {course.channel} <span>{course.videos[0].local ? 'on your server' : 'on YouTube'}</span>
          </div>
          <h1>{course.title}</h1>
          <div className="profile-stats">
            <span>
              <strong>{reels.length.toLocaleString()}</strong> reels
            </span>
            <span>
              <strong>{course.videos.length.toLocaleString()}</strong>{' '}
              {course.videos.length === 1 ? 'lecture' : 'lectures'}
            </span>
            <span>
              <strong>{completed.size.toLocaleString()}</strong> completed
            </span>
          </div>
          {!course.videos[0].local && (
            <a className="profile-source" href={source} target="_blank" rel="noreferrer">
              Original {course.videos.length === 1 ? 'lecture' : 'playlist'} on{' '}
              <span className="youtube-link-label">YouTube</span> <ArrowUpRight size={13} />
            </a>
          )}
        </div>
      </header>
      <div className="profile-actions">
        <button className="button primary" onClick={() => onPlay(resume)}>
          <Play size={15} />
          {last > 0 ? 'Continue learning' : 'Start learning'}
        </button>
        <button className="button secondary" onClick={() => onPlay(next)}>
          {completed.size === reels.length ? 'Watch again' : 'Next unwatched'}
          <ArrowUpRight size={15} />
        </button>
      </div>
      <div className="profile-completion">
        <span>
          {percent}% complete <i>·</i> {seconds}-second reels
        </span>
        <div className="progress-bar">
          <i style={{ width: `${percent}%` }} />
        </div>
        <strong>
          {completed.size} / {reels.length}
        </strong>
      </div>
      <div className="profile-grid-toolbar">
        <span className="profile-grid-tab">
          <Clapperboard size={17} /> REELS
        </span>
        <details
          className="lecture-picker"
          onKeyDown={(e) => {
            if (e.key === 'Escape') e.currentTarget.open = false;
          }}
        >
          <summary aria-label="Filter reels by lecture">
            {filter === 'all' ? 'All lectures' : `Lecture ${Number(filter) + 1}`}
            <ChevronDown size={14} />
          </summary>
          <div className="lecture-picker-menu" role="group" aria-label="Lectures">
            {[
              { value: 'all', title: 'All lectures' },
              ...course.videos.map((v, index) => ({ value: String(index), title: v.title })),
            ].map((item) => (
              <button
                key={item.value}
                aria-pressed={filter === item.value}
                onClick={(e) => {
                  onLectureChange(
                    item.value === 'all' ? 'all' : course.videos[Number(item.value)].id,
                  );
                  setLimit(60);
                  e.currentTarget.closest('details')!.open = false;
                }}
              >
                <span>
                  {item.value === 'all' ? 'All' : String(Number(item.value) + 1).padStart(2, '0')}
                </span>
                <strong>{item.title}</strong>
                {filter === item.value && <Check size={14} />}
              </button>
            ))}
          </div>
        </details>
      </div>
      <div className="profile-reel-grid">
        {filtered.slice(0, limit).map(({ reel, index }) => {
          const done = completed.has(reel.id);
          return (
            <button
              className={`profile-reel-tile ${done ? 'watched' : ''}`}
              key={reel.id}
              onClick={() => onPlay(index)}
              aria-label={`Play reel ${index + 1}: ${reel.video.title}, ${clock(reel.start)} to ${clock(reel.end)}${done ? ', completed' : ''}`}
            >
              <div className="tile-top">
                <span>{String(index + 1).padStart(2, '0')}</span>
                <span>
                  {done ? (
                    <>
                      <Check size={13} />
                      <small>Watched</small>
                    </>
                  ) : savedIds.has(reel.id) ? (
                    <Bookmark size={15} fill="currentColor" />
                  ) : null}
                </span>
              </div>
              <OrientedThumbnail video={reel.video} time={reel.start} upgrade={reel} />
              <div className="tile-details">
                <strong>{reel.video.title}</strong>
                <div className="tile-meta-line">
                  <span className="tile-lecture">
                    L{String(reel.videoIndex + 1).padStart(2, '0')}
                  </span>
                  <span className="tile-time">
                    {clock(reel.start)}–{clock(reel.end)}
                  </span>
                </div>
              </div>
              <span
                className="tile-watch-progress"
                role="progressbar"
                aria-label={`Reel ${index + 1} watched coverage`}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(Math.min(1, watched(reel, progress)) * 100)}
              >
                <i style={{ width: `${Math.min(1, watched(reel, progress)) * 100}%` }} />
              </span>
            </button>
          );
        })}
      </div>
      {filtered.length > limit && (
        <button className="button secondary load-reels" onClick={() => setLimit((n) => n + 60)}>
          Show more reels{' '}
          <span>
            ({Math.min(limit, filtered.length)} of {filtered.length})
          </span>
        </button>
      )}
    </section>
  );
}
