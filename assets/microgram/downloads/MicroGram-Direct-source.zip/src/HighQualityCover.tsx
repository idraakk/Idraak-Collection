import { useState } from 'react';
import { coverSources } from './coverSources';
import { cachedCover } from './coverWarmup';
export { coverSources } from './coverSources';
export function HighQualityCover({ videoId, fallback }: { videoId?: string; fallback: string }) {
  const sources = coverSources(videoId, fallback);
  const [attempt, setAttempt] = useState({ source: '', index: 0 });
  const index =
    attempt.source === sources[0]
      ? attempt.index
      : Math.max(0, sources.indexOf(cachedCover(sources[0]) ?? sources[0]));
  const next = () => setAttempt({ source: sources[0], index: index + 1 });
  return (
    <img
      src={sources[Math.min(index, sources.length - 1)]}
      alt=""
      loading="lazy"
      onLoad={(event) => {
        // YouTube can return a tiny placeholder with HTTP 200 for unavailable covers.
        if (event.currentTarget.naturalWidth <= 120 && index < sources.length - 1) next();
      }}
      onError={(event) => {
        if (index < sources.length - 1) next();
        else {
          event.currentTarget.onerror = null;
          event.currentTarget.src = '/local-cover.svg';
        }
      }}
    />
  );
}
