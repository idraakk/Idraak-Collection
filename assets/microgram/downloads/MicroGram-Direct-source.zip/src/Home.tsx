import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowUpRight, Play, Plus, Settings2, Target } from 'lucide-react';
import { ChoiceMenu } from './ChoiceMenu';
import { ActivityHeatmap } from './LearningHeatmap';
import { localDate, type State } from './storage';
import { Community } from './community/Community';
import type { CommunityPost } from './community/schema';
function HomePost({
  children,
  topic,
  profile,
  learner = false,
  verified = false,
}: {
  children: ReactNode;
  topic: string;
  profile?: State['profile'];
  learner?: boolean;
  verified?: boolean;
}) {
  const name = learner ? profile?.name?.trim() || 'User' : 'Idraak';
  const username = learner ? profile?.username?.trim() : 'idraakk';
  return (
    <article className="home-post" aria-label={`${name} · ${topic}`}>
      <header className="home-post-author">
        <img
          src={learner ? profile?.photo || '/avatar-placeholder.svg' : '/icon.svg'}
          alt={name}
          width="40"
          height="40"
        />
        <div>
          <strong>
            {name}
            {verified && (
              <svg
                className="creator-badge"
                width="15"
                height="15"
                viewBox="0 0 24 24"
                role="img"
                aria-label="MicroGram creator"
              >
                <path
                  fill="#0095f6"
                  d="M12 0 15 2.2 18.6 1.6 20 5.1 23.4 6.6 22.8 10.2 24 12 21.8 15 22.4 18.6 18.9 20 17.4 23.4 13.8 22.8 12 24 9 21.8 5.4 22.4 4 18.9 .6 17.4 1.2 13.8 0 12 2.2 9 1.6 5.4 5.1 4 6.6 .6 10.2 1.2Z"
                />
                <path
                  d="m6.5 12 3.5 3.5 7.5-7.5"
                  fill="none"
                  stroke="#080808"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}
          </strong>
          <span>
            {username ? '@' + username + (topic ? ' · ' : '') : ''}
            {topic}
          </span>
        </div>
      </header>
      <div className="home-post-content">{children}</div>
    </article>
  );
}
export function Home({
  state,
  progressFirst,
  onStart,
  onImport,
  onSettings,
  onPrivacy,
  onGoal,
  onOpenReplies,
}: {
  state: State;
  progressFirst: boolean;
  onStart: () => void;
  onImport: () => void;
  onSettings: () => void;
  onPrivacy: () => void;
  onGoal: (goal: number) => void;
  onOpenReplies: (post: CommunityPost, enabled: boolean) => void;
}) {
  const date = localDate();
  const hasLectures = state.courses.length > 0;
  const progressPosts = (
    <>
      <HomePost topic="Your daily goal" profile={state.profile} learner>
        <section className="home-daily-goal" aria-label="Daily learning goal">
          <div className="home-goal-heading">
            <div>
              <Target size={20} />
              <h2>Daily learning goal</h2>
            </div>
            <ChoiceMenu
              label="Daily learning goal"
              value={state.goal}
              choices={[5, 10, 15, 20, 30, 60, 120, 180, 240, 300, 360]}
              onChange={onGoal}
            />
          </div>
          <div className="home-goal-caption">
            <span>Today</span>
            <span>
              <strong>{Math.floor((state.activity[date] ?? 0) / 60)}</strong> / {state.goal} min
            </span>
          </div>
          <div
            className="home-goal-track"
            role="progressbar"
            aria-label="Today's daily learning goal"
            aria-valuemin={0}
            aria-valuemax={state.goal}
            aria-valuenow={Math.min(state.goal, Math.floor((state.activity[date] ?? 0) / 60))}
          >
            <i
              style={{
                width: `${Math.min(100, ((state.activity[date] ?? 0) / (state.goal * 60)) * 100)}%`,
              }}
            />
          </div>
        </section>
      </HomePost>
      <HomePost topic="Your learning year" profile={state.profile} learner>
        <ActivityHeatmap activity={state.activity} goal={state.goal} />
      </HomePost>
    </>
  );
  return (
    <section className="today-home home-feed" aria-label="Today">
      <header className="today-header">
        <div>
          <span className="today-wordmark">
            microgram<span>.</span>
          </span>

          <p>
            {new Date().toLocaleDateString(undefined, {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>
        <button
          className="utility-icon today-settings"
          aria-label="Open your settings"
          onClick={onSettings}
        >
          <Settings2 size={22} />
        </button>
      </header>
      <div className="today-intro">
        <h1>
          Hello
          {state.profile?.name ? (
            <>
              , <em>{state.profile.name}.</em>
            </>
          ) : (
            '.'
          )}
        </h1>
        <p>Your lectures, one reel at a time.</p>
      </div>
      <Community
        Post={HomePost}
        progress={progressPosts}
        progressFirst={progressFirst}
        onOpenReplies={onOpenReplies}
        onStart={hasLectures ? onStart : onImport}
        hasLectures={hasLectures}
        renderFooter={(feedback) => (
          <HomeFooter>
            <span>
              <em>Made by Idraak</em>
            </span>
            <div className="home-footer-links">
              <nav aria-label="Find Idraak">
                {feedback}
                <a
                  href="https://www.linkedin.com/in/idraak/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  LinkedIn <ArrowUpRight size={14} />
                </a>
                <a
                  href="https://www.instagram.com/idraakk/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Instagram <ArrowUpRight size={14} />
                </a>
              </nav>
              <button className="home-footer-privacy" onClick={onPrivacy}>
                Privacy &amp; terms
              </button>
            </div>
          </HomeFooter>
        )}
      />
    </section>
  );
}

function HomeFooter({ children }: { children: ReactNode }) {
  const slot = useRef<HTMLDivElement>(null);
  const dock = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const placeholder = slot.current;
    const bar = dock.current;
    if (!placeholder || !bar) return;

    const resize = new ResizeObserver(() => {
      placeholder.style.minHeight = bar.offsetHeight + 'px';
    });
    resize.observe(bar);

    // The reserved space comes into view as the last post clears the footer.
    const reveal = new IntersectionObserver(
      ([entry]) => {
        setVisible(entry.isIntersecting && entry.intersectionRatio >= 0.9);
      },
      { threshold: 0.9 },
    );
    reveal.observe(placeholder);

    return () => {
      resize.disconnect();
      reveal.disconnect();
    };
  }, []);

  return (
    <div ref={slot} className="home-footer-slot">
      <div ref={dock} className="home-footer-bar" data-visible={visible} inert={!visible}>
        <footer className="home-social-footer">{children}</footer>
      </div>
    </div>
  );
}
