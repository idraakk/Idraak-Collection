import { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { activityYear } from './activityHeatmap';
export function ActivityHeatmap({
  activity,
  goal,
}: {
  activity: Record<string, number>;
  goal: number;
}) {
  const data = useMemo(() => activityYear(activity, goal), [activity, goal]);
  const [selected, setSelected] = useState<string | null>(null);
  const viewport = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    if (viewport.current) viewport.current.scrollLeft = viewport.current.scrollWidth;
  }, []);
  const day = data.days.find((d) => d.key === selected && d.inRange);
  return (
    <section className="home-heatmap" aria-label="Your learning activity">
      <div className="heatmap-heading">
        <div>
          <span className="today-kicker">A LITTLE, OFTEN</span>
          <h2>Your learning year</h2>
        </div>
        <div className="heatmap-summary">
          <span>
            {data.active} active {data.active === 1 ? 'day' : 'days'}
          </span>
          <span className="heatmap-goal">{goal} min daily goal</span>
        </div>
      </div>
      <div className="heatmap-body">
        <div className="heatmap-weekdays">
          <span>Mon</span>
          <span>Wed</span>
          <span>Fri</span>
        </div>
        <div className="heatmap-viewport" ref={viewport}>
          <div className="heatmap-months">
            {data.days
              .filter((_, i) => i % 7 === 0)
              .map((d, i) => (
                <span key={d.key}>
                  {i === 0 || d.date.getDate() <= 7
                    ? d.date.toLocaleDateString(undefined, { month: 'short' })
                    : ''}
                </span>
              ))}
          </div>
          <div className="heatmap-cells">
            {data.days.map((d) => (
              <button
                key={d.key}
                disabled={!d.inRange}
                data-level={d.level}
                aria-pressed={selected === d.key}
                aria-label={`${d.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}: ${Math.floor(d.seconds / 60)} video minutes`}
                title={`${d.key}: ${Math.floor(d.seconds / 60)} video minutes`}
                onClick={() => setSelected(d.key)}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="heatmap-footer">
        <span>
          {day
            ? `${day.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · ${Math.floor(day.seconds / 60)} video minutes`
            : 'Last 365 days · tap a day to explore'}
        </span>
        <span className="heatmap-legend">
          Less
          {[0, 1, 2, 3, 4].map((level) => (
            <i key={level} data-level={level} />
          ))}
          More
        </span>
      </div>
    </section>
  );
}
