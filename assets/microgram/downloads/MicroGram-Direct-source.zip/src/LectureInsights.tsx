import { useEffect, useId, useMemo, useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { clock } from './core';
import { courseInsights, type learningInsights } from './insights';
import type { State } from './storage';

type Summary = ReturnType<typeof learningInsights>['courses'][number];
const minutes = (seconds: number) =>
  seconds > 0 && seconds < 60 ? '<1' : Math.floor(seconds / 60).toLocaleString();

function LectureDetails({ state, item, days }: { state: State; item: Summary; days: number }) {
  const data = useMemo(() => courseInsights(state, item.course, days), [state, item.course, days]);
  const [showAll, setShowAll] = useState(false);
  const max = Math.max(60, ...data.dates.map((d) => d.seconds));
  const isPlaylist = item.course.kind === 'playlist' || data.videos.length > 1;
  return (
    <div className="lecture-detail">
      <div className="lecture-detail-metrics">
        <div>
          <strong>
            {minutes(data.viewed)}
            <small> min</small>
          </strong>
          <span>Covered</span>
        </div>
        <div>
          <strong>
            {minutes(data.remaining)}
            <small> min</small>
          </strong>
          <span>Remaining</span>
        </div>
        <div>
          <strong>
            {data.completed}
            <small> / {data.reels}</small>
          </strong>
          <span>Reels completed</span>
        </div>
      </div>
      <div className="lecture-chart-heading">
        <h4>Daily viewing</h4>
        <span>
          {days} days · {minutes(data.periodSeconds)} min played
        </span>
      </div>
      <div
        className={`rhythm-chart lecture-daily-chart${days === 30 ? ' month' : ''}`}
        role="img"
        aria-label={`${item.course.title} daily viewing: ${data.dates.map((d) => `${d.key}: ${Math.round(d.seconds)} seconds`).join(', ')}`}
      >
        {data.dates.map((d, i) => (
          <div key={d.key} title={`${d.key}: ${minutes(d.seconds)} min played`}>
            <span>{days <= 7 ? minutes(d.seconds) : ''}</span>
            <div className="rhythm-track">
              <i style={{ height: `${d.seconds ? Math.max(3, (d.seconds / max) * 100) : 0}%` }} />
            </div>
            <small>{days <= 7 ? d.label : i % 5 === 0 ? d.key.slice(-2) : ''}</small>
          </div>
        ))}
      </div>
      <p className="lecture-history-caption">
        {data.periodSeconds > 0
          ? 'Video time played, including replays.'
          : data.tracked
            ? 'No viewing in this period.'
            : 'Daily history starts with your next watch.'}
      </p>
      {!isPlaylist ? (
        <>
          <div className="lecture-chart-heading">
            <h4>Where you’ve watched</h4>
            <span>All-time coverage</span>
          </div>
          <div
            className="lecture-timeline"
            role="img"
            aria-label={`Watched coverage: ${data.timeline.map((b) => `${clock(b.start)}–${clock(b.end)}: ${b.percent}%`).join(', ')}`}
          >
            {data.timeline.map((bin) => (
              <div
                key={bin.start}
                title={`${clock(bin.start)}–${clock(bin.end)} · ${bin.percent}% covered`}
              >
                <i style={{ height: `${bin.percent}%` }} />
              </div>
            ))}
          </div>
          <div className="lecture-chart-caption">
            <span>0:00</span>
            <span>{clock(data.total)}</span>
          </div>
        </>
      ) : (
        <>
          <div className="lecture-chart-heading">
            <h4>Where you’ve watched</h4>
            <span>By lecture · all time</span>
          </div>
          <div
            className="playlist-timeline-viewport"
            tabIndex={0}
            role="region"
            aria-label="Playlist coverage by lecture number"
          >
            <div
              className="playlist-numbered-timeline"
              role="img"
              aria-label={`Watched playlist coverage: ${data.videos.map((v, i) => `Lecture ${i + 1}: ${v.percent}%`).join(', ')}`}
              style={{
                gridTemplateColumns: `repeat(${data.videos.length}, minmax(24px, 1fr))`,
                minWidth: `${data.videos.length * 30 - 6}px`,
              }}
            >
              {data.videos.map(({ video, percent }, i) => (
                <div
                  key={video.id}
                  title={`Lecture ${i + 1} · ${video.title} · ${percent}% covered`}
                >
                  <div className="playlist-numbered-track">
                    <i style={{ height: `${percent}%` }} />
                  </div>
                  <span>{String(i + 1).padStart(2, '0')}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="lecture-chart-caption playlist-timeline-caption">
            <span>Lecture number</span>
            <span>Pink = watched</span>
          </div>
          <div className="lecture-chart-heading">
            <h4>Lecture coverage</h4>
            <span>{data.videos.length} lectures · all time</span>
          </div>
          <div className="playlist-coverage-list">
            {(showAll ? data.videos : data.videos.slice(0, 8)).map(
              ({ video, viewed, percent }, i) => (
                <div key={video.id} className="playlist-coverage-row">
                  <span className="coverage-row-number">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <div className="coverage-row-heading">
                      <span>{video.title}</span>
                      <strong>{percent}%</strong>
                    </div>
                    <div className="insight-progress">
                      <i style={{ width: `${percent}%` }} />
                    </div>
                    <small>
                      {minutes(viewed)} of {minutes(video.duration)} min covered
                    </small>
                  </div>
                </div>
              ),
            )}
          </div>
          {data.videos.length > 8 && (
            <button className="lecture-show-all" onClick={() => setShowAll((v) => !v)}>
              {showAll ? 'Show fewer lectures' : `Show all ${data.videos.length} lectures`}
            </button>
          )}
        </>
      )}
    </div>
  );
}

export function LectureInsightRow({
  state,
  item,
  days,
  open,
  onToggle,
}: {
  state: State;
  item: Summary;
  days: number;
  open: boolean;
  onToggle: () => void;
}) {
  const [visited, setVisited] = useState(false);
  useEffect(() => {
    if (open) setVisited(true);
  }, [open]);
  const id = useId();
  return (
    <article className={`lecture-insight-card${open ? ' is-open' : ''}`}>
      <button
        className="lecture-insight-toggle"
        aria-label={`View insights for ${item.course.title}`}
        aria-expanded={open}
        aria-controls={id}
        onClick={() => {
          setVisited(true);
          onToggle();
        }}
      >
        <img
          src={item.course.videos[0].thumbnail}
          alt=""
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = '/local-cover.svg';
          }}
        />
        <div>
          <h3>{item.course.title}</h3>
          <p>
            {item.completed}/{item.reels} reels · {minutes(item.total - item.viewed)} min remaining
          </p>
          <div className="insight-progress">
            <i style={{ width: `${item.percent}%` }} />
          </div>
        </div>
        <span className="lecture-insight-end">
          <strong>{item.percent}%</strong>
          <ChevronDown size={17} />
        </span>
      </button>
      <div id={id} className="lecture-insight-expansion" aria-hidden={!open} inert={!open}>
        <div className="lecture-detail-clip">
          {(visited || open) && <LectureDetails state={state} item={item} days={days} />}
        </div>
      </div>
    </article>
  );
}
