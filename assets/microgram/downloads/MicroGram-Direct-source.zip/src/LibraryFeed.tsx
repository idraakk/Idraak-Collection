import { HighQualityCover } from './HighQualityCover';
import { useEffect, useRef, useState } from 'react';
import { ListVideo, MoreVertical, Plus, Search, UserRound, X, List } from 'lucide-react';
import { SearchResults } from './SearchResults';
import { complete, segments, type Course, type Progress } from './core';
import { CourseCacheButton } from './StoragePanel';
import { androidDirect } from './androidDirect';

type Metadata = {
  id: string;
  channel: string;
  avatar?: string;
  thumbnail?: string;
  views?: string;
  publishedAt?: string;
};
const cached = new Map<string, { at: number; data: Metadata }>();
export const clearLibraryMetadataCache = () => cached.clear();
const base = import.meta.env.VITE_API_BASE_URL ?? '';
export function isPlaylist(c: Course) {
  if (c.kind) return c.kind === 'playlist';
  return c.videos.length > 1 || (!c.sample && !c.videos[0].local && c.id !== c.videos[0].id);
}
export function durationLabel(seconds: number) {
  const s = Math.floor(seconds),
    hours = Math.floor(s / 3600);
  return `${hours ? `${hours}:` : ''}${hours ? String(Math.floor(s / 60) % 60).padStart(2, '0') : Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
function publishedLabel(date?: string) {
  if (!date || !Number.isFinite(Date.parse(date))) return '';
  const days = Math.max(0, Math.floor((Date.now() - Date.parse(date)) / 86400000));
  if (!days) return 'Today';
  const [n, unit] =
    days >= 365
      ? [Math.floor(days / 365), 'year']
      : days >= 30
        ? [Math.floor(days / 30), 'month']
        : [days, 'day'];
  return `${n} ${unit}${n === 1 ? '' : 's'} ago`;
}
export function LibraryFeed({
  courses,
  seconds,
  progress,
  onOpen,
  onImport,
  onRemove,
}: {
  courses: Course[];
  seconds: number;
  progress: Progress;
  onOpen: (c: Course) => void;
  onImport: () => void;
  onRemove: (c: Course, cleared: boolean) => void;
}) {
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const searchInput = useRef<HTMLInputElement>(null);
  const [pressed, setPressed] = useState<string | null>(null);
  useEffect(() => {
    if (searchOpen) searchInput.current?.focus();
  }, [searchOpen]);
  function closeSearch() {
    setSearchOpen(false);
    setQuery('');
  }
  const [filter, setFilter] = useState('All');
  const [metadata, setMetadata] = useState<Record<string, Metadata>>({});
  const feed = useRef<HTMLElement>(null);
  const identity = JSON.stringify(
    courses
      .filter((c) => !c.videos[0].local)
      .map((c) => ({ video: c.videos[0].id, playlist: isPlaylist(c) ? c.id : '' })),
  );
  useEffect(() => {
    const abort = new AbortController();
    const targets: { video: string; playlist: string }[] = JSON.parse(identity);
    const existing: Record<string, Metadata> = {};
    for (const [key, entry] of cached)
      if (Date.now() - entry.at < 3600000) existing[key] = entry.data;
    setMetadata(existing);
    const missing = targets.filter(
      (t) =>
        !existing[`v:${t.video}`]?.avatar || (t.playlist && !existing[`p:${t.playlist}`]?.avatar),
    );
    void (async () => {
      const batchSize = androidDirect ? 4 : 20;
      for (let i = 0; i < missing.length && !abort.signal.aborted; i += batchSize) {
        const batch = missing.slice(i, i + batchSize);
        try {
          const r = await fetch(`${base}/api/library-metadata`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: abort.signal,
            body: JSON.stringify({
              videoIds: [...new Set(batch.map((t) => t.video))],
              playlistIds: [...new Set(batch.map((t) => t.playlist).filter(Boolean))],
            }),
          });
          if (!r.ok) break;
          const result: { videos: Metadata[]; playlists: Metadata[] } = await r.json();
          if (abort.signal.aborted) return;
          const incoming: Record<string, Metadata> = {};
          for (const [prefix, values] of [
            ['v', result.videos],
            ['p', result.playlists],
          ] as const)
            for (const data of values) {
              const key = `${prefix}:${data.id}`;
              incoming[key] = data;
              if (cached.size >= 1000) cached.delete(cached.keys().next().value!);
              cached.set(key, { at: Date.now(), data });
            }
          setMetadata((old) => ({ ...old, ...incoming }));
        } catch {
          break;
        }
      }
    })();
    return () => abort.abort();
  }, [identity]);
  useEffect(() => {
    const dismiss = (e: Event) => {
      if (document.querySelector('.confirm-dialog[open]')) return;
      feed.current?.querySelectorAll<HTMLDetailsElement>('details[open]').forEach((d) => {
        if (e.type === 'keydown' || !d.contains(e.target as Node)) d.open = false;
      });
    };
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') dismiss(e);
    };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', dismiss);
      document.removeEventListener('keydown', key);
    };
  }, []);
  const entries = courses.map((c) => {
    const list = segments(c, seconds);
    return { c, total: list.length, done: list.filter((r) => complete(r, progress)).length };
  });
  const filtered = entries.filter(
    ({ c, done, total }) =>
      `${c.title} ${c.channel}`.toLowerCase().includes(query.toLowerCase()) &&
      (filter === 'All' ||
        (filter === 'Videos' && !isPlaylist(c)) ||
        (filter === 'Playlists' && isPlaylist(c)) ||
        (filter === 'In progress' && done > 0 && done < total) ||
        (filter === 'Completed' && done === total)),
  );
  return (
    <section className="youtube-library" ref={feed} aria-label="Learning library">
      <div className="library-feed-heading">
        {searchOpen ? (
          <input
            ref={searchInput}
            className="library-inline-search"
            aria-label="Search your library"
            placeholder="Search your library"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') closeSearch();
            }}
          />
        ) : (
          <h1 className="library-wordmark">Library</h1>
        )}
        <div className="library-heading-actions">
          <button
            className="library-search-toggle"
            aria-label={searchOpen ? 'Close library search' : 'Search library'}
            aria-expanded={searchOpen}
            onClick={() => (searchOpen ? closeSearch() : setSearchOpen(true))}
          >
            {searchOpen ? <X size={23} /> : <Search size={23} />}
          </button>
          {!searchOpen && (
            <button className="library-add" onClick={onImport}>
              <Plus size={19} /> Add videos
            </button>
          )}
        </div>
      </div>
      <div className="library-filter-chips" aria-label="Filter library">
        {['All', 'Videos', 'Playlists', 'In progress', 'Completed'].map((name) => (
          <button key={name} aria-pressed={filter === name} onClick={() => setFilter(name)}>
            {name}
          </button>
        ))}
      </div>
      <SearchResults query={query}>
        <div className="youtube-feed-grid">
          {filtered.map(({ c, done, total }) => {
            const playlist = isPlaylist(c),
              first = c.videos[0];
            const videoMeta = metadata[`v:${first.id}`];
            const owner = (playlist ? metadata[`p:${c.id}`] : undefined) ?? videoMeta;
            const thumbnail = owner?.thumbnail ?? videoMeta?.thumbnail ?? first.thumbnail;
            const pct = total ? (done / total) * 100 : 0;
            const stats = playlist
              ? `${c.videos.length} videos · Playlist`
              : [
                  videoMeta?.views !== undefined
                    ? `${new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 }).format(Number(videoMeta.views))}`
                    : '',
                  publishedLabel(videoMeta?.publishedAt),
                ]
                  .filter(Boolean)
                  .join(' · ');
            return (
              <article
                className={`youtube-feed-card${playlist ? ' playlist-feed-card' : ''}${pressed === c.id ? ' touch-highlight' : ''}`}
                onTouchStart={(e) => {
                  if (!(e.target as HTMLElement).closest('details')) setPressed(c.id);
                }}
                onTouchEnd={() => setPressed(null)}
                onTouchCancel={() => setPressed(null)}
                onPointerDown={(e) => {
                  if (e.pointerType === 'mouse' && !(e.target as HTMLElement).closest('details'))
                    setPressed(c.id);
                }}
                onPointerUp={() => setPressed(null)}
                onPointerLeave={(e) => {
                  if (e.pointerType === 'mouse') setPressed(null);
                }}
                key={c.id}
              >
                <button
                  className="feed-thumbnail"
                  aria-label={`Open ${c.title} profile`}
                  onClick={() => onOpen(c)}
                >
                  <HighQualityCover
                    videoId={first.local ? undefined : first.id}
                    fallback={thumbnail}
                  />
                  {playlist && (
                    <span className="feed-playlist-badge">
                      <ListVideo size={16} /> {c.videos.length} videos
                    </span>
                  )}
                  <span className="feed-duration">
                    {durationLabel(c.videos.reduce((sum, v) => sum + v.duration, 0))}
                  </span>
                  <span
                    className="feed-watch-progress"
                    role="progressbar"
                    aria-label={`${c.title} reels watched`}
                    aria-valuemin={0}
                    aria-valuemax={total}
                    aria-valuenow={done}
                  >
                    <i style={{ width: `${pct}%` }} />
                  </span>
                </button>
                <div className="feed-video-info">
                  <div className="feed-channel-avatar" title={owner?.channel || c.channel}>
                    {owner?.avatar ? (
                      <img
                        src={owner.avatar}
                        alt={`${owner.channel || c.channel} channel`}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        key={owner.avatar}
                        onLoad={(e) => {
                          e.currentTarget.style.display = 'block';
                        }}
                        onError={(e) => {
                          const image = e.currentTarget;
                          if (image.src.includes('://yt3.ggpht.com/'))
                            image.src = image.src.replace(
                              '://yt3.ggpht.com/',
                              '://yt3.googleusercontent.com/',
                            );
                          else image.style.display = 'none';
                        }}
                      />
                    ) : null}
                    <UserRound size={22} aria-hidden="true" />
                  </div>
                  <div className="feed-video-copy">
                    <button className="feed-title" onClick={() => onOpen(c)}>
                      <h2>{c.title}</h2>
                    </button>
                    <p
                      className="feed-metadata"
                      title={[owner?.channel || c.channel, stats, `${done}/${total} reels watched`]
                        .filter(Boolean)
                        .join(' · ')}
                    >
                      <span className="feed-metadata-summary">
                        {owner?.channel || c.channel}
                        {stats && <> · {stats}</>}
                      </span>
                      <span className="feed-metadata-watched">
                        {' '}
                        · {done}/{total} watched
                      </span>
                    </p>
                  </div>
                  <details className="feed-options">
                    <summary aria-label={`Options for ${c.title}`}>
                      <MoreVertical size={21} />
                    </summary>
                    <div
                      className="feed-options-scrim"
                      onClick={(e) => {
                        const details = e.currentTarget.closest('details');
                        if (details) details.open = false;
                      }}
                    />
                    <div className="feed-options-panel">
                      <span className="feed-options-handle" aria-hidden="true" />
                      <button onClick={() => onOpen(c)}>
                        <List size={20} />
                        View all reels
                      </button>
                      <CourseCacheButton
                        course={c}
                        courses={courses}
                        onRemove={(cleared) => onRemove(c, cleared)}
                      />
                    </div>
                  </details>
                </div>
              </article>
            );
          })}
        </div>
        {!filtered.length && (
          <div className="library-feed-empty">
            <h2>{courses.length ? 'No matching lectures' : 'Your next lecture starts here'}</h2>
            <p>
              {courses.length
                ? 'Try another search or filter.'
                : 'Add a YouTube video or playlist to build your library.'}
            </p>
            {!courses.length && (
              <button className="button primary" onClick={onImport}>
                Add your first video
              </button>
            )}
          </div>
        )}
      </SearchResults>
    </section>
  );
}
