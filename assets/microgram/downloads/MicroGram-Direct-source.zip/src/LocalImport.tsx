import { useState } from 'react';
import type { Course } from './core';
import { deviceStreaming } from './deviceStreaming';
export function LocalImport({
  onImported,
  onBusy,
}: {
  onImported: (course: Course) => void;
  onBusy: (busy: boolean) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function upload(file: File) {
    setError('');
    setBusy(true);
    onBusy(true);
    const objectURL = URL.createObjectURL(file);
    try {
      if (file.size > 2 * 1024 ** 3) throw new Error('Choose an MP4 smaller than 2 GB.');
      const { duration, width, height } = await new Promise<{
        duration: number;
        width: number;
        height: number;
      }>((resolve, reject) => {
        const video = document.createElement('video');
        video.preload = 'metadata';
        const timer = setTimeout(() => {
          video.removeAttribute('src');
          video.load();
          reject(new Error('Could not read this video.'));
        }, 15000);
        video.onloadedmetadata = () => {
          clearTimeout(timer);
          resolve({ duration: video.duration, width: video.videoWidth, height: video.videoHeight });
          video.removeAttribute('src');
          video.load();
        };
        video.onerror = () => {
          clearTimeout(timer);
          reject(new Error('Choose a playable H.264/AAC MP4.'));
        };
        video.src = objectURL;
      });
      if (!Number.isFinite(duration) || duration <= 0 || duration > 86400)
        throw new Error('Choose a video shorter than 24 hours.');
      const id = Array.from(crypto.getRandomValues(new Uint8Array(6)), (b) =>
        b.toString(16).padStart(2, '0'),
      )
        .join('')
        .slice(0, 11);
      const response = await fetch(
        `${import.meta.env.VITE_API_BASE_URL ?? ''}/api/media/${id}/upload`,
        { method: 'POST', headers: { 'Content-Type': 'video/mp4' }, body: file },
      );
      if (!response.ok) {
        const result = await response.json();
        throw new Error(result.error || 'Upload failed.');
      }
      const title = file.name.replace(/\.mp4$/i, '');
      onImported({
        id,
        title,
        channel: 'My videos',
        importedAt: Date.now(),
        videos: [
          {
            id,
            title,
            channel: 'My videos',
            duration: Math.ceil(duration),
            width,
            height,
            thumbnail: '/local-cover.svg',
            local: true,
          },
        ],
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed.');
    } finally {
      URL.revokeObjectURL(objectURL);
      setBusy(false);
      onBusy(false);
    }
  }
  return (
    <div className="local-import">
      <h3>Or use your own video</h3>
      <p>
        Import an MP4 you own or have permission to use.{' '}
        {deviceStreaming ? 'It stays on this device.' : 'It stays on this personal server.'}
      </p>
      <label className="button secondary full">
        {busy ? 'Copying your video…' : 'Choose MP4 file'}
        <input
          aria-label="Import local MP4"
          type="file"
          accept="video/mp4,.mp4"
          disabled={busy}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void upload(file);
            e.target.value = '';
          }}
        />
      </label>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
