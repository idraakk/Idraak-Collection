import { useImperativeHandle, useLayoutEffect, useRef, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { BookOpen, Check, X } from 'lucide-react';
import { clock, type Segment } from './core';
import { PAGE_MOTION } from './savedTransition';
export type NotesDialogControls = { close: () => void };
export function NotesDialog({
  segment,
  value,
  onChange,
  onClose,
  controlRef,
  origin,
}: {
  segment: Segment;
  value: string;
  onChange: (value: string) => void;
  onClose: () => void;
  controlRef: RefObject<NotesDialogControls | null>;
  origin?: DOMRect | null;
}) {
  const backdrop = useRef<HTMLDivElement>(null),
    panel = useRef<HTMLDivElement>(null);
  const closed = useRef(false);
  function close() {
    if (closed.current) return;
    closed.current = true;
    if (
      !matchMedia('(prefers-reduced-motion: reduce)').matches &&
      backdrop.current &&
      panel.current
    ) {
      const anchor = document.querySelector('.notes-control')?.getBoundingClientRect() ?? origin;
      const box = panel.current.getBoundingClientRect();
      if (anchor)
        panel.current.style.transformOrigin = `${anchor.x + anchor.width / 2 - box.x}px ${anchor.y + anchor.height / 2 - box.y}px`;
      const transform = getComputedStyle(panel.current).transform;
      const copy = backdrop.current.cloneNode(true) as HTMLDivElement;
      copy.classList.add('notes-exit-snapshot');
      copy.setAttribute('aria-hidden', 'true');
      copy.inert = true;
      copy.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
      copy.querySelectorAll('[role]').forEach((node) => node.removeAttribute('role'));
      const copiedPanel = copy.querySelector<HTMLElement>('.notes-dialog')!;
      const field = copy.querySelector('textarea');
      if (field) field.value = value;
      document.body.append(copy);
      copy.animate([{ opacity: 1 }, { opacity: 0 }], {
        duration: PAGE_MOTION.duration,
        easing: 'ease-out',
        fill: 'forwards',
      });
      copiedPanel.animate(
        [
          { transform, opacity: 1 },
          { transform: 'scale(.12)', opacity: 0 },
        ],
        { duration: PAGE_MOTION.duration, easing: PAGE_MOTION.easing, fill: 'forwards' },
      );
      setTimeout(() => copy.remove(), PAGE_MOTION.duration + 20);
    }
    onClose();
  }
  useImperativeHandle(controlRef, () => ({ close }));
  useLayoutEffect(() => {
    document.querySelectorAll('.notes-exit-snapshot').forEach((node) => node.remove());
    const box = panel.current!.getBoundingClientRect();
    const anchor = origin ?? document.querySelector('.notes-control')?.getBoundingClientRect();
    if (anchor)
      panel.current!.style.transformOrigin = `${anchor.x + anchor.width / 2 - box.x}px ${anchor.y + anchor.height / 2 - box.y}px`;
    if (!matchMedia('(prefers-reduced-motion: reduce)').matches)
      panel.current!.animate(
        [
          { transform: 'scale(.12)', opacity: 0 },
          { transform: 'scale(1)', opacity: 1 },
        ],
        { duration: PAGE_MOTION.duration, easing: PAGE_MOTION.easing },
      );
    const frame = requestAnimationFrame(() =>
      panel.current?.querySelector('textarea')?.focus({ preventScroll: true }),
    );
    return () => cancelAnimationFrame(frame);
  }, []);
  return createPortal(
    <div
      className="notes-backdrop"
      ref={backdrop}
      onClick={(e) => {
        if (e.target === e.currentTarget) close();
      }}
    >
      <div
        className="notes-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="notes-title"
        ref={panel}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.stopPropagation();
            close();
          }
          if (e.key === 'Tab') {
            const items = panel.current!.querySelectorAll<HTMLElement>('button,textarea');
            if (e.shiftKey && document.activeElement === items[0]) {
              e.preventDefault();
              items[items.length - 1].focus();
            } else if (!e.shiftKey && document.activeElement === items[items.length - 1]) {
              e.preventDefault();
              items[0].focus();
            }
          }
        }}
      >
        <button className="notes-close" aria-label="Close notes" onClick={close}>
          <X size={20} />
        </button>
        <span className="notes-symbol">
          <BookOpen size={23} />
        </span>
        <h2 id="notes-title">Your note</h2>
        <p>
          {segment.video.title} · {clock(segment.start)}
        </p>
        <label htmlFor="note">Your takeaway</label>
        <textarea
          id="note"
          rows={6}
          maxLength={5000}
          value={value}
          placeholder="What clicked for you?"
          onChange={(e) => onChange(e.target.value)}
        />
        <button className="button primary full" onClick={close}>
          Done <Check size={17} />
        </button>
      </div>
    </div>,
    document.body,
  );
}
