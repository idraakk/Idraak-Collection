import { useEffect, useRef, useState } from 'react';
import type { Segment, Video } from './core';
import { autoRotate } from './videoLayout';
import { getFrameDimensions, rememberFrameDimensions, useReelFrame } from './reelFrames';
import { requestThumbnailUpgrade } from './thumbnailUpgrade';

export function OrientedThumbnail({
  video,
  time,
  fit = false,
  rotation,
  upgrade,
}: {
  video: Video;
  time?: number;
  fit?: boolean;
  rotation?: boolean;
  upgrade?: Segment;
}) {
  const source = useReelFrame(video, time);
  const host = useRef<HTMLSpanElement>(null);
  const [fallback, setFallback] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!upgrade || !host.current) return;
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), {
      rootMargin: '100px',
    });
    observer.observe(host.current);
    return () => observer.disconnect();
  }, [upgrade?.id]);
  const [size, setSize] = useState({ width: 3, height: 4 });
  const [natural, setNatural] = useState({ width: 16, height: 9 });
  useEffect(() => {
    const observer = new ResizeObserver(([entry]) => setSize(entry.contentRect));
    if (host.current) observer.observe(host.current);
    return () => observer.disconnect();
  }, []);
  const actual =
    video.width && video.height
      ? { width: video.width, height: video.height }
      : getFrameDimensions(video.id);
  const rotated =
    rotation ??
    autoRotate(
      actual?.width ?? natural.width,
      actual?.height ?? natural.height,
      size.width,
      size.height,
    );
  // Standard 4:3 YouTube covers often contain letterboxing around 16:9 footage.
  const sourceAspect = actual
    ? actual.width / actual.height
    : !video.local && Math.abs(natural.width / natural.height - 4 / 3) < 0.02
      ? 16 / 9
      : natural.width / natural.height;
  const cropWidth = Math.min(natural.width, natural.height * sourceAspect);
  const cropHeight = Math.min(natural.height, natural.width / sourceAspect);
  const scale = (fit ? Math.min : Math.max)(
    (rotated ? size.height : size.width) / cropWidth,
    (rotated ? size.width : size.height) / cropHeight,
  );
  useEffect(() => {
    if (
      upgrade &&
      visible &&
      (!loaded || natural.width < 480 || fallback) &&
      !source.startsWith('blob:')
    )
      return requestThumbnailUpgrade(upgrade);
  }, [upgrade?.id, visible, loaded, natural.width, fallback, source]);
  return (
    <span
      ref={host}
      className={`oriented-thumbnail ${rotated ? 'thumbnail-rotated' : ''} ${loaded ? 'thumbnail-ready' : 'thumbnail-loading'}`}
    >
      <img
        key={source}
        src={source}
        onError={(e) => {
          const image = e.currentTarget;
          setFallback(true);
          if (image.src !== new URL(video.thumbnail, location.href).href)
            image.src = video.thumbnail;
          else image.style.visibility = 'hidden';
        }}
        style={{
          inset: 'auto',
          left: '50%',
          top: '50%',
          width: natural.width * scale,
          height: natural.height * scale,
          maxWidth: 'none',
          maxHeight: 'none',
          transform: `translate(-50%, -50%) rotate(${rotated ? 90 : 0}deg)`,
        }}
        alt=""
        loading="lazy"
        onLoad={(e) => {
          const image = e.currentTarget;
          if (
            time !== undefined &&
            image.naturalWidth >= 480 &&
            image.src !== new URL(video.thumbnail, location.href).href
          )
            rememberFrameDimensions(video.id, image.naturalWidth, image.naturalHeight);
          setNatural({
            width: e.currentTarget.naturalWidth,
            height: e.currentTarget.naturalHeight,
          });
          setLoaded(true);
          setFallback(e.currentTarget.src === new URL(video.thumbnail, location.href).href);
        }}
      />
    </span>
  );
}
