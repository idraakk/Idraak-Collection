import { createPortal } from 'react-dom';
import { Check, ChevronDown, Gauge } from 'lucide-react';
import { useContext, useEffect, useRef, useState, type RefObject } from 'react';
import { PlaybackLayout } from './videoLayout';
import type { Segment } from './core';
const base = import.meta.env.VITE_API_BASE_URL ?? '';
const captionCache = new Map<string, string>();
export const speeds = [1, 1.25, 1.5, 1.75, 2];
export function PlaybackSettings({
  video,
  segment,
  speed,
  setSpeed,
  controlsHidden,
  mediaVersion = 0,
}: {
  video: RefObject<HTMLVideoElement | null>;
  segment: Segment;
  speed: number;
  setSpeed: (n: number) => void;
  controlsHidden: boolean;
  mediaVersion?: number;
}) {
  const [open, setOpen] = useState(false);
  const panel = useRef<HTMLDivElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  const layout = useContext(PlaybackLayout);
  const [captionSize, setCaptionSize] = useState({ width: 0, height: 0 });
  useEffect(() => {
    const v = video.current;
    if (!v) return;
    const measure = () => {
      let width = v.clientWidth,
        height = v.clientHeight;
      if (layout.fit && v.videoWidth && v.videoHeight) {
        const scale = Math.min(width / v.videoWidth, height / v.videoHeight);
        width = v.videoWidth * scale;
        height = v.videoHeight * scale;
      }
      setCaptionSize({ width, height });
    };
    const observer = new ResizeObserver(measure);
    observer.observe(v);
    v.addEventListener('loadedmetadata', measure);
    measure();
    return () => {
      observer.disconnect();
      v.removeEventListener('loadedmetadata', measure);
    };
  }, [video, layout.rotated, layout.fit, segment.video.id, mediaVersion]);
  useEffect(() => {
    if (controlsHidden) setOpen(false);
  }, [controlsHidden]);
  useEffect(() => {
    if (!open) return;
    const outside = (e: PointerEvent) => {
      if (!panel.current?.contains(e.target as Node) && !toggle.current?.contains(e.target as Node))
        setOpen(false);
    };
    document.addEventListener('pointerdown', outside, true);
    return () => document.removeEventListener('pointerdown', outside, true);
  }, [open]);
  const [tracks, setTracks] = useState<{ language: string; label: string }[]>([]);
  const [language, setLanguage] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [requested, setRequested] = useState(false);
  const [retry, setRetry] = useState(0);
  const [text, setText] = useState('');
  useEffect(() => {
    setTracks([]);
    setLanguage('');
    setText('');
    setRequested(false);
    setMessage('');
  }, [segment.video.id]);
  useEffect(() => {
    if (!requested || segment.video.local) return;
    const abort = new AbortController();
    setLoading(true);
    setMessage('');
    fetch(`${base}/api/media/${segment.video.id}/captions`, { signal: abort.signal })
      .then(async (r) => {
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || 'Captions unavailable.');
        return data;
      })
      .then((data) => {
        if (abort.signal.aborted) return;
        setTracks(data.tracks);
        if (!data.tracks.length) setMessage('This video has no available YouTube captions.');
      })
      .catch((e) => {
        if (!abort.signal.aborted) setMessage(e.message);
      })
      .finally(() => {
        if (!abort.signal.aborted) setLoading(false);
      });
    return () => abort.abort();
  }, [requested, segment.video.id, retry]);
  useEffect(() => {
    setText('');
    if (!language || !video.current) return;
    const abort = new AbortController();
    let track: HTMLTrackElement | undefined,
      url = '';
    setLoading(true);
    setMessage('');
    const cacheKey = `${segment.video.id}:${language}`;
    const cached = captionCache.get(cacheKey);
    const request = cached
      ? Promise.resolve({ vtt: cached })
      : fetch(
          `${base}/api/media/${segment.video.id}/captions?language=${encodeURIComponent(language)}`,
          { signal: abort.signal },
        ).then(async (r) => {
          const data = await r.json();
          if (!r.ok) throw new Error(data.error || 'Captions unavailable.');
          if (typeof data.vtt === 'string' && data.vtt.length <= 500000) {
            if (captionCache.size >= 8) captionCache.delete(captionCache.keys().next().value!);
            captionCache.set(cacheKey, data.vtt);
          }
          return data;
        });
    request
      .then((data) => {
        if (abort.signal.aborted || !video.current) return;
        url = URL.createObjectURL(new Blob([data.vtt], { type: 'text/vtt' }));
        track = document.createElement('track');
        track.kind = 'subtitles';
        track.src = url;
        track.srclang = language;
        video.current.append(track);
        track.track.mode = 'hidden';
        track.track.oncuechange = () => {
          const cues = Array.from(track?.track.activeCues ?? []) as VTTCue[];
          setText(
            cues
              .map((c) => c.getCueAsHTML().textContent)
              .filter(Boolean)
              .join('\n'),
          );
        };
        track.onerror = () => setMessage('This caption track could not be displayed.');
      })
      .catch((e) => {
        if (!abort.signal.aborted) setMessage(e.message);
      })
      .finally(() => {
        if (!abort.signal.aborted) setLoading(false);
      });
    return () => {
      abort.abort();
      if (track) {
        track.track.oncuechange = null;
        track.remove();
      }
      if (url) URL.revokeObjectURL(url);
    };
  }, [language, segment.video.id, retry, mediaVersion]);
  useEffect(() => {
    setOpen(false);
  }, [segment.id]);
  return (
    <>
      {createPortal(
        <button
          ref={toggle}
          className="playback-settings-toggle"
          aria-label="Playback speed and captions"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <Gauge size={28} />
          <span>{speed}×</span>
        </button>,
        document.getElementById('reel-speed-slot') ?? document.body,
      )}
      {open && (
        <div
          ref={panel}
          className="playback-settings-panel"
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === 'Escape') setOpen(false);
          }}
        >
          <SettingChoice
            label="Playback speed"
            value={String(speed)}
            choices={speeds.map((n) => ({ value: String(n), label: `${n}×` }))}
            onChange={(value) => setSpeed(Number(value))}
          />
          {segment.video.local ? (
            <p>Local videos have no YouTube caption track.</p>
          ) : (
            <>
              {!requested && (
                <button onClick={() => setRequested(true)}>Load YouTube captions</button>
              )}
              {tracks.length > 0 && (
                <SettingChoice
                  label="Caption language"
                  value={language}
                  choices={[
                    { value: '', label: 'Off' },
                    ...tracks.map((t) => ({ value: t.language, label: t.label })),
                  ]}
                  onChange={setLanguage}
                />
              )}
              {loading && <p role="status">Loading captions…</p>}
              {message && <p role="status">{message}</p>}
              {message && !loading && (
                <button onClick={() => setRetry((n) => n + 1)}>Retry captions</button>
              )}
            </>
          )}
          <button onClick={() => setOpen(false)}>Done</button>
        </div>
      )}
      {text && (
        <div
          className="caption-plane"
          style={{
            width: captionSize.width,
            height: captionSize.height,
            transform: `translate(-50%, -50%) rotate(${layout.rotated ? 90 : 0}deg)`,
          }}
        >
          <div className="video-captions" aria-hidden="true">
            <span>{text}</span>
          </div>
        </div>
      )}
    </>
  );
}

function SettingChoice({
  label,
  value,
  choices,
  onChange,
}: {
  label: string;
  value: string;
  choices: { value: string; label: string }[];
  onChange: (value: string) => void;
}) {
  return (
    <details className="setting-choice">
      <summary aria-label={label}>
        <span>{label}</span>
        <strong>{choices.find((item) => item.value === value)?.label}</strong>
        <ChevronDown size={14} />
      </summary>
      <div role="group" aria-label={label}>
        {choices.map((item) => (
          <button
            key={item.value}
            aria-pressed={value === item.value}
            onClick={(e) => {
              onChange(item.value);
              e.currentTarget.closest('details')!.open = false;
            }}
          >
            {item.label}
            {value === item.value && <Check size={14} />}
          </button>
        ))}
      </div>
    </details>
  );
}
