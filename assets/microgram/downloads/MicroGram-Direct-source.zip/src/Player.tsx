import {
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type RefObject,
  type VideoHTMLAttributes,
} from 'react';
import {
  LoaderCircle,
  Camera,
  Volume2,
  VolumeX,
  CircleAlert,
  Settings2,
  Play,
  Lightbulb,
} from 'lucide-react';
import { captureFrame } from './screenNotes';
import { deviceStreaming } from './deviceStreaming';
import { androidDirect } from './androidDirect';
import { rememberReelFrame } from './reelFrames';
import { qualityPlayers, type VideoQuality } from './videoQuality';
import type { ReelDeck } from './reelDeck';
import type { Segment } from './core';
import { autoRotate, PlaybackLayout, useViewport } from './videoLayout';
import { OrientedThumbnail } from './OrientedThumbnail';
import { PlaybackSettings } from './PlaybackSettings';
import { QualitySettings } from './QualitySettings';
function VideoSlot({
  videoRef,
  guard,
  ...props
}: VideoHTMLAttributes<HTMLVideoElement> & {
  videoRef: (element: HTMLVideoElement | null) => void;
  guard: (element: HTMLVideoElement) => boolean;
}) {
  const events: Record<string, unknown> = {};
  for (const [name, value] of Object.entries(props))
    if (name.startsWith('on') && typeof value === 'function')
      events[name] = (event: { currentTarget: HTMLVideoElement }) => {
        if (guard(event.currentTarget)) value(event);
      };
  return <video {...props} {...events} ref={videoRef} />;
}
export type PlayerControls = {
  togglePlay: () => void;
  toggleMute: () => void;
  seekBy: (seconds: number) => void;
  prepareReel: (next: Segment) => void;
  getPlayback: () => { time: number; paused: boolean } | undefined;
};
const base = import.meta.env.VITE_API_BASE_URL ?? '';
const BUFFER_TIPS = [
  'Pause the video, then tap the camera to capture a Screen Note.',
  'Find your captured frames in Saved / Screen Notes.',
  'Hold the video to temporarily watch at 2x speed.',
  'Drag the progress bar to revisit a moment in this reel.',
  'Label your Screen Notes to find them faster when revising.',
];
export const prepared = new Set<string>();
export const mediaSource = (id: string) => `${base}/api/media/${id}/file?cache=managed-v1`;
export function Player({
  segment,
  onTick,
  onEnd,
  onDuration,
  onDimensions,
  controlRef,
  onPlaybackChange,
  controlsHidden,
  onToggleControls,
  onOpenSettings,
  speed,
  setSpeed,
  quality = 'high',
  qualityFor,
  setQuality,
  onCapture,
  onCaptureError,
  initialTime,
  initiallyPaused = false,
  singleReel = false,
  entryKey,
  preloadReels = true,
  nearbyReels = [],
}: {
  segment: Segment;
  onTick: (previous: number, current: number, playbackRate: number) => void;
  onEnd: () => void;
  onDuration: (duration: number) => void;
  onDimensions: (width: number, height: number) => void;
  controlRef: RefObject<PlayerControls | null>;
  onPlaybackChange: (playing: boolean) => void;
  controlsHidden: boolean;
  onToggleControls: () => void;
  onOpenSettings?: () => void;
  speed: number;
  setSpeed: (speed: number) => void;
  quality?: VideoQuality;
  qualityFor?: (id: string) => VideoQuality;
  setQuality?: (quality: VideoQuality) => void;
  onCapture: (
    frame: Blob,
    time: number,
    segment: Segment,
    layout: { captureRotation: 0 | 90; captureViewport: 'portrait' | 'landscape' },
  ) => void;
  onCaptureError: (message: string) => void;
  initialTime?: number;
  initiallyPaused?: boolean;
  singleReel?: boolean;
  entryKey?: string;
  preloadReels?: boolean;
  nearbyReels?: Segment[];
}) {
  const video = useRef<HTMLVideoElement>(null);
  const slots = useRef<(HTMLVideoElement | null)[]>([]);
  const deck = useRef<ReelDeck | null>(null);
  const activeSlotRef = useRef(0);
  const [activeSlot, setActiveSlot] = useState(0);
  const nativeDeck = androidDirect && deviceStreaming && !segment.video.local && !singleReel;
  const deckLoading = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const neighbors = useRef(nearbyReels);
  neighbors.current = nearbyReels;
  const qualityRef = useRef({ quality, qualityFor });
  qualityRef.current = { quality, qualityFor };
  useEffect(() => {
    for (const element of slots.current) if (element) qualityPlayers.get(element)?.().refresh();
    if (video.current) qualityPlayers.get(video.current)?.().refresh();
  }, [quality, activeSlot]);
  const transitionFrame = useRef<HTMLCanvasElement>(null);
  const preparedSeek = useRef<string | null>(null);
  const captureLayout = useContext(PlaybackLayout);
  const latest = useRef({
    segment,
    onTick,
    onEnd,
    onDuration,
    onDimensions,
    onPlaybackChange,
    initialTime,
    initiallyPaused,
    singleReel,
    preloadReels,
  });
  latest.current = {
    segment,
    onTick,
    onEnd,
    onDuration,
    onDimensions,
    onPlaybackChange,
    initialTime,
    initiallyPaused,
    singleReel,
    preloadReels,
  };
  const [attempt, setAttempt] = useState(0);
  const [ready, setReady] = useState('');
  const [adaptiveLoading, setAdaptiveLoading] = useState(false);
  const [buffering, setBuffering] = useState(false);
  const [bufferTip, setBufferTip] = useState(-1);
  const bufferingTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  function endBuffering() {
    clearTimeout(bufferingTimer.current);
    setBuffering(false);
  }
  useEffect(() => {
    endBuffering();
    return () => clearTimeout(bufferingTimer.current);
  }, [segment.id]);
  useEffect(() => {
    if (!nativeDeck) return;
    let cancelled = false;
    void Promise.all([import('./reelDeck'), import('./adaptivePlayback')])
      .then(([{ ReelDeck }, { attachAdaptivePlayer }]) => {
        if (cancelled) return;
        const elements = slots.current.filter((v): v is HTMLVideoElement => !!v);
        const pool = new ReelDeck(elements, {
          create: attachAdaptivePlayer,
          quality: (id) => qualityRef.current.qualityFor?.(id) ?? qualityRef.current.quality,
          nearby: () => neighbors.current,
          select: (slot) => {
            if (cancelled) return;
            activeSlotRef.current = slot;
            video.current = slots.current[slot];
            setActiveSlot(slot);
          },
          frame: rememberReelFrame,
          failure: (message) => {
            if (!cancelled) setError(message);
          },
        });
        deck.current = pool;
        seek();
      })
      .catch((e) => {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Player unavailable.');
      });
    return () => {
      cancelled = true;
      clearTimeout(deckLoading.current);
      const pool = deck.current;
      deck.current = null;
      void pool?.destroy();
      activeSlotRef.current = 0;
      setActiveSlot(0);
    };
  }, [nativeDeck, attempt]);
  useEffect(() => {
    if (
      nativeDeck ||
      !deviceStreaming ||
      segment.video.local ||
      ready !== segment.video.id ||
      !video.current
    )
      return;
    const element = video.current;
    let cancelled = false;
    let controller: { destroy: () => Promise<void> } | undefined;
    const loading = setTimeout(() => {
      if (!cancelled) setAdaptiveLoading(true);
    }, 350);
    void import('./adaptivePlayback')
      .then(async ({ attachAdaptivePlayer }) => {
        if (cancelled) return;
        const player = attachAdaptivePlayer(
          element,
          ready,
          latest.current.initialTime ?? latest.current.segment.start,
          (message) => {
            if (!cancelled) setError(message);
          },
          () => ({
            start: latest.current.segment.start,
            end: latest.current.segment.end,
            enabled: latest.current.preloadReels && !latest.current.singleReel,
          }),
          { preference: () => qualityRef.current.quality },
        );
        controller = player;
        await player.ready;
        if (!cancelled) {
          clearTimeout(loading);
          setAdaptiveLoading(false);
        }
      })
      .catch((failure) => {
        if (!cancelled) {
          clearTimeout(loading);
          setAdaptiveLoading(false);
          setError(
            failure instanceof Error
              ? failure.message
              : 'This lecture could not start. Try again to refresh its stream.',
          );
        }
      });
    return () => {
      cancelled = true;
      clearTimeout(loading);
      setAdaptiveLoading(false);
      void controller?.destroy();
    };
  }, [ready, segment.video.id, segment.video.local, nativeDeck]);
  const [error, setError] = useState('');
  const [preparing, setPreparing] = useState(false);
  const [checkingLong, setCheckingLong] = useState(false);
  const [showPreparation, setShowPreparation] = useState(false);
  useEffect(() => {
    setShowPreparation(false);
    if (ready === segment.video.id || error || !preparing) return;
    const timer = setTimeout(() => setShowPreparation(true), 350);
    return () => clearTimeout(timer);
  }, [ready, error, segment.video.id, preparing]);
  useEffect(() => {
    setCheckingLong(false);
    if (ready === segment.video.id || error || preparing) return;
    const timer = setTimeout(() => setCheckingLong(true), 350);
    return () => clearTimeout(timer);
  }, [ready, error, segment.video.id, preparing]);

  const [paused, setPaused] = useState(initiallyPaused);
  const [capturing, setCapturing] = useState(false);
  const [muted, setMuted] = useState(false);
  const [boosting, setBoosting] = useState(false);
  const [position, setPosition] = useState(segment.start);
  const hold = useRef<{ x: number; y: number; timer: ReturnType<typeof setTimeout> } | null>(null);
  const held = useRef(false);
  const scrubbing = useRef(false);
  const resumeAfterScrub = useRef(false);
  const queuedSeek = useRef<number | null>(null);
  const seekFrame = useRef(0);
  function pumpSeek() {
    const v = video.current;
    if (!v || v.seeking || queuedSeek.current === null) return;
    previous.current = undefined;
    seekPending.current = true;
    const target = queuedSeek.current;
    queuedSeek.current = null;
    v.currentTime = target;
  }
  function seekPosition(percent: number) {
    const v = video.current;
    if (!v || !v.readyState) return;
    const { start, end } = latest.current.segment;
    const limit = Math.max(start, end - 0.12);
    queueSeek(start + ((limit - start) * percent) / 100);
  }
  function queueSeek(target: number) {
    queuedSeek.current = target;
    setPosition(target);
    pumpSeek();
  }
  function finishScrub() {
    if (!scrubbing.current) return;
    scrubbing.current = false;
    pumpSeek();
    if (!video.current?.seeking && queuedSeek.current === null && resumeAfterScrub.current) {
      resumeAfterScrub.current = false;
      void play();
    }
  }
  useEffect(() => () => cancelAnimationFrame(seekFrame.current), []);
  const suppressTapUntil = useRef(0);
  const tap = useRef<{
    at: number;
    x: number;
    y: number;
    timer: ReturnType<typeof setTimeout>;
  } | null>(null);
  function handleTap(x: number, y: number) {
    if (Date.now() <= suppressTapUntil.current) return;
    const last = tap.current;
    if (last && Date.now() - last.at < 300 && Math.hypot(x - last.x, y - last.y) < 45) {
      clearTimeout(last.timer);
      tap.current = null;
      onToggleControls();
      return;
    }
    if (last) clearTimeout(last.timer);
    tap.current = {
      at: Date.now(),
      x,
      y,
      timer: setTimeout(() => {
        tap.current = null;
        toggle();
      }, 300),
    };
  }
  function releaseHold() {
    if (hold.current) clearTimeout(hold.current.timer);
    hold.current = null;
    if (held.current) suppressTapUntil.current = Date.now() + 600;
    held.current = false;
    setBoosting(false);
  }
  useEffect(() => {
    if (video.current) video.current.playbackRate = boosting ? 2 : speed;
  }, [speed, boosting, ready, activeSlot]);
  useEffect(() => {
    releaseHold();
    if (tap.current) clearTimeout(tap.current.timer);
    tap.current = null;
    queuedSeek.current = null;
    scrubbing.current = false;
    resumeAfterScrub.current = false;
    cancelAnimationFrame(seekFrame.current);
    setPosition(segment.start);
  }, [segment.id]);
  useEffect(() => {
    window.addEventListener('blur', releaseHold);
    window.addEventListener('resize', releaseHold);
    document.addEventListener('visibilitychange', releaseHold);
    return () => {
      if (hold.current) clearTimeout(hold.current.timer);
      if (tap.current) clearTimeout(tap.current.timer);
      window.removeEventListener('blur', releaseHold);
      window.removeEventListener('resize', releaseHold);
      document.removeEventListener('visibilitychange', releaseHold);
    };
  }, []);
  const previous = useRef<number | undefined>(undefined);
  const seekPending = useRef(false);
  const activeId = useRef('');
  async function play() {
    const v = video.current;
    if (!v) return;
    try {
      await v.play();
    } catch {
      setPaused(true);
      latest.current.onPlaybackChange(false);
    }
  }
  function seek(replay = false) {
    if (deck.current && !replay) {
      const pool = deck.current,
        s = latest.current.segment;
      previous.current = undefined;
      seekPending.current = true;
      activeId.current = s.id;
      clearTimeout(deckLoading.current);
      if (!pool.readyFor(s.id))
        deckLoading.current = setTimeout(() => setAdaptiveLoading(true), 350);
      const time = Math.max(s.start, Math.min(latest.current.initialTime ?? s.start, s.end - 0.05));
      void pool
        .activate(s, time)
        .then((v) => {
          if (deck.current !== pool || latest.current.segment.id !== s.id) return;
          clearTimeout(deckLoading.current);
          setAdaptiveLoading(false);
          endBuffering();
          seekPending.current = v.seeking;
          activeId.current = s.id;
          setPosition(v.currentTime);
          if (v.videoWidth && v.videoHeight)
            latest.current.onDimensions(v.videoWidth, v.videoHeight);
          latest.current.onDuration(Math.ceil(v.duration));
          if (latest.current.initiallyPaused) {
            v.pause();
            setPaused(true);
            latest.current.onPlaybackChange(false);
          } else void play();
        })
        .catch((e) => {
          if (deck.current === pool && latest.current.segment.id === s.id) {
            clearTimeout(deckLoading.current);
            setAdaptiveLoading(false);
            setError(e instanceof Error ? e.message : 'This reel could not start.');
          }
        });
      return;
    }
    const v = video.current;
    if (!v || !v.readyState) return;
    previous.current = undefined;
    seekPending.current = true;
    activeId.current = latest.current.segment.id;
    const s = latest.current.segment;
    const warm =
      !replay && preparedSeek.current === s.id && v.currentTime >= s.start && v.currentTime < s.end;
    preparedSeek.current = null;
    if (transitionFrame.current) transitionFrame.current.style.display = 'none';
    const time = replay
      ? s.start
      : Math.max(s.start, Math.min(latest.current.initialTime ?? s.start, s.end - 0.05));
    if (!warm) v.currentTime = time;
    else seekPending.current = v.seeking;
    setPosition(warm ? v.currentTime : time);
    if (!replay && latest.current.initiallyPaused) {
      v.pause();
      setPaused(true);
      latest.current.onPlaybackChange(false);
    } else void play();
  }
  function toggle() {
    const v = video.current;
    if (!v) return;
    if (v.paused) void play();
    else v.pause();
  }
  useEffect(() => {
    controlRef.current = {
      togglePlay: toggle,
      toggleMute: () => setMuted((value) => !value),
      seekBy: (seconds) => {
        const v = video.current;
        if (!v?.readyState || scrubbing.current) return;
        const { start, end } = latest.current.segment;
        const target = (queuedSeek.current ?? v.currentTime) + seconds;
        queueSeek(Math.max(start, Math.min(target, end - 0.12)));
      },
      prepareReel: (next) => {
        if (deck.current) {
          deck.current.prepare(next, true);
          return;
        }
        const v = video.current,
          canvas = transitionFrame.current;
        if (!v || !canvas || v.readyState < 2 || next.video.id !== latest.current.segment.video.id)
          return;
        try {
          canvas.width = Math.min(1280, v.videoWidth);
          canvas.height = Math.round((canvas.width * v.videoHeight) / v.videoWidth);
          const context = canvas.getContext('2d');
          if (!context) return;
          context.drawImage(v, 0, 0, canvas.width, canvas.height);
        } catch {
          return;
        }
        canvas.style.display = 'block';
        previous.current = undefined;
        preparedSeek.current = next.id;
        activeId.current = next.id;
        seekPending.current = true;
        v.currentTime = next.start;
      },
      getPlayback: () =>
        video.current
          ? { time: video.current.currentTime, paused: video.current.paused }
          : undefined,
    };
    return () => {
      controlRef.current = null;
    };
  }, []);
  useEffect(() => {
    if (nativeDeck) {
      setReady(segment.video.id);
      setError('');
      setPreparing(false);
      return;
    }
    const abort = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    let requested = false;
    setReady('');
    setError('');
    setPreparing(false);
    previous.current = undefined;
    const check = async () => {
      try {
        const response = await fetch(`${base}/api/media/${segment.video.id}/status`, {
          signal: AbortSignal.any([abort.signal, AbortSignal.timeout(15000)]),
        });
        if (!response.ok) throw new Error('The personal media server is unavailable.');
        let job = await response.json();
        if (job.state === 'missing' || (job.state === 'error' && attempt > 0 && !requested)) {
          requested = true;
          if (segment.video.local)
            throw new Error('This local file is missing from the server. Import it again.');
          const r = await fetch(`${base}/api/media/${segment.video.id}/prepare`, {
            method: 'POST',
            signal: abort.signal,
          });
          job = await r.json();
          if (!r.ok) throw new Error(job.error || 'Could not prepare video.');
        }
        if (abort.signal.aborted) return;
        if (job.state === 'ready') {
          prepared.add(segment.video.id);
          setPreparing(false);
          setReady(segment.video.id);
        } else if (job.state === 'error') {
          setPreparing(false);
          setError(job.error || 'Download failed.');
        } else {
          setPreparing(true);
          timer = setTimeout(check, 1500);
        }
      } catch (e) {
        if (!abort.signal.aborted) setError(e instanceof Error ? e.message : 'Preparation failed.');
      }
    };
    void check();
    return () => {
      abort.abort();
      clearTimeout(timer);
    };
  }, [segment.video.id, attempt, nativeDeck]);
  useLayoutEffect(() => {
    seek();
  }, [segment.id, ready, entryKey]);
  useEffect(() => {
    if (!ready) return;
    const keep = () => {
      void fetch(`${base}/api/media/${ready}/keepalive`, { method: 'POST' }).catch(() => {});
    };
    keep();
    const timer = setInterval(keep, 25000);
    return () => clearInterval(timer);
  }, [ready]);
  useEffect(() => {
    const timer = setInterval(() => {
      const v = video.current,
        s = latest.current.segment;
      if (
        !v ||
        v.paused ||
        scrubbing.current ||
        v.seeking ||
        document.hidden ||
        seekPending.current ||
        activeId.current !== s.id
      ) {
        previous.current = undefined;
        return;
      }
      const now = v.currentTime;
      if (previous.current !== undefined && now >= s.start && now <= s.end + 1)
        latest.current.onTick(previous.current, Math.min(now, s.end), v.playbackRate);
      previous.current = now;
      if (now >= s.end - 0.08) {
        latest.current.onEnd();
        seek(true);
      }
    }, 200);
    const hidden = () => {
      if (document.hidden) video.current?.pause();
      previous.current = undefined;
    };
    document.addEventListener('visibilitychange', hidden);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', hidden);
    };
  }, []);
  return (
    <div className="player-shell personal-player" data-boosting={boosting}>
      {(nativeDeck || ready === segment.video.id) &&
        Array.from({ length: nativeDeck ? 4 : 1 }, (_, slot) => (
          <VideoSlot
            key={`${nativeDeck ? 'deck' : 'single'}-${slot}`}
            videoRef={(element) => {
              slots.current[slot] = element;
              if (activeSlotRef.current === slot) video.current = element;
            }}
            guard={(element) => video.current === element}
            data-active={!nativeDeck || activeSlot === slot}
            aria-hidden={nativeDeck && activeSlot !== slot}
            style={
              nativeDeck
                ? {
                    opacity: activeSlot === slot ? 1 : 0,
                    pointerEvents: activeSlot === slot ? 'auto' : 'none',
                  }
                : undefined
            }
            poster="/player-poster.svg"
            className="native-video"
            src={deviceStreaming && !segment.video.local ? undefined : mediaSource(ready)}
            playsInline
            preload={nativeDeck ? 'auto' : deviceStreaming ? 'metadata' : 'auto'}
            muted={nativeDeck && activeSlot !== slot ? true : muted}
            onClick={(e) => handleTap(e.clientX, e.clientY)}
            onContextMenu={(e) => e.preventDefault()}
            onPointerDown={(e) => {
              if (!e.isPrimary || e.button !== 0) {
                releaseHold();
                return;
              }
              releaseHold();
              e.currentTarget.setPointerCapture(e.pointerId);
              hold.current = {
                x: e.clientX,
                y: e.clientY,
                timer: setTimeout(() => {
                  held.current = true;
                  setBoosting(true);
                }, 350),
              };
            }}
            onPointerMove={(e) => {
              if (
                hold.current &&
                !held.current &&
                Math.hypot(e.clientX - hold.current.x, e.clientY - hold.current.y) > 10
              )
                releaseHold();
            }}
            onPointerUp={releaseHold}
            onPointerCancel={releaseHold}
            onLostPointerCapture={releaseHold}
            onTimeUpdate={(e) => {
              if (
                activeId.current === latest.current.segment.id &&
                !scrubbing.current &&
                queuedSeek.current === null
              )
                setPosition(e.currentTarget.currentTime);
            }}
            onLoadedMetadata={() => {
              video.current!.playbackRate = boosting ? 2 : speed;
              if (video.current!.videoWidth && video.current!.videoHeight)
                latest.current.onDimensions(video.current!.videoWidth, video.current!.videoHeight);
              latest.current.onDuration(Math.ceil(video.current!.duration));
              seek();
            }}
            onSeeked={() => {
              seekPending.current = false;
              previous.current = undefined;
              cancelAnimationFrame(seekFrame.current);
              seekFrame.current = requestAnimationFrame(() => {
                pumpSeek();
                if (
                  !scrubbing.current &&
                  queuedSeek.current === null &&
                  !video.current?.seeking &&
                  resumeAfterScrub.current
                ) {
                  resumeAfterScrub.current = false;
                  void play();
                }
              });
            }}
            onWaiting={() => {
              clearTimeout(bufferingTimer.current);
              bufferingTimer.current = setTimeout(() => {
                const v = video.current;
                if (v && v.readyState < 3 && !v.paused && !scrubbing.current) {
                  setBuffering(true);
                  setBufferTip((t) => t + 1);
                }
              }, 1100);
            }}
            onCanPlay={endBuffering}
            onPlaying={endBuffering}
            onPlay={() => {
              setPaused(false);
              latest.current.onPlaybackChange(true);
            }}
            onPause={() => {
              endBuffering();
              if (!scrubbing.current) {
                resumeAfterScrub.current = false;
                if (tap.current) clearTimeout(tap.current.timer);
                tap.current = null;
              }
              setPaused(true);
              latest.current.onPlaybackChange(false);
            }}
            onEnded={() => {
              latest.current.onEnd();
              seek(true);
            }}
            onError={() =>
              setError(
                deviceStreaming
                  ? 'This source could not stream to your browser. Its stream may be unavailable, expired or blocked. Try again or import an MP4.'
                  : 'This file cannot play in your browser. Use an H.264/AAC MP4 file.',
              )
            }
            disablePictureInPicture
          />
        ))}
      <canvas
        ref={transitionFrame}
        className="seek-transition-frame"
        style={{ display: 'none', pointerEvents: 'none' }}
        aria-hidden="true"
      />
      {((!ready && !preparing && checkingLong) || adaptiveLoading || buffering) && !error && (
        <div className="media-check" role="status">
          <div className="stream-loading-hint">
            <div className="stream-loading-orbit">
              <LoaderCircle className="spin" size={26} aria-hidden="true" />
            </div>
            <span className="stream-loading-eyebrow">
              {adaptiveLoading || !ready ? 'A MOMENT TO CONNECT' : 'KEEPING YOUR FLOW'}
            </span>
            <strong>
              {buffering && !adaptiveLoading ? 'Buffering your video' : 'Getting your video ready'}
            </strong>
            <p>
              {buffering && !adaptiveLoading
                ? 'Loading the next frames for smooth playback.'
                : 'Connecting to the video source and loading the first frames.'}
            </p>
            <div className="stream-loading-tip">
              <span className="stream-tip-label">
                <Lightbulb size={14} aria-hidden="true" /> QUICK TIP
              </span>
              <small>
                {adaptiveLoading || !ready
                  ? 'Double-tap the video to hide or show the controls.'
                  : BUFFER_TIPS[Math.max(0, bufferTip) % BUFFER_TIPS.length]}
              </small>
            </div>
          </div>
        </div>
      )}
      {!ready && !error && preparing && showPreparation && (
        <div className="media-status">
          <LoaderCircle className="spin" size={32} />
          <h2>Preparing your lecture</h2>
          <p>
            The first play downloads the video to your private cache. This can take a few minutes.
            Once ready, every reel uses the same file.
          </p>
        </div>
      )}
      {error && (
        <div className="media-status media-error" role="alert">
          <span className="media-error-icon">
            <CircleAlert size={26} />
          </span>
          <h2>
            {/storage|space|disk|cache/i.test(error)
              ? 'Storage needs attention'
              : 'Couldn’t prepare this video'}
          </h2>
          <p>{error}</p>
          <button
            className="button primary"
            onClick={() => {
              setReady('');
              setAttempt((n) => n + 1);
            }}
          >
            Try again
          </button>
          {/storage|space|disk|cache/i.test(error) && onOpenSettings && (
            <button className="button secondary" onClick={onOpenSettings}>
              <Settings2 size={16} /> Manage storage
            </button>
          )}
          <small>
            {/storage|space|disk|cache/i.test(error)
              ? 'Video storage is on your computer/server. Clearing phone data does not free that drive.'
              : 'You can also import an MP4 through Library.'}
          </small>
        </div>
      )}
      {paused && !scrubbing.current && ready && !error && (
        <button
          className="center-play screen-capture"
          aria-label="Capture screen note"
          disabled={capturing}
          onClick={async () => {
            const v = video.current;
            if (!v || capturing) return;
            const moment = latest.current.segment;
            const time = v.currentTime;
            setCapturing(true);
            try {
              const layout = {
                captureRotation: captureLayout.rotated ? (90 as const) : (0 as const),
                captureViewport:
                  window.innerHeight > window.innerWidth
                    ? ('portrait' as const)
                    : ('landscape' as const),
              };
              onCapture(await captureFrame(v), time, moment, layout);
            } catch (e) {
              onCaptureError(e instanceof Error ? e.message : 'Could not capture this frame.');
            } finally {
              setCapturing(false);
            }
          }}
        >
          {capturing ? (
            <LoaderCircle size={30} className="spin" />
          ) : (
            <Camera size={32} strokeWidth={2.2} />
          )}
        </button>
      )}
      {ready && !error && (
        <PlaybackSettings
          mediaVersion={activeSlot}
          controlsHidden={controlsHidden}
          video={video}
          segment={segment}
          speed={speed}
          setSpeed={setSpeed}
        />
      )}
      {ready && !error && deviceStreaming && !segment.video.local && setQuality && (
        <QualitySettings
          key={segment.id}
          video={video}
          quality={quality}
          onChange={setQuality}
          hidden={controlsHidden}
          mediaVersion={activeSlot}
        />
      )}
      {singleReel && paused && !scrubbing.current && ready && !error && (
        <button
          className="center-play saved-resume"
          aria-label="Play this saved reel"
          onClick={() => void play()}
        >
          <Play size={22} fill="currentColor" />
          <span>Play</span>
        </button>
      )}
      <div className="playback-timeline">
        <i
          style={{
            width: `${Math.max(0, Math.min(1, (position - segment.start) / (segment.end - segment.start))) * 100}%`,
          }}
        />
        <input
          type="range"
          min="0"
          max="100"
          step="0.1"
          aria-label="Reel playback position"
          aria-valuetext={`${Math.round(position - segment.start)} of ${Math.round(segment.end - segment.start)} seconds`}
          disabled={!ready || Boolean(error)}
          value={Math.max(
            0,
            Math.min(100, ((position - segment.start) / (segment.end - segment.start)) * 100),
          )}
          onPointerDown={(e) => {
            e.stopPropagation();
            releaseHold();
            if (tap.current) clearTimeout(tap.current.timer);
            tap.current = null;
            suppressTapUntil.current = Date.now() + 600;
            scrubbing.current = true;
            resumeAfterScrub.current = Boolean(video.current && !video.current.paused);
            video.current?.pause();
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerUp={finishScrub}
          onPointerCancel={finishScrub}
          onLostPointerCapture={finishScrub}
          onChange={(e) => seekPosition(Number(e.target.value))}
          onClick={(e) => e.stopPropagation()}
        />
      </div>
      {paused && !scrubbing.current && ready && !error && (
        <button
          className="sound-toggle"
          aria-label={muted ? 'Unmute video' : 'Mute video'}
          onClick={() => setMuted((m) => !m)}
        >
          {muted ? <VolumeX size={22} /> : <Volume2 size={22} />}
        </button>
      )}
    </div>
  );
}
export function AdjacentVideo({ segment }: { segment: Segment }) {
  const [available, setAvailable] = useState(prepared.has(segment.video.id));
  const layout = useContext(PlaybackLayout);
  const viewport = useViewport();
  const [dimensions, setDimensions] = useState({
    width: segment.video.width ?? 0,
    height: segment.video.height ?? 0,
  });
  const rotated =
    layout.videoId === segment.video.id
      ? layout.rotated
      : autoRotate(dimensions.width, dimensions.height, viewport.width, viewport.height);
  const fit =
    layout.videoId === segment.video.id
      ? layout.fit
      : (layout.resolve?.(segment.video)?.fit ?? true);
  const rotation =
    layout.videoId === segment.video.id
      ? layout.rotated
      : (layout.resolve?.(segment.video)?.rotated ?? rotated);
  return available && (!deviceStreaming || segment.video.local) ? (
    <video
      className={`adjacent-native-video ${rotation ? 'adjacent-rotated' : ''}`}
      style={{ objectFit: fit ? 'contain' : 'cover' }}
      src={mediaSource(segment.video.id)}
      muted
      playsInline
      preload="auto"
      onError={() => {
        prepared.delete(segment.video.id);
        setAvailable(false);
      }}
      onLoadedMetadata={(e) => {
        setDimensions({ width: e.currentTarget.videoWidth, height: e.currentTarget.videoHeight });
        e.currentTarget.currentTime = segment.start;
      }}
    />
  ) : (
    <OrientedThumbnail video={segment.video} time={segment.start} fit={fit} rotation={rotation} />
  );
}
