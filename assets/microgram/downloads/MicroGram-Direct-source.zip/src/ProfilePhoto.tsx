import { createPortal } from 'react-dom';
import { useDismissibleMenu } from './dismissibleMenu';
import { useEffect, useRef, useState } from 'react';
import { UserRound, X } from 'lucide-react';

/** Local-only circular preview; persists a bounded square JPEG for circular avatars. */
export function ProfilePhoto({
  value,
  onChange,
}: {
  value?: string;
  onChange: (photo?: string) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const image = useRef<HTMLImageElement>(null);
  const [source, setSource] = useState('');
  const crop = useRef<HTMLDivElement>(null);
  useEffect(
    () => () => {
      if (source) URL.revokeObjectURL(source);
    },
    [source],
  );
  const [error, setError] = useState('');
  const [size, setSize] = useState({ width: 1, height: 1 });
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const scale = Math.max(240 / size.width, 240 / size.height) * zoom;
  const limit = (x: number, y: number, nextZoom = zoom) => {
    const s = Math.max(240 / size.width, 240 / size.height) * nextZoom;
    return {
      x: Math.max(-(size.width * s - 240) / 2, Math.min((size.width * s - 240) / 2, x)),
      y: Math.max(-(size.height * s - 240) / 2, Math.min((size.height * s - 240) / 2, y)),
    };
  };
  const close = () => {
    URL.revokeObjectURL(source);
    setSource('');
    pointers.current.clear();
  };
  useDismissibleMenu(Boolean(source), crop, close);
  return (
    <div className="profile-photo-picker">
      <button
        type="button"
        className="profile-photo-preview"
        onClick={() => input.current?.click()}
        aria-label="Choose profile photo"
      >
        {value ? <img src={value} alt="Your profile" /> : <UserRound size={28} />}
      </button>
      <div>
        <button type="button" onClick={() => input.current?.click()}>
          {value ? 'Change photo' : 'Add profile photo'}
        </button>
        <p>Choose a photo, then move and zoom to frame it.</p>
        {value && (
          <button type="button" onClick={() => onChange(undefined)}>
            Remove photo
          </button>
        )}
      </div>
      <input
        ref={input}
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (!file) return;
          if (!file.type.startsWith('image/') || file.size > 25 * 1024 * 1024) {
            setError('Choose an image smaller than 25 MB.');
            return;
          }
          setError('');
          if (source) URL.revokeObjectURL(source);
          setZoom(1);
          setOffset({ x: 0, y: 0 });
          setSource(URL.createObjectURL(file));
        }}
      />
      {error && <p role="alert">{error}</p>}
      {source &&
        createPortal(
          <div
            className="profile-crop-overlay"
            role="dialog"
            aria-modal="true"
            aria-label="Adjust profile photo"
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                e.stopPropagation();
                close();
              }
            }}
          >
            <div ref={crop} className="profile-crop-sheet">
              <header>
                <h3>Adjust your photo</h3>
                <button type="button" onClick={close} aria-label="Cancel photo crop">
                  <X size={20} />
                </button>
              </header>
              <div className="profile-crop-frame">
                <div
                  className="profile-crop-window"
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
                  }}
                  onPointerMove={(e) => {
                    const old = pointers.current.get(e.pointerId);
                    if (!old) return;
                    const other = [...pointers.current.entries()].find(
                      ([id]) => id !== e.pointerId,
                    )?.[1];
                    if (other) {
                      const before = Math.hypot(old.x - other.x, old.y - other.y);
                      const after = Math.hypot(e.clientX - other.x, e.clientY - other.y);
                      const next = Math.max(1, Math.min(4, (zoom * after) / Math.max(1, before)));
                      setZoom(next);
                      setOffset(limit(offset.x, offset.y, next));
                    } else
                      setOffset(limit(offset.x + e.clientX - old.x, offset.y + e.clientY - old.y));
                    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
                  }}
                  onPointerUp={(e) => pointers.current.delete(e.pointerId)}
                  onPointerCancel={(e) => pointers.current.delete(e.pointerId)}
                >
                  <img
                    ref={image}
                    src={source}
                    alt="Move to position your profile photo"
                    draggable={false}
                    onLoad={(e) =>
                      setSize({
                        width: e.currentTarget.naturalWidth,
                        height: e.currentTarget.naturalHeight,
                      })
                    }
                    onError={() => {
                      setError('This image could not be opened. Choose another photo.');
                      close();
                    }}
                    style={{
                      width: size.width * scale,
                      height: size.height * scale,
                      transform: `translate(-50%,-50%) translate(${offset.x}px,${offset.y}px)`,
                    }}
                  />
                </div>
              </div>
              <label className="profile-zoom">
                Zoom
                <input
                  type="range"
                  min="1"
                  max="4"
                  step="0.01"
                  value={zoom}
                  onChange={(e) => {
                    const z = Number(e.target.value);
                    setZoom(z);
                    setOffset(limit(offset.x, offset.y, z));
                  }}
                />
              </label>
              <div className="profile-crop-actions">
                <button type="button" className="button secondary" onClick={close}>
                  Cancel
                </button>
                <button
                  className="button primary full"
                  type="button"
                  onClick={() => {
                    if (!image.current?.naturalWidth) return;
                    const canvas = document.createElement('canvas');
                    canvas.width = 384;
                    canvas.height = 384;
                    const ctx = canvas.getContext('2d');
                    if (!ctx) return;
                    ctx.drawImage(
                      image.current,
                      (size.width - 240 / scale) / 2 - offset.x / scale,
                      (size.height - 240 / scale) / 2 - offset.y / scale,
                      240 / scale,
                      240 / scale,
                      0,
                      0,
                      384,
                      384,
                    );
                    onChange(canvas.toDataURL('image/jpeg', 0.85));
                    close();
                  }}
                >
                  Use photo
                </button>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
