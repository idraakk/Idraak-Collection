import { useMemo, useState } from 'react';
import { Clock3, CheckCheck, Flame, Layers3, Target } from 'lucide-react';
import { LectureInsightRow } from './LectureInsights';
import { learningInsights } from './insights';
import type { State } from './storage';
const minutes = (seconds: number) =>
  seconds < 60 && seconds > 0 ? '<1' : Math.floor(seconds / 60).toLocaleString();
export function Insights({ state }: { state: State }) {
  const [days, setDays] = useState(7);
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set());
  const data = useMemo(() => learningInsights(state, days), [state, days]);
  const max = Math.max(state.goal * 60, ...data.dates.map((d) => d.seconds), 1);
  const percent = data.duration ? Math.round((data.covered / data.duration) * 100) : 0;
  const today = data.dates.at(-1)!;
  const allExpanded =
    data.courses.length > 0 && data.courses.every((item) => expanded.has(item.course.id));
  return (
    <section className="insights-page" aria-label="Learning insights">
      <header className="utility-heading">
        <div>
          <span className="utility-kicker">YOUR LEARNING, IN VIEW</span>
          <h1>Insights</h1>
        </div>
      </header>
      <div className="insights-period" role="group" aria-label="Insights period">
        {[1, 7, 30].map((n) => (
          <button key={n} aria-pressed={days === n} onClick={() => setDays(n)}>
            {n === 1 ? 'Today' : `Last ${n} days`}
          </button>
        ))}
      </div>
      <div className="insight-metrics">
        <article>
          <Clock3 size={20} />
          <strong>
            {minutes(data.periodSeconds)}
            <small> min</small>
          </strong>
          <span>Video time played</span>
          <p>Includes replays</p>
        </article>
        <article>
          <Flame size={20} />
          <strong>
            {data.activeDays}
            <small> / {days}</small>
          </strong>
          <span>Days you learned</span>
          <p>{data.streak ? `${data.streak}-day current streak` : 'Your next day starts here'}</p>
        </article>
        <article>
          <CheckCheck size={20} />
          <strong>
            {data.goalDays}
            <small> days</small>
          </strong>
          <span>Daily goal reached</span>
          <p>{state.goal} minutes of video per day</p>
        </article>
      </div>
      <section className="insight-card rhythm-card">
        <div className="insight-section-title">
          <div>
            <h2>Your rhythm</h2>
            <p>
              {today.seconds > 0
                ? `${minutes(today.seconds)} video minutes today`
                : 'No video time recorded today yet'}
            </p>
          </div>
          <span>
            {data.activeDays} active {data.activeDays === 1 ? 'day' : 'days'}
          </span>
        </div>
        <div
          className="rhythm-goal-summary"
          aria-label={`Daily learning goal: ${state.goal} minutes`}
        >
          <Target size={16} aria-hidden="true" />
          <span>Daily learning goal</span>
          <strong>{state.goal} min/day</strong>
        </div>
        <div
          className={`rhythm-chart ${days === 30 ? 'month' : ''}`}
          role="img"
          aria-label={`Daily video minutes: ${data.dates.map((d) => `${d.key}: ${minutes(d.seconds)}`).join(', ')}`}
        >
          {data.dates.map((d, i) => (
            <div key={d.key} title={`${d.key}: ${minutes(d.seconds)} min`}>
              <span>{days <= 7 ? minutes(d.seconds) : ''}</span>
              <div className="rhythm-track">
                <i
                  className={d.seconds >= state.goal * 60 ? 'goal-met' : ''}
                  style={{ height: `${Math.max(d.seconds ? 3 : 0, (d.seconds / max) * 100)}%` }}
                />
              </div>
              <small>{days <= 7 ? d.label : i % 5 === 0 ? d.key.slice(-2) : ''}</small>
            </div>
          ))}
        </div>
        <div className="chart-caption">
          <span>
            <i /> Video time played
          </span>
          <span>Brighter bars reached your daily goal</span>
        </div>
      </section>
      <section className="insight-card coverage-card">
        <div className="insight-section-title">
          <div>
            <h2>What you’ve covered</h2>
            <p>Across your current library · all time</p>
          </div>
          <Layers3 size={20} />
        </div>
        <div className="coverage-total">
          <strong>
            {percent}
            <small>%</small>
          </strong>
          <div>
            <span>
              {minutes(data.covered)} of {minutes(data.duration)} video minutes
            </span>
            <p>{minutes(data.remaining)} min left to explore</p>
          </div>
        </div>
        <div
          className="insight-progress"
          role="progressbar"
          aria-label="Library video coverage"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={percent}
        >
          <i style={{ width: `${percent}%` }} />
        </div>
        <div className="coverage-facts">
          <span>
            <strong>
              {data.completed}/{data.totalReels}
            </strong>{' '}
            reels completed
          </span>
          <span>
            <strong>{data.uniqueVideos}</strong> unique lectures
          </span>
        </div>
      </section>
      <div className="insight-section-title lecture-insights-title">
        <div>
          <h2>Lecture by lecture</h2>
        </div>
        {data.courses.length > 0 && (
          <button
            className="lecture-expand-all"
            onClick={() =>
              setExpanded(
                allExpanded ? new Set() : new Set(data.courses.map((item) => item.course.id)),
              )
            }
          >
            {allExpanded ? 'Collapse all' : 'Expand all'}
          </button>
        )}
      </div>
      <div className="lecture-insights">
        {data.courses.map((item) => (
          <LectureInsightRow
            key={item.course.id}
            state={state}
            item={item}
            days={days}
            open={expanded.has(item.course.id)}
            onToggle={() =>
              setExpanded((current) => {
                const next = new Set(current);
                if (next.has(item.course.id)) next.delete(item.course.id);
                else next.add(item.course.id);
                return next;
              })
            }
          />
        ))}
      </div>
      {!data.courses.length && (
        <div className="insight-card insights-empty">
          <h2>Your story starts with a lecture</h2>
          <p>Add a video or playlist in Library. Your learning will appear here as you watch.</p>
        </div>
      )}
      <details className="insight-method">
        <summary>How these numbers work</summary>
        <p>
          Video time measures playback along the lecture timeline, including replays, rather than
          time on the clock. Coverage counts each watched second once, even if a lecture appears in
          multiple playlists. A reel is completed at 90% watched. Changing reel length changes reel
          counts while keeping watched seconds. Daily goal counts use your current goal. Your data
          is stored on this device.
        </p>
      </details>
    </section>
  );
}
