import { useEffect, useRef, useState, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { SlidersHorizontal, Check, ChevronDown } from 'lucide-react';
import { qualityPlayers, type VideoQuality } from './videoQuality';
import { useDismissibleMenu } from './dismissibleMenu';

export function QualitySettings({
  video,
  quality,
  onChange,
  hidden,
  mediaVersion,
}: {
  video: RefObject<HTMLVideoElement | null>;
  quality: VideoQuality;
  onChange: (quality: VideoQuality) => void;
  hidden: boolean;
  mediaVersion: number;
}) {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState({ height: 0, heights: [] as number[] });
  const panel = useRef<HTMLDivElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  useDismissibleMenu(open, panel, () => setOpen(false));
  useEffect(() => {
    const update = () => {
      const current = video.current && qualityPlayers.get(video.current)?.();
      if (current) setStatus({ height: current.height, heights: current.heights });
    };
    update();
    const timer = setInterval(update, 800);
    return () => clearInterval(timer);
  }, [video, mediaVersion]);
  useEffect(() => {
    setOpen(false);
  }, [hidden, mediaVersion]);
  const label =
    quality === 'auto'
      ? 'Auto'
      : quality === 'high'
        ? 'HD'
        : quality === 'saver'
          ? 'Data'
          : `${quality}p`;
  const choices: { value: VideoQuality; label: string }[] = [
    { value: 'auto', label: 'Automatic' },
    { value: 'high', label: 'Higher picture quality' },
    { value: 'saver', label: 'Data saver' },
    ...status.heights
      .filter((height) => ['1080', '720', '480', '360', '240', '144'].includes(String(height)))
      .map((height) => ({ value: String(height) as VideoQuality, label: `Up to ${height}p` })),
  ];
  return (
    <>
      {createPortal(
        <button
          ref={toggle}
          className="quality-toggle"
          aria-label="Video quality"
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
        >
          <SlidersHorizontal size={28} strokeWidth={2.4} />
          <span>{label}</span>
        </button>,
        document.getElementById('reel-quality-slot') ?? document.body,
      )}
      {open && (
        <div
          ref={panel}
          className="playback-settings-panel quality-panel"
          onKeyDown={(event) => {
            event.stopPropagation();
            if (event.key === 'Escape') setOpen(false);
          }}
        >
          <details className="setting-choice" open>
            <summary>
              Video quality <ChevronDown size={16} />
            </summary>
            <div role="group" aria-label="Video quality">
              {choices.map((choice) => (
                <button
                  key={choice.value}
                  aria-pressed={choice.value === quality}
                  onClick={() => onChange(choice.value)}
                >
                  {choice.label}
                  {choice.value === quality && <Check size={16} />}
                </button>
              ))}
            </div>
          </details>
          <p className="quality-status">
            {status.height ? `Playing at ${status.height}p · ` : ''}Adapts to your connection
          </p>
          <button onClick={() => setOpen(false)}>Done</button>
        </div>
      )}
    </>
  );
}
