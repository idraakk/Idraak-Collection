import { Clock3 } from 'lucide-react';
import { clock, type Segment } from './core';
/** The same geometry and typography during a swipe and after activation. */
export function ReelOverlay({
  segment,
  index,
  total,
  profileLink = false,
  profileTitle,
  onProfile,
  onContinue,
  preview = false,
}: {
  segment: Segment;
  index: number;
  total: number;
  profileLink?: boolean;
  profileTitle?: string;
  onProfile?: () => void;
  onContinue?: () => void;
  preview?: boolean;
}) {
  return (
    <>
      <div className="reel-top">
        <span className="reel-counter">
          {index + 1}
          <span> / {total}</span>
        </span>
      </div>
      <div className="reel-bottom">
        <div className="creator-row compact-reel-caption">
          <span className="creator-avatar" title={segment.video.channel}>
            <img
              src={segment.video.thumbnail}
              alt=""
              onError={(event) => {
                event.currentTarget.onerror = null;
                event.currentTarget.src = '/local-cover.svg';
              }}
            />
          </span>
          <div>
            <strong>
              {profileLink ? (
                <button
                  className="compact-reel-title reel-profile-link"
                  title={segment.video.title}
                  aria-label={`Open ${profileTitle ?? segment.video.title} learning profile`}
                  tabIndex={preview ? -1 : undefined}
                  onClick={onProfile}
                >
                  {segment.video.title}
                </button>
              ) : (
                <span className="compact-reel-title" title={segment.video.title}>
                  {segment.video.title}
                </span>
              )}
            </strong>
          </div>
        </div>
        <div className="segment-meta">
          <span>
            <Clock3 size={13} /> {clock(segment.start)}–{clock(segment.end)}
          </span>
          {onContinue ? (
            <button
              className="continue-lecture"
              tabIndex={preview ? -1 : undefined}
              onClick={onContinue}
            >
              Continue lecture
            </button>
          ) : (
            <span>{Math.ceil(segment.end - segment.start)} second reel</span>
          )}
        </div>
      </div>
    </>
  );
}
