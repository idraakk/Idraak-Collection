import {
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from 'react';
import { flushSync } from 'react-dom';
import { AdjacentVideo } from './Player';
import { Clapperboard, Play } from 'lucide-react';
import { clock, type Segment } from './core';
import { deviceAngle, reelSwipe, type TouchPoint } from './reelGesture';

export type ReelPagerControl = { navigate: (delta: number) => void };
type Motion = { distance: number; extent: number; angle: number; settling: boolean };
const resting: Motion = { distance: 0, extent: 0, angle: 0, settling: false };
function vector(angle: number) {
  const a = ((angle % 360) + 360) % 360;
  return a === 90 ? [-1, 0] : a === 270 ? [1, 0] : a === 180 ? [0, 1] : [0, -1];
}
function distance(start: TouchPoint, end: TouchPoint, angle: number) {
  const [x, y] = vector(angle);
  return (end.x - start.x) * x + (end.y - start.y) * y;
}

/** Adjacent cover panels move beside the original live player, never over it. */
export function ReelPager({
  children,
  index,
  reels,
  controlRef,
  onNavigate,
  onBusy,
  onPrepare,
  renderPreview,
}: {
  children: ReactNode;
  index: number;
  reels: Segment[];
  controlRef: RefObject<ReelPagerControl | null>;
  onNavigate: (delta: number) => void;
  onBusy: (busy: boolean) => void;
  onPrepare?: (next: Segment) => void;
  renderPreview?: (segment: Segment, index: number) => ReactNode;
}) {
  const viewport = useRef<HTMLDivElement>(null);
  const [motion, setMotion] = useState<Motion>(resting);
  const live = useRef(resting);
  const gesture = useRef<{ point: TouchPoint; angle: number } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const locked = useRef(false);
  const suppressClick = useRef(false);
  const wheelAt = useRef(0);
  const latest = useRef({ index, reels, onNavigate, onBusy, onPrepare });
  latest.current = { index, reels, onNavigate, onBusy, onPrepare };
  function update(m: Motion) {
    live.current = m;
    setMotion(m);
  }
  function extent(angle: number) {
    const rect = viewport.current?.getBoundingClientRect();
    return Math.max(1, Math.abs(vector(angle)[0]) ? (rect?.width ?? 1) : (rect?.height ?? 1));
  }
  function settle(delta: number, angle = live.current.angle) {
    if (locked.current || latest.current.reels.length <= 1) return;
    const valid =
      latest.current.index + delta >= 0 &&
      latest.current.index + delta < latest.current.reels.length;
    const direction = valid ? Math.sign(delta) : 0;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    locked.current = true;
    latest.current.onBusy(true);
    if (direction)
      latest.current.onPrepare?.(latest.current.reels[latest.current.index + direction]);
    const finish = () => {
      if (direction) latest.current.onNavigate(direction);
      update(resting);
      locked.current = false;
      latest.current.onBusy(false);
    };
    if (reduced) {
      finish();
      return;
    }
    const size = extent(angle);
    // Establish the adjacent panel offscreen before transitioning both panels together.
    flushSync(() =>
      update({ distance: live.current.distance, extent: size, angle, settling: false }),
    );
    viewport.current?.getBoundingClientRect();
    update({ distance: direction * size, extent: size, angle, settling: true });
    timer.current = setTimeout(finish, 280);
  }
  useImperativeHandle(controlRef, () => ({ navigate: (delta) => settle(delta, deviceAngle()) }));
  useEffect(() => {
    const cancel = () => {
      clearTimeout(timer.current);
      gesture.current = null;
      locked.current = false;
      update(resting);
      latest.current.onBusy(false);
    };
    window.addEventListener('resize', cancel);
    return () => {
      clearTimeout(timer.current);
      window.removeEventListener('resize', cancel);
      latest.current.onBusy(false);
    };
  }, []);
  const [vx, vy] = vector(motion.angle);
  function style(offset: number) {
    return {
      transform: `translate3d(${vx * offset}px,${vy * offset}px,0)`,
      transition: motion.settling ? 'transform 280ms cubic-bezier(.22,.75,.22,1)' : 'none',
    };
  }
  return (
    <div
      ref={viewport}
      className="reel-viewport"
      data-moving={motion.distance !== 0 || motion.settling}
      onClickCapture={(e) => {
        if (suppressClick.current) {
          e.preventDefault();
          e.stopPropagation();
          suppressClick.current = false;
        }
      }}
      onTouchStart={(e) => {
        if (locked.current || reels.length <= 1 || e.touches.length !== 1) return;
        const target = (e.target as HTMLElement).closest(
          'button,a,input,textarea,select,.playback-settings-panel',
        );
        if (target && !target.classList.contains('lesson-preview')) return;
        suppressClick.current = false;
        gesture.current = {
          point: { x: e.touches[0].clientX, y: e.touches[0].clientY },
          angle: deviceAngle(),
        };
        update({ ...resting, angle: gesture.current.angle, extent: extent(gesture.current.angle) });
      }}
      onTouchMove={(e) => {
        if (viewport.current?.querySelector('.personal-player[data-boosting="true"]')) {
          gesture.current = null;
          suppressClick.current = true;
          update(resting);
          return;
        }
        const g = gesture.current;
        if (!g || locked.current) return;
        if (e.touches.length !== 1) {
          gesture.current = null;
          settle(0);
          return;
        }
        const end = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        const d = distance(g.point, end, g.angle);
        const cross = Math.abs(vector(g.angle)[0])
          ? Math.abs(end.y - g.point.y)
          : Math.abs(end.x - g.point.x);
        if (Math.abs(d) < 8 || cross > Math.abs(d) * 1.2) return;
        suppressClick.current = true;
        latest.current.onBusy(true);
        const blocked =
          d > 0
            ? latest.current.index === latest.current.reels.length - 1
            : latest.current.index === 0;
        const size = extent(g.angle);
        update({
          distance: Math.max(-size, Math.min(size, blocked ? d * 0.18 : d)),
          extent: size,
          angle: g.angle,
          settling: false,
        });
      }}
      onTouchEnd={(e) => {
        const g = gesture.current;
        gesture.current = null;
        if (!g || locked.current) return;
        const end = { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
        const delta = reelSwipe(g.point, end, g.angle);
        if (delta || live.current.distance) settle(delta, g.angle);
      }}
      onTouchCancel={() => {
        gesture.current = null;
        if (!locked.current) settle(0);
      }}
      onWheel={(e) => {
        if (Math.abs(e.deltaY) > 35 && Date.now() - wheelAt.current > 500 && !locked.current) {
          wheelAt.current = Date.now();
          settle(e.deltaY > 0 ? 1 : -1, 0);
        }
      }}
    >
      <div className="reel-current-panel" style={style(motion.distance)}>
        {children}
      </div>
      {motion.extent > 0 &&
        [-1, 1].map((delta) => {
          const reel = reels[index + delta];
          return reel ? (
            <div
              key={delta}
              className="reel-adjacent-panel"
              aria-hidden="true"
              style={style(motion.distance - delta * motion.extent)}
            >
              <AdjacentVideo key={reel.video.id} segment={reel} />
              {renderPreview ? (
                renderPreview(reel, index + delta)
              ) : (
                <>
                  <span className="adjacent-count">
                    <Clapperboard size={17} /> REEL {index + delta + 1} / {reels.length}
                  </span>
                  <div>
                    <span>
                      LECTURE {reel.videoIndex + 1} · {reel.video.channel}
                    </span>
                    <h2>{reel.video.title}</h2>
                    <p>
                      <Play size={14} /> {clock(reel.start)}–{clock(reel.end)}
                    </p>
                    <small>Lecture cover · playback continues at this timestamp</small>
                  </div>
                </>
              )}
            </div>
          ) : null;
        })}
    </div>
  );
}
