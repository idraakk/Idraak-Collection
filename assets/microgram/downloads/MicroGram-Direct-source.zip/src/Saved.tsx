import { useRef } from 'react';
import { SavedSectionPager, type SavedSectionControl } from './SavedSectionPager';
import { Bookmark, BookOpen, Clapperboard, Play, ArrowUpRight, Camera } from 'lucide-react';
import type { ScreenNote } from './storage';
import { ScreenNotes } from './CapturedNotes';
import { clock } from './core';
import { OrientedThumbnail } from './OrientedThumbnail';
import type { SavedMoment } from './savedMoments';
import type { Course } from './core';
export function Saved({
  reels,
  notes,
  section,
  onSection,
  onOpen,
  hidden,
  screenNotes,
  selectedScreenVideo,
  onScreenVideo,
  onScreenNote,
  onDeleteAlbum,
  onDeletePhoto,
  onPlayScreenNote,
  courses,
}: {
  reels: SavedMoment[];
  notes: SavedMoment[];
  section: 'reels' | 'notes' | 'screens';
  onSection: (section: 'reels' | 'notes' | 'screens') => void;
  onOpen: (item: SavedMoment, notes?: boolean) => void;
  hidden: boolean;
  screenNotes: ScreenNote[];
  selectedScreenVideo: string | null;
  onScreenVideo: (video: string | null) => void;
  onScreenNote: (note: ScreenNote) => void;
  onDeleteAlbum: (videoId: string) => Promise<void>;
  onDeletePhoto: (id: string) => Promise<void>;
  onPlayScreenNote: (note: ScreenNote) => void;
  courses: Course[];
}) {
  const albumOpen = section === 'screens' && Boolean(selectedScreenVideo);
  const sections = ['screens', 'notes', 'reels'] as const;
  const pager = useRef<SavedSectionControl | null>(null);
  const renderPanel = (selected: typeof section) =>
    selected === 'reels' ? (
      <div id="saved-reels-panel" role="tabpanel" aria-labelledby="saved-reels-tab">
        <div className="saved-reel-grid">
          {reels.map((item) => (
            <button
              key={item.segment.id}
              className="saved-reel-tile"
              onClick={() => onOpen(item)}
              aria-label={`Watch saved reel: ${item.segment.video.title}, ${clock(item.segment.start)}`}
            >
              <OrientedThumbnail video={item.segment.video} />
              <Clapperboard size={17} className="saved-tile-kind" />
              <div>
                <strong>{item.segment.video.title}</strong>
                <span>
                  {clock(item.segment.start)}–{clock(item.segment.end)}
                </span>
              </div>
            </button>
          ))}
        </div>
        {!reels.length && (
          <div className="saved-empty">
            <Bookmark size={30} />
            <h2>Keep a moment worth returning to</h2>
            <p>Bookmark a reel while watching. It will appear here.</p>
          </div>
        )}
      </div>
    ) : selected === 'screens' ? (
      <ScreenNotes
        courses={courses}
        notes={screenNotes}
        selectedVideo={selectedScreenVideo}
        onSelect={onScreenVideo}
        onOpen={onScreenNote}
        onDeleteAlbum={onDeleteAlbum}
        onDeletePhoto={onDeletePhoto}
        onPlay={onPlayScreenNote}
      />
    ) : (
      <div
        id="saved-notes-panel"
        role="tabpanel"
        aria-labelledby="saved-notes-tab"
        className="saved-note-list"
      >
        {notes.map((item) => (
          <article key={item.segment.id}>
            <button
              className="note-video-link"
              onClick={() => onOpen(item)}
              aria-label={`Watch note video: ${item.segment.video.title}, ${clock(item.segment.start)}`}
            >
              <img src={item.segment.video.thumbnail} alt="" />
              <div>
                <h2>{item.segment.video.title}</h2>
                <span>
                  {clock(item.segment.start)}–{clock(item.segment.end)} ·{' '}
                  {item.segment.video.channel}
                </span>
              </div>
              <Play size={17} />
            </button>
            <p>{item.note}</p>
            <button className="read-note" onClick={() => onOpen(item, true)}>
              Open note <ArrowUpRight size={15} />
            </button>
          </article>
        ))}
        {!notes.length && (
          <div className="saved-empty">
            <BookOpen size={30} />
            <h2>Your ideas belong here</h2>
            <p>Add a note to a reel. Find it here with a link to that moment.</p>
          </div>
        )}
      </div>
    );
  return (
    <section className="saved-page" aria-label="Saved moments and notes" hidden={hidden}>
      {!albumOpen && (
        <>
          <header className="utility-heading">
            <div>
              <span className="utility-kicker">YOUR COLLECTION</span>
              <h1>Saved</h1>
            </div>
            <Bookmark size={23} />
          </header>
          <div className="saved-sections" role="tablist" aria-label="Saved sections">
            {[
              {
                id: 'screens',
                label: 'Screen Notes',
                icon: Camera,
                count: screenNotes.length,
                prefix: 'screen',
              },
              { id: 'notes', label: 'Notes', icon: BookOpen, count: notes.length, prefix: 'notes' },
              {
                id: 'reels',
                label: 'Reels',
                icon: Clapperboard,
                count: reels.length,
                prefix: 'reels',
              },
            ].map(({ id, label, icon: Icon, count, prefix }) => (
              <button
                key={id}
                role="tab"
                id={`saved-${prefix}-tab`}
                aria-controls={`saved-${prefix}-panel`}
                aria-selected={section === id}
                onClick={() => pager.current?.select(sections.indexOf(id as typeof section))}
              >
                <Icon size={17} />
                {label}
                <span>{count}</span>
              </button>
            ))}
          </div>
        </>
      )}
      <SavedSectionPager
        index={sections.indexOf(section)}
        enabled={!albumOpen && !hidden}
        onChange={(at) => onSection(sections[at])}
        render={(at) => renderPanel(sections[at])}
        control={pager}
      />
    </section>
  );
}
