import {
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from 'react';
import { flushSync } from 'react-dom';
import { hasActiveMenu } from './dismissibleMenu';
export type SavedSectionControl = { select: (index: number) => void };
export function SavedSectionPager({
  index,
  enabled,
  onChange,
  render,
  control,
}: {
  index: number;
  enabled: boolean;
  onChange: (index: number) => void;
  render: (index: number) => ReactNode;
  control: RefObject<SavedSectionControl | null>;
}) {
  const host = useRef<HTMLDivElement>(null);
  const [motion, setMotion] = useState({ x: 0, moving: false, settling: false, width: 1 });
  const live = useRef(motion);
  live.current = motion;
  const gesture = useRef<{ x: number; y: number } | null>(null);
  const [height, setHeight] = useState(0);
  useEffect(() => {
    const root = host.current;
    if (!root) return;
    const measure = () =>
      setHeight(
        Math.max(
          ...Array.from(
            root.querySelectorAll<HTMLElement>('.saved-swipe-panel'),
            (child) => child.scrollHeight,
          ),
        ),
      );
    const observer = new ResizeObserver(measure);
    Array.from(root.querySelectorAll<HTMLElement>('.saved-swipe-panel')).forEach((child) =>
      observer.observe(child),
    );
    measure();
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const tabs = host.current?.parentElement?.querySelector<HTMLElement>('.saved-sections');
    if (!tabs) return;
    tabs.style.setProperty('--saved-position', String(index - motion.x / motion.width));
    tabs.style.setProperty(
      '--saved-transition',
      motion.settling ? 'transform 220ms cubic-bezier(.22,.7,.28,1)' : 'none',
    );
  }, [index, motion]);
  const target = useRef<number | null>(null);
  const entryOffset = useRef(0);
  const contentTop = () => (host.current?.getBoundingClientRect().top ?? 0) + window.scrollY;
  const begin = () => {
    entryOffset.current = Math.max(0, window.scrollY - contentTop());
  };
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const suppress = useRef(false);
  const latest = useRef({ index, onChange });
  latest.current = { index, onChange };
  const finish = () => {
    const next = target.current;
    target.current = null;
    clearTimeout(timer.current);
    if (next !== null && next !== latest.current.index)
      window.scrollTo({ top: Math.min(window.scrollY, contentTop()), behavior: 'instant' });
    flushSync(() => {
      if (next !== null && next !== latest.current.index) latest.current.onChange(next);
      const reset = { ...live.current, x: 0, moving: false, settling: false };
      live.current = reset;
      setMotion(reset);
    });
  };
  const settle = (next: number) => {
    if (target.current !== null) return;
    next = Math.max(0, Math.min(2, next));
    const width = host.current?.clientWidth ?? 1;
    target.current = next;
    const settled = {
      x: (latest.current.index - next) * width,
      width,
      moving: true,
      settling: true,
    };
    live.current = settled;
    setMotion(settled);
    timer.current = setTimeout(
      finish,
      matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 230,
    );
  };
  useEffect(() => {
    const root = host.current;
    if (!root) return;
    const observer = new ResizeObserver(() =>
      setMotion((value) => ({ ...value, width: root.clientWidth })),
    );
    observer.observe(root);
    return () => observer.disconnect();
  }, []);
  useImperativeHandle(control, () => ({
    select: (next) => {
      if (enabled && next !== index) {
        begin();
        settle(next);
      }
    },
  }));
  useEffect(() => () => clearTimeout(timer.current), []);
  return (
    <div
      ref={host}
      className="saved-swipe-viewport"
      data-moving={motion.moving}
      style={{
        minHeight: Math.max(
          height,
          typeof window === 'undefined'
            ? 0
            : window.innerHeight - Math.max(0, host.current?.getBoundingClientRect().top ?? 0) - 64,
        ),
      }}
      onClickCapture={(event) => {
        if (suppress.current) {
          event.preventDefault();
          event.stopPropagation();
          suppress.current = false;
        }
      }}
      onPointerDown={(event) => {
        if (
          !enabled ||
          target.current !== null ||
          hasActiveMenu() ||
          !event.isPrimary ||
          (event.target as HTMLElement).closest('input,textarea,select,[role=menu]')
        )
          return;
        suppress.current = false;
        begin();
        gesture.current = { x: event.clientX, y: event.clientY };
      }}
      onPointerMove={(event) => {
        const start = gesture.current;
        if (!start) return;
        let x = event.clientX - start.x;
        const y = event.clientY - start.y;
        if (!live.current.moving && Math.abs(y) > 10 && Math.abs(y) > Math.abs(x) * 1.1) {
          gesture.current = null;
          return;
        }
        if (!live.current.moving && (Math.abs(x) < 8 || Math.abs(x) < Math.abs(y) * 1.2)) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        suppress.current = true;
        if ((index === 0 && x > 0) || (index === 2 && x < 0)) x *= 0.16;
        const width = host.current?.clientWidth ?? 1;
        const next = {
          x: Math.max(-width, Math.min(width, x)),
          width,
          moving: true,
          settling: false,
        };
        live.current = next;
        setMotion(next);
      }}
      onPointerUp={() => {
        if (!gesture.current) return;
        gesture.current = null;
        if (live.current.moving)
          settle(
            index +
              (Math.abs(live.current.x) > Math.min(72, live.current.width * 0.18)
                ? live.current.x < 0
                  ? 1
                  : -1
                : 0),
          );
      }}
      onPointerCancel={() => {
        gesture.current = null;
        if (live.current.moving && target.current === null) settle(index);
      }}
    >
      <div
        className="saved-swipe-track"
        style={{
          transform: `translate3d(${-index * motion.width + motion.x}px,0,0)`,
          transition: motion.settling ? 'transform 220ms cubic-bezier(.22,.7,.28,1)' : 'none',
        }}
      >
        {[0, 1, 2].map((at) => (
          <div
            key={at}
            className={`saved-swipe-panel${at === index ? ' current' : ''}`}
            data-offscreen={!motion.moving && at !== index}
            inert={at !== index}
            aria-hidden={at !== index}
            style={{
              transform:
                motion.moving && at !== index ? `translateY(${entryOffset.current}px)` : 'none',
            }}
          >
            {render(at)}
          </div>
        ))}
      </div>
    </div>
  );
}
