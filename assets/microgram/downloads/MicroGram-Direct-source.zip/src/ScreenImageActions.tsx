import { useEffect, useRef, useState, type ReactNode } from 'react';
import { MoreVertical, Trash2, Play } from 'lucide-react';
import type { ScreenNote } from './storage';
import { ConfirmAction } from './ConfirmAction';
import { useDismissibleMenu } from './dismissibleMenu';

export function ScreenAlbumActions({
  notes,
  onDelete,
}: {
  notes: ScreenNote[];
  onDelete: (videoId: string) => Promise<void>;
}) {
  const [open, setOpen] = useState(false),
    [confirm, setConfirm] = useState(false);
  const [above, setAbove] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  useDismissibleMenu(open, menu, () => setOpen(false));
  return (
    <div
      className="screen-actions"
      ref={root}
      onKeyDown={(e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          setOpen(false);
          root.current?.querySelector('button')?.focus();
        }
      }}
    >
      <button
        className="screen-album-options"
        aria-label={`Album options: ${notes[0].videoTitle}`}
        aria-expanded={open}
        aria-haspopup="menu"
        onClick={() => {
          const bottom = root.current?.getBoundingClientRect().bottom ?? 0;
          const nav = document.querySelector('.mobile-nav')?.getBoundingClientRect().height ?? 0;
          setAbove(bottom + 64 > innerHeight - nav);
          setOpen((o) => !o);
        }}
      >
        <MoreVertical size={21} />
      </button>
      {open && (
        <div
          ref={menu}
          className={`screen-album-menu${above ? ' opens-up' : ''}`}
          role="menu"
          aria-label="Album options"
        >
          <button
            role="menuitem"
            className="screen-delete-all"
            onClick={() => {
              setOpen(false);
              setConfirm(true);
            }}
          >
            <Trash2 size={17} />
            Delete all images
          </button>
        </div>
      )}
      {confirm && (
        <ConfirmAction
          title="Delete this Screen Notes album?"
          description={`Delete all ${notes.length} images, labels and notes for “${notes[0].videoTitle}” from this device?`}
          action="Delete all images"
          onClose={() => setConfirm(false)}
          onConfirm={() => onDelete(notes[0].videoId)}
        />
      )}
    </div>
  );
}

export function ScreenNoteTile({
  note,
  children,
  onOpen,
  onDelete,
  onPlay,
}: {
  note: ScreenNote;
  children: ReactNode;
  onOpen: () => void;
  onDelete: (id: string) => Promise<void>;
  onPlay: () => void;
}) {
  const [open, setOpen] = useState(false),
    [confirm, setConfirm] = useState(false);
  const root = useRef<HTMLElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const start = useRef({ x: 0, y: 0 });
  const held = useRef(false);
  function cancel() {
    clearTimeout(timer.current);
  }
  function show() {
    cancel();
    held.current = true;
    setOpen(true);
  }
  useEffect(() => () => clearTimeout(timer.current), []);
  const menu = useRef<HTMLDivElement>(null);
  useDismissibleMenu(open, menu, () => setOpen(false), true);
  return (
    <article
      className="screen-note-card"
      ref={root}
      onKeyDown={(e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          setOpen(false);
        }
      }}
    >
      <button
        className="screen-note-open"
        aria-haspopup="menu"
        onClick={() => {
          if (held.current) return;
          onOpen();
        }}
        onPointerDown={(e) => {
          if (!e.isPrimary || e.button !== 0) return;
          cancel();
          held.current = false;
          start.current = { x: e.clientX, y: e.clientY };
          timer.current = setTimeout(show, 500);
        }}
        onPointerMove={(e) => {
          if (Math.hypot(e.clientX - start.current.x, e.clientY - start.current.y) > 10) cancel();
        }}
        onPointerUp={cancel}
        onPointerCancel={cancel}
        onLostPointerCapture={cancel}
        onContextMenu={(e) => {
          e.preventDefault();
          show();
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') held.current = false;
          if (e.key === 'ContextMenu' || (e.shiftKey && e.key === 'F10')) {
            e.preventDefault();
            show();
          }
        }}
      >
        {children}
      </button>
      {open && (
        <div ref={menu} className="screen-photo-menu" role="menu" aria-label="Photo options">
          <button
            role="menuitem"
            className="screen-play-moment"
            onClick={() => {
              setOpen(false);
              onPlay();
            }}
          >
            <Play size={16} />
            Open reel at this frame
          </button>
          <button
            role="menuitem"
            onClick={() => {
              setOpen(false);
              setConfirm(true);
            }}
          >
            <Trash2 size={16} />
            Delete photo
          </button>
        </div>
      )}
      {confirm && (
        <ConfirmAction
          title="Delete this photo?"
          description="This removes this captured image, its label and note from this device."
          action="Delete photo"
          onClose={() => setConfirm(false)}
          onConfirm={() => onDelete(note.id)}
        />
      )}
    </article>
  );
}
