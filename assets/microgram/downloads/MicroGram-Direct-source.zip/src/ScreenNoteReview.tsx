import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import { photoPanBounds, clampPhotoPan } from './photoZoom';
import { ArrowLeft, ChevronLeft, ChevronRight, Pencil, RotateCw } from 'lucide-react';
import { clock } from './core';
import type { ScreenNote } from './storage';
import { ScreenFrame, ScreenNoteEditor } from './CapturedNotes';
import { screenNoteTurn } from './screenNotes';
import { useViewport } from './videoLayout';

export type ScreenReviewMode = 'fullscreen' | 'edit';
function PhotoDeck({
  notes,
  index,
  turned,
  onSelect,
  onDimensions,
  viewport,
  onToggleChrome,
  hideControls = false,
}: {
  notes: ScreenNote[];
  index: number;
  turned: boolean;
  onSelect: (note: ScreenNote) => void;
  onDimensions: (width: number, height: number) => void;
  onToggleChrome?: () => void;
  hideControls?: boolean;
  viewport: { width: number; height: number };
}) {
  const box = useRef<HTMLDivElement>(null);
  const [motion, setMotion] = useState({ offset: 0, settling: false });
  const live = useRef({ notes, index, onSelect, viewport, turned, onToggleChrome });
  live.current = { notes, index, onSelect, viewport, turned, onToggleChrome };
  const [zoom, setZoom] = useState({ scale: 1, x: 0, y: 0, animate: false });
  const zoomRef = useRef(zoom);
  const tap = useRef<{
    at: number;
    x: number;
    y: number;
    timer: ReturnType<typeof setTimeout>;
  } | null>(null);
  function updateZoom(next: typeof zoom) {
    zoomRef.current = next;
    setZoom(next);
  }
  function clearTap() {
    if (tap.current) clearTimeout(tap.current.timer);
    tap.current = null;
  }
  function pan(x: number, y: number, scale = zoomRef.current.scale) {
    const img = box.current?.querySelector<HTMLImageElement>(
      '.screen-photo-slide[aria-hidden="false"] img',
    );
    return clampPhotoPan(
      x,
      y,
      photoPanBounds(
        img?.naturalWidth ?? 0,
        img?.naturalHeight ?? 0,
        live.current.viewport,
        live.current.turned,
        scale,
      ),
    );
  }
  function zoomAt(x: number, y: number) {
    if (zoomRef.current.scale > 1) {
      updateZoom({ scale: 1, x: 0, y: 0, animate: true });
      return;
    }
    const img = box.current?.querySelector<HTMLImageElement>(
      '.screen-photo-slide[aria-hidden="false"] img',
    );
    if (!img?.naturalWidth) return;
    const rect = box.current!.getBoundingClientRect();
    const scale = 2.5;
    const offset = pan(
      (rect.width / 2 - (x - rect.left)) * (scale - 1),
      (rect.height / 2 - (y - rect.top)) * (scale - 1),
      scale,
    );
    updateZoom({ scale, ...offset, animate: true });
  }
  function handleTap(x: number, y: number) {
    const last = tap.current;
    if (last && performance.now() - last.at < 300 && Math.hypot(last.x - x, last.y - y) < 45) {
      clearTap();
      zoomAt(x, y);
      return;
    }
    clearTap();
    tap.current = {
      at: performance.now(),
      x,
      y,
      timer: setTimeout(() => {
        tap.current = null;
        live.current.onToggleChrome?.();
      }, 300),
    };
  }
  useLayoutEffect(() => {
    clearTap();
    drag.current = null;
    updateZoom({ scale: 1, x: 0, y: 0, animate: false });
  }, [notes[index]?.id, turned, viewport.width, viewport.height]);
  const locked = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const drag = useRef<{
    kind: 'swipe' | 'pan';
    panX: number;
    panY: number;
    position: number;
    cross: number;
    at: number;
    distance: number;
    cancelled: boolean;
  } | null>(null);
  const suppressClick = useRef(false);
  const touchClickUntil = useRef(0);
  const size = () => Math.max(1, box.current?.getBoundingClientRect().width ?? 1);
  function settle(delta: number) {
    if (locked.current) return;
    const next = live.current.notes[live.current.index + delta];
    const direction = next ? delta : 0;
    if (!direction && (!drag.current || Math.abs(drag.current.distance) <= 7)) {
      drag.current = null;
      setMotion({ offset: 0, settling: false });
      return;
    }
    locked.current = true;
    clearTap();
    if (direction) updateZoom({ scale: 1, x: 0, y: 0, animate: true });
    drag.current = null;
    setMotion({ offset: -direction * size(), settling: true });
    const finish = () => {
      if (direction) live.current.onSelect(next);
      setMotion({ offset: 0, settling: false });
      locked.current = false;
    };
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) finish();
    else timer.current = setTimeout(finish, 240);
  }
  useEffect(() => {
    const resize = () => {
      clearTimeout(timer.current);
      drag.current = null;
      locked.current = false;
      setMotion({ offset: 0, settling: false });
      clearTap();
      updateZoom({ scale: 1, x: 0, y: 0, animate: false });
    };
    const key = (e: KeyboardEvent) => {
      if (
        e.defaultPrevented ||
        document.querySelector('.confirm-dialog[open]') ||
        ['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)
      )
        return;
      if (e.ctrlKey || e.metaKey) return;
      if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        if (zoomRef.current.scale === 1) {
          const rect = box.current!.getBoundingClientRect();
          zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2);
        }
        return;
      }
      if (e.key === '-' || e.key === '0') {
        e.preventDefault();
        updateZoom({ scale: 1, x: 0, y: 0, animate: true });
        return;
      }
      if (
        zoomRef.current.scale > 1 &&
        ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)
      ) {
        e.preventDefault();
        const z = zoomRef.current;
        const offset = pan(
          z.x + (e.key === 'ArrowLeft' ? 60 : e.key === 'ArrowRight' ? -60 : 0),
          z.y + (e.key === 'ArrowUp' ? 60 : e.key === 'ArrowDown' ? -60 : 0),
        );
        updateZoom({ ...z, ...offset, animate: true });
        return;
      }
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        e.preventDefault();
        settle(e.key === 'ArrowRight' ? 1 : -1);
      }
    };
    window.addEventListener('keydown', key);
    window.addEventListener('resize', resize);
    return () => {
      clearTimeout(timer.current);
      clearTap();
      window.removeEventListener('keydown', key);
      window.removeEventListener('resize', resize);
    };
  }, []);
  return (
    <div
      className="screen-photo-deck"
      ref={box}
      data-settling={motion.settling}
      data-zoom={zoom.scale}
      data-zoomed={zoom.scale > 1}
      role="group"
      aria-label="Screen note photo"
      onPointerDown={(e) => {
        if (
          locked.current ||
          !e.isPrimary ||
          e.button !== 0 ||
          (e.target as HTMLElement).closest('button')
        )
          return;
        suppressClick.current = false;
        if (e.pointerType !== 'touch') touchClickUntil.current = 0;
        box.current?.setPointerCapture(e.pointerId);
        drag.current = {
          kind: zoomRef.current.scale > 1 ? 'pan' : 'swipe',
          panX: zoomRef.current.x,
          panY: zoomRef.current.y,
          position: e.clientX,
          cross: e.clientY,
          at: performance.now(),
          distance: 0,
          cancelled: false,
        };
      }}
      onPointerMove={(e) => {
        const start = drag.current;
        if (!start || locked.current || start.cancelled) return;
        if (start.kind === 'pan') {
          const dx = e.clientX - start.position,
            dy = e.clientY - start.cross;
          if (Math.hypot(dx, dy) > 5) {
            suppressClick.current = true;
            clearTap();
          }
          updateZoom({
            ...zoomRef.current,
            ...pan(start.panX + dx, start.panY + dy),
            animate: false,
          });
          return;
        }
        const distance = e.clientX - start.position;
        const cross = Math.abs(e.clientY - start.cross);
        if (cross > Math.max(12, Math.abs(distance) * 1.2)) {
          start.cancelled = true;
          suppressClick.current = true;
          clearTap();
          setMotion({ offset: 0, settling: false });
          return;
        }
        start.distance = distance;
        if (Math.abs(distance) > 7) {
          suppressClick.current = true;
          clearTap();
        }
        const blocked =
          (distance > 0 && index === 0) || (distance < 0 && index === notes.length - 1);
        setMotion({ offset: blocked ? distance * 0.2 : distance, settling: false });
      }}
      onPointerUp={(e) => {
        const start = drag.current;
        if (!start || !e.isPrimary) return;
        const touch = e.pointerType === 'touch';
        if (touch) touchClickUntil.current = performance.now() + 600;
        if (start.kind === 'pan') {
          if (touch && !suppressClick.current) handleTap(e.clientX, e.clientY);
          drag.current = null;
          return;
        }
        if (start.cancelled || Math.abs(start.distance) <= 7) {
          if (touch && !start.cancelled && !suppressClick.current) handleTap(e.clientX, e.clientY);
          drag.current = null;
          setMotion({ offset: 0, settling: false });
          return;
        }
        const velocity = Math.abs(start.distance) / Math.max(1, performance.now() - start.at);
        const move =
          !start.cancelled &&
          (Math.abs(start.distance) > Math.min(70, size() * 0.18) ||
            (Math.abs(start.distance) > 22 && velocity > 0.45));
        settle(move ? (start.distance < 0 ? 1 : -1) : 0);
      }}
      onPointerCancel={() => {
        if (drag.current?.kind === 'pan') drag.current = null;
        else if (drag.current) settle(0);
      }}
      onLostPointerCapture={() => {
        if (drag.current?.kind === 'pan') drag.current = null;
        else if (drag.current) settle(0);
      }}
      onClick={(e) => {
        if (performance.now() < touchClickUntil.current) return;
        if (suppressClick.current) {
          suppressClick.current = false;
          return;
        }
        handleTap(e.clientX, e.clientY);
      }}
    >
      {[-1, 0, 1].map((delta) => {
        const note = notes[index + delta];
        return note ? (
          <div
            key={note.id}
            className="screen-photo-slide"
            aria-hidden={delta !== 0}
            style={{ transform: `translate3d(calc(${delta * 100}% + ${motion.offset}px),0,0)` }}
          >
            <div
              className={`screen-photo-zoom${zoom.animate ? ' is-animating' : ''}`}
              style={{
                transform:
                  delta === 0
                    ? `translate3d(${zoom.x}px,${zoom.y}px,0) scale(${zoom.scale})`
                    : 'none',
              }}
            >
              <div
                className="screen-photo-orientation"
                data-photo-turned={turned}
                style={
                  {
                    width: turned ? viewport.height : viewport.width,
                    height: turned ? viewport.width : viewport.height,
                    '--photo-angle': turned ? '90deg' : '0deg',
                  } as CSSProperties
                }
              >
                <ScreenFrame note={note} onDimensions={delta === 0 ? onDimensions : undefined} />
              </div>
            </div>
          </div>
        ) : null;
      })}
      <button
        className="screen-photo-prev"
        inert={hideControls}
        aria-hidden={hideControls}
        aria-label="Previous screen note"
        disabled={index <= 0}
        onClick={(e) => {
          e.stopPropagation();
          settle(-1);
        }}
      >
        <ChevronLeft size={23} />
      </button>
      <button
        className="screen-photo-next"
        inert={hideControls}
        aria-hidden={hideControls}
        aria-label="Next screen note"
        disabled={index >= notes.length - 1}
        onClick={(e) => {
          e.stopPropagation();
          settle(1);
        }}
      >
        <ChevronRight size={23} />
      </button>
    </div>
  );
}
export function ScreenNoteReview({
  note,
  notes,
  mode,
  onMode,
  onClose,
  onSelect,
  busy,
  onSave,
  onDelete,
  rotation,
  onRotation,
}: {
  note: ScreenNote;
  notes: ScreenNote[];
  mode: ScreenReviewMode;
  onMode: (mode: ScreenReviewMode) => void;
  onClose: () => void;
  onSelect: (note: ScreenNote) => void;
  busy: boolean;
  onSave: (note: ScreenNote) => Promise<void>;
  onDelete: () => Promise<void>;
  rotation?: 0 | 90;
  onRotation: (rotation: 0 | 90) => void;
}) {
  const queue = [...notes]
    .filter((n) => n.videoId === note.videoId)
    .sort((a, b) => a.time - b.time || a.createdAt - b.createdAt);
  const index = Math.max(
    0,
    queue.findIndex((n) => n.id === note.id),
  );
  const viewport = useViewport();
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [chrome, setChrome] = useState(true);
  const [details, setDetails] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const turned =
    rotation !== undefined
      ? rotation === 90
      : screenNoteTurn(note, viewport.height > viewport.width, dimensions.width, dimensions.height);
  useEffect(() => {
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = overflow;
    };
  }, []);
  useEffect(() => {
    setChrome(true);
    setDetails(false);
    root.current
      ?.querySelector<HTMLElement>(mode === 'edit' ? 'input' : '.screen-full-header button')
      ?.focus({ preventScroll: true });
  }, [mode]);
  function select(next: ScreenNote) {
    setDetails(false);
    onSelect(next);
  }
  if (mode === 'edit')
    return (
      <div ref={root}>
        <ScreenNoteEditor
          key={note.id}
          draft={note}
          existing
          busy={busy}
          onSave={onSave}
          onDelete={onDelete}
        />
      </div>
    );
  return (
    <div
      ref={root}
      className={`screen-full-surface ${chrome ? '' : 'screen-chrome-hidden'}`}
      tabIndex={-1}
      data-turned={turned}
    >
      <PhotoDeck
        notes={queue.length ? queue : [note]}
        index={index}
        turned={turned}
        viewport={viewport}
        onSelect={select}
        onToggleChrome={() => {
          setChrome((c) => !c);
          setDetails(false);
          if (chrome) root.current?.focus({ preventScroll: true });
        }}
        hideControls={!chrome}
        onDimensions={(width, height) =>
          setDimensions((s) => (s.width === width && s.height === height ? s : { width, height }))
        }
      />
      <header className="screen-full-header" inert={!chrome} aria-hidden={!chrome}>
        <button aria-label="Close screen notes viewer" onClick={onClose}>
          <ArrowLeft size={23} />
        </button>
        <h2 id="modal-title">{note.videoTitle}</h2>
        <div
          className="screen-photo-count"
          aria-label={`Photo ${index + 1} of ${queue.length}`}
          aria-live="polite"
        >
          <strong>{index + 1}</strong>
          <span>/ {queue.length}</span>
        </div>
        <button
          aria-label="Rotate photo"
          aria-pressed={turned}
          onClick={() => onRotation(turned ? 0 : 90)}
        >
          <RotateCw size={23} />
        </button>
      </header>
      <div
        className={`screen-full-caption ${details ? 'show-note' : ''}`}
        inert={!chrome}
        aria-hidden={!chrome}
      >
        <div className="screen-caption-heading">
          <h3>{note.label || `Frame at ${clock(note.time)}`}</h3>
          <button
            className="screen-caption-edit"
            aria-label="Edit note"
            onClick={() => onMode('edit')}
          >
            <Pencil size={16} />
            <span>Edit</span>
          </button>
        </div>
        {note.note && (
          <button
            className="screen-description"
            aria-label="Captured note description"
            aria-expanded={details}
            onClick={() => setDetails((d) => !d)}
          >
            <span className="screen-description-text">{note.note}</span>
            {!details && (note.note.length > 100 || note.note.split('\n').length > 2) && (
              <span className="screen-description-more">more</span>
            )}
          </button>
        )}
        <span className="screen-caption-time">{clock(note.time)} · Screen Note</span>
      </div>
    </div>
  );
}
