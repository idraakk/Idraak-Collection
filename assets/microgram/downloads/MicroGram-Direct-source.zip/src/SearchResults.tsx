import { useLayoutEffect, useRef, type ReactNode } from 'react';

export function SearchResults({ query, children }: { query: string; children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  const previous = useRef(query);
  useLayoutEffect(() => {
    if (previous.current === query) return;
    previous.current = query;
    const node = root.current;
    if (!node || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    node.dataset.searchUpdating = 'true';
    const animation = node.animate(
      [
        { opacity: 0.65, transform: 'translateY(4px)' },
        { opacity: 1, transform: 'translateY(0)' },
      ],
      { duration: 180, easing: 'cubic-bezier(.22,.75,.25,1)' },
    );
    const timer = setTimeout(() => delete node.dataset.searchUpdating, 190);
    return () => {
      clearTimeout(timer);
      animation.cancel();
      delete node.dataset.searchUpdating;
    };
  }, [query]);
  return (
    <div ref={root} className="search-results">
      {children}
    </div>
  );
}
