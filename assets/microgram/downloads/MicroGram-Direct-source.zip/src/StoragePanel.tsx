import { ChoiceMenu } from './ChoiceMenu';
import { Capacitor } from '@capacitor/core';
import { useEffect, useState } from 'react';
import type { Course } from './core';
import { ConfirmAction } from './ConfirmAction';
import { deviceStreaming } from './deviceStreaming';
import { Trash2, HardDrive, RefreshCw } from 'lucide-react';
const native = Capacitor.isNativePlatform();
const base = import.meta.env.VITE_API_BASE_URL ?? '';
export function bytes(n: number) {
  return n >= 1024 ** 3 ? `${(n / 1024 ** 3).toFixed(1)} GB` : `${(n / 1024 ** 2).toFixed(1)} MB`;
}
type Entry = {
  id: string;
  bytes: number;
  kind: 'download' | 'upload' | 'legacy';
  protected: boolean;
};
type Storage = {
  used: number;
  limit: number;
  free: number;
  entries: Entry[];
  downloading: boolean;
};
async function api(path: string, method = 'GET', body?: unknown) {
  const r = await fetch(`${base}/api/media/storage${path}`, {
    method,
    cache: 'no-store',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || 'Storage is unavailable.');
  return data;
}
export function CourseCacheButton({
  course,
  courses,
  onRemove,
}: {
  course: Course;
  courses: Course[];
  onRemove: (cleared: boolean) => void;
}) {
  const [confirmation, setConfirmation] = useState<'remove' | 'clear' | null>(null);
  const [clearOnRemove, setClearOnRemove] = useState(true);
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState('');
  const ids = course.videos
    .filter(
      (v) =>
        !v.local &&
        !courses.some((c) => c.id !== course.id && c.videos.some((other) => other.id === v.id)),
    )
    .map((v) => v.id);
  return (
    <div className="course-cache">
      <label className="remove-cache-choice">
        <input
          type="checkbox"
          checked={clearOnRemove}
          onChange={(e) => setClearOnRemove(e.target.checked)}
        />{' '}
        Clear downloads when removing
      </label>
      <button className="remove-course" disabled={busy} onClick={() => setConfirmation('remove')}>
        <Trash2 size={20} /> Remove from library
      </button>
      <button className="text-button" disabled={busy} onClick={() => setConfirmation('clear')}>
        <HardDrive size={20} /> Clear downloaded videos
      </button>
      {confirmation && (
        <ConfirmAction
          title={
            confirmation === 'remove'
              ? 'Remove this from your library?'
              : 'Clear downloaded videos?'
          }
          description={
            confirmation === 'remove'
              ? `${course.title} will leave your library.${clearOnRemove ? ' Its eligible downloaded copies will also be deleted from media storage.' : ' Downloaded copies will be kept.'} Your notes and learning progress are kept.`
              : 'Eligible downloaded copies will be deleted from media storage. You will need to download them again to watch. Your library, notes and progress are kept. Shared, active and original files are protected.'
          }
          action={confirmation === 'remove' ? 'Remove' : 'Clear downloads'}
          onClose={() => setConfirmation(null)}
          onConfirm={async () => {
            setBusy(true);
            try {
              if (confirmation === 'remove') {
                if (clearOnRemove) await api('/clear', 'POST', { ids });
                onRemove(clearOnRemove);
              } else {
                const result = await api('/clear', 'POST', { ids });
                setMessage(
                  `Freed ${bytes(result.freed)}. Shared, active and original files are kept.`,
                );
              }
            } finally {
              setBusy(false);
            }
          }}
        />
      )}
      {message && <p role="status">{message}</p>}
    </div>
  );
}
export function StoragePanel({
  courses,
  onNotify,
}: {
  courses: Course[];
  onNotify: (message: string) => void;
}) {
  const [confirmation, setConfirmation] = useState<{
    title: string;
    description: string;
    work: () => Promise<string>;
  } | null>(null);
  const [data, setData] = useState<Storage | null>(null),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [checkedAt, setCheckedAt] = useState('');
  async function refresh() {
    setRefreshing(true);
    try {
      setData(await api(''));
      setError('');
      setCheckedAt(
        new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setRefreshing(false);
    }
  }
  useEffect(() => {
    void refresh();
  }, []);
  return (
    <section className="panel storage-panel" aria-label="Video storage">
      {confirmation && (
        <ConfirmAction
          title={confirmation.title}
          description={confirmation.description}
          action="Confirm deletion"
          onClose={() => setConfirmation(null)}
          onConfirm={async () => {
            const result = await confirmation.work();
            await refresh();
            onNotify(result);
          }}
        />
      )}
      <h2>Video storage</h2>
      <p>
        {deviceStreaming
          ? 'Temporary video parts are stored on this device and automatically removed as the cache fills.'
          : 'Stored on your computer/server, shared by devices using this server.'}{' '}
        Clearing downloads keeps your library, notes, bookmarks and progress.
      </p>
      {error && <p role="alert">{error}</p>}
      {data && (
        <>
          {data.downloading && (
            <p>A video is being prepared. Temporary working files also use disk space.</p>
          )}
          <div className="storage-summary">
            <strong>
              {bytes(data.used)} / {bytes(data.limit)}
            </strong>
            <span>
              {bytes(data.free)}{' '}
              {deviceStreaming
                ? native
                  ? 'free on this device'
                  : 'available browser storage (estimate)'
                : 'free on the server drive'}
            </span>
          </div>
          <div className="progress-bar">
            <i style={{ width: `${Math.min(100, (data.used / data.limit) * 100)}%` }} />
          </div>
          <div className="storage-actions">
            <div className="cache-limit-choice">
              <span>Temporary cache limit</span>{' '}
              <ChoiceMenu
                label="Video storage limit"
                value={data.limit / 1024 ** 3}
                choices={deviceStreaming ? [250 / 1024, 0.5, 1, 2, 4] : [2, 5, 10, 20]}
                formatLabel={(n) => (n < 1 ? `${n * 1024} MB` : `${n} GB`)}
                onChange={(gib) => {
                  setConfirmation({
                    title: 'Change video storage budget?',
                    description: deviceStreaming
                      ? 'Reducing the budget clears older temporary video parts on this device. Imported originals, notes and progress are kept.'
                      : 'Reducing the budget may delete older downloaded copies automatically. Active files and originals stay protected. This budget does not add free space to the server drive.',
                    work: async () => {
                      await api('/limit', 'POST', { gib });
                      return 'Storage budget updated. Older downloads were cleared if needed.';
                    },
                  });
                }}
              />
            </div>
            <button
              className="button secondary"
              disabled={busy}
              onClick={() =>
                setConfirmation({
                  title: 'Clear temporary downloads?',
                  description: native
                    ? 'Deletes cached video parts on this phone. Playback may need to fetch them again. Imported video files, notes, captured images and progress stay.'
                    : 'Eligible downloaded copies will be deleted from media storage. Active videos and originals are protected. Your library and learning data stay.',
                  work: async () => {
                    const r = await api('/clear', 'POST', {});
                    return native
                      ? `Freed ${bytes(r.freed)} from ${r.removed} videos.`
                      : `Freed ${bytes(r.freed)} from ${r.removed} videos. ${r.skipped} active or protected files kept.`;
                  },
                })
              }
            >
              Clear temporary cache
            </button>
          </div>
          <p className="storage-note">
            {deviceStreaming ? (
              'Older temporary video parts are removed automatically at the cache limit. Imported MP4 originals are stored separately and are only deleted explicitly.'
            ) : (
              <>
                Older downloads are removed automatically when space is needed. Active videos are
                protected. Uploaded MP4s and older files with unknown origins are never
                automatically deleted. Closing a player releases its protection after about 90
                seconds.
              </>
            )}
          </p>
          {data.entries.length === 0 ? (
            <p>No cached video parts or imported video files.</p>
          ) : (
            <ul className="storage-files">
              {data.entries.map((entry) => {
                const title =
                  courses.flatMap((c) => c.videos).find((v) => v.id === entry.id)?.title ??
                  `Video ${entry.id}`;
                return (
                  <li key={entry.id}>
                    <div>
                      <strong>{title}</strong>
                      <small>
                        {bytes(entry.bytes)} ·{' '}
                        {entry.kind === 'download'
                          ? 'Cached video parts'
                          : entry.kind === 'upload'
                            ? 'Uploaded original'
                            : 'Protected older file'}
                        {entry.protected ? ' · Active' : ''}
                      </small>
                    </div>
                    <button
                      className="button subtle"
                      disabled={busy || entry.protected}
                      aria-label={`${entry.kind === 'download' ? 'Clear cache for' : 'Delete file for'} ${title}`}
                      onClick={() =>
                        setConfirmation({
                          title:
                            entry.kind === 'download'
                              ? 'Clear this download?'
                              : 'Delete original file?',
                          description:
                            entry.kind === 'download'
                              ? 'Cached parts of this video will be removed. Watching it again may use internet data. Your library, notes and progress stay.'
                              : `Permanently delete “${title}” from ${deviceStreaming ? 'this device' : 'the server'}? This may be your only copy. Its library entry, notes and progress remain.`,
                          work: async () => {
                            if (entry.kind === 'download') {
                              const r = await api('/clear', 'POST', { ids: [entry.id] });
                              return `Freed ${bytes(r.freed)}.${r.skipped ? ' Video is active; try again later.' : ''}`;
                            }
                            await api(`/${entry.id}?confirm=delete-original`, 'DELETE');
                            return 'Original file deleted. Learning data was kept.';
                          },
                        })
                      }
                    >
                      {entry.kind === 'download' ? 'Clear cache' : 'Delete file'}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </>
      )}
      <div className="storage-refresh">
        <button
          className="button secondary"
          disabled={busy || refreshing}
          aria-busy={refreshing}
          onClick={() => void refresh()}
        >
          <RefreshCw size={15} className={refreshing ? 'spin' : ''} />
          {refreshing ? 'Checking storage…' : 'Refresh storage'}
        </button>
        <span role="status">
          {refreshing ? 'Reading device storage' : checkedAt ? `Last checked ${checkedAt}` : ''}
        </span>
      </div>
      <details className="storage-help">
        <summary>
          {deviceStreaming ? 'Device video storage' : 'Server storage and phone storage'}
        </summary>
        <p className="storage-note">
          {deviceStreaming ? (
            native ? (
              'This limit covers temporary video chunks, not total app storage. Android may reclaim cache when space is low. Imported MP4 files, captured images and learning data use additional space. Clear cache beside a video to free just its downloaded parts; you can stream them again. Export backs up learning data and images, not video files.'
            ) : (
              'Temporary video parts use the cache budget. Imported MP4 files are separate. Your browser may remove site data when space is low. Export a backup to keep your learning data and images.'
            )
          ) : (
            <>
              Downloads are saved on the computer/server. Your phone streams them using temporary
              playback buffers. Clearing this cache does not clear browser-managed phone data; use
              your browser’s site settings for that. Raising the video budget does not create free
              drive space.
            </>
          )}
        </p>
      </details>
    </section>
  );
}
