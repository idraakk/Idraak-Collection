import { localDate } from './storage';
export function activityYear(activity: Record<string, number>, goal: number, now = new Date()) {
  const first = new Date(now);
  first.setHours(12, 0, 0, 0);
  first.setDate(first.getDate() - 364);
  const gridStart = new Date(first);
  gridStart.setDate(gridStart.getDate() - gridStart.getDay());
  const end = new Date(now);
  end.setHours(12, 0, 0, 0);
  const days: { key: string; date: Date; seconds: number; level: number; inRange: boolean }[] = [];
  for (
    const d = new Date(gridStart);
    d <= end || days.length % 7 !== 0;
    d.setDate(d.getDate() + 1)
  ) {
    const inRange = d >= first && d <= end;
    const key = localDate(d),
      seconds = inRange ? Math.max(0, activity[key] ?? 0) : 0;
    const ratio = seconds / Math.max(60, goal * 60);
    days.push({
      key,
      date: new Date(d),
      seconds,
      inRange,
      level: !seconds ? 0 : ratio < 0.25 ? 1 : ratio < 0.5 ? 2 : ratio < 1 ? 3 : 4,
    });
  }
  return { days, active: days.filter((d) => d.inRange && d.seconds > 0).length };
}
