import { qualityCeiling, qualityPlayers, type VideoQuality } from './videoQuality';
import { warmReels } from './reelPrefetch';
import type { ReelWindow } from './reelWarmTargets';
import { reelBufferPlan } from './reelWarmTargets';
import { androidDirect } from './androidDirect';
import shaka from 'shaka-player';
shaka.polyfill.installAll();
export function attachAdaptivePlayer(
  video: HTMLVideoElement,
  id: string,
  start: number,
  onFailure: (message: string) => void,
  getWindow?: () => ReelWindow,
  options?: { deck?: boolean; thumbnail?: boolean; preference?: () => VideoQuality },
) {
  if (!shaka.Player.isBrowserSupported())
    throw new Error(
      'This browser does not support HD streaming. Try a recent Chrome, Edge or Safari.',
    );
  const player = new shaka.Player();
  const buffer = options?.thumbnail
    ? { ahead: 0.5, behind: 0 }
    : options?.deck
      ? { ahead: 8, behind: 2 }
      : androidDirect
        ? reelBufferPlan(getWindow?.())
        : { ahead: 40, behind: 45 };
  const publicFunnel =
    typeof location !== 'undefined' &&
    location.hostname.endsWith('.ts.net') &&
    location.port !== '8443';
  player.configure({
    abr: {
      enabled: true,
      // WebView downlink is a coarse browser estimate, not source throughput.
      useNetworkInformation: false,
      defaultBandwidthEstimate: publicFunnel ? 500_000 : 20_000_000,
      switchInterval: 2,
      clearBufferSwitch: true,
      safeMarginSwitch: options?.deck ? 0 : 2,
      bandwidthUpgradeTarget: 0.9,
      restrictions: {
        maxHeight: Math.min(
          qualityCeiling(options?.preference?.() ?? 'high', !!options?.deck),
          publicFunnel ? 480 : 1080,
        ),
      },
    },
    restrictions: { maxHeight: 1080 },
    streaming: {
      bufferingGoal: buffer.ahead,
      rebufferingGoal: androidDirect ? 0.5 : 2,
      bufferBehind: buffer.behind,
      segmentPrefetchLimit: options?.thumbnail ? 0 : androidDirect ? 2 : 1,
      retryParameters: {
        maxAttempts: 3,
        baseDelay: 500,
        backoffFactor: 2,
        timeout: 90000,
        connectionTimeout: 90000,
        stallTimeout: 30000,
      },
    },
    manifest: {
      disableAudio: !!options?.thumbnail,
      retryParameters: {
        maxAttempts: 2,
        baseDelay: 500,
        timeout: 120000,
        connectionTimeout: 120000,
        stallTimeout: 30000,
      },
    },
  });
  let destroyed = false;
  let foreground = !options?.deck;
  let loaded = false;
  let lastPreference = options?.preference?.() ?? 'high';
  const refreshQuality = () => {
    if (destroyed) return;
    const device = navigator as Navigator & { connection?: { saveData?: boolean } };
    const requested = options?.preference?.() ?? 'high';
    const preference = requested === 'auto' && device.connection?.saveData ? 'saver' : requested;
    const changed = requested !== lastPreference;
    if (loaded) lastPreference = requested;
    const ceiling = qualityCeiling(preference);
    player.configure({
      abr: {
        enabled: true,
        bandwidthUpgradeTarget: preference === 'saver' ? 0.7 : 0.9,
        restrictions: { maxHeight: ceiling },
        // Replace old-quality data rather than waiting for 35 buffered seconds.
        // Paused neighbours need no runway; active playback retains two seconds.
        safeMarginSwitch: foreground ? 2 : 0,
      },
    });
    if (loaded && changed) {
      const tracks = player.getVariantTracks();
      const candidates = tracks
        .filter((track) => track.height && track.height <= ceiling)
        .sort((a, b) => a.height! - b.height! || a.bandwidth - b.bandwidth);
      const choice = candidates.at(-1);
      if (choice) {
        // A preference change must also replace an old buffered rendition even
        // when the selected track already matches the requested track.
        player.selectVariantTrack(choice, true, foreground ? 2 : 0);
      }
    }
  };
  const setForeground = (active: boolean) => {
    if (!options?.deck || destroyed) return;
    foreground = active;
    player.configure({
      streaming: { bufferingGoal: active ? 35 : 8, bufferBehind: active ? 12 : 2 },
    });
    refreshQuality();
  };
  const status = () => ({
    height: video.videoHeight,
    heights: [
      ...new Set(
        player
          .getVariantTracks()
          .map((track) => track.height)
          .filter((height): height is number => !!height),
      ),
    ].sort((a, b) => b - a),
    refresh: refreshQuality,
  });
  qualityPlayers.set(video, status);
  let stopWarming: (() => void) | undefined;
  let starting = true;
  const explain = (error: { code?: number; data?: unknown[] }) => {
    if (error.code === 1001 && typeof error.data?.[2] === 'string') {
      try {
        const message = JSON.parse(error.data[2]).error;
        if (typeof message === 'string' && message.length < 300) return message;
      } catch {
        /* Non-JSON network responses use the general recovery message. */
      }
    }
    return 'This lecture could not stream. Try again to refresh its source, or try another lecture.';
  };
  const failure = (event: Event) => {
    const detail = (
      event as unknown as { detail: { severity: number; code: number; data?: unknown[] } }
    ).detail;
    if (!destroyed && !starting && detail?.severity === 2) onFailure(explain(detail));
  };
  player.addEventListener('error', failure);
  const destroy = async () => {
    destroyed = true;
    if (qualityPlayers.get(video) === status) qualityPlayers.delete(video);
    stopWarming?.();
    player.removeEventListener('error', failure);
    await player.destroy();
  };
  const ready = (async () => {
    try {
      await player.attach(video);
      for (let attempt = 0; !destroyed; attempt++) {
        try {
          const refresh = attempt ? `?retry=${Date.now()}` : '';
          await player.load(
            `/api/stream/${id}/manifest.mpd${refresh}`,
            start,
            'application/dash+xml',
          );
          starting = false;
          loaded = true;
          refreshQuality();
          if (getWindow && !destroyed) stopWarming = warmReels(player, video, getWindow);
          return;
        } catch (error) {
          if (destroyed) return;
          console.warn('Adaptive startup attempt failed', {
            attempt: attempt + 1,
            code: (error as { code?: number }).code,
          });
          const reason = explain(error as { code?: number; data?: unknown[] });
          if (
            attempt === 1 ||
            /blocking playback requests|missing its video resolver|private, restricted|installed JavaScript runtime|stopped the video resolver/.test(
              reason,
            )
          )
            throw error;
          await player.unload();
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
      }
    } catch (error) {
      throw new Error(explain(error as { code?: number; data?: unknown[] }));
    }
  })();
  return {
    ready,
    destroy,
    setForeground,
    downloadedBytes: () => Number(player.getStats().bytesDownloaded) || 0,
  };
}
