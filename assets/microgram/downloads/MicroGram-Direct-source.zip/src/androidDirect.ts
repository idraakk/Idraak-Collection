import { Capacitor, registerPlugin } from '@capacitor/core';
export const androidDirect = Capacitor.getPlatform() === 'android';
const native = registerPlugin<{
  request(options: {
    path: string;
    method: string;
    body: string;
  }): Promise<{ status: number; body: string }>;
  startupReady(): Promise<void>;
  original(options: { id: string; operation: string; data?: string }): Promise<void>;
}>('DirectStream');
export function notifyStartupReady() {
  if (androidDirect) void native.startupReady().catch(() => {});
}
export async function initializeAndroidDirect() {
  if (!androidDirect) return;
  // Native WebView interception serves GET/range requests; only mutations need
  // the Capacitor bridge because WebResourceRequest does not expose POST bodies.
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const request = new Request(input, init);
    const url = new URL(request.url);
    if (
      url.origin === location.origin &&
      /^\/api\/stream\/[\w-]{11}\/track\/\w+$/.test(url.pathname) &&
      request.method === 'GET' &&
      request.headers.has('Range')
    ) {
      // WebView seeks intercepted InputStreams itself for a Range header, even
      // when native code already returned that range. Keep ranges explicit in
      // the local URL to prevent the offset being applied twice.
      url.searchParams.set('range', request.headers.get('Range')!);
      const headers = new Headers(request.headers);
      headers.delete('Range');
      return originalFetch(new Request(url, { headers, signal: request.signal }));
    }
    if (
      url.origin !== location.origin ||
      !url.pathname.startsWith('/api/') ||
      ['GET', 'HEAD'].includes(request.method)
    )
      return originalFetch(input, init);
    request.signal.throwIfAborted();
    const upload = /^\/api\/media\/([\w-]{11})\/upload$/.exec(url.pathname);
    if (upload && request.method === 'POST') {
      const id = upload[1];
      const file = await request.blob();
      await native.original({ id, operation: 'begin' });
      try {
        for (let offset = 0; offset < file.size; offset += 128 * 1024) {
          request.signal.throwIfAborted();
          const bytes = new Uint8Array(await file.slice(offset, offset + 128 * 1024).arrayBuffer());
          let text = '';
          for (let i = 0; i < bytes.length; i += 8192)
            text += String.fromCharCode(...bytes.subarray(i, i + 8192));
          await native.original({ id, operation: 'append', data: btoa(text) });
        }
        await native.original({ id, operation: 'finish' });
        return Response.json({ stored: true });
      } catch (error) {
        await native.original({ id, operation: 'cancel' });
        throw error;
      }
    }
    const response = await native.request({
      path: url.pathname + url.search,
      method: request.method,
      body: await request.text(),
    });
    request.signal.throwIfAborted();
    if (url.pathname === '/api/media/storage/clear' && response.status < 300)
      window.dispatchEvent(new Event('microgram-cache-cleared'));
    return new Response(response.body, {
      status: response.status,
      headers: { 'Content-Type': 'application/json' },
    });
  };
}
