import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { useEffect, useState } from 'react';
import { communityBase } from './community/client';

const preferenceKey = 'microgram-usage-analytics';
const queueKey = 'microgram-usage-queue';
const installKey = 'microgram-usage-install';
const dayMs = 86_400_000;
const dayOffset = 19_800_000;
const checkpointInterval = 20_000;
const uploadInterval = 5 * 60_000;
const minimumUploadInterval = 60_000;
const maxRetryInterval = 15 * 60_000;
const batchSize = 24;
const enabled = Capacitor.getPlatform() === 'android' && Boolean(communityBase);

type Snapshot = {
  id: string;
  openedAt: number;
  day: string;
  activeMs: number;
  watchMs: number;
};

function pending(): Snapshot[] {
  try {
    return JSON.parse(localStorage.getItem(queueKey) ?? '[]');
  } catch {
    return [];
  }
}

function save(queue: Snapshot[]) {
  localStorage.setItem(queueKey, JSON.stringify(queue.slice(-240)));
}

const key = (row: Snapshot) => row.id + row.day;
const day = (time: number) => new Date(time + dayOffset).toISOString().slice(0, 10);
let watch: ((seconds: number) => void) | undefined;
export function recordAnalyticsWatch(seconds: number) {
  watch?.(seconds);
}

const defaultPreference =
  (import.meta.env.VITE_PERSONAL_USAGE_ANALYTICS ?? 'true') === 'true' ? 'on' : 'off';

function storedPreference() {
  return localStorage.getItem(preferenceKey) ?? defaultPreference;
}

export function useAppAnalytics() {
  const [preference, setPreference] = useState(() => (enabled ? storedPreference() : 'off'));

  function choose(share: boolean) {
    localStorage.setItem(preferenceKey, share ? 'on' : 'off');
    if (!share) {
      localStorage.removeItem(queueKey);
      localStorage.removeItem(installKey);
    }
    setPreference(share ? 'on' : 'off');
  }

  useEffect(() => {
    if (!enabled || preference !== 'on') return;
    const installation = localStorage.getItem(installKey) ?? crypto.randomUUID();
    localStorage.setItem(installKey, installation);
    let stopped = false;
    let sending = false;
    let nextUploadAt = Date.now() + uploadInterval;
    let earliestUploadAt = 0;
    let retryInterval = minimumUploadInterval;
    let session:
      | {
          id: string;
          openedAt: number;
          last: number;
          rows: Map<string, Snapshot>;
          persisted: Map<string, Snapshot>;
        }
      | undefined;

    function checkpoint(watchMs = 0) {
      if (!session) return;
      const now = Date.now();
      // Bound the contribution after a suspended WebView or a device clock change.
      let cursor =
        now - Math.round(Math.min(30_000, Math.max(0, performance.now() - session.last)));
      session.last = performance.now();
      do {
        const date = day(cursor);
        const end = Math.min(
          now,
          (Math.floor((cursor + dayOffset) / dayMs) + 1) * dayMs - dayOffset,
        );
        const row = session.rows.get(date) ?? {
          id: session.id,
          openedAt: session.openedAt,
          day: date,
          activeMs: 0,
          watchMs: 0,
        };
        row.activeMs = Math.min(dayMs, row.activeMs + end - cursor);
        if (end === now && date === day(now)) row.watchMs = Math.min(dayMs, row.watchMs + watchMs);
        session.rows.set(date, row);
        cursor = end;
      } while (cursor < now);
    }

    function persist() {
      if (!session || stopped || storedPreference() !== 'on') return;
      checkpoint();
      const rows = new Map(pending().map((row) => [key(row), row]));
      for (const row of session.rows.values()) {
        const previous = session.persisted.get(row.day);
        if (previous?.activeMs === row.activeMs && previous.watchMs === row.watchMs) continue;
        rows.set(key(row), row);
        session.persisted.set(row.day, { ...row });
      }
      save([...rows.values()].filter((row) => row.day >= day(Date.now() - 14 * dayMs)));
    }

    async function flush(expedite = false) {
      const now = Date.now();
      if (
        stopped ||
        sending ||
        storedPreference() !== 'on' ||
        now < earliestUploadAt ||
        (!expedite && now < nextUploadAt)
      )
        return;
      const queue = pending();
      const rows = queue.slice(0, batchSize);
      if (!rows.length) return;

      sending = true;
      earliestUploadAt = now + minimumUploadInterval;
      try {
        const response = await fetch(communityBase + '/analytics/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ installation, rows }),
          keepalive: true,
          signal: AbortSignal.timeout(12_000),
        });
        if (stopped || storedPreference() !== 'on') return;
        if (!response.ok) throw new Error('Analytics upload failed');

        const sent = new Map(rows.map((row) => [key(row), row]));
        const remaining = pending().filter((row) => {
          const previous = sent.get(key(row));
          return !previous || row.activeMs > previous.activeMs || row.watchMs > previous.watchMs;
        });
        save(remaining);
        // Drain a backlog gradually, without letting reconnects burst against D1.
        nextUploadAt =
          Date.now() + (queue.length > batchSize ? minimumUploadInterval : uploadInterval);
        retryInterval = minimumUploadInterval;
      } catch {
        earliestUploadAt = Date.now() + retryInterval;
        nextUploadAt = earliestUploadAt;
        retryInterval = Math.min(retryInterval * 2, maxRetryInterval);
      } finally {
        sending = false;
      }
    }

    const reconnect = () => void flush(true);

    function foreground(active: boolean) {
      if (stopped) return;
      if (active && !session) {
        session = {
          id: crypto.randomUUID(),
          openedAt: Date.now(),
          last: performance.now(),
          rows: new Map(),
          persisted: new Map(),
        };
        persist();
      } else if (!active && session) {
        persist();
        session = undefined;
        void flush(true);
      }
    }

    watch = (seconds) => checkpoint(Math.round(seconds * 1000));
    let receivedState = false;
    const listener = App.addListener('appStateChange', ({ isActive }) => {
      receivedState = true;
      foreground(isActive);
    });
    void App.getState()
      .then(({ isActive }) => {
        if (!receivedState) foreground(isActive);
      })
      .catch(() => {});
    const timer = window.setInterval(() => {
      persist();
      void flush();
    }, checkpointInterval);
    window.addEventListener('online', reconnect);
    return () => {
      stopped = true;
      session = undefined;
      watch = undefined;
      window.clearInterval(timer);
      window.removeEventListener('online', reconnect);
      void listener.then((handle) => handle.remove()).catch(() => {});
    };
  }, [preference]);

  return { available: enabled, preference, choose };
}
