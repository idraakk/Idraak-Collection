import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import { useEffect, useState } from 'react';
import { communityBase } from './community/client';

const preferenceKey = 'microgram-usage-analytics';
const queueKey = 'microgram-usage-queue';
const installKey = 'microgram-usage-install';
const dayMs = 86_400_000;
const dayOffset = 19_800_000;
const enabled = Capacitor.getPlatform() === 'android' && Boolean(communityBase);

type Snapshot = {
  id: string;
  openedAt: number;
  day: string;
  activeMs: number;
  watchMs: number;
};

function pending(): Snapshot[] {
  try {
    return JSON.parse(localStorage.getItem(queueKey) ?? '[]');
  } catch {
    return [];
  }
}

function save(queue: Snapshot[]) {
  localStorage.setItem(queueKey, JSON.stringify(queue.slice(-240)));
}

const key = (row: Snapshot) => row.id + row.day;
const day = (time: number) => new Date(time + dayOffset).toISOString().slice(0, 10);
let watch: ((seconds: number) => void) | undefined;
export function recordAnalyticsWatch(seconds: number) {
  watch?.(seconds);
}

export function useAppAnalytics() {
  const [preference, setPreference] = useState(() =>
    enabled ? localStorage.getItem(preferenceKey) : 'off',
  );

  function choose(share: boolean) {
    localStorage.setItem(preferenceKey, share ? 'on' : 'off');
    if (!share) {
      localStorage.removeItem(queueKey);
      localStorage.removeItem(installKey);
    }
    setPreference(share ? 'on' : 'off');
  }

  useEffect(() => {
    if (!enabled || preference !== 'on') return;
    const installation = localStorage.getItem(installKey) ?? crypto.randomUUID();
    localStorage.setItem(installKey, installation);
    let stopped = false;
    let sending = false;
    let session:
      { id: string; openedAt: number; last: number; rows: Map<string, Snapshot> } | undefined;

    function checkpoint(watchMs = 0) {
      if (!session) return;
      const now = Date.now();
      // Bound the contribution after a suspended WebView or a device clock change.
      let cursor =
        now - Math.round(Math.min(30_000, Math.max(0, performance.now() - session.last)));
      session.last = performance.now();
      do {
        const date = day(cursor);
        const end = Math.min(
          now,
          (Math.floor((cursor + dayOffset) / dayMs) + 1) * dayMs - dayOffset,
        );
        const row = session.rows.get(date) ?? {
          id: session.id,
          openedAt: session.openedAt,
          day: date,
          activeMs: 0,
          watchMs: 0,
        };
        row.activeMs = Math.min(dayMs, row.activeMs + end - cursor);
        if (end === now && date === day(now)) row.watchMs = Math.min(dayMs, row.watchMs + watchMs);
        session.rows.set(date, row);
        cursor = end;
      } while (cursor < now);
    }

    function persist() {
      if (!session || stopped || localStorage.getItem(preferenceKey) !== 'on') return;
      checkpoint();
      const rows = new Map(pending().map((row) => [key(row), row]));
      for (const row of session.rows.values()) rows.set(key(row), row);
      save([...rows.values()].filter((row) => row.day >= day(Date.now() - 14 * dayMs)));
    }

    async function flush() {
      if (stopped || sending || localStorage.getItem(preferenceKey) !== 'on') return;
      sending = true;
      try {
        while (!stopped && localStorage.getItem(preferenceKey) === 'on') {
          const rows = pending().slice(0, 24);
          if (!rows.length) break;
          const response = await fetch(communityBase + '/analytics/sessions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ installation, rows }),
            keepalive: true,
            signal: AbortSignal.timeout(12_000),
          });
          if (!response.ok || stopped || localStorage.getItem(preferenceKey) !== 'on') break;
          const sent = new Map(rows.map((row) => [key(row), row]));
          save(
            pending().filter((row) => {
              const previous = sent.get(key(row));
              return (
                !previous || row.activeMs > previous.activeMs || row.watchMs > previous.watchMs
              );
            }),
          );
        }
      } catch {
        // The next foreground checkpoint retries locally queued snapshots.
      } finally {
        sending = false;
      }
    }

    function foreground(active: boolean) {
      if (stopped) return;
      if (active && !session) {
        session = {
          id: crypto.randomUUID(),
          openedAt: Date.now(),
          last: performance.now(),
          rows: new Map(),
        };
        persist();
        void flush();
      } else if (!active && session) {
        persist();
        session = undefined;
        void flush();
      }
    }

    watch = (seconds) => checkpoint(Math.round(seconds * 1000));
    let receivedState = false;
    const listener = App.addListener('appStateChange', ({ isActive }) => {
      receivedState = true;
      foreground(isActive);
    });
    void App.getState()
      .then(({ isActive }) => {
        if (!receivedState) foreground(isActive);
      })
      .catch(() => {});
    const timer = window.setInterval(() => {
      persist();
      void flush();
    }, 20_000);
    window.addEventListener('online', flush);
    return () => {
      stopped = true;
      session = undefined;
      watch = undefined;
      window.clearInterval(timer);
      window.removeEventListener('online', flush);
      void listener.then((handle) => handle.remove()).catch(() => {});
    };
  }, [preference]);

  return { available: enabled, preference, choose };
}
