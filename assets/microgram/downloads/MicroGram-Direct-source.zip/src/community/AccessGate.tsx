import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowUpRight, LockKeyhole, RefreshCw, X, ArrowUpCircle } from 'lucide-react';
import { z } from 'zod';
import { boundedJson, communityBase, communityConfigured } from './client';
import { accessPolicySchema, availableRelease, freeAccess, type AppRelease } from './schema';
import { androidDirect, notifyStartupReady } from '../androidDirect';
import { App as NativeApp } from '@capacitor/app';
import './access.css';

const resultSchema = z.object({ policy: accessPolicySchema, expiresAt: z.number().optional() });
const passSchema = z.object({ token: z.string().regex(/^[a-f0-9-]{72}$/), expiresAt: z.number() });
const cacheKey = 'microgram.access.' + communityBase;
const passKey = 'microgram.pass.' + communityBase;
const noticeKey = 'microgram.notice.' + communityBase;
const updateKey = 'microgram.update.' + communityBase;
type Result = z.infer<typeof resultSchema>;

function stored<T>(key: string, parse: (value: unknown) => T): T | undefined {
  try {
    return parse(JSON.parse(localStorage.getItem(key) || 'null'));
  } catch {
    return undefined;
  }
}
function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* Storage may be disabled. */
  }
}

export function StartupReady() {
  useEffect(notifyStartupReady, []);
  return null;
}

function ReleaseCard({
  release,
  onLater,
  onCheck,
  checking,
}: {
  release: AppRelease;
  onLater?: () => void;
  onCheck: () => void;
  checking: boolean;
}) {
  return (
    <section className="access-card release-card" aria-labelledby="release-title">
      <div className="access-icon">
        <ArrowUpCircle size={28} />
      </div>
      <span className="access-brand">MicroGram · {release.versionName}</span>
      <h1 id="release-title">{release.title}</h1>
      <p>{release.message}</p>
      <a className="access-primary" href={release.url} target="_blank" rel="noopener noreferrer">
        Get the update <ArrowUpRight size={16} />
      </a>
      <div className="release-actions">
        {onLater && <button onClick={onLater}>Not now</button>}
        <button className="access-retry" onClick={onCheck} disabled={checking}>
          <RefreshCw size={15} /> Check again
        </button>
      </div>
    </section>
  );
}

export function AccessGate({ children }: { children: ReactNode }) {
  const [result, setResult] = useState(() => stored(cacheKey, resultSchema.parse));
  const [seenNotice, setSeenNotice] = useState(() => stored(noticeKey, z.string().parse));
  const [code, setCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [checking, setChecking] = useState(communityConfigured);
  const [bootChecked, setBootChecked] = useState(!communityConfigured);
  const [offline, setOffline] = useState(false);
  const [message, setMessage] = useState('');
  const [time, setTime] = useState(Date.now);
  const [build, setBuild] = useState<number>();
  const [checkingBuild, setCheckingBuild] = useState(androidDirect);
  const [dismissedBuild, setDismissedBuild] = useState(() => stored(updateKey, z.number().parse));
  useEffect(() => {
    if (!androidDirect) return;
    let active = true;
    const finish = () => {
      if (active) setCheckingBuild(false);
    };
    const timer = window.setTimeout(finish, 2500);
    void NativeApp.getInfo()
      .then(({ build }) => {
        if (active && /^\d+$/.test(build)) setBuild(Number(build));
      })
      .catch(() => {})
      .finally(() => {
        clearTimeout(timer);
        finish();
      });
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, []);
  const pass = useRef(stored(passKey, passSchema.parse));
  const attempt = useRef(0);

  const check = useCallback(async () => {
    if (!communityConfigured) return;
    const request = ++attempt.current;
    setChecking(true);
    try {
      const current = resultSchema.parse(
        await boundedJson(
          await fetch(communityBase + '/access', {
            credentials: 'omit',
            cache: 'no-store',
            signal: AbortSignal.timeout(5000),
            headers: pass.current ? { Authorization: 'Bearer ' + pass.current.token } : undefined,
          }),
          8192,
        ),
      );
      if (request !== attempt.current) return;
      setResult(current);
      save(cacheKey, current);
      setOffline(false);
    } catch {
      if (request === attempt.current) setOffline(true);
    } finally {
      if (request === attempt.current) {
        setTime(Date.now());
        setChecking(false);
        setBootChecked(true);
      }
    }
  }, []);

  useEffect(() => {
    if (!communityConfigured) return;
    void check();
    const resume = () => {
      if (!document.hidden) void check();
    };
    document.addEventListener('visibilitychange', resume);
    window.addEventListener('microgram:resume', resume);
    window.addEventListener('online', resume);
    const refresh = window.setInterval(resume, 60000);
    const clock = window.setInterval(() => setTime(Date.now()), 15000);
    return () => {
      ++attempt.current;
      clearInterval(refresh);
      clearInterval(clock);
      document.removeEventListener('visibilitychange', resume);
      window.removeEventListener('microgram:resume', resume);
      window.removeEventListener('online', resume);
    };
  }, [check]);

  const policy = result?.policy ?? freeAccess;
  const locked =
    policy.mode === 'paused' ||
    (policy.mode === 'membership' && !(result?.expiresAt && result.expiresAt > time));
  const release = availableRelease(policy.release, build);
  if (communityConfigured && (!bootChecked || checkingBuild))
    return (
      <main className="access-startup" aria-busy="true" aria-label="MicroGram">
        <img src="/brand-post.svg" alt="MicroGram" />
      </main>
    );
  if (release?.required)
    return (
      <main className="access-screen">
        <StartupReady />
        <ReleaseCard release={release} checking={checking} onCheck={() => void check()} />
      </main>
    );
  if (locked)
    return (
      <main className="access-screen">
        <StartupReady />
        <section className="access-card">
          <div className="access-icon">
            <LockKeyhole size={28} />
          </div>
          <span className="access-brand">MicroGram</span>
          <h1>{policy.title}</h1>
          <p>{policy.message}</p>
          {policy.mode === 'membership' && (
            <>
              {policy.checkout && (
                <a
                  className="access-primary"
                  href={policy.checkout}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {policy.checkoutLabel || 'View access options'} <ArrowUpRight size={16} />
                </a>
              )}
              <form
                onSubmit={async (event) => {
                  event.preventDefault();
                  if (submitting) return;
                  setSubmitting(true);
                  setMessage('');
                  try {
                    const response = await fetch(communityBase + '/access/redeem', {
                      method: 'POST',
                      credentials: 'omit',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ code }),
                      signal: AbortSignal.timeout(10000),
                    });
                    if (!response.ok) {
                      const detail = await response.json().catch(() => null);
                      throw new Error(
                        typeof detail?.error === 'string'
                          ? detail.error
                          : 'Could not redeem this code.',
                      );
                    }
                    const redeemed = passSchema.parse(await boundedJson(response, 4096));
                    pass.current = redeemed;
                    save(passKey, redeemed);
                    setCode('');
                    await check();
                  } catch (error) {
                    setMessage(
                      error instanceof Error ? error.message : 'Could not redeem this code.',
                    );
                  } finally {
                    setSubmitting(false);
                  }
                }}
              >
                <label htmlFor="access-code">Already have a code?</label>
                <div className="access-redeem">
                  <input
                    id="access-code"
                    value={code}
                    onChange={(event) => setCode(event.target.value)}
                    placeholder="Enter your access code"
                    maxLength={44}
                    required
                    autoComplete="off"
                  />
                  <button disabled={submitting}>{submitting ? 'Checking…' : 'Unlock'}</button>
                </div>
              </form>
            </>
          )}
          {message && (
            <p className="access-status" role="status">
              {message}
            </p>
          )}
          {offline && (
            <p className="access-status">Connect to the internet to check your access.</p>
          )}
          <button className="access-retry" disabled={checking} onClick={() => void check()}>
            <RefreshCw size={15} /> {checking ? 'Checking…' : 'Check access'}
          </button>
        </section>
      </main>
    );
  return (
    <>
      <StartupReady />
      {children}
      {release && release.versionCode !== dismissedBuild && (
        <div
          className="release-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="release-title"
        >
          <ReleaseCard
            release={release}
            checking={checking}
            onCheck={() => void check()}
            onLater={() => {
              save(updateKey, release.versionCode);
              setDismissedBuild(release.versionCode);
            }}
          />
        </div>
      )}
      {policy.notice && policy.notice !== seenNotice && (
        <aside className="access-notice" aria-label="MicroGram notice">
          <p>{policy.notice}</p>
          <button
            aria-label="Dismiss notice"
            onClick={() => {
              save(noticeKey, policy.notice);
              setSeenNotice(policy.notice);
            }}
          >
            <X size={18} />
          </button>
        </aside>
      )}
    </>
  );
}
