import {
  useEffect,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
  type CSSProperties,
} from 'react';
import {
  Bookmark,
  Clapperboard,
  Link2,
  ArrowUpRight,
  MessageCircle,
  Play,
  Plus,
  RefreshCw,
  X,
} from 'lucide-react';
import { boundedJson, cachedFeed, communityBase, communityConfigured, refreshFeed } from './client';
import {
  archivePosts,
  feedbackSchema,
  partnerCreativeSchema,
  visiblePosts,
  type CommunityBlock,
  type CommunityFeed,
} from './schema';
import { markPostSeen, PostVisibility, readSeenPosts } from './Replies';
import { usePullToRefresh } from './usePullToRefresh';
import type { CommunityPost } from './schema';
import { RichText } from './RichText';
import './community.css';

function frameStyle(block: {
  ratio?: string;
  fit?: 'cover' | 'contain';
  zoom?: number;
}): CSSProperties {
  const ratio = { square: '1', portrait: '4 / 5', wide: '16 / 9' }[
    block.ratio as 'square' | 'portrait' | 'wide'
  ];
  return {
    aspectRatio: ratio,
    objectFit: block.fit ?? (ratio ? 'cover' : 'contain'),
    transform: block.zoom && block.zoom > 1 ? 'scale(' + block.zoom + ')' : undefined,
  };
}
function RemoteVideo({ block }: { block: Extract<CommunityBlock, { type: 'video' }> }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) ref.current?.pause();
    });
    if (ref.current) observer.observe(ref.current);
    const hide = () => {
      if (document.hidden) ref.current?.pause();
    };
    document.addEventListener('visibilitychange', hide);
    return () => {
      observer.disconnect();
      document.removeEventListener('visibilitychange', hide);
    };
  }, []);
  return (
    <figure>
      <video
        ref={ref}
        controls
        style={frameStyle(block)}
        loop={block.loop}
        muted={block.muted}
        playsInline
        preload="none"
        poster={block.poster}
        src={block.src}
        aria-label={block.caption || 'Video from Idraak'}
      />
      {block.caption && <figcaption>{block.caption}</figcaption>}
    </figure>
  );
}
export function PostBlock({ block }: { block: CommunityBlock }) {
  switch (block.type) {
    case 'text':
      return (
        <p className="home-introduction community-text" style={{ textAlign: block.align }}>
          <RichText block={block} />
        </p>
      );
    case 'heading':
      return (
        <h2 style={{ textAlign: block.align }}>
          <RichText block={block} />
        </h2>
      );
    case 'quote':
      return (
        <blockquote style={{ textAlign: block.align }}>
          <RichText block={block} />
          {block.attribution && <cite>{block.attribution}</cite>}
        </blockquote>
      );
    case 'image':
      return (
        <figure>
          <img
            style={frameStyle(block)}
            src={
              block.src === 'https://microgram-community.idraakmk.workers.dev/brand-post.svg'
                ? '/brand-post.svg'
                : block.src
            }
            alt={block.alt}
            loading="lazy"
            referrerPolicy="no-referrer"
          />
          {block.caption && <figcaption>{block.caption}</figcaption>}
        </figure>
      );
    case 'gallery':
      return (
        <div className="community-gallery" aria-label="Photo gallery">
          {block.images.map((item, index) => (
            <figure key={index}>
              <img
                style={frameStyle(item)}
                src={item.src}
                alt={item.alt}
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              {item.caption && <figcaption>{item.caption}</figcaption>}
            </figure>
          ))}
        </div>
      );
    case 'video':
      return <RemoteVideo block={block} />;
    case 'list':
      return (
        <ul>
          {block.items.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      );
    case 'link':
      return (
        <a className="community-link" href={block.url} target="_blank" rel="noopener noreferrer">
          <span>
            {block.label}
            {block.description && <small>{block.description}</small>}
          </span>
          <ArrowUpRight size={18} />
        </a>
      );
  }
}

function Feedback() {
  const dialog = useRef<HTMLDialogElement>(null);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState('');
  return (
    <>
      <button
        className="home-feedback-link"
        type="button"
        aria-haspopup="dialog"
        onClick={() => {
          setStatus('');
          dialog.current?.showModal();
        }}
      >
        Write to Idraak <MessageCircle size={14} />
      </button>
      <dialog
        ref={dialog}
        className="community-feedback community-feedback-dialog"
        aria-labelledby="feedback-title"
      >
        <header>
          <h2 id="feedback-title">Write to Idraak</h2>
          <button type="button" onClick={() => dialog.current?.close()} aria-label="Close feedback">
            <X size={19} />
          </button>
        </header>
        <form
          onSubmit={async (event) => {
            event.preventDefault();
            if (sending) return;
            const form = event.currentTarget;
            const data = new FormData(form);
            const parsed = feedbackSchema.safeParse(Object.fromEntries(data));
            if (!parsed.success) {
              setStatus('Write between 5 and 2,000 characters.');
              return;
            }
            setSending(true);
            setStatus('');
            try {
              await boundedJson(
                await fetch(`${communityBase}/feedback`, {
                  method: 'POST',
                  credentials: 'omit',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(parsed.data),
                  signal: AbortSignal.timeout(10000),
                }),
                4096,
              );
              form.reset();
              setStatus('Message sent. Thank you for helping shape MicroGram.');
            } catch {
              setStatus('Could not send. Your message is still here—please try again.');
            } finally {
              setSending(false);
            }
          }}
        >
          <p>
            Send an idea, report a problem, or say hello. Only what you enter here is sent to
            Idraak. Messages are retained for up to 90 days.
          </p>
          <label>
            About
            <select name="category">
              <option value="idea">An idea</option>
              <option value="problem">A problem</option>
              <option value="message">A message</option>
            </select>
          </label>
          <label>
            Your message
            <textarea name="message" required minLength={5} maxLength={2000} rows={4} />
          </label>
          <label>
            Email or social handle for a reply (optional)
            <input name="replyTo" maxLength={200} autoComplete="off" />
          </label>
          <label className="community-honeypot" aria-hidden="true">
            Leave empty
            <input name="website" tabIndex={-1} autoComplete="off" />
          </label>
          <button className="community-send" disabled={sending}>
            {sending ? 'Sending…' : 'Send message'}
          </button>
        </form>
        {status && <p role="status">{status}</p>}
      </dialog>
    </>
  );
}

function EditorialContent({ post, action }: { post: CommunityPost; action: ReactNode }) {
  const purpose = post.layout === 'purpose';
  if (!purpose && post.layout !== 'momentum')
    return (
      <>
        {post.blocks.map((block, index) => (
          <PostBlock key={index} block={block} />
        ))}
        {action}
      </>
    );
  const [title, intro] = post.blocks;
  const remaining = post.blocks.slice(purpose ? 2 : 3);
  const section = purpose ? undefined : post.blocks[2];
  const icons = [Link2, Clapperboard, Bookmark];
  const steps: ReactNode[] = [];
  for (let i = 0; i < remaining.length; i++) {
    const heading = remaining[i],
      body = remaining[i + 1];
    if (heading.type !== 'heading' || body?.type !== 'text') {
      steps.push(<PostBlock key={i} block={heading} />);
      continue;
    }
    const Icon = icons[steps.length % icons.length];
    const label = String(steps.length + 1).padStart(2, '0');
    steps.push(
      <div key={i}>
        <span aria-hidden="true">{purpose ? <Icon size={20} /> : label}</span>
        <div>
          <h3 style={{ textAlign: heading.align }}>
            <RichText block={heading} />
          </h3>
          <p style={{ textAlign: body.align }}>
            <RichText block={body} />
          </p>
        </div>
      </div>,
    );
    i++;
  }
  return (
    <section className={purpose ? 'home-purpose' : 'home-momentum'} aria-label={post.topic}>
      {title && <PostBlock block={title} />}
      {intro?.type === 'text' ? (
        <p
          className={purpose ? 'home-purpose-intro' : 'home-momentum-intro'}
          style={{ textAlign: intro.align }}
        >
          <RichText block={intro} />
        </p>
      ) : (
        intro && <PostBlock block={intro} />
      )}
      {section?.type === 'heading' ? (
        <h3 style={{ textAlign: section.align }}>
          <RichText block={section} />
        </h3>
      ) : (
        section && <PostBlock block={section} />
      )}
      {steps.length > 0 && (
        <div className={purpose ? 'home-purpose-steps' : 'home-momentum-points'}>{steps}</div>
      )}
      {action && <div className="home-purpose-action">{action}</div>}
    </section>
  );
}

export function Community({
  Post,
  progress,
  progressFirst,
  onOpenReplies,
  onStart,
  hasLectures,
  renderFooter,
}: {
  progress: ReactNode;
  progressFirst: boolean;
  onOpenReplies: (post: CommunityPost, enabled: boolean) => void;
  onStart: () => void;
  hasLectures: boolean;
  renderFooter: (feedback: ReactNode) => ReactNode;
  Post: ComponentType<{ children: ReactNode; topic: string; verified?: boolean }>;
}) {
  const [feed, setFeed] = useState(cachedFeed);
  const [pending, setPending] = useState<CommunityFeed>();
  const [message, setMessage] = useState('');
  const [now, setNow] = useState(Date.now);
  const [replyCounts, setReplyCounts] = useState<Record<string, number>>({});
  useEffect(() => {
    if (!communityConfigured) return;
    let current = true;
    let requestId = 0;
    const loadCounts = async () => {
      if (document.hidden) return;
      const request = ++requestId;
      try {
        const data = (await boundedJson(
          await fetch(communityBase + '/posts/reply-counts', {
            credentials: 'omit',
            signal: AbortSignal.timeout(6000),
          }),
          16000,
        )) as { counts: Record<string, number> };
        if (current && request === requestId && data.counts) setReplyCounts(data.counts);
      } catch {
        /* Keep the last known counts. */
      }
    };
    void loadCounts();
    const timer = window.setInterval(loadCounts, 30000);
    window.addEventListener('microgram:replies-changed', loadCounts);
    window.addEventListener('microgram:resume', loadCounts);
    return () => {
      current = false;
      window.clearInterval(timer);
      window.removeEventListener('microgram:replies-changed', loadCounts);
      window.removeEventListener('microgram:resume', loadCounts);
    };
  }, []);
  const [seen, setSeen] = useState(readSeenPosts);
  const { pull, refreshing, refreshingRef } = usePullToRefresh(communityConfigured, async () => {
    setMessage('');
    try {
      setFeed(await refreshFeed(true));
      setSeen(readSeenPosts());
      setNow(Date.now());
      setPending(undefined);
    } catch {
      setMessage('You’re offline or posts are unavailable. Saved posts are still here.');
    }
  });
  useEffect(() => {
    let active = true;
    const refresh = () => {
      void refreshFeed()
        .then((next) => {
          if (!active) return;
          // A kill switch takes effect immediately; normal updates never jump a reader's scroll.
          if (!next.enabled) {
            setFeed(next);
            setPending(undefined);
          } else if (next.revision !== feed.revision) {
            setNow(Date.now());
            if (window.scrollY < 80 && !document.querySelector('.community-thread')) setFeed(next);
            else setPending(next);
          }
        })
        .catch(() => {});
    };
    refresh();
    const onVisible = () => {
      if (!document.hidden) {
        setNow(Date.now());
        refresh();
      }
    };
    const onReturn = () => {
      if (!document.hidden && !document.querySelector('.community-thread'))
        setSeen(readSeenPosts());
      onVisible();
    };
    document.addEventListener('visibilitychange', onReturn);
    window.addEventListener('pageshow', onReturn);
    window.addEventListener('microgram:resume', onReturn);
    const timer = window.setInterval(onVisible, 300_000);
    return () => {
      active = false;
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onReturn);
      window.removeEventListener('pageshow', onReturn);
      window.removeEventListener('microgram:resume', onReturn);
    };
  }, [feed.revision]);
  const cards = (posts: CommunityPost[], editorial = false) =>
    posts.map((post) => (
      <Post
        key={post.id}
        topic={
          post.headingPlacement === 'body' || post.headingPlacement === 'none' ? '' : post.topic
        }
        verified={post.id !== 'editorial-next-scroll'}
      >
        <PostVisibility id={post.id} publishedAt={post.publishedAt}>
          <div
            className="community-post"
            data-post-font={post.font || 'default'}
            style={{ '--post-color': post.color } as CSSProperties}
          >
            {!editorial && (
              <div className="community-meta">
                {post.pinned && <span>Pinned · </span>}
                {post.kind === 'sponsored'
                  ? `Advertisement · ${post.sponsor}`
                  : post.kind === 'announcement'
                    ? 'Announcement'
                    : 'From the creator'}{' '}
                ·{' '}
                <time dateTime={post.publishedAt}>
                  {new Date(post.publishedAt).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                  })}
                </time>
              </div>
            )}
            {(post.headingPlacement === 'body' || post.headingPlacement === 'both') && (
              <h2>{post.topic}</h2>
            )}
            <EditorialContent
              post={post}
              action={
                post.id === 'editorial-next-scroll' ? (
                  <button
                    className="today-start"
                    onClick={onStart}
                    aria-label={hasLectures ? 'Play this reel' : 'Add your first lecture'}
                  >
                    {hasLectures ? <Play size={18} fill="currentColor" /> : <Plus size={18} />}
                    {hasLectures ? 'Start learning' : 'Add your first lecture'}{' '}
                    <ArrowUpRight size={18} />
                  </button>
                ) : undefined
              }
            />
            {communityConfigured && feed.enabled && post.commentsEnabled === true && (
              <button
                className={
                  post.id === 'editorial-next-scroll'
                    ? 'community-reply-trigger after-lecture-action'
                    : 'community-reply-trigger'
                }
                onClick={() => {
                  markPostSeen(post.id, post.publishedAt);
                  onOpenReplies(post, true);
                }}
              >
                <MessageCircle size={18} /> Replies{' '}
                <span className="community-reply-count">{replyCounts[post.id] ?? 0}</span>
              </button>
            )}
          </div>
        </PostVisibility>
      </Post>
    ));
  const posts = visiblePosts(feed, now);
  const editorials = archivePosts(feed).filter(
    (post) =>
      Date.parse(post.publishedAt) <= now && (!post.expiresAt || Date.parse(post.expiresAt) > now),
  );
  const isTop = (post: CommunityPost) => seen[post.id] !== post.publishedAt;
  return (
    <div className="community-feed">
      {communityConfigured && (
        <button className="community-access-refresh" ref={refreshingRef} type="button">
          Refresh Home
        </button>
      )}
      {communityConfigured && (
        <div
          className="community-pull-indicator"
          data-visible={pull > 0 || refreshing}
          data-pulling={pull > 0 && !refreshing}
          aria-hidden={!pull && !refreshing}
          style={{ '--pull': (refreshing ? 52 : pull) + 'px' } as CSSProperties}
          role="status"
          aria-label={refreshing ? 'Refreshing Home' : 'Pull to refresh'}
        >
          <RefreshCw size={20} className={refreshing ? 'community-spin' : ''} />
        </div>
      )}
      {message && (
        <p role="status" className="community-status">
          {message}
        </p>
      )}
      {pending && (
        <button
          className="community-new"
          onClick={() => {
            setFeed(pending);
            setNow(Date.now());
            setPending(undefined);
          }}
        >
          New posts · Show updates
        </button>
      )}
      {cards(posts.filter(isTop))}
      {progressFirst && progress}
      {cards(
        editorials.filter((post) => post.id === 'editorial-intro'),
        true,
      )}
      {!progressFirst && progress}
      {cards(posts.filter((post) => !isTop(post)))}
      {cards(
        editorials.filter((post) => post.id !== 'editorial-intro'),
        true,
      )}
      {renderFooter(
        communityConfigured && feed.enabled && feed.feedbackEnabled ? <Feedback /> : null,
      )}
    </div>
  );
}

export function ReelSponsor({
  reelKey,
  onActive,
}: {
  reelKey: string;
  onActive: (active: boolean) => void;
}) {
  const [feed, setFeed] = useState(cachedFeed);
  const [count, setCount] = useState(0);
  const [dismissed, setDismissed] = useState(-1);
  const previous = useRef('');
  useEffect(() => {
    if (previous.current && previous.current !== reelKey) setCount((value) => value + 1);
    previous.current = reelKey;
    let live = true;
    void refreshFeed()
      .then((next) => {
        if (live) setFeed(next);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, [reelKey]);
  const ad = feed.reelAd;
  const active = !!(
    feed.enabled &&
    ad?.enabled &&
    count >= ad.every &&
    count % ad.every === 0 &&
    previous.current === reelKey &&
    dismissed !== count
  );
  const source = ad?.creativeUrl;
  const [partner, setPartner] = useState<{
    count: number;
    source: string;
    creative?: ReturnType<typeof partnerCreativeSchema.parse>;
  }>();
  useEffect(() => {
    if (!active || !source) return;
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 2200);
    let current = true;
    void (async () => {
      try {
        const result = partnerCreativeSchema.parse(
          await boundedJson(
            await fetch(source, {
              credentials: 'omit',
              cache: 'no-store',
              signal: controller.signal,
            }),
            16000,
          ),
        );
        if (current) setPartner({ count, source, creative: result });
      } catch {
        if (current) setPartner({ count, source });
      } finally {
        window.clearTimeout(timer);
      }
    })();
    return () => {
      current = false;
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [active, source, count]);
  const partnerReady = !!source && partner?.count === count && partner.source === source;
  const show = active && (!source || partnerReady);
  useEffect(() => {
    onActive(show);
    return () => onActive(false);
  }, [show, onActive]);
  return show && ad ? (
    <SponsoredSlide
      key={count}
      ad={{ ...ad, ...(partnerReady ? partner?.creative : undefined) }}
      close={() => setDismissed(count)}
    />
  ) : null;
}

function SponsoredSlide({
  ad,
  close,
}: {
  ad: NonNullable<CommunityFeed['reelAd']>;
  close: () => void;
}) {
  const [elapsed, setElapsed] = useState(0);
  const dialog = useRef<HTMLDialogElement>(null);
  const startY = useRef<number | null>(null);
  useEffect(() => {
    dialog.current?.showModal();
    const started = Date.now();
    const interval = window.setInterval(
      () => setElapsed(Math.floor((Date.now() - started) / 1000)),
      200,
    );
    return () => window.clearInterval(interval);
  }, []);
  useEffect(() => {
    if (elapsed >= ad.duration) close();
  }, [elapsed, ad.duration, close]);
  const canSkip = elapsed >= ad.skipAfter;
  return (
    <dialog
      ref={dialog}
      className="community-ad-slide"
      aria-label="Sponsored reel"
      onCancel={(event) => {
        event.preventDefault();
        if (canSkip) close();
      }}
      onPointerDown={(event) => {
        startY.current = event.clientY;
      }}
      onPointerUp={(event) => {
        if (canSkip && startY.current !== null && Math.abs(event.clientY - startY.current) > 65)
          close();
        startY.current = null;
      }}
    >
      {ad.video ? (
        <video autoPlay muted playsInline src={ad.video} poster={ad.poster} onError={close} />
      ) : (
        ad.poster && <img src={ad.poster} alt="" onError={close} />
      )}
      <header>
        <span>Sponsored · {ad.name}</span>
        <button disabled={!canSkip} onClick={close}>
          {canSkip ? 'Skip ad' : 'Skip in ' + (ad.skipAfter - elapsed) + 's'}
        </button>
      </header>
      <footer>
        <p>{ad.message}</p>
        {ad.url && (
          <a href={ad.url} target="_blank" rel="noopener noreferrer">
            Learn more
          </a>
        )}
      </footer>
    </dialog>
  );
}
