import { ConfirmAction } from '../ConfirmAction';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowLeft, Ellipsis, Trash2 } from 'lucide-react';
import type { State } from '../storage';
import { communityBase, communityConfigured, boundedJson } from './client';
import type { CommunityPost } from './schema';

const seenKey = 'microgram.community.seen';
export function readSeenPosts(): Record<string, string> {
  try {
    const saved = JSON.parse(localStorage.getItem(seenKey) || '{}');
    return saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
  } catch {
    return {};
  }
}
export function markPostSeen(id: string, publishedAt: string) {
  try {
    const { [id]: previous, ...seen } = readSeenPosts();
    if (previous === publishedAt) return;
    localStorage.setItem(
      seenKey,
      JSON.stringify(
        Object.fromEntries(Object.entries({ ...seen, [id]: publishedAt }).slice(-200)),
      ),
    );
  } catch {
    /* Local storage can be unavailable. */
  }
}

export function PostVisibility({
  id,
  publishedAt,
  children,
}: {
  id: string;
  publishedAt: string;
  children: ReactNode;
}) {
  const element = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const node = element.current;
    if (!communityConfigured || !node) return;
    let timer: number | undefined;
    const visible = () => {
      const box = node.getBoundingClientRect();
      const height = Math.min(box.bottom, window.innerHeight) - Math.max(box.top, 0);
      return (
        !document.hidden &&
        box.height > 0 &&
        height >= Math.min(box.height * 0.5, window.innerHeight * 0.3)
      );
    };
    const observe = new IntersectionObserver(
      () => {
        if (!visible()) {
          clearTimeout(timer);
          timer = undefined;
          return;
        }
        if (timer !== undefined) return;
        timer = window.setTimeout(() => {
          timer = undefined;
          if (!visible()) return;
          markPostSeen(id, publishedAt);
          try {
            const countedKey = 'microgram.community.counted';
            const counted = JSON.parse(localStorage.getItem(countedKey) || '[]') as string[];
            if (!counted.includes(id)) {
              const viewerKey = 'microgram.community.viewer';
              const viewer = localStorage.getItem(viewerKey) || crypto.randomUUID();
              localStorage.setItem(viewerKey, viewer);
              void fetch(communityBase + '/posts/' + id + '/view', {
                method: 'POST',
                credentials: 'omit',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ viewer }),
                signal: AbortSignal.timeout(6000),
              })
                .then((response) => {
                  if (response.ok) {
                    const latest = JSON.parse(localStorage.getItem(countedKey) || '[]') as string[];
                    localStorage.setItem(
                      countedKey,
                      JSON.stringify([...new Set([...latest, id])].slice(-200)),
                    );
                  }
                })
                .catch(() => {});
            }
          } catch {
            /* Posts still work if local storage is unavailable. */
          }
          observe.disconnect();
        }, 1200);
      },
      { threshold: [0, 0.05, 0.1, 0.2, 0.25, 0.5, 0.75] },
    );
    observe.observe(node);
    return () => {
      clearTimeout(timer);
      observe.disconnect();
    };
  }, [id, publishedAt]);
  return <div ref={element}>{children}</div>;
}

const ownerKey = 'microgram.reply.owner.' + communityBase;
function replyOwner(create = false) {
  try {
    const existing = localStorage.getItem(ownerKey);
    if (existing || !create) return existing ?? undefined;
    const token = crypto.randomUUID() + crypto.randomUUID();
    localStorage.setItem(ownerKey, token);
    return token;
  } catch {
    return undefined;
  }
}
const replyChange = () => window.dispatchEvent(new Event('microgram:replies-changed'));

interface Reply {
  id: string;
  name: string;
  username: string;
  message: string;
  created_at: number;
  owned?: boolean | number;
}

export function ReplyThread({
  post,
  profile,
  enabled,
  onClose,
}: {
  post: CommunityPost;
  profile: State['profile'];
  enabled: boolean;
  onClose: () => void;
}) {
  const backButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    backButton.current?.focus({ preventScroll: true });
  }, []);
  const [replies, setReplies] = useState<Reply[]>([]);
  const replyVersion = useRef(0);
  const [status, setStatus] = useState('');
  const [sending, setSending] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<string>();
  const [loaded, setLoaded] = useState(false);
  const [canReply, setCanReply] = useState(enabled);
  const endpoint = communityBase + '/posts/' + post.id + '/comments';
  useEffect(() => {
    const controller = new AbortController();
    const update = async () => {
      const version = replyVersion.current;
      try {
        const owner = replyOwner();
        const data = (await boundedJson(
          await fetch(endpoint, {
            signal: controller.signal,
            headers: owner ? { Authorization: 'Bearer ' + owner } : undefined,
          }),
          512000,
        )) as { comments: Reply[]; enabled: boolean };
        if (!controller.signal.aborted && version === replyVersion.current) {
          setReplies(data.comments);
          setCanReply(data.enabled);
          setLoaded(true);
        }
      } catch {
        if (!controller.signal.aborted) setStatus('Could not load replies.');
      }
    };
    void update();
    const timer = window.setInterval(update, 15000);
    return () => {
      controller.abort();
      window.clearInterval(timer);
    };
  }, [endpoint]);
  return (
    <section
      className="community-thread"
      role="dialog"
      aria-modal="true"
      aria-label="Post conversation"
      onKeyDown={(event) => {
        if (
          event.key === 'Escape' &&
          event.target instanceof Node &&
          event.currentTarget.contains(event.target)
        ) {
          event.preventDefault();
          onClose();
        }
      }}
    >
      <header>
        <button ref={backButton} aria-label="Back to feed" onClick={onClose}>
          <ArrowLeft size={22} />
        </button>
        <strong>Post</strong>
      </header>
      <article className="community-reply-row community-thread-post">
        <img src="/icon.svg" alt="" />
        <div>
          <strong>Idraak</strong> <small>@idraakk</small>
          {post.headingPlacement !== 'none' && <h3>{post.topic}</h3>}
          {post.blocks
            .filter((block) => block.type === 'text')
            .map((block, index) => (
              <p key={index}>{block.text}</p>
            ))}
        </div>
      </article>
      {canReply && (
        <form
          onSubmit={async (event) => {
            event.preventDefault();
            if (sending) return;
            const form = event.currentTarget;
            const data = new FormData(form);
            setSending(true);
            setStatus('');
            try {
              const ownerToken = replyOwner(true);
              const reply = (await boundedJson(
                await fetch(endpoint, {
                  method: 'POST',
                  credentials: 'omit',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    name: profile?.name || data.get('name'),
                    username: profile?.username || data.get('username') || '',
                    message: data.get('message'),
                    ownerToken,
                  }),
                  signal: AbortSignal.timeout(10000),
                }),
                4096,
              )) as Reply;
              replyVersion.current++;
              setReplies((current) => [reply, ...current.filter((item) => item.id !== reply.id)]);
              replyChange();
              form.reset();
            } catch {
              setStatus('Could not send your reply. Try again in a moment.');
            } finally {
              setSending(false);
            }
          }}
        >
          {!profile?.name && (
            <div className="community-reply-identity">
              <input
                name="name"
                required
                maxLength={60}
                aria-label="Display name"
                placeholder="Display name"
              />
              <input
                name="username"
                maxLength={30}
                pattern="[a-zA-Z0-9_.]*"
                aria-label="Username"
                placeholder="Username (optional)"
              />
            </div>
          )}
          <div className="community-reply-compose">
            <img src={profile?.photo || '/avatar-placeholder.svg'} alt="" />
            <textarea
              name="message"
              aria-label="Post your reply"
              placeholder="Post your reply"
              maxLength={500}
              required
              rows={2}
            />
          </div>
          <footer>
            <button disabled={sending}>{sending ? 'Sending…' : 'Reply'}</button>
          </footer>
        </form>
      )}
      {status && (
        <p role="status" className="community-thread-status">
          {status}
        </p>
      )}
      {!status && !replies.length && (
        <p className="community-thread-status">{loaded ? 'No replies yet.' : 'Loading replies…'}</p>
      )}
      {replies.map((reply) => (
        <article className="community-reply-row" data-owned={Boolean(reply.owned)} key={reply.id}>
          <img src="/avatar-placeholder.svg" alt="" />
          <div>
            <strong>{reply.name}</strong> {reply.username && <small>@{reply.username}</small>}{' '}
            <small>
              ·{' '}
              {new Date(reply.created_at).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric',
              })}
            </small>
            <p>{reply.message}</p>
          </div>
          {Boolean(reply.owned) && (
            <details className="community-reply-options">
              <summary aria-label="Options for your reply">
                <Ellipsis size={18} />
              </summary>
              <button
                type="button"
                onClick={(event) => {
                  const options = event.currentTarget.closest('details');
                  if (options) {
                    options.open = false;
                    options.querySelector('summary')?.focus();
                  }
                  setPendingDelete(reply.id);
                }}
              >
                <Trash2 size={15} /> Delete reply
              </button>
            </details>
          )}
        </article>
      ))}
      {pendingDelete && (
        <ConfirmAction
          title="Delete your reply?"
          description="Your reply will be removed from the conversation."
          action="Delete reply"
          onClose={() => setPendingDelete(undefined)}
          onConfirm={async () => {
            const owner = replyOwner();
            if (!owner) throw new Error('This device no longer has access to delete that reply.');
            try {
              await boundedJson(
                await fetch(endpoint + '/' + encodeURIComponent(pendingDelete), {
                  method: 'DELETE',
                  credentials: 'omit',
                  headers: { Authorization: 'Bearer ' + owner },
                  signal: AbortSignal.timeout(10000),
                }),
                4096,
              );
            } catch {
              throw new Error('Could not delete your reply. Please try again.');
            }
            replyVersion.current++;
            setReplies((current) => current.filter((item) => item.id !== pendingDelete));
            replyChange();
          }}
        />
      )}
    </section>
  );
}
