import type { CSSProperties } from 'react';
import type { CommunityBlock } from './schema';

export type TextBlock = Extract<CommunityBlock, { type: 'heading' | 'text' | 'quote' }>;
const fonts = {
  sans: 'system-ui, sans-serif',
  serif: 'Georgia, serif',
  mono: 'ui-monospace, monospace',
};
export function RichText({ block }: { block: TextBlock }) {
  if (!block.runs?.length) return <>{block.text}</>;
  return (
    <span className="community-rich">
      {block.runs.map((run, index) => {
        const style: CSSProperties = {
          color: run.color,
          backgroundColor: run.highlight,
          fontFamily: run.font && fonts[run.font],
          fontSize: run.size,
          fontWeight: run.bold ? 700 : undefined,
          fontStyle: run.italic ? 'italic' : undefined,
          textDecoration:
            [run.underline && 'underline', run.strike && 'line-through']
              .filter(Boolean)
              .join(' ') || undefined,
        };
        return run.href ? (
          <a key={index} style={style} href={run.href} target="_blank" rel="noopener noreferrer">
            {run.text}
          </a>
        ) : (
          <span key={index} style={style}>
            {run.text}
          </span>
        );
      })}
    </span>
  );
}
