import { emptyFeed, feedSchema, httpsUrl, type CommunityFeed } from './schema';

export const communityBase = (import.meta.env.VITE_COMMUNITY_URL || '').replace(/\/+$/, '');
export const communityConfigured =
  httpsUrl.safeParse(communityBase).success && new URL(communityBase).origin === communityBase;
const CACHE = 'microgram.community.v1';
const MAX_AGE = 72 * 60 * 60 * 1000;
const MAX_BYTES = 256 * 1024;
let inFlight: Promise<CommunityFeed> | undefined;
let lastChecked = 0;
export function cachedFeed(): CommunityFeed {
  try {
    const saved = JSON.parse(localStorage.getItem(CACHE) || 'null');
    if (saved?.source === communityBase && Date.now() - saved.time < MAX_AGE)
      return feedSchema.parse(saved.feed);
  } catch {
    /* Storage can be disabled, corrupt, or full. */
  }
  return emptyFeed;
}
export async function boundedJson(response: Response, max = MAX_BYTES): Promise<unknown> {
  if (!response.ok) throw new Error('Community is temporarily unavailable. Please try again.');
  if (!response.body) throw new Error('Empty response');
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let size = 0,
    result = '';
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > max) throw new Error('Response too large');
      result += decoder.decode(value, { stream: true });
    }
    return JSON.parse(result + decoder.decode());
  } finally {
    await reader.cancel().catch(() => {});
  }
}
export async function refreshFeed(force = false): Promise<CommunityFeed> {
  if (!communityConfigured) return emptyFeed;
  if (inFlight) return inFlight;
  if (!force && Date.now() - lastChecked < 300_000) return cachedFeed();
  inFlight = (async () => {
    const response = await fetch(`${communityBase}/feed`, {
      credentials: 'omit',
      cache: 'no-cache',
      signal: AbortSignal.timeout(7000),
    });
    const feed = feedSchema.parse(await boundedJson(response));
    try {
      localStorage.setItem(
        CACHE,
        JSON.stringify({ source: communityBase, time: Date.now(), feed }),
      );
    } catch {
      /* Still render without cache. */
    }
    lastChecked = Date.now();
    return feed;
  })();
  try {
    return await inFlight;
  } finally {
    inFlight = undefined;
  }
}
