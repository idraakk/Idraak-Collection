import { z } from 'zod';
import editorials from './editorials.json';

// Content is data, never remotely supplied HTML, JavaScript, or app permissions.
export const httpsUrl = z
  .string()
  .max(2048)
  .url()
  .refine((value) => {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && !url.username && !url.password;
    } catch {
      return false;
    }
  }, 'Use a public HTTPS URL without credentials');
const text = z.string().trim().min(1).max(6000);
const frame = {
  ratio: z.enum(['original', 'square', 'portrait', 'wide']).optional(),
  fit: z.enum(['cover', 'contain']).optional(),
  zoom: z.number().min(1).max(2).optional(),
};
const image = z.object({
  ...frame,
  src: httpsUrl,
  alt: z.string().max(300),
  caption: z.string().max(500).optional(),
});
const color = z.string().regex(/^#[0-9a-fA-F]{6}$/);
const font = z.enum(['sans', 'serif', 'mono']);
export const richRun = z.object({
  text: z.string().min(1).max(6000),
  bold: z.boolean().optional(),
  italic: z.boolean().optional(),
  underline: z.boolean().optional(),
  strike: z.boolean().optional(),
  color: color.optional(),
  highlight: color.optional(),
  size: z.number().int().min(12).max(48).optional(),
  font: font.optional(),
  href: httpsUrl.optional(),
});
const richText = {
  runs: z.array(richRun).max(100).optional(),
  align: z.enum(['left', 'center', 'right']).optional(),
};
export const blockSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('text'), text, ...richText }),
  z.object({ type: z.literal('heading'), text: text.max(180), ...richText }),
  z.object({
    type: z.literal('quote'),
    text,
    ...richText,
    attribution: z.string().max(100).optional(),
  }),
  z.object({ type: z.literal('image'), ...image.shape }),
  z.object({ type: z.literal('gallery'), images: z.array(image).min(1).max(8) }),
  z.object({
    type: z.literal('video'),
    ...frame,
    loop: z.boolean().optional(),
    muted: z.boolean().optional(),
    src: httpsUrl,
    poster: httpsUrl.optional(),
    caption: z.string().max(500).optional(),
  }),
  z.object({ type: z.literal('list'), items: z.array(text.max(500)).min(1).max(12) }),
  z.object({
    type: z.literal('link'),
    label: text.max(80),
    url: httpsUrl,
    description: z.string().max(300).optional(),
  }),
]);
export const postSchema = z
  .object({
    id: z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/),
    kind: z.enum(['post', 'announcement', 'sponsored']).default('post'),
    topic: z.string().min(1).max(100),
    font: z.enum(['default', 'sans', 'serif', 'mono']).optional(),
    color: z
      .string()
      .regex(/^#[0-9a-fA-F]{6}$/)
      .optional(),
    layout: z.enum(['standard', 'purpose', 'momentum']).optional(),
    headingPlacement: z.enum(['byline', 'body', 'both', 'none']).optional(),
    publishedAt: z.string().datetime(),
    expiresAt: z.string().datetime().optional(),
    pinned: z.boolean().default(false),
    commentsEnabled: z.boolean().optional(),
    sponsor: z.string().max(100).optional(),
    blocks: z.array(blockSchema).min(1).max(20),
  })
  .refine(
    (p) => !p.expiresAt || Date.parse(p.expiresAt) > Date.parse(p.publishedAt),
    'Expiry must follow publication',
  )
  .refine((p) => p.kind !== 'sponsored' || !!p.sponsor?.trim(), 'Sponsored posts need a sponsor');
function normalizeCheckout(value: unknown) {
  if (typeof value !== 'string') return undefined;
  const input = value.trim();
  if (!input) return undefined;
  try {
    const url = new URL(input.includes('://') ? input : 'https://' + input);
    if (
      url.protocol !== 'https:' ||
      url.username ||
      url.password ||
      !url.hostname.includes('.') ||
      url.hostname.endsWith('.localhost') ||
      url.hostname.endsWith('.local')
    )
      return undefined;
    return url.href;
  } catch {
    return undefined;
  }
}
export const releaseSchema = z.object({
  versionCode: z.number().int().min(1).max(2100000000),
  versionName: z.string().trim().min(1).max(40),
  url: httpsUrl,
  required: z.boolean().default(false),
  title: z.string().trim().min(1).max(100),
  message: z.string().trim().min(1).max(1000),
});
export type AppRelease = z.infer<typeof releaseSchema>;
export function availableRelease(release: AppRelease | undefined, installed: number | undefined) {
  return release && installed !== undefined && installed < release.versionCode
    ? release
    : undefined;
}
const accessSettings = z.object({
  mode: z.enum(['free', 'paused', 'membership']).default('free'),
  title: z.string().trim().max(100).default('MicroGram access'),
  message: z.string().trim().max(1000).default('Enter an access code to continue using MicroGram.'),
  checkout: z
    .string()
    .max(2048)
    .refine(
      (value) => Boolean(normalizeCheckout(value)),
      'Enter a public HTTPS checkout URL, or leave it blank.',
    )
    .optional(),
  checkoutLabel: z.string().trim().max(60).optional(),
  notice: z.string().trim().max(700).optional(),
  release: releaseSchema.optional(),
});
export const accessPolicySchema = z.preprocess((input) => {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return input;
  const policy = input as Record<string, unknown>;
  const checkout = normalizeCheckout(policy.checkout);
  if (checkout) return { ...policy, checkout };
  return {
    ...policy,
    checkout:
      policy.mode === 'membership' && typeof policy.checkout === 'string' && policy.checkout.trim()
        ? 'invalid-checkout-url'
        : undefined,
  };
}, accessSettings);
export const freeAccess = accessPolicySchema.parse({});
export type AccessPolicy = z.infer<typeof accessPolicySchema>;
export const partnerCreativeSchema = z
  .object({
    name: text.max(80),
    message: text.max(140),
    video: httpsUrl.optional(),
    poster: httpsUrl.optional(),
    url: httpsUrl.optional(),
  })
  .refine((ad) => Boolean(ad.video || ad.poster), 'The campaign needs an image or video');

export const feedSchema = z
  .object({
    version: z.literal(1),
    revision: z.string().min(1).max(100),
    enabled: z.boolean().default(true),
    posts: z.array(postSchema).max(50),
    editorials: z.array(postSchema).max(3).optional(),
    access: accessPolicySchema.optional(),
    feedbackEnabled: z.boolean().default(false),
    commentsEnabled: z.boolean().default(true),
    reelAd: z
      .object({
        enabled: z.boolean(),
        name: text.max(80),
        message: text.max(140),
        video: httpsUrl.optional(),
        poster: httpsUrl.optional(),
        url: httpsUrl.optional(),
        creativeUrl: httpsUrl.optional(),
        every: z.number().int().min(3).max(100),
        duration: z.number().int().min(5).max(30),
        skipAfter: z.number().int().min(0).max(30),
      })
      .refine((ad) => ad.skipAfter <= ad.duration, 'Skip time must be within the ad duration')
      .optional(),
    reelSponsor: z
      .object({
        enabled: z.boolean().default(false),
        id: z.string().min(1).max(80),
        name: z.string().min(1).max(80),
        message: z.string().min(1).max(140),
        url: httpsUrl,
        startsAt: z.string().datetime(),
        expiresAt: z.string().datetime(),
        every: z.number().int().min(10).max(100).default(20),
      })
      .refine(
        (ad) => Date.parse(ad.expiresAt) > Date.parse(ad.startsAt),
        'Sponsor expiry must follow its start',
      )
      .optional(),
  })
  .refine((f) => {
    const ids = f.posts.map((post) => post.id);
    const editorialIds = (f.editorials ?? []).map((post) => post.id);
    return (
      !ids.some((id) => id.startsWith('editorial-')) &&
      new Set(ids).size === ids.length &&
      new Set(editorialIds).size === editorialIds.length &&
      editorialIds.every((id) => editorials.some((post) => post.id === id))
    );
  }, 'Post IDs must be unique');
export type CommunityFeed = z.infer<typeof feedSchema>;
export type CommunityPost = z.infer<typeof postSchema>;
export type CommunityBlock = z.infer<typeof blockSchema>;
export const defaultEditorials = z.array(postSchema).parse(editorials);
export function archivePosts(feed: CommunityFeed) {
  return (feed.editorials ?? defaultEditorials).map((post) => {
    if (post.layout) return post;
    const original = defaultEditorials.find((item) => item.id === post.id);
    if (!original?.layout) return post;
    const title = post.blocks[0];
    const restoreTitle =
      original.layout === 'purpose' &&
      title?.type === 'heading' &&
      title.text === 'Make your next scroll count.' &&
      !title.runs?.length;
    return {
      ...post,
      layout: original.layout,
      blocks: restoreTitle ? [original.blocks[0], ...post.blocks.slice(1)] : post.blocks,
    };
  });
}
export const emptyFeed: CommunityFeed = {
  version: 1,
  revision: 'empty',
  enabled: true,
  posts: [],
  feedbackEnabled: false,
  commentsEnabled: true,
};
export function visiblePosts(feed: CommunityFeed, now = Date.now()) {
  if (!feed.enabled) return [];
  return feed.posts
    .filter(
      (p) => Date.parse(p.publishedAt) <= now && (!p.expiresAt || Date.parse(p.expiresAt) > now),
    )
    .sort(
      (a, b) =>
        Number(b.pinned) - Number(a.pinned) ||
        Date.parse(b.publishedAt) - Date.parse(a.publishedAt),
    );
}
export const feedbackSchema = z.object({
  category: z.enum(['idea', 'problem', 'message']),
  message: z.string().trim().min(5).max(2000),
  replyTo: z.string().trim().max(200).default(''),
  website: z.string().max(200).default(''), // Honeypot; never displayed to real users.
});

export const commentInput = z.object({
  name: z.string().trim().min(1).max(60),
  username: z
    .string()
    .trim()
    .max(30)
    .regex(/^[a-zA-Z0-9_.]*$/)
    .default(''),
  message: z.string().trim().min(1).max(500),
});
