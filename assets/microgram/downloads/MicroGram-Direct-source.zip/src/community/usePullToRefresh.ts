import { useEffect, useRef, useState } from 'react';

const releaseDistance = 48;
export function usePullToRefresh(enabled: boolean, refresh: () => Promise<void>) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const refreshingRef = useRef<HTMLButtonElement>(null);
  const latest = useRef(refresh);
  latest.current = refresh;
  useEffect(() => {
    if (!enabled) return;
    let mounted = true;
    let active = false;
    let point: { x: number; y: number } | undefined;
    let distance = 0;
    const run = async () => {
      if (active) return;
      active = true;
      setRefreshing(true);
      try {
        await latest.current();
      } finally {
        active = false;
        if (mounted) setRefreshing(false);
      }
    };
    const start = (event: TouchEvent) => {
      if (
        active ||
        window.scrollY > 1 ||
        event.touches.length !== 1 ||
        document.querySelector('[aria-modal="true"]') ||
        (event.target instanceof Element && event.target.closest('input, textarea, select, video'))
      )
        return;
      const touch = event.touches[0];
      point = { x: touch.clientX, y: touch.clientY };
    };
    const move = (event: TouchEvent) => {
      if (!point || event.touches.length !== 1) return;
      const touch = event.touches[0];
      const delta = touch.clientY - point.y;
      if (delta < -6 || Math.abs(touch.clientX - point.x) > Math.max(12, delta)) {
        reset();
        return;
      }
      if (delta < 8) return;
      if (event.cancelable) event.preventDefault();
      distance = Math.min(76, delta * 0.5);
      setPull(distance);
    };
    const reset = () => {
      point = undefined;
      distance = 0;
      setPull(0);
    };
    const end = () => {
      const ready = distance >= releaseDistance;
      reset();
      if (ready) void run();
    };
    const button = refreshingRef.current;
    button?.addEventListener('click', run);
    window.addEventListener('touchstart', start, { passive: true });
    window.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', end);
    window.addEventListener('touchcancel', reset);
    return () => {
      mounted = false;
      button?.removeEventListener('click', run);
      window.removeEventListener('touchstart', start);
      window.removeEventListener('touchmove', move);
      window.removeEventListener('touchend', end);
      window.removeEventListener('touchcancel', reset);
    };
  }, [enabled]);
  return { pull, refreshing, refreshingRef };
}
