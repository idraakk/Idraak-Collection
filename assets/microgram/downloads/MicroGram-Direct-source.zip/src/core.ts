export type Video = {
  width?: number;
  height?: number;
  local?: boolean;
  id: string;
  title: string;
  channel: string;
  duration: number;
  thumbnail: string;
};
export type Course = {
  kind?: 'video' | 'playlist';
  id: string;
  title: string;
  channel: string;
  videos: Video[];
  importedAt: number;
  sample?: boolean;
  reelSeconds?: 15 | 30 | 60 | 90;
};
export type Segment = {
  id: string;
  video: Video;
  index: number;
  start: number;
  end: number;
  videoIndex: number;
};
export type Progress = Record<string, number[]>;
export const DURATIONS = [15, 30, 60, 90] as const;
export function segmentVideo(video: Video, seconds: number, videoIndex = 0): Segment[] {
  if (
    !Number.isFinite(seconds) ||
    seconds < 1 ||
    !Number.isFinite(video.duration) ||
    video.duration <= 0
  )
    return [];
  return Array.from({ length: Math.ceil(video.duration / seconds) }, (_, index) => ({
    id: `${video.id}:${seconds}:${index}`,
    video,
    index,
    start: index * seconds,
    end: Math.min((index + 1) * seconds, video.duration),
    videoIndex,
  }));
}
export function segments(course: Course, seconds = 60) {
  seconds = course.reelSeconds ?? seconds;
  return course.videos.flatMap((v, i) => segmentVideo(v, seconds, i));
}
export function watched(segment: Segment, progress: Progress) {
  const set = new Set(progress[segment.video.id] ?? []);
  let count = 0;
  for (let i = segment.start; i < segment.end; i++) if (set.has(i)) count++;
  return count / (segment.end - segment.start);
}
export function complete(segment: Segment, progress: Progress) {
  return watched(segment, progress) >= 0.9;
}
export function parseYouTubeUrl(input: string): { kind: 'video' | 'playlist'; id: string } {
  let url: URL;
  try {
    url = new URL(input.trim());
  } catch {
    throw new Error('Paste a complete YouTube video or playlist link.');
  }
  if (
    !['https:', 'http:'].includes(url.protocol) ||
    !['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'www.youtu.be'].includes(
      url.hostname,
    )
  )
    throw new Error('Please use a youtube.com or youtu.be link.');
  const list = url.searchParams.get('list');
  if (list !== null) {
    if (!/^[\w-]{10,100}$/.test(list))
      throw new Error(
        'This playlist link is incomplete. Copy its full playlist link from YouTube.',
      );
    return { kind: 'playlist', id: list };
  }
  const id = url.hostname.endsWith('youtu.be')
    ? url.pathname.slice(1)
    : (url.searchParams.get('v') ?? url.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]+)/)?.[1]);
  if (!id || !/^[\w-]{11}$/.test(id))
    throw new Error('This link does not contain a valid video or playlist.');
  return { kind: 'video', id };
}
export function parseDuration(value: string) {
  const m = value.match(/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/);
  return m
    ? Math.ceil(
        Number(m[1] ?? 0) * 86400 +
          Number(m[2] ?? 0) * 3600 +
          Number(m[3] ?? 0) * 60 +
          Number(m[4] ?? 0),
      )
    : 0;
}
export function clock(seconds: number) {
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
}
export function recordInterval(
  progress: Progress,
  videoId: string,
  previous: number,
  current: number,
): Progress {
  // Ignore seeks, buffering gaps, reverse playback, and background intervals.
  if (current <= previous || current - previous > 2.5) return progress;
  const seconds = new Set(progress[videoId] ?? []);
  for (let s = Math.ceil(previous); s < Math.floor(current); s++) seconds.add(s);
  // Track the second crossed on a normal polling interval.
  if (Math.floor(current) > Math.floor(previous)) seconds.add(Math.floor(previous));
  return { ...progress, [videoId]: [...seconds].sort((a, b) => a - b) };
}
