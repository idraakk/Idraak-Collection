export function coverSources(videoId: string | undefined, fallback: string) {
  const id = /\/vi(?:_webp)?\/([\w-]{11})\//.exec(fallback)?.[1] ?? videoId;
  return [
    ...new Set(
      id
        ? ['maxresdefault', 'sddefault', 'hqdefault']
            .map((name) => `https://i.ytimg.com/vi/${id}/${name}.jpg`)
            .concat(fallback)
        : [fallback],
    ),
  ];
}
