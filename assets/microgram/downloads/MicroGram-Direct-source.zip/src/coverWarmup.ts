import type { Course } from './core';
import { coverSources } from './coverSources';
const warm = new Map<string, { image: HTMLImageElement; source: string; bytes: number }>();
const pending = new Set<string>();
export const cachedCover = (key: string) => warm.get(key)?.source;
export function primeLibraryCovers(courses: Course[]) {
  const queue = courses
    .filter((course) => !course.videos[0]?.local)
    .slice(0, 6)
    .map((course) => coverSources(course.videos[0].id, course.videos[0].thumbnail));
  const next = () => {
    const sources = queue.shift();
    if (!sources) return;
    const key = sources[0];
    if (warm.has(key) || pending.has(key)) {
      next();
      return;
    }
    pending.add(key);
    const image = new Image();
    image.fetchPriority = 'low';
    let at = 0;
    const advance = () => {
      if (++at < sources.length) image.src = sources[at];
      else {
        pending.delete(key);
        next();
      }
    };
    image.onerror = advance;
    image.onload = () => {
      if (image.naturalWidth <= 120) {
        advance();
        return;
      }
      warm.set(key, {
        image,
        source: image.src,
        bytes: image.naturalWidth * image.naturalHeight * 4,
      });
      let total = [...warm.values()].reduce((sum, entry) => sum + entry.bytes, 0);
      while (total > 24 * 1024 * 1024 && warm.size > 1) {
        const first = warm.keys().next().value!;
        total -= warm.get(first)!.bytes;
        warm.delete(first);
      }
      pending.delete(key);
      next();
    };
    image.src = sources[0];
  };
  next();
  next();
}
