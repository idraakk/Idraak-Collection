import { androidDirect, initializeAndroidDirect } from './androidDirect';
export const deviceStreaming = androidDirect || import.meta.env.VITE_DEVICE_STREAMING === 'true';
export async function initializeDeviceStreaming() {
  if (androidDirect) {
    await initializeAndroidDirect();
    return;
  }
  if (!deviceStreaming) {
    if (navigator.serviceWorker?.controller?.scriptURL.includes('/device-streaming-sw.js')) {
      for (const r of await navigator.serviceWorker.getRegistrations())
        if (r.active?.scriptURL.includes('/device-streaming-sw.js')) await r.unregister();
      location.reload();
      await new Promise(() => {});
    }
    return;
  }
  if (!window.isSecureContext || !('serviceWorker' in navigator))
    throw new Error(
      'Device streaming needs HTTPS. Open the hosted HTTPS address, or localhost on this computer.',
    );
  await navigator.serviceWorker.register('/device-streaming-sw.js', {
    scope: '/',
    updateViaCache: 'none',
  });
  await navigator.serviceWorker.ready;
  if (!navigator.serviceWorker.controller)
    await new Promise<void>((resolve, reject) => {
      const done = () => {
        clearTimeout(timer);
        navigator.serviceWorker.removeEventListener('controllerchange', done);
        resolve();
      };
      const timer = setTimeout(() => {
        navigator.serviceWorker.removeEventListener('controllerchange', done);
        reject(new Error('Could not start device streaming. Reload and try again.'));
      }, 10000);
      navigator.serviceWorker.addEventListener('controllerchange', done);
    });
}
