import { useLayoutEffect, useRef, type RefObject } from 'react';
let active: {
  token: object;
  element: HTMLElement;
  close: () => void;
  openingPress: boolean;
} | null = null;
let swallowClick = false;
export const hasActiveMenu = () => Boolean(active);
function announce(open: boolean) {
  window.dispatchEvent(new CustomEvent('microgram-menu', { detail: open }));
}
export function dismissActiveMenu() {
  if (!active) return false;
  const menu = active;
  active = null;
  menu.close();
  announce(false);
  return true;
}
function pointerDown(event: PointerEvent) {
  swallowClick = false;
  if (!active) return;
  active.openingPress = false;
  if (active.element.contains(event.target as Node)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  swallowClick = true;
  dismissActiveMenu();
}
function click(event: MouseEvent) {
  if (swallowClick && event.detail > 0) {
    swallowClick = false;
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  if (!active) return;
  // Releasing the finger that opened a long-press menu is not an outside tap.
  if (active.openingPress && event.detail > 0) {
    active.openingPress = false;
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  if (!active.element.contains(event.target as Node)) {
    event.preventDefault();
    event.stopImmediatePropagation();
    dismissActiveMenu();
  }
}
function key(event: KeyboardEvent) {
  if (!active) return;
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopImmediatePropagation();
    dismissActiveMenu();
  }
  if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
    const buttons = [
      ...active.element.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'),
    ];
    if (!buttons.length) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const current = buttons.indexOf(document.activeElement as HTMLButtonElement);
    const next =
      event.key === 'Home'
        ? 0
        : event.key === 'End'
          ? buttons.length - 1
          : (current + (event.key === 'ArrowUp' ? -1 : 1) + buttons.length) % buttons.length;
    buttons[next].focus();
  }
}
document.addEventListener('pointerdown', pointerDown, true);
document.addEventListener('click', click, true);
document.addEventListener('keydown', key, true);
if (import.meta.hot)
  import.meta.hot.dispose(() => {
    dismissActiveMenu();
    document.removeEventListener('pointerdown', pointerDown, true);
    document.removeEventListener('click', click, true);
    document.removeEventListener('keydown', key, true);
  });
export function useDismissibleMenu(
  open: boolean,
  element: RefObject<HTMLDivElement | null>,
  close: () => void,
  openingPress = false,
) {
  const latest = useRef(close);
  latest.current = close;
  useLayoutEffect(() => {
    if (!open || !element.current) return;
    dismissActiveMenu();
    const token = {};
    active = { token, element: element.current, close: () => latest.current(), openingPress };
    announce(true);
    return () => {
      if (active?.token === token) {
        active = null;
        announce(false);
      }
    };
  }, [open]);
}
