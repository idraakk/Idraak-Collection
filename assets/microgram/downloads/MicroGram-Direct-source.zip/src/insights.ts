import { complete, segments, type Course } from './core';
import { localDate, type State } from './storage';
export function learningInsights(state: State, days = 7, now = new Date()) {
  const dates = Array.from({ length: days }, (_, i) => {
    const date = new Date(now);
    date.setDate(date.getDate() - days + 1 + i);
    const key = localDate(date);
    return {
      key,
      label: date.toLocaleDateString(undefined, { weekday: 'short' }),
      seconds: state.activity[key] ?? 0,
    };
  });
  const uniqueVideos = [
    ...new Map(state.courses.flatMap((c) => c.videos).map((v) => [v.id, v])).values(),
  ];
  const coverage = (id: string, duration: number) =>
    new Set((state.progress[id] ?? []).filter((s) => s >= 0 && s < duration)).size;
  const duration = uniqueVideos.reduce((n, v) => n + v.duration, 0);
  const covered = uniqueVideos.reduce((n, v) => n + coverage(v.id, v.duration), 0);
  const uniqueReels = [
    ...new Map(
      state.courses.flatMap((c) => segments(c, state.seconds)).map((r) => [r.id, r]),
    ).values(),
  ];
  let streak = 0;
  const cursor = new Date(now);
  if (!(state.activity[localDate(cursor)] > 0)) cursor.setDate(cursor.getDate() - 1);
  for (let i = 0; i < 36600 && (state.activity[localDate(cursor)] ?? 0) > 0; i++) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  const courses = state.courses.map((course) => {
    const videos = [...new Map(course.videos.map((v) => [v.id, v])).values()];
    const total = videos.reduce((n, v) => n + v.duration, 0);
    const viewed = videos.reduce((n, v) => n + coverage(v.id, v.duration), 0);
    const reels = segments(course, state.seconds);
    return {
      course,
      total,
      viewed,
      percent: total ? Math.round((viewed / total) * 100) : 0,
      completed: reels.filter((r) => complete(r, state.progress)).length,
      reels: reels.length,
    };
  });
  return {
    dates,
    streak,
    duration,
    covered,
    remaining: duration - covered,
    courses,
    completed: uniqueReels.filter((r) => complete(r, state.progress)).length,
    totalReels: uniqueReels.length,
    uniqueVideos: uniqueVideos.length,
    activeDays: dates.filter((d) => d.seconds > 0).length,
    goalDays: dates.filter((d) => d.seconds >= state.goal * 60).length,
    periodSeconds: dates.reduce((n, d) => n + d.seconds, 0),
  };
}

export function courseInsights(state: State, course: Course, days = 7, now = new Date()) {
  const videos = [...new Map(course.videos.map((v) => [v.id, v])).values()].map((video) => {
    const seconds = new Set(
      (state.progress[video.id] ?? []).filter((s) => s >= 0 && s < video.duration),
    );
    const viewed = Math.min(video.duration, seconds.size);
    return { video, seconds, viewed, percent: Math.round((viewed / video.duration) * 100) };
  });
  const total = videos.reduce((sum, v) => sum + v.video.duration, 0);
  const viewed = videos.reduce((sum, v) => sum + v.viewed, 0);
  const reels = [...new Map(segments(course, state.seconds).map((r) => [r.id, r])).values()];
  const dates = Array.from({ length: days }, (_, i) => {
    const date = new Date(now);
    date.setDate(date.getDate() - days + 1 + i);
    const key = localDate(date);
    return {
      key,
      label: date.toLocaleDateString(undefined, { weekday: 'short' }),
      seconds: videos.reduce((sum, v) => sum + (state.videoActivity?.[v.video.id]?.[key] ?? 0), 0),
    };
  });
  const first = videos[0];
  const count = first ? Math.min(12, Math.max(1, Math.floor(first.video.duration))) : 0;
  const timeline =
    videos.length === 1
      ? Array.from({ length: count }, (_, i) => {
          const start = Math.floor((i * first.video.duration) / count);
          const end =
            i === count - 1
              ? first.video.duration
              : Math.floor(((i + 1) * first.video.duration) / count);
          const covered = [...first.seconds].filter((s) => s >= start && s < end).length;
          return {
            start,
            end,
            percent: Math.min(100, Math.round((covered / Math.max(1, end - start)) * 100)),
          };
        })
      : [];
  return {
    videos,
    total,
    viewed,
    remaining: total - viewed,
    dates,
    timeline,
    completed: reels.filter((r) => complete(r, state.progress)).length,
    reels: reels.length,
    periodSeconds: dates.reduce((sum, d) => sum + d.seconds, 0),
    tracked: videos.some((v) => Object.keys(state.videoActivity?.[v.video.id] ?? {}).length > 0),
  };
}
