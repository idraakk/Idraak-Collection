import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { AccessGate, StartupReady } from './community/AccessGate';
import { initializeDeviceStreaming } from './deviceStreaming';
import '@fontsource/dm-sans/latin-400.css';
import '@fontsource/dm-sans/latin-500.css';
import '@fontsource/dm-sans/latin-600.css';
import '@fontsource/manrope/latin-400.css';
import '@fontsource/manrope/latin-500.css';
import '@fontsource/manrope/latin-600.css';
import '@fontsource/manrope/latin-700.css';
import '@fontsource/manrope/latin-800.css';
import '@fontsource/roboto/latin-400.css';
import '@fontsource/roboto/latin-500.css';
import '@fontsource/roboto/latin-700.css';
import '@fontsource/roboto-condensed/latin-700.css';
import './styles.css';
class Boundary extends React.Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <main className="fatal">
        <StartupReady />
        <h1>Let’s try that again.</h1>
        <p>Your saved progress is still on this device.</p>
        <button onClick={() => location.reload()}>Reload MicroGram</button>
      </main>
    ) : (
      this.props.children
    );
  }
}
initializeDeviceStreaming()
  .then(() =>
    ReactDOM.createRoot(document.getElementById('root')!).render(
      <React.StrictMode>
        <Boundary>
          <AccessGate>
            <App />
          </AccessGate>
        </Boundary>
      </React.StrictMode>,
    ),
  )
  .catch((error: Error) => {
    ReactDOM.createRoot(document.getElementById('root')!).render(
      <main className="fatal">
        <StartupReady />
        <h1>Open MicroGram securely</h1>
        <p>{error.message}</p>
        <button onClick={() => location.reload()}>Try again</button>
      </main>,
    );
  });
