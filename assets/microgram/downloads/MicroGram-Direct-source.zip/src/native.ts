import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
export async function shareMoment(title: string, url: string) {
  if (Capacitor.isNativePlatform()) {
    await Share.share({ title, text: 'One small idea worth sharing.', url });
    return 'shared';
  }
  if (navigator.share) {
    await navigator.share({ title, text: 'One small idea worth sharing.', url });
    return 'shared';
  }
  await navigator.clipboard.writeText(url);
  return 'copied';
}
export async function exportBackup(content: string, name: string) {
  if (Capacitor.isNativePlatform()) {
    const result = await Filesystem.writeFile({
      path: name,
      data: content,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    });
    await Share.share({ title: 'MicroGram learning backup', files: [result.uri] });
    return;
  }
  const url = URL.createObjectURL(new Blob([content], { type: 'application/json' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export async function clearTemporaryBackups() {
  if (!Capacitor.isNativePlatform()) return;
  const { files } = await Filesystem.readdir({ path: '', directory: Directory.Cache });
  for (const file of files)
    if (file.name.startsWith('microgram-screen-share-'))
      await Filesystem.rmdir({ path: file.name, directory: Directory.Cache, recursive: true });
    else if (/^microgram-\d{4}-\d{2}-\d{2}\.json$/.test(file.name))
      await Filesystem.deleteFile({ path: file.name, directory: Directory.Cache });
}
