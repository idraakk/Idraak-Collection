import type { State } from './storage';
import { resolveMoment } from './savedMoments';
export type SavedReturn = {
  courseId: string;
  segmentId: string;
  time: number;
  paused: boolean;
  section: 'reels' | 'notes' | 'screens';
  screenVideo: string | null;
};
export type ReelProfileReturn = { videoId: string; start: number; time: number; paused: boolean };
export type AppView = 'feed' | 'library' | 'profile' | 'reels' | 'saved' | 'progress' | 'settings';
export type NavigationState = {
  view: AppView;
  courseId: string;
  index: number;
  reelVideoId: string;
  immersive: boolean;
  libraryProfile: string | null;
  profileScroll: number;
  scrollY: number;
  controlsHidden: boolean;
  savedSection: 'reels' | 'notes' | 'screens';
  savedScreenVideo?: string | null;
  savedQueueIds: string[];
  savedPlayback?: { time: number; paused: boolean };
  savedReturn?: SavedReturn;
  reelsProfile?: ReelProfileReturn;
  scrollPositions?: Record<string, number>;
};
export const navigationKey = 'microgram.navigation.v1';
export function readNavigation(state: State): NavigationState {
  const course = state.courses[0];
  const fallback: NavigationState = {
    view: 'feed',
    courseId: course?.id ?? '',
    index: course ? (state.last[course.id] ?? 0) : 0,
    reelVideoId: '',
    immersive: false,
    libraryProfile: null,
    profileScroll: 0,
    scrollY: 0,
    controlsHidden: false,
    savedSection: 'screens',
    savedQueueIds: [],
  };
  try {
    const raw = JSON.parse(sessionStorage.getItem(navigationKey) ?? 'null');
    if (
      !raw ||
      !['feed', 'library', 'profile', 'reels', 'saved', 'progress', 'settings'].includes(raw.view)
    )
      return fallback;
    const selected = state.courses.find((c) => c.id === raw.courseId);
    const view = !selected && ['profile', 'reels'].includes(raw.view) ? 'library' : raw.view;
    const nonnegative = (n: unknown) =>
      typeof n === 'number' && Number.isFinite(n) && n >= 0 ? Math.min(n, 1000000) : 0;
    const parentCourse = state.courses.find((c) => c.id === raw.savedReturn?.courseId);
    const parentMoment =
      parentCourse && typeof raw.savedReturn?.segmentId === 'string'
        ? resolveMoment(raw.savedReturn.segmentId, [parentCourse])
        : null;
    const savedReturn: SavedReturn | undefined =
      view === 'reels' &&
      parentMoment &&
      ['reels', 'notes', 'screens'].includes(raw.savedReturn.section) &&
      typeof raw.savedReturn.time === 'number' &&
      Number.isFinite(raw.savedReturn.time) &&
      raw.savedReturn.time >= 0
        ? {
            courseId: parentCourse!.id,
            segmentId: parentMoment.segment.id,
            time: Math.max(
              parentMoment.segment.start,
              Math.min(raw.savedReturn.time, parentMoment.segment.end - 0.05),
            ),
            paused: raw.savedReturn.paused === true,
            section: raw.savedReturn.section,
            screenVideo: state.screenNotes?.some((n) => n.videoId === raw.savedReturn.screenVideo)
              ? raw.savedReturn.screenVideo
              : null,
          }
        : undefined;
    const profileVideo = selected?.videos.find((v) => v.id === raw.reelsProfile?.videoId);
    const reelsProfile: ReelProfileReturn | undefined =
      view === 'reels' &&
      profileVideo &&
      typeof raw.reelsProfile.start === 'number' &&
      Number.isFinite(raw.reelsProfile.start) &&
      raw.reelsProfile.start >= 0 &&
      raw.reelsProfile.start < profileVideo.duration &&
      typeof raw.reelsProfile.time === 'number' &&
      Number.isFinite(raw.reelsProfile.time) &&
      raw.reelsProfile.time >= 0
        ? {
            videoId: profileVideo.id,
            start: raw.reelsProfile.start,
            time: Math.min(raw.reelsProfile.time, profileVideo.duration - 0.05),
            paused: raw.reelsProfile.paused === true,
          }
        : undefined;
    return {
      view,
      courseId: selected?.id ?? fallback.courseId,
      index: selected ? Math.floor(nonnegative(raw.index)) : fallback.index,
      reelVideoId:
        selected?.videos.find((v) => v.id === raw.reelVideoId)?.id ?? selected?.videos[0]?.id ?? '',
      immersive: Boolean(
        selected &&
        ((view === 'reels' && !reelsProfile) ||
          (raw.immersive && ['profile', 'feed', 'saved'].includes(view))),
      ),
      savedReturn,
      reelsProfile,
      libraryProfile: state.courses.some((c) => c.id === raw.libraryProfile)
        ? raw.libraryProfile
        : null,
      profileScroll: nonnegative(raw.profileScroll),
      scrollY: nonnegative(raw.scrollY),
      controlsHidden: raw.controlsHidden === true,
      savedSection:
        raw.savedSection === 'screens'
          ? 'screens'
          : raw.savedSection === 'notes'
            ? 'notes'
            : raw.savedSection === 'reels'
              ? 'reels'
              : 'screens',
      savedPlayback:
        raw.savedPlayback &&
        typeof raw.savedPlayback.time === 'number' &&
        Number.isFinite(raw.savedPlayback.time) &&
        raw.savedPlayback.time >= 0
          ? {
              time: Math.min(raw.savedPlayback.time, 86400),
              paused: raw.savedPlayback.paused === true,
            }
          : undefined,
      savedScreenVideo:
        typeof raw.savedScreenVideo === 'string' &&
        state.screenNotes?.some((n) => n.videoId === raw.savedScreenVideo)
          ? raw.savedScreenVideo
          : null,
      scrollPositions: Object.fromEntries(
        Object.entries(
          raw.scrollPositions && typeof raw.scrollPositions === 'object' ? raw.scrollPositions : {},
        )
          .slice(0, 1000)
          .filter(
            ([key, value]) =>
              key.length < 400 && typeof value === 'number' && Number.isFinite(value) && value >= 0,
          )
          .map(([key, value]) => [key, nonnegative(value)]),
      ),
      savedQueueIds: Array.isArray(raw.savedQueueIds)
        ? raw.savedQueueIds
            .filter(
              (id: unknown) => typeof id === 'string' && /^[\w-]{11}:(15|30|60|90):\d+$/.test(id),
            )
            .slice(0, 10000)
        : [],
    };
  } catch {
    return fallback;
  }
}
export function saveNavigation(route: NavigationState) {
  try {
    sessionStorage.setItem(navigationKey, JSON.stringify(route));
  } catch {
    /* Navigation still works if browser storage is unavailable. */
  }
}
