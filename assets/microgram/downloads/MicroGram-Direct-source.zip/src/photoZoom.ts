export function photoPanBounds(
  width: number,
  height: number,
  viewport: { width: number; height: number },
  turned: boolean,
  scale: number,
) {
  const w = turned ? height : width;
  const h = turned ? width : height;
  const fit = w > 0 && h > 0 ? Math.min(viewport.width / w, viewport.height / h) : 1;
  return {
    x: Math.max(0, ((w || viewport.width) * fit * scale - viewport.width) / 2),
    y: Math.max(0, ((h || viewport.height) * fit * scale - viewport.height) / 2),
  };
}
export function clampPhotoPan(x: number, y: number, bounds: { x: number; y: number }) {
  return {
    x: bounds.x ? Math.max(-bounds.x, Math.min(bounds.x, x)) : 0,
    y: bounds.y ? Math.max(-bounds.y, Math.min(bounds.y, y)) : 0,
  };
}
