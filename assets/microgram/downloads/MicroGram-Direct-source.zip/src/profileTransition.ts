export function clearProfileExit() {
  document.querySelectorAll('.profile-exit-snapshot').forEach((node) => node.remove());
}
export function animateProfileExit() {
  clearProfileExit();
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const source = document.querySelector<HTMLElement>('.course-profile');
  if (!source) return;
  const rect = source.getBoundingClientRect();
  const copy = source.cloneNode(true) as HTMLElement;
  copy.classList.add('profile-exit-snapshot');
  copy.setAttribute('aria-hidden', 'true');
  copy.inert = true;
  copy.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
  Object.assign(copy.style, {
    left: `${rect.left}px`,
    top: `${rect.top}px`,
    width: `${rect.width}px`,
    height: `${rect.height}px`,
  });
  document.body.append(copy);
  copy.addEventListener('animationend', () => copy.remove(), { once: true });
  setTimeout(() => copy.remove(), 250);
}
