import type { Segment } from './core';
import type { attachAdaptivePlayer } from './adaptivePlayback';
import { openingTimes, requestOpenings } from './reelOpenings';
import type { VideoQuality } from './videoQuality';

type Controller = ReturnType<typeof attachAdaptivePlayer>;
type Slot = {
  video: HTMLVideoElement;
  segment?: Segment;
  controller?: Controller;
  state: 'empty' | 'loading' | 'ready' | 'used' | 'failed';
  epoch: number;
  promise?: Promise<void>;
  target: number;
  failedAt: number;
};
type Options = {
  create: typeof attachAdaptivePlayer;
  quality?: (id: string) => VideoQuality;
  nearby: () => Segment[];
  select: (slot: number) => void;
  frame: (segment: Segment, video: HTMLVideoElement) => Promise<void>;
  failure: (message: string) => void;
};

/** Bounded video surfaces: one audible, neighbours paused at decoded first frames. */
export class ReelDeck {
  private slots: Slot[];
  private active = 0;
  private current = '';
  private destroyed = false;
  private timer: ReturnType<typeof setInterval>;
  private entered = 0;
  private warmStage = -1;
  private direction = 1;
  private saveData: boolean;
  private hidden = () => {
    if (document.hidden) {
      for (const slot of this.slots) slot.video.pause();
      const s = this.slots[this.active].segment;
      if (s) requestOpenings(s.video.id, []);
    }
  };
  constructor(
    videos: HTMLVideoElement[],
    private options: Options,
  ) {
    const device = navigator as Navigator & {
      deviceMemory?: number;
      connection?: { saveData?: boolean; effectiveType?: string };
    };
    this.saveData =
      !!device.connection?.saveData ||
      ['2g', 'slow-2g'].includes(device.connection?.effectiveType ?? '');
    const memory = device.deviceMemory ?? 4;
    const count = this.saveData || memory <= 2 ? 2 : memory >= 8 ? 4 : 3;
    this.slots = videos
      .slice(0, count)
      .map((video) => ({ video, state: 'empty', epoch: 0, target: 0, failedAt: 0 }));
    this.timer = setInterval(() => void this.tick(), 350);
    document.addEventListener('visibilitychange', this.hidden);
  }
  readyFor(id: string) {
    return this.slots.some((s) => s.segment?.id === id && s.state === 'ready' && !s.video.seeking);
  }
  private choose(segment: Segment) {
    const found = this.slots.findIndex((s) => s.segment?.id === segment.id);
    if (found >= 0) return found;
    if (!this.current) return 0;
    const empty = this.slots.findIndex((s, i) => i !== this.active && !s.segment);
    if (empty >= 0) return empty;
    const nearby = this.options.nearby();
    const at = nearby.findIndex((s) => s.id === this.current);
    const keep = new Set([segment.id, this.current, nearby[at + 1]?.id, nearby[at - 1]?.id]);
    const unused = this.slots.findIndex(
      (s, i) => i !== this.active && (!s.segment || !keep.has(s.segment.id)),
    );
    return unused >= 0 ? unused : this.slots.findIndex((_, i) => i !== this.active);
  }
  activate(segment: Segment, time = segment.start): Promise<HTMLVideoElement> {
    if (this.destroyed) return Promise.reject(new Error('Player closed.'));
    const existing = this.slots[this.active];
    if (
      this.current === segment.id &&
      existing.segment?.id === segment.id &&
      existing.state !== 'failed'
    )
      return (existing.promise ?? Promise.resolve()).then(() => existing.video);
    const index = this.choose(segment);
    const previousIndex = this.active,
      old = this.slots[this.active];
    const ordered = this.options.nearby();
    const from = ordered.findIndex((s) => s.id === this.current),
      to = ordered.findIndex((s) => s.id === segment.id);
    if (from >= 0 && to >= 0 && from !== to) this.direction = Math.sign(to - from);
    this.active = index;
    this.current = segment.id;
    this.entered = Date.now();
    this.warmStage = -1;
    this.options.select(index);
    if (old !== this.slots[index]) {
      old.controller?.setForeground(false);
      old.video.muted = true;
      old.video.pause();
      if (old.state === 'ready') old.state = 'used';
      if (old.segment && old.controller)
        void this.load(previousIndex, old.segment, old.segment.start).catch(() => {});
    }
    const slot = this.slots[index];
    const ready = this.load(index, segment, time);
    return ready.then(() => {
      if (this.destroyed || this.current !== segment.id || this.active !== index)
        throw new Error('Reel changed.');
      slot.controller?.setForeground(true);
      return slot.video;
    });
  }
  prepare(segment: Segment, intent = false) {
    if (this.destroyed) return;
    const index = this.choose(segment);
    if (index === this.active) return;
    void this.load(index, segment, segment.start).catch(() => {});
    if (intent && this.slots.length >= 4) {
      const ordered = this.options.nearby();
      const from = ordered.findIndex((s) => s.id === this.current),
        to = ordered.findIndex((s) => s.id === segment.id);
      const following = ordered[to + Math.sign(to - from)];
      if (from >= 0 && to >= 0 && from !== to && following) {
        const extra = this.choose(following);
        if (extra !== this.active && extra !== index)
          void this.load(extra, following, following.start).catch(() => {});
      }
    }
  }
  private load(index: number, segment: Segment, time: number): Promise<void> {
    const slot = this.slots[index];
    if (slot.segment?.id === segment.id) {
      if (slot.state === 'loading' && Math.abs(slot.target - time) < 0.05) return slot.promise!;
      if (
        slot.state === 'ready' &&
        slot.video.readyState >= 3 &&
        !slot.video.seeking &&
        Math.abs(slot.video.currentTime - time) < 0.15
      )
        return Promise.resolve();
      if (slot.state === 'failed' && Date.now() - slot.failedAt < 15000 && index !== this.active)
        return Promise.reject(new Error('Standby unavailable.'));
    }
    const reuse =
      slot.segment?.video.id === segment.video.id &&
      slot.controller &&
      ['ready', 'used'].includes(slot.state) &&
      slot.video.readyState >= 2;
    const previous = slot.controller;
    const epoch = ++slot.epoch;
    slot.segment = segment;
    slot.target = time;
    slot.state = 'loading';
    slot.video.pause();
    if (index !== this.active) slot.video.muted = true;
    slot.promise = (async () => {
      if (!reuse) {
        slot.controller = undefined;
        await previous?.destroy();
        if (this.destroyed || slot.epoch !== epoch) throw new Error('Preparation cancelled.');
        const controller = this.options.create(
          slot.video,
          segment.video.id,
          time,
          (message) => {
            if (!this.destroyed && slot.epoch === epoch && this.active === index)
              this.options.failure(message);
          },
          undefined,
          { deck: true, preference: () => this.options.quality?.(segment.video.id) ?? 'high' },
        );
        slot.controller = controller;
        await controller.ready;
      }
      if (this.destroyed || slot.epoch !== epoch) throw new Error('Preparation cancelled.');
      if (Math.abs(slot.video.currentTime - time) > 0.08) slot.video.currentTime = time;
      const deadline = Date.now() + 35000;
      while (
        slot.video.readyState < 3 ||
        slot.video.seeking ||
        Math.abs(slot.video.currentTime - time) > 0.3
      ) {
        if (this.destroyed || slot.epoch !== epoch) throw new Error('Preparation cancelled.');
        if (slot.video.error || Date.now() > deadline)
          throw new Error('This reel could not get ready. Try again.');
        await new Promise((resolve) => setTimeout(resolve, 30));
      }
      if (this.destroyed || slot.epoch !== epoch) throw new Error('Preparation cancelled.');
      slot.state = 'ready';
      void this.options.frame(segment, slot.video).catch(() => {});
    })().catch((error) => {
      if (slot.epoch === epoch) {
        slot.state = 'failed';
        slot.failedAt = Date.now();
      }
      throw error;
    });
    return slot.promise;
  }
  private async tick() {
    if (this.destroyed || document.hidden) return;
    const slot = this.slots[this.active];
    if (!slot.segment || slot.state !== 'ready' || slot.video.paused || slot.video.seeking) return;
    const nearby = this.options.nearby(),
      at = nearby.findIndex((s) => s.id === this.current);
    const stage = Date.now() - this.entered >= 5000 ? 1 : 0;
    if (this.warmStage !== stage) {
      this.warmStage = stage;
      requestOpenings(
        slot.segment.video.id,
        openingTimes(slot.segment, nearby, stage ? 5000 : 0, this.saveData, this.direction),
      );
    }
    const targets = [this.direction, -this.direction, 2 * this.direction, 3 * this.direction]
      .map((offset) => nearby[at + offset])
      .filter((s): s is Segment => !!s)
      .slice(0, this.slots.length - 1);
    for (const target of targets) {
      if (!target) continue;
      const existing = this.slots.find((s) => s.segment?.id === target.id);
      if (existing?.state === 'loading') continue;
      if (existing?.state === 'ready' && Math.abs(existing.video.currentTime - target.start) < 0.15)
        continue;
      this.prepare(target);
      return; // at most one new standby preparation per scheduler turn
    }
  }
  destroy() {
    this.destroyed = true;
    clearInterval(this.timer);
    document.removeEventListener('visibilitychange', this.hidden);
    const segment = this.slots[this.active].segment;
    if (segment) requestOpenings(segment.video.id, []);
    return Promise.all(
      this.slots.map(async (slot) => {
        slot.epoch++;
        slot.video.pause();
        await slot.controller?.destroy();
      }),
    );
  }
}
