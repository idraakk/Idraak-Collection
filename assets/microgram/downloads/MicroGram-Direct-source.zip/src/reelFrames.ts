import { useSyncExternalStore } from 'react';
import { androidDirect } from './androidDirect';
import type { Segment, Video } from './core';

const frames = new Map<string, { url: string; bytes: number }>();
const dimensions = new Map<string, { width: number; height: number }>();
let dimensionsVersion = 0;
const listeners = new Set<() => void>();
export const getFrameDimensions = (id: string) => dimensions.get(id);
export function rememberFrameDimensions(id: string, width: number, height: number) {
  const known = dimensions.get(id);
  if (
    width > 0 &&
    height > 0 &&
    (!known || Math.abs(known.width / known.height - width / height) > 0.001)
  ) {
    dimensions.set(id, { width, height });
    dimensionsVersion++;
    for (const notify of listeners) notify();
  }
}
export function useFrameDimensions() {
  return useSyncExternalStore(
    (notify) => {
      listeners.add(notify);
      return () => {
        listeners.delete(notify);
      };
    },
    () => dimensionsVersion,
  );
}
let bytes = 0;
const key = (id: string, time: number) => `${id}:${Math.round(time * 1000)}`;
export function useReelFrame(video: Video, time?: number) {
  return useSyncExternalStore(
    (callback) => {
      listeners.add(callback);
      return () => {
        listeners.delete(callback);
      };
    },
    () =>
      time === undefined || video.local || !androidDirect
        ? video.thumbnail
        : (frames.get(key(video.id, time))?.url ?? `/api/media/${video.id}/preview?time=${time}`),
  );
}
export function clearReelFrames() {
  for (const f of frames.values()) URL.revokeObjectURL(f.url);
  frames.clear();
  dimensions.clear();
  dimensionsVersion++;
  bytes = 0;
  for (const notify of listeners) notify();
}
if (typeof window !== 'undefined')
  window.addEventListener('microgram-cache-cleared', clearReelFrames);
export async function rememberReelFrame(segment: Segment, video: HTMLVideoElement) {
  if (
    Math.abs(video.currentTime - segment.start) > 0.2 ||
    video.readyState < 2 ||
    !video.videoWidth
  )
    return;
  const id = key(segment.video.id, segment.start);
  rememberFrameDimensions(segment.video.id, video.videoWidth, video.videoHeight);
  if (frames.has(id)) return;
  const canvas = document.createElement('canvas');
  canvas.width = Math.min(640, video.videoWidth);
  canvas.height = Math.round((canvas.width * video.videoHeight) / video.videoWidth);
  try {
    canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
  } catch {
    return;
  }
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/jpeg', 0.68),
  );
  if (!blob || blob.size > 128000) return;
  const url = URL.createObjectURL(blob);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
  } catch {}
  if (frames.has(id)) {
    URL.revokeObjectURL(url);
    return;
  }
  frames.set(id, { url, bytes: blob.size });
  bytes += blob.size;
  while (frames.size > 128 || bytes > 8 * 1024 * 1024) {
    const first = frames.keys().next().value!;
    const old = frames.get(first)!;
    frames.delete(first);
    bytes -= old.bytes;
    URL.revokeObjectURL(old.url);
  }
  for (const notify of listeners) notify();
  if (androidDirect) {
    const image = canvas.toDataURL('image/jpeg', 0.68).split(',')[1];
    void fetch(`/api/media/${segment.video.id}/preview?time=${segment.start}`, {
      method: 'POST',
      body: JSON.stringify({ image }),
    }).catch(() => {});
  }
}
