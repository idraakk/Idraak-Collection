export type TouchPoint = { x: number; y: number };

/** A forward swipe travels from the phone's charging edge toward its top. */
export function reelSwipe(start: TouchPoint, end: TouchPoint, angle = 0): -1 | 0 | 1 {
  const x = start.x - end.x;
  const y = start.y - end.y;
  const orientation = ((angle % 360) + 360) % 360;
  const along = orientation === 90 ? x : orientation === 270 ? -x : orientation === 180 ? -y : y;
  const across = orientation === 90 || orientation === 270 ? y : x;
  if (Math.abs(along) < 60 || Math.abs(along) < Math.abs(across) * 1.2) return 0;
  return along > 0 ? 1 : -1;
}

export function deviceAngle(): number {
  return (
    screen.orientation?.angle ?? (window as Window & { orientation?: number }).orientation ?? 0
  );
}
