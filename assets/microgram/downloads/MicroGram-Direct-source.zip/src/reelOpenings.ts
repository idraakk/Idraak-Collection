import { androidDirect } from './androidDirect';
import type { Course, Segment, Video } from './core';

export function openingTimes(
  current: Segment,
  nearby: Segment[],
  dwell = 0,
  saveData = false,
  direction = 1,
) {
  const same = nearby
    .filter((s) => s.video.id === current.video.id)
    .sort((a, b) => a.start - b.start);
  const index = same.findIndex((s) => s.id === current.id);
  if (index < 0) return [current.start];
  const offsets = saveData ? [0, 1] : dwell < 5000 ? [0, 1, -1, 2] : [0, 1, -1, 2, -2, 3, 4, 5];
  return offsets
    .map((n) => same[index + n * direction]?.start)
    .filter((n): n is number => n !== undefined);
}
export function requestOpenings(id: string, starts: number[]) {
  if (!androidDirect) return;
  void fetch(`/api/media/${id}/warm`, { method: 'POST', body: JSON.stringify({ starts }) }).catch(
    () => {},
  );
}
export function primeVideo(video: Video, seconds: number) {
  if (video.local) return;
  const connection = (
    navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }
  ).connection;
  const dataSaver =
    connection?.saveData || ['2g', 'slow-2g'].includes(connection?.effectiveType ?? '');
  requestOpenings(
    video.id,
    Array.from({ length: dataSaver ? 1 : 3 }, (_, i) => i * seconds).filter(
      (t) => t < video.duration,
    ),
  );
}
export function primeCourse(course: Course, seconds: number) {
  if (course.videos[0]) primeVideo(course.videos[0], course.reelSeconds ?? seconds);
}
