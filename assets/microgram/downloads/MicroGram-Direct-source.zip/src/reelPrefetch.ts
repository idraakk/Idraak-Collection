import type shaka from 'shaka-player';
import { reelWarmTargets, type ReelWindow } from './reelWarmTargets';

// Warm exact DASH ranges through the existing bounded device cache. No hidden
// video elements, full-file downloads or separate unbounded cache are created.
export function warmReels(
  player: shaka.Player,
  video: HTMLVideoElement,
  getWindow: () => ReelWindow,
) {
  const completed = new Set<string>();
  let busy = false,
    stopped = false,
    windowKey = '',
    spent = 0;
  let request: AbortController | undefined;
  let manifest: ReturnType<shaka.Player['getManifest']> | undefined;
  let variantId: number | undefined;
  const connection = (
    navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }
  ).connection;
  const constrained = () =>
    Boolean(
      (location.hostname.endsWith('.ts.net') && location.port !== '8443') ||
      connection?.saveData ||
      ['slow-2g', '2g'].includes(connection?.effectiveType || ''),
    );
  const budget = () => (constrained() ? 4 : 24) * 1024 * 1024;
  const eligible = () =>
    !stopped && !video.paused && !video.seeking && video.readyState >= 3 && !document.hidden;
  const cancel = () => request?.abort();
  function bufferAhead() {
    for (let i = 0; i < video.buffered.length; i++)
      if (video.buffered.start(i) <= video.currentTime && video.buffered.end(i) > video.currentTime)
        return video.buffered.end(i) - video.currentTime;
    return 0;
  }
  async function tick() {
    if (busy || !eligible() || bufferAhead() < Math.max(4, video.playbackRate * 3)) return;
    const window = getWindow();
    const key = `${window.start}:${window.end}`;
    if (key !== windowKey) {
      windowKey = key;
      spent = 0;
    }
    if (!window.enabled || spent >= budget()) return;
    const track = player.getVariantTracks().find((t) => t.active);
    if (!manifest || variantId !== track?.id) {
      manifest = player.getManifest();
      variantId = track?.id;
    }
    const variant = manifest?.variants.find((v) => v.id === track?.id);
    if (!variant) return;
    busy = true;
    request = new AbortController();
    const signal = request.signal;
    try {
      for (const target of reelWarmTargets(window, video.duration, constrained())) {
        // Audio first so a swipe does not reveal a picture with missing sound.
        for (const stream of [variant.audio, variant.video]) {
          if (!stream?.segmentIndex) continue;
          const iterator = stream.segmentIndex.getIteratorForTime(target.time);
          for (let n = 0; n < 4; n++) {
            const ref = iterator?.next().value;
            if (!ref || ref.getStartTime() >= target.time + target.seconds) break;
            if (
              !eligible() ||
              signal.aborted ||
              getWindow().start !== window.start ||
              bufferAhead() < 3
            )
              return;
            const uri = ref.getUris()[0];
            const start = ref.getStartByte(),
              end = ref.getEndByte();
            if (!uri || end === null || end < start) continue;
            const url = new URL(uri, location.href);
            if (
              url.origin !== location.origin ||
              !/^\/api\/stream\/[\w-]{11}\/track\//.test(url.pathname)
            )
              continue;
            const id = `${url.href}:${start}:${end}`;
            if (completed.has(id)) continue;
            const cost = (Math.floor(end / 1048576) - Math.floor(start / 1048576) + 1) * 1048576;
            if (spent + cost > budget()) continue;
            spent += cost;
            const response = await fetch(url, {
              headers: { Range: `bytes=${start}-${end}`, 'X-Microgram-Prefetch': '1' },
              signal,
              priority: 'low',
            });
            if (response.status !== 206) {
              await response.body?.cancel();
              return;
            }
            const reader = response.body?.getReader();
            if (!reader) return;
            while (!(await reader.read()).done) {
              if (signal.aborted) {
                await reader.cancel();
                return;
              }
            }
            completed.add(id);
            if (completed.size > 160) completed.delete(completed.values().next().value!);
          }
        }
      }
    } catch {
      /* Optional warming must never interrupt foreground playback. */
    } finally {
      busy = false;
      request = undefined;
    }
  }
  const timer = setInterval(() => void tick(), 600);
  video.addEventListener('pause', cancel);
  video.addEventListener('seeking', cancel);
  document.addEventListener('visibilitychange', cancel);
  return () => {
    stopped = true;
    cancel();
    clearInterval(timer);
    video.removeEventListener('pause', cancel);
    video.removeEventListener('seeking', cancel);
    document.removeEventListener('visibilitychange', cancel);
  };
}
