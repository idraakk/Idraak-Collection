export type ReelWindow = { start: number; end: number; enabled: boolean };
// Keep upcoming boundaries in MSE, not just on disk. Limit the window so a
// long lecture never becomes a full-video memory buffer.
export function reelBufferPlan(window?: ReelWindow) {
  if (!window?.enabled) return { ahead: 20, behind: 10 };
  const length = Math.max(1, window.end - window.start);
  return {
    ahead: Math.min(180, Math.max(40, length * 2 + 10)),
    behind: Math.min(120, Math.max(30, length + 10)),
  };
}
export function reelWarmTargets(window: ReelWindow, duration: number, saveData = false) {
  const length = window.end - window.start;
  if (!window.enabled || !Number.isFinite(duration) || length <= 0) return [];
  const targets = [
    { time: window.end, seconds: 10 },
    ...(!saveData
      ? [
          { time: window.end + length, seconds: 6 },
          { time: window.end + 2 * length, seconds: 4 },
          { time: window.start - length, seconds: 4 },
        ]
      : []),
  ];
  return targets
    .filter((t) => t.time >= 0 && t.time < duration)
    .map((t) => ({ ...t, seconds: Math.min(t.seconds, duration - t.time) }));
}
