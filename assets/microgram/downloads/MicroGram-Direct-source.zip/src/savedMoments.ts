import type { Course, Segment } from './core';
import type { State } from './storage';
export type SavedMoment = { segment: Segment; course: Course; aliases: string[]; note: string };
const courseIndex = new WeakMap<Course[], Map<string, { course: Course; videoIndex: number }>>();
function indexed(courses: Course[]) {
  let result = courseIndex.get(courses);
  if (!result) {
    result = new Map();
    for (const course of courses)
      course.videos.forEach((video, videoIndex) => {
        if (!result!.has(video.id)) result!.set(video.id, { course, videoIndex });
      });
    courseIndex.set(courses, result);
  }
  return result;
}
export function resolveMoment(id: string, courses: Course[]): SavedMoment | null {
  const match = id.match(/^([\w-]{11}):(15|30|60|90):(\d+)$/);
  if (!match) return null;
  const entry = indexed(courses).get(match[1]);
  if (!entry) return null;
  const { course, videoIndex } = entry;
  const video = course.videos[videoIndex],
    seconds = Number(match[2]),
    index = Number(match[3]);
  const start = seconds * index;
  if (!Number.isSafeInteger(index) || start >= video.duration) return null;
  return {
    course,
    segment: {
      id,
      video,
      videoIndex,
      index,
      start,
      end: Math.min(video.duration, start + seconds),
    },
    aliases: [id],
    note: '',
  };
}
export const momentKey = (r: Segment) => `${r.video.id}:${r.start}:${r.end}`;
export function idsForMoment(segment: Segment, ids: string[], courses: Course[]) {
  const key = momentKey(segment);
  return [...new Set(ids)].filter((id) => {
    const item = resolveMoment(id, courses);
    return item && momentKey(item.segment) === key;
  });
}
export function savedMoments(state: State, mode: 'reels' | 'notes'): SavedMoment[] {
  const ids =
    mode === 'reels'
      ? state.saved
      : Object.keys(state.notes).filter((id) => state.notes[id].trim());
  const groups = new Map<string, SavedMoment>();
  for (const id of [...new Set(ids)].reverse()) {
    const item = resolveMoment(id, state.courses);
    if (!item) continue;
    const key = momentKey(item.segment),
      existing = groups.get(key);
    if (existing) existing.aliases.push(id);
    else groups.set(key, item);
  }
  const notesByMoment = new Map<string, Set<string>>();
  for (const [id, text] of Object.entries(state.notes)) {
    if (!text.trim()) continue;
    const item = resolveMoment(id, state.courses);
    if (!item) continue;
    const key = momentKey(item.segment);
    if (!notesByMoment.has(key)) notesByMoment.set(key, new Set());
    notesByMoment.get(key)!.add(text);
  }
  for (const item of groups.values())
    item.note = [...(notesByMoment.get(momentKey(item.segment)) ?? [])].join('\n\n');
  return [...groups.values()];
}
