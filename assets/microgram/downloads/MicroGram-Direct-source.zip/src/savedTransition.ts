type Motion = { direction: 'open' | 'back'; snapshot: HTMLElement; scroll: number; target: string };
export const PAGE_MOTION = { duration: 190, easing: 'cubic-bezier(.22,.75,.25,1)' };
let pending: Motion | null = null;
let running: Animation[] = [];
let restore: (() => void) | undefined;
let cleanupTimer: ReturnType<typeof setTimeout> | undefined;
export function cancelSavedTransition() {
  clearTimeout(cleanupTimer);
  for (const animation of running) animation.cancel();
  running = [];
  restore?.();
  restore = undefined;
  document.querySelectorAll('.saved-motion-snapshot').forEach((n) => n.remove());
  pending = null;
}
export function prepareSavedTransition(
  direction: Motion['direction'],
  scroll: number,
  options: { source?: string; target?: string } = {},
) {
  const source = document.querySelector<HTMLElement>(options.source ?? 'main .saved-page');
  if (!source || matchMedia('(prefers-reduced-motion: reduce)').matches) {
    cancelSavedTransition();
    return false;
  }
  const rect = source.getBoundingClientRect(),
    copy = source.cloneNode(true) as HTMLElement;
  // Freeze only visible images, so React can safely revoke their object URLs
  // while the outgoing page is animating. Offscreen captures allocate no canvas.
  const originalImages = source.querySelectorAll<HTMLImageElement | HTMLVideoElement>('img,video');
  copy.querySelectorAll<HTMLElement>('img,video').forEach((image, i) => {
    const original = originalImages[i],
      box = original.getBoundingClientRect();
    if (
      (original instanceof HTMLVideoElement ? original.readyState >= 2 : original.complete) &&
      (original instanceof HTMLVideoElement ? original.videoWidth : original.naturalWidth) &&
      box.bottom > 0 &&
      box.top < innerHeight &&
      box.width > 0
    ) {
      const canvas = document.createElement('canvas');
      const width =
        original instanceof HTMLVideoElement ? original.videoWidth : original.naturalWidth;
      const height =
        original instanceof HTMLVideoElement ? original.videoHeight : original.naturalHeight;
      const scale = Math.min(1, 1000 / width);
      canvas.width = Math.round(width * scale);
      canvas.height = Math.round(height * scale);
      try {
        canvas.getContext('2d')?.drawImage(original, 0, 0, canvas.width, canvas.height);
      } catch {
        /* External covers can remain plain placeholders. */
      }
      canvas.className = original.className;
      canvas.style.cssText = original.style.cssText;
      const computed = getComputedStyle(original);
      for (const property of [
        'position',
        'inset',
        'left',
        'top',
        'right',
        'bottom',
        'width',
        'height',
        'max-width',
        'max-height',
        'object-fit',
        'transform',
        'transform-origin',
        'display',
        'border-radius',
        'opacity',
      ])
        canvas.style.setProperty(property, computed.getPropertyValue(property));
      image.replaceWith(canvas);
    } else {
      image.removeAttribute('src');
      image.style.visibility = 'hidden';
    }
  });
  copy.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
  copy.querySelectorAll('[role]').forEach((n) => n.removeAttribute('role'));
  const opacity = getComputedStyle(source).opacity;
  cancelSavedTransition();
  Object.assign(copy.style, {
    position: 'absolute',
    left: `${rect.left}px`,
    top: `${rect.top}px`,
    width: `${rect.width}px`,
    height: `${rect.height}px`,
    margin: '0',
    opacity,
    animation: 'none',
  });
  const snapshot = document.createElement('div');
  snapshot.className = 'saved-motion-snapshot';
  snapshot.inert = true;
  snapshot.setAttribute('aria-hidden', 'true');
  const context = document.createElement('div');
  context.className = document.querySelector('.app')?.className ?? '';
  const sourceStyle = getComputedStyle(source);
  Object.assign(context.style, {
    position: 'static',
    minHeight: '0',
    fontFamily: sourceStyle.fontFamily,
    fontSize: sourceStyle.fontSize,
    color: sourceStyle.color,
  });
  context.append(copy);
  // An inert paint copy must never become a second app/main/control in live
  // document queries. Its closed shadow tree also isolates transient styles.
  const shadow = snapshot.attachShadow({ mode: 'closed' });
  const styles = document.createElement('style');
  styles.textContent = [...document.styleSheets]
    .flatMap((sheet) => {
      try {
        return [...sheet.cssRules].map((rule) => rule.cssText);
      } catch {
        return [];
      }
    })
    .join('\n');
  shadow.append(styles, context);
  document.body.append(snapshot);
  pending = { direction, snapshot, scroll, target: options.target ?? 'main .saved-page' };
  return true;
}
export function finishSavedTransition() {
  const motion = pending;
  if (!motion) return;
  pending = null;
  const page = document.querySelector<HTMLElement>(motion.target);
  if (!page) {
    cancelSavedTransition();
    return;
  }
  window.scrollTo({ top: motion.scroll, behavior: 'instant' });
  const prior = {
    position: page.style.position,
    zIndex: page.style.zIndex,
    background: page.style.background,
    pointerEvents: page.style.pointerEvents,
  };
  Object.assign(page.style, {
    position:
      getComputedStyle(page).position === 'static' ? 'relative' : getComputedStyle(page).position,
    zIndex: motion.direction === 'open' ? '16' : '14',
    background: '#080808',
    pointerEvents: 'none',
  });
  motion.snapshot.style.zIndex = '15';
  const options: KeyframeAnimationOptions = {
    ...PAGE_MOTION,
    fill: 'both',
  };
  const frames =
    motion.direction === 'open'
      ? [
          { transform: 'translate3d(16%,0,0)', opacity: 0.82 },
          { transform: 'translate3d(0,0,0)', opacity: 1 },
        ]
      : [
          { transform: 'translate3d(-4%,0,0)', opacity: 0.94 },
          { transform: 'translate3d(0,0,0)', opacity: 1 },
        ];
  running = [
    page.animate(frames, options),
    motion.snapshot.animate(
      motion.direction === 'open'
        ? [{ opacity: 1 }, { opacity: 0 }]
        : [
            { transform: 'translate3d(0,0,0)', opacity: 1 },
            { transform: 'translate3d(16%,0,0)', opacity: 0 },
          ],
      options,
    ),
  ];
  page.dataset.savedMotion = motion.direction;
  restore = () => {
    Object.assign(page.style, prior);
    delete page.dataset.savedMotion;
  };
  cleanupTimer = setTimeout(cancelSavedTransition, 200);
}
