import { getScreenImage } from './screenNotes';
type Entry = { source: string; bytes: number; pending?: Promise<string>; valid: boolean };
const images = new Map<string, Entry>();
let bytes = 0;
export const cachedScreenSource = (id: string) => images.get(id)?.source ?? '';
export function screenImageSource(id: string): Promise<string> {
  const found = images.get(id);
  if (found) {
    images.delete(id);
    images.set(id, found);
    return found.pending ?? Promise.resolve(found.source);
  }
  const entry: Entry = { source: '', bytes: 0, valid: true };
  images.set(id, entry);
  entry.pending = getScreenImage(id)
    .then((blob) => {
      if (!blob || !entry.valid) {
        if (images.get(id) === entry) images.delete(id);
        return '';
      }
      entry.source = URL.createObjectURL(blob);
      entry.bytes = blob.size;
      bytes += blob.size;
      entry.pending = undefined;
      while (images.size > 64 || bytes > 16 * 1024 * 1024) {
        const oldest = [...images].find(([key, value]) => key !== id && !value.pending);
        if (!oldest) break;
        images.delete(oldest[0]);
        oldest[1].valid = false;
        bytes -= oldest[1].bytes;
        URL.revokeObjectURL(oldest[1].source);
      }
      return entry.source;
    })
    .catch(() => {
      if (images.get(id) === entry) images.delete(id);
      return '';
    });
  return entry.pending;
}
export function primeScreenSources(ids: string[]) {
  for (const id of [...new Set(ids)].slice(0, 18)) void screenImageSource(id);
}
if (typeof window !== 'undefined')
  window.addEventListener('microgram-screen-images', (event) => {
    const ids = (event as CustomEvent<string[] | undefined>).detail;
    for (const [id, entry] of images)
      if (!ids || ids.includes(id)) {
        images.delete(id);
        entry.valid = false;
        bytes -= entry.bytes;
        if (entry.source) URL.revokeObjectURL(entry.source);
      }
  });
