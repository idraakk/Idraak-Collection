import type { ScreenNote, State } from './storage';
import { schema, migrateState, expireMetadata } from './storage';
import { z } from 'zod';

const database = 'microgram.screen-notes.v1';
const store = 'frames';
export const SCREEN_NOTE_LIMIT = 500;
export const SCREEN_NOTE_BYTES = 50 * 1024 * 1024;
function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    let request: IDBOpenDBRequest;
    try {
      request = indexedDB.open(database, 1);
    } catch {
      reject(
        new Error(
          'Screen Notes storage is unavailable. Allow site storage or free some device space, then try again.',
        ),
      );
      return;
    }
    request.onupgradeneeded = () => request.result.createObjectStore(store);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(new Error('Screen Notes storage is unavailable on this device.'));
    request.onblocked = () => reject(new Error('Close other MicroGram tabs and try again.'));
  });
}
async function transaction<T>(
  mode: IDBTransactionMode,
  work: (s: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const request = work(tx.objectStore(store));
    tx.oncomplete = () => {
      db.close();
      resolve(request.result);
    };
    tx.onerror = tx.onabort = () => {
      db.close();
      reject(new Error('Could not save the frame. Free some device storage and try again.'));
    };
  });
}
export const getScreenImage = (id: string): Promise<Blob | undefined> =>
  transaction('readonly', (s) => s.get(id));
export const clearScreenImages = async () => {
  await transaction('readwrite', (s) => s.clear());
  window.dispatchEvent(new CustomEvent('microgram-screen-images'));
};
export const removeScreenImage = async (id: string) => {
  await transaction('readwrite', (s) => s.delete(id));
  window.dispatchEvent(new CustomEvent('microgram-screen-images', { detail: [id] }));
};
export async function putScreenImages(images: { id: string; blob: Blob }[], restoring = false) {
  const db = await openDatabase();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const s = tx.objectStore(store);
    const keys = s.getAllKeys();
    const values = s.getAll();
    values.onsuccess = () => {
      const incoming = new Map(images.map((i) => [i.id, i.blob]));
      const existing = (values.result as Blob[]).reduce(
        (sum, blob, i) => sum + (incoming.has(String(keys.result[i])) ? 0 : blob.size),
        0,
      );
      const incomingBytes = images.reduce((sum, image) => sum + image.blob.size, 0);
      // A restore temporarily stages new images before replacing metadata; old images
      // remain recoverable if the localStorage write fails. Cleanup follows success.
      if (
        incomingBytes > SCREEN_NOTE_BYTES ||
        existing + incomingBytes > SCREEN_NOTE_BYTES * (restoring ? 2 : 1)
      ) {
        tx.abort();
        return;
      }
      for (const image of images) s.put(image.blob, image.id);
    };
    tx.oncomplete = () => {
      db.close();
      window.dispatchEvent(
        new CustomEvent('microgram-screen-images', { detail: images.map((image) => image.id) }),
      );
      resolve();
    };
    tx.onerror = tx.onabort = () => {
      db.close();
      reject(
        new Error(
          'Screen Notes storage is full or unavailable. Export a backup, then remove some captures to free space.',
        ),
      );
    };
  });
}
export async function pruneScreenImages(keep: string[]) {
  const db = await openDatabase();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, 'readwrite');
    const s = tx.objectStore(store);
    const allowed = new Set(keep);
    const keys = s.getAllKeys();
    keys.onsuccess = () => {
      for (const id of keys.result) if (!allowed.has(String(id))) s.delete(id);
    };
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = tx.onabort = () => {
      db.close();
      reject(new Error('Could not clean Screen Notes storage.'));
    };
  });
}
export function captureFrame(video: HTMLVideoElement): Promise<Blob> {
  if (video.readyState < 2 || !video.videoWidth || video.seeking)
    return Promise.reject(new Error('Wait for the frame to finish loading, then try again.'));
  const canvas = document.createElement('canvas');
  const scale = Math.min(1, 1600 / Math.max(video.videoWidth, video.videoHeight));
  canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
  canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
  const context = canvas.getContext('2d');
  if (!context) return Promise.reject(new Error('Frame capture is unavailable in this browser.'));
  try {
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    return new Promise((resolve, reject) =>
      canvas.toBlob(
        (blob) =>
          blob ? resolve(blob) : reject(new Error('Could not capture this frame. Try again.')),
        'image/jpeg',
        0.86,
      ),
    );
  } catch {
    return Promise.reject(new Error('This video source does not allow frame capture.'));
  }
}
function dataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Could not read a Screen Note for backup.'));
    reader.readAsDataURL(blob);
  });
}
export async function screenNotesBackup(state: State) {
  if (!state.screenNotes?.length) return state;
  const images: Record<string, string> = {};
  for (const note of state.screenNotes) {
    const blob = await getScreenImage(note.id);
    if (!blob)
      throw new Error(
        'A Screen Note image is missing. Remove that capture or restore its backup before exporting.',
      );
    images[note.id] = await dataUrl(blob);
  }
  return { ...state, screenNoteImages: images };
}
export async function readScreenNotesBackup(
  raw: unknown,
): Promise<{ state: State; images: { id: string; blob: Blob }[] }> {
  const state = migrateState(expireMetadata(schema.parse(raw)));
  const media = z
    .object({ screenNoteImages: z.record(z.string(), z.string().max(4_000_000)).optional() })
    .parse(raw).screenNoteImages;
  const images = [];
  let total = 0;
  for (const note of state.screenNotes ?? []) {
    const image = media?.[note.id];
    if (!image || !/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(image))
      throw new Error('Backup contains a missing or invalid Screen Note image.');
    const binary = atob(image.slice(image.indexOf(',') + 1));
    total += binary.length;
    if (total > SCREEN_NOTE_BYTES) throw new Error('Screen Notes exceed the 50 MB device limit.');
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    // Validate actual signatures rather than trusting a data URL's MIME type.
    const jpeg = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    const png = [137, 80, 78, 71, 13, 10, 26, 10].every((n, i) => bytes[i] === n);
    if (
      (!jpeg && !png) ||
      (jpeg && !image.startsWith('data:image/jpeg;')) ||
      (png && !image.startsWith('data:image/png;'))
    )
      throw new Error('Invalid Screen Note image in backup.');
    images.push({
      id: note.id,
      blob: new Blob([bytes], { type: jpeg ? 'image/jpeg' : 'image/png' }),
    });
  }
  return { state, images };
}
export function screenNoteGroups(notes: ScreenNote[]) {
  const groups = new Map<string, ScreenNote[]>();
  for (const note of [...notes].sort((a, b) => b.createdAt - a.createdAt)) {
    const group = groups.get(note.videoId) ?? [];
    group.push(note);
    groups.set(note.videoId, group);
  }
  return [...groups].map(([videoId, items]) => ({ videoId, items }));
}
export function screenNoteTurn(
  note: ScreenNote,
  portrait: boolean,
  imageWidth: number,
  imageHeight: number,
) {
  if (note.captureRotation !== undefined && note.captureViewport) {
    const sameViewport = (note.captureViewport === 'portrait') === portrait;
    return sameViewport ? note.captureRotation === 90 : note.captureRotation !== 90;
  }
  // Older captures retain their original image and use the player's default fit.
  return imageWidth > imageHeight && portrait;
}
