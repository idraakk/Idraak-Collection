import { z } from 'zod';
import type { Course, Progress } from './core';
const video = z.object({
  width: z.number().positive().max(32768).optional(),
  height: z.number().positive().max(32768).optional(),
  local: z.boolean().optional(),
  id: z.string().regex(/^[\w-]{11}$/),
  title: z.string().max(500),
  channel: z.string().max(300),
  duration: z.number().positive().max(86400),
  thumbnail: z
    .string()
    .refine((value) => value === '/local-cover.svg' || /^https:\/\/i\.ytimg\.com\//.test(value)),
});
const course = z.object({
  kind: z.enum(['video', 'playlist']).optional(),
  reelSeconds: z.union([z.literal(15), z.literal(30), z.literal(60), z.literal(90)]).optional(),
  id: z.string().max(150),
  title: z.string().max(500),
  channel: z.string().max(300),
  videos: z.array(video).min(1).max(1000),
  importedAt: z.number(),
  sample: z.boolean().optional(),
});
export const screenNoteSchema = z.object({
  id: z.string().regex(/^[\w-]{1,100}$/),
  videoId: z.string().regex(/^[\w-]{11}$/),
  videoTitle: z.string().max(500),
  channel: z.string().max(300),
  courseId: z.string().max(150),
  courseTitle: z.string().max(500),
  playlist: z.boolean(),
  time: z.number().nonnegative().max(86400),
  createdAt: z.number().nonnegative(),
  captureRotation: z.union([z.literal(0), z.literal(90)]).optional(),
  captureViewport: z.enum(['portrait', 'landscape']).optional(),
  label: z.string().trim().max(120),
  note: z.string().max(5000),
});
export type ScreenNote = z.infer<typeof screenNoteSchema>;
export const schema = z.object({
  version: z.literal(1),
  videoLayouts: z
    .record(z.string(), z.object({ fit: z.boolean().optional(), rotated: z.boolean().optional() }))
    .optional(),
  videoQualities: z
    .record(
      z.string(),
      z.enum(['auto', 'high', 'saver', '1080', '720', '480', '360', '240', '144']),
    )
    .optional(),
  courses: z.array(course).max(100),
  progress: z.record(z.string(), z.array(z.number().int().nonnegative().max(86400)).max(86401)),
  saved: z
    .array(z.string())
    .max(10000)
    .transform((ids) => [...new Set(ids)]),
  notes: z.record(z.string(), z.string().max(5000)),
  screenNotes: z
    .array(screenNoteSchema)
    .max(500)
    .refine((items) => new Set(items.map((n) => n.id)).size === items.length)
    .optional(),
  screenNoteRotations: z.record(z.string(), z.union([z.literal(0), z.literal(90)])).optional(),
  profileLectures: z.record(z.string(), z.string().max(150)).optional(),
  seconds: z.union([z.literal(15), z.literal(30), z.literal(60), z.literal(90)]),
  goal: z.number().int().min(1).max(360),
  activity: z.record(z.string(), z.number().nonnegative()),
  videoActivity: z
    .record(
      z.string().regex(/^[\w-]{11}$/),
      z.record(z.string().regex(/^\d{4}-\d{2}-\d{2}$/), z.number().nonnegative()),
    )
    .optional(),
  last: z.record(z.string(), z.number().int().nonnegative()),
  home: z
    .object({
      minutes: z.union([z.literal(3), z.literal(5), z.literal(10)]),
      intention: z.string().max(180),
      reflections: z.record(z.string(), z.string().max(2000)),
    })
    .optional(),
  playbackSpeeds: z
    .record(
      z.string(),
      z.union([z.literal(1), z.literal(1.25), z.literal(1.5), z.literal(1.75), z.literal(2)]),
    )
    .optional(),
  lastPlayback: z
    .object({
      courseId: z.string().max(150),
      videoId: z.string().max(150),
      start: z.number().nonnegative().max(86400),
    })
    .optional(),
  profile: z
    .object({
      name: z.string().trim().min(1).max(60),
      photo: z
        .string()
        .max(400000)
        .regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/)
        .optional(),
      username: z
        .string()
        .trim()
        .regex(/^[a-zA-Z0-9_.]{1,30}$/)
        .optional(),
    })
    .optional(),
  consent: z.boolean(),
});
export type State = z.infer<typeof schema>;
export const starter: Course = {
  id: 'starter-linear-algebra',
  title: 'Essence of linear algebra',
  channel: '3Blue1Brown',
  sample: true,
  importedAt: 0,
  videos: [
    {
      id: 'fNk_zzaMoSs',
      title: 'Vectors, what even are they?',
      channel: '3Blue1Brown',
      duration: 592,
      thumbnail: 'https://i.ytimg.com/vi/fNk_zzaMoSs/hqdefault.jpg',
    },
  ],
};
export const initial: State = {
  version: 1,
  courses: [starter],
  progress: {} as Progress,
  saved: [],
  notes: {},
  seconds: 60,
  goal: 10,
  activity: {},
  last: {},
  consent: false,
};
export function load(): State {
  try {
    const raw = localStorage.getItem('microgram.v1');
    return raw ? migrateState(expireMetadata(schema.parse(JSON.parse(raw)))) : initial;
  } catch {
    return initial;
  }
}
export function migrateState(state: State): State {
  return {
    ...state,
    courses: state.courses.map((course) => ({
      ...course,
      reelSeconds: course.reelSeconds ?? state.seconds,
    })),
  };
}
export function clearDeviceStorage() {
  for (const store of [localStorage, sessionStorage]) {
    const keys = Array.from({ length: store.length }, (_, i) => store.key(i)).filter(
      (key): key is string => Boolean(key?.startsWith('microgram.')),
    );
    for (const key of keys) store.removeItem(key);
  }
}
export function expireMetadata(state: State, now = Date.now()): State {
  const courses = state.courses.filter(
    (c) =>
      c.videos.every((v) => v.local) || c.sample || now - c.importedAt < 30 * 24 * 60 * 60 * 1000,
  );
  return courses.length === state.courses.length ? state : { ...state, courses };
}
export function persist(state: State) {
  localStorage.setItem('microgram.v1', JSON.stringify(state));
}
export function localDate(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
