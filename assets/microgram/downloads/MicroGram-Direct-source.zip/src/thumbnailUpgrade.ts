import { androidDirect } from './androidDirect';
import { rememberReelFrame } from './reelFrames';
import type { Segment } from './core';
import type { attachAdaptivePlayer } from './adaptivePlayback';

export function thumbnailOrder(a: Segment, b: Segment) {
  return a.videoIndex - b.videoIndex || a.start - b.start;
}
type Job = { segment: Segment; cancelled: boolean; finishing?: boolean };
const queue = new Map<string, Job>();
let running = false;
let timer: ReturnType<typeof setTimeout> | undefined;
let current: Job | undefined;
let decoder: ReturnType<typeof attachAdaptivePlayer> | undefined;
let surface: HTMLVideoElement | undefined;
let budgetStart = 0,
  count = 0,
  bytes = 0;
function release() {
  if (decoder) {
    bytes += decoder.downloadedBytes();
    void decoder.destroy().catch(() => {});
  }
  decoder = undefined;
  surface?.remove();
  surface = undefined;
}
function schedule(delay = 500) {
  clearTimeout(timer);
  if (!running && queue.size) timer = setTimeout(() => void pump(), delay);
}
async function pump() {
  if (running || !queue.size) return;
  if (
    document.hidden ||
    [...document.querySelectorAll<HTMLVideoElement>('video[data-active="true"]')].some(
      (v) => !v.paused,
    )
  ) {
    schedule(1000);
    return;
  }
  if (Date.now() - budgetStart >= 60000) {
    budgetStart = Date.now();
    count = bytes = 0;
  }
  // One video-only decoder, visible tiles only, bounded work per minute.
  if (count >= 12 || bytes >= 12 * 1024 * 1024) {
    schedule(Math.max(500, 60000 - (Date.now() - budgetStart)));
    return;
  }
  running = true;
  let videoId = '';
  try {
    while (
      queue.size &&
      count < 12 &&
      bytes + (decoder?.downloadedBytes() ?? 0) < 12 * 1024 * 1024 &&
      !document.hidden
    ) {
      const [key, job] = [...queue.entries()].sort((a, b) =>
        thumbnailOrder(a[1].segment, b[1].segment),
      )[0];
      queue.delete(key);
      current = job;
      if (job.cancelled) continue;
      try {
        if (!decoder || videoId !== job.segment.video.id) {
          release();
          const { attachAdaptivePlayer } = await import('./adaptivePlayback');
          if (job.cancelled) continue;
          surface = document.createElement('video');
          surface.muted = true;
          surface.playsInline = true;
          surface.setAttribute('aria-hidden', 'true');
          surface.style.cssText =
            'position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:0;top:0';
          document.body.append(surface);
          videoId = job.segment.video.id;
          decoder = attachAdaptivePlayer(surface, videoId, job.segment.start, () => {}, undefined, {
            thumbnail: true,
            preference: () => '720',
          });
          await decoder.ready;
        }
        if (job.cancelled || !surface) continue;
        const element = surface;
        if (Math.abs(element.currentTime - job.segment.start) > 0.1)
          element.currentTime = job.segment.start;
        const deadline = Date.now() + 18000;
        while (
          !job.cancelled &&
          (element.seeking ||
            element.readyState < 2 ||
            Math.abs(element.currentTime - job.segment.start) > 0.2)
        ) {
          if (Date.now() > deadline) throw new Error('Thumbnail preparation timed out.');
          await new Promise((resolve) => setTimeout(resolve, 70));
        }
        if (!job.cancelled) {
          await new Promise<void>((resolve) =>
            requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
          );
          if (!job.cancelled) {
            job.finishing = true;
            await rememberReelFrame(job.segment, element);
          }
          count++;
        }
      } catch {
        release();
      }
    }
  } finally {
    release();
    current = undefined;
    running = false;
    schedule();
  }
}
export function requestThumbnailUpgrade(segment: Segment) {
  if (!androidDirect || segment.video.local) return () => {};
  const job: Job = { segment, cancelled: false };
  queue.set(segment.id, job);
  schedule();
  return () => {
    job.cancelled = true;
    if (queue.get(segment.id) === job) queue.delete(segment.id);
    if (current === job && !job.finishing) release();
    if (!queue.size) clearTimeout(timer);
  };
}
