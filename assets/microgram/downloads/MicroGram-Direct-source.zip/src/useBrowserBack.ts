import { useLayoutEffect, useRef } from 'react';
import { flushSync } from 'react-dom';

/** Each nested view has its own Back entry; no entry is replenished after a Back press. */
export function useBrowserBack(
  depth: number,
  onBack: (context?: { browserTransition?: boolean }) => boolean,
  native: boolean,
) {
  const latest = useRef({ depth, onBack });
  latest.current = { depth, onBack };
  // Reuse this tab's existing entries on refresh so Back retains the same parents.
  const existing = history.state?.microgramNavigation;
  const reusable =
    typeof existing?.session === 'string' &&
    existing.session.startsWith('microgram-') &&
    Number.isInteger(existing.depth) &&
    existing.depth >= 0 &&
    existing.depth <= 10;
  const session = useRef(reusable ? existing.session : `microgram-${Date.now()}-${Math.random()}`);
  const position = useRef(reusable ? existing.depth : 0);
  const initialized = useRef(reusable);
  const applying = useRef(false);
  const moving = useRef(false);
  function entry(level: number) {
    return {
      ...history.state,
      microgramSubpage: undefined,
      microgramNavigation: { session: session.current, depth: level },
    };
  }
  function sync() {
    if (native || applying.current || moving.current) return;
    if (!initialized.current) {
      history.replaceState(entry(0), '', location.href);
      initialized.current = true;
    }
    while (position.current < latest.current.depth) {
      position.current++;
      history.pushState(entry(position.current), '', location.href);
    }
    if (position.current > latest.current.depth) {
      moving.current = true;
      history.go(latest.current.depth - position.current);
    }
  }
  useLayoutEffect(() => {
    if (native) return;
    const previousRestoration = history.scrollRestoration;
    history.scrollRestoration = 'manual';
    const pop = (event: PopStateEvent) => {
      const mark = history.state?.microgramNavigation;
      if (mark?.session !== session.current) return;
      position.current = mark.depth;
      if (moving.current) {
        moving.current = false;
        sync();
        return;
      }
      applying.current = true;
      let blocked = false;
      // Flush each level before the next Back event can observe stale React state.
      for (let n = 0; n < 8 && latest.current.depth > mark.depth; n++) {
        let handled = false;
        flushSync(() => {
          handled = latest.current.onBack({
            browserTransition: Boolean(
              (event as PopStateEvent & { hasUAVisualTransition?: boolean }).hasUAVisualTransition,
            ),
          });
        });
        if (!handled) {
          blocked = true;
          break;
        }
      }
      applying.current = false;
      if (blocked) sync();
      else if (latest.current.depth < mark.depth) {
        // Forward entries cannot restore obsolete modal/player state.
        position.current = latest.current.depth;
        history.replaceState(entry(position.current), '', location.href);
      }
    };
    window.addEventListener('popstate', pop);
    return () => {
      window.removeEventListener('popstate', pop);
      history.scrollRestoration = previousRestoration;
    };
  }, [native]);
  useLayoutEffect(() => {
    sync();
  });
}
