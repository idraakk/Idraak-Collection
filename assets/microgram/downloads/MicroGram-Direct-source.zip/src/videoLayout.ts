import { createContext, useEffect, useState } from 'react';
import type { Video } from './core';
export type VideoLayout = { fit: boolean; rotated: boolean };
/** Fill only when at least 94% of the original picture remains visible. */
export function defaultVideoFit(
  width: number,
  height: number,
  viewportWidth: number,
  viewportHeight: number,
  rotated: boolean,
) {
  if (!width || !height || !viewportWidth || !viewportHeight) return true;
  const picture = rotated ? height / width : width / height;
  const screen = viewportWidth / viewportHeight;
  return Math.min(picture / screen, screen / picture) < 0.94;
}
export function autoRotate(
  width: number,
  height: number,
  viewportWidth: number,
  viewportHeight: number,
) {
  return width > height && height > 0 && viewportHeight > viewportWidth;
}
export function useViewport() {
  const [size, setSize] = useState(() => ({
    width: window.innerWidth,
    height: window.innerHeight,
  }));
  useEffect(() => {
    const update = () => setSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);
  return size;
}
export const PlaybackLayout = createContext<{
  videoId: string;
  rotated: boolean;
  fit: boolean;
  resolve?: (video: Video) => VideoLayout;
}>({ videoId: '', rotated: false, fit: true });
