export const QUALITY_CHOICES = [
  'auto',
  'high',
  'saver',
  '1080',
  '720',
  '480',
  '360',
  '240',
  '144',
] as const;
export type VideoQuality = (typeof QUALITY_CHOICES)[number];
export function qualityCeiling(preference: VideoQuality, _standby = false, _recovering = false) {
  const cap =
    preference === 'saver'
      ? 360
      : preference === 'auto' || preference === 'high'
        ? 1080
        : Number(preference);
  // Preload the same rendition as active playback. ABR handles real throughput.
  return cap;
}
export type QualityStatus = { heights: number[]; height: number; refresh: () => void };
export const qualityPlayers = new WeakMap<HTMLVideoElement, () => QualityStatus>();
