import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import type { VideoQuality } from '../src/videoQuality';
const mock = vi.hoisted(() => ({ players: [] as any[] }));
vi.mock('shaka-player', () => ({
  default: {
    polyfill: { installAll() {} },
    Player: class {
      static isBrowserSupported() {
        return true;
      }
      configure = vi.fn();
      attach = vi.fn(async () => {});
      load = vi.fn(async () => {});
      destroy = vi.fn(async () => {});
      addEventListener = vi.fn();
      removeEventListener = vi.fn();
      selectVariantTrack = vi.fn();
      getVariantTracks = () => [
        { id: 1, height: 360, bandwidth: 400_000 },
        { id: 2, height: 720, bandwidth: 1_500_000 },
        { id: 3, height: 1080, bandwidth: 4_000_000 },
      ];
      constructor() {
        mock.players.push(this);
      }
    },
  },
}));
vi.mock('../src/androidDirect', () => ({ androidDirect: true }));
vi.mock('../src/reelPrefetch', () => ({ warmReels: vi.fn() }));
import { attachAdaptivePlayer } from '../src/adaptivePlayback';
import { qualityPlayers } from '../src/videoQuality';
beforeEach(() => {
  mock.players.length = 0;
  vi.stubGlobal('navigator', { connection: { downlink: 0.1 } });
});
afterEach(() => vi.unstubAllGlobals());
const surface = () => Object.assign(new EventTarget(), { videoHeight: 1080 }) as HTMLVideoElement;
it('starts both current and preloaded reels without a 720p cap or browser downlink override', async () => {
  const video = surface();
  const controller = attachAdaptivePlayer(video, 'lecture', 0, vi.fn(), undefined, { deck: true });
  await controller.ready;
  const player = mock.players[0];
  expect(player.configure.mock.calls[0][0].abr).toMatchObject({
    enabled: true,
    useNetworkInformation: false,
    defaultBandwidthEstimate: 20_000_000,
    clearBufferSwitch: true,
    switchInterval: 2,
    restrictions: { maxHeight: 1080 },
  });
  controller.setForeground(true);
  video.dispatchEvent(new Event('waiting'));
  expect(player.configure.mock.lastCall[0].abr.restrictions.maxHeight).toBe(1080);
  await controller.destroy();
});
it('replaces buffered quality on the current AND paused neighbouring reel, independently of other videos', async () => {
  let quality: VideoQuality = 'high';
  const videos = [surface(), surface(), surface()];
  const controllers = videos.map((video, index) =>
    attachAdaptivePlayer(video, index === 2 ? 'other' : 'lecture', 60 * index, vi.fn(), undefined, {
      deck: true,
      preference: () => (index === 2 ? 'high' : quality),
    }),
  );
  await Promise.all(controllers.map((c) => c.ready));
  controllers[0].setForeground(true);
  quality = '360';
  videos.forEach((v) => qualityPlayers.get(v)!().refresh());
  expect(mock.players[0].selectVariantTrack).toHaveBeenLastCalledWith(
    expect.objectContaining({ height: 360 }),
    true,
    2,
  );
  expect(mock.players[1].selectVariantTrack).toHaveBeenLastCalledWith(
    expect.objectContaining({ height: 360 }),
    true,
    0,
  );
  expect(mock.players[2].selectVariantTrack).not.toHaveBeenCalled();
  quality = 'high';
  videos.forEach((v) => qualityPlayers.get(v)!().refresh());
  expect(mock.players[0].selectVariantTrack).toHaveBeenLastCalledWith(
    expect.objectContaining({ height: 1080 }),
    true,
    2,
  );
  expect(mock.players[1].selectVariantTrack).toHaveBeenLastCalledWith(
    expect.objectContaining({ height: 1080 }),
    true,
    0,
  );
  await Promise.all(controllers.map((c) => c.destroy()));
});
it('applies a selection made while the manifest is still loading', async () => {
  let quality: VideoQuality = 'high';
  const video = surface();
  const controller = attachAdaptivePlayer(video, 'lecture', 0, vi.fn(), undefined, {
    preference: () => quality,
  });
  quality = '480';
  qualityPlayers.get(video)!().refresh();
  await controller.ready;
  expect(mock.players[0].selectVariantTrack).toHaveBeenLastCalledWith(
    expect.objectContaining({ height: 360 }),
    true,
    2,
  );
  await controller.destroy();
});
