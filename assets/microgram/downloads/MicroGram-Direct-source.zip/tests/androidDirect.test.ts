import { beforeEach, afterEach, expect, it, vi } from 'vitest';
const native = vi.hoisted(() => ({ request: vi.fn(), original: vi.fn() }));
vi.mock('@capacitor/core', () => ({
  Capacitor: { getPlatform: () => 'android' },
  registerPlugin: () => native,
}));
import { initializeAndroidDirect } from '../src/androidDirect';
const network = vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) => Response.json({ network: true }));
beforeEach(() => {
  native.request.mockReset().mockResolvedValue({ status: 200, body: '{"course":{"id":"test"}}' });
  native.original.mockReset().mockResolvedValue(undefined);
  network.mockClear();
  vi.stubGlobal('window', { fetch: network });
  vi.stubGlobal('location', { origin: 'https://localhost' });
});
afterEach(() => vi.unstubAllGlobals());
it('routes local API mutations to the on-device plugin', async () => {
  await initializeAndroidDirect();
  const response = await window.fetch('https://localhost/api/import', {
    method: 'POST',
    body: '{"url":"https://youtu.be/KGOEK0-XBIg"}',
  });
  expect(native.request).toHaveBeenCalledWith({
    path: '/api/import',
    method: 'POST',
    body: '{"url":"https://youtu.be/KGOEK0-XBIg"}',
  });
  expect((await response.json()).course.id).toBe('test');
  expect(network).not.toHaveBeenCalled();
});
it('leaves binary GET requests to native WebView interception, and external requests untouched', async () => {
  await initializeAndroidDirect();
  await window.fetch('https://localhost/api/stream/testvideo01/track/t0', {
    headers: { Range: 'bytes=742-3953' },
  });
  await window.fetch('https://example.com/api/import', { method: 'POST', body: '{}' });
  expect(network).toHaveBeenCalledTimes(2);
  const rewritten = network.mock.calls[0][0] as Request;
  expect(new URL(rewritten.url).searchParams.get('range')).toBe('bytes=742-3953');
  expect(rewritten.headers.has('Range')).toBe(false);
  expect(native.request).not.toHaveBeenCalled();
});
it('does not dispatch already-aborted mutations', async () => {
  await initializeAndroidDirect();
  const abort = new AbortController();
  abort.abort();
  await expect(
    window.fetch('https://localhost/api/import', {
      method: 'POST',
      body: '{}',
      signal: abort.signal,
    }),
  ).rejects.toThrow();
  expect(native.request).not.toHaveBeenCalled();
});
it('imports originals in bounded chunks and commits only after all chunks succeed', async () => {
  await initializeAndroidDirect();
  await window.fetch('https://localhost/api/media/localtest01/upload', {
    method: 'POST',
    body: new Blob([new Uint8Array(300000)]),
  });
  expect(native.original.mock.calls.map(([r]) => r.operation)).toEqual([
    'begin',
    'append',
    'append',
    'append',
    'finish',
  ]);
  for (const [r] of native.original.mock.calls)
    if (r.operation === 'append') expect(r.data.length).toBeLessThanOrEqual(175000);
});
