import { afterEach, expect, it, vi } from 'vitest';

const mock = vi.hoisted(() => ({
  stateChanged: (_state: { isActive: boolean }) => {},
  cleanup: () => {},
}));

vi.mock('@capacitor/core', () => ({ Capacitor: { getPlatform: () => 'android' } }));
vi.mock('@capacitor/app', () => ({
  App: {
    addListener: async (_event: string, handler: typeof mock.stateChanged) => {
      mock.stateChanged = handler;
      return { remove: async () => {} };
    },
    getState: async () => ({ isActive: true }),
  },
}));
vi.mock('../src/community/client', () => ({ communityBase: 'https://studio.example' }));
vi.mock('react', () => ({
  useState: (initial: () => string) => [initial(), () => {}],
  useEffect: (setup: () => (() => void) | undefined) => {
    mock.cleanup = setup() ?? (() => {});
  },
}));

afterEach(() => {
  mock.cleanup();
  vi.useRealTimers();
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetModules();
});

async function start(buildDefault?: string, savedPreference?: string) {
  vi.useFakeTimers();
  vi.stubEnv('VITE_PERSONAL_USAGE_ANALYTICS', buildDefault);
  const values = new Map<string, string>();
  if (savedPreference) values.set('microgram-usage-analytics', savedPreference);
  vi.stubGlobal('localStorage', {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
  });
  const events = Object.assign(new EventTarget(), { setInterval, clearInterval });
  vi.stubGlobal('window', events);
  const upload = vi.fn(async () => ({ ok: true }));
  vi.stubGlobal('fetch', upload);
  const { useAppAnalytics } = await import('../src/appAnalytics');
  useAppAnalytics();
  await vi.advanceTimersByTimeAsync(0);
  return { upload, events, values };
}

it.each([
  ['a disabled build default', 'false', undefined],
  ['a previous opt-out', undefined, 'off'],
])('respects %s', async (_label, buildDefault, savedPreference) => {
  const { upload, values } = await start(buildDefault, savedPreference);
  await vi.advanceTimersByTimeAsync(300_000);
  expect(values.has('microgram-usage-queue')).toBe(false);
  expect(upload).not.toHaveBeenCalled();
});

it('keeps short local checkpoints and batches network writes across foreground changes', async () => {
  const { upload, values } = await start();
  const queue = () => JSON.parse(values.get('microgram-usage-queue') ?? '[]');
  await vi.advanceTimersByTimeAsync(20_000);
  expect(queue()[0].activeMs).toBe(20_000);
  expect(upload).not.toHaveBeenCalled();
  await vi.advanceTimersByTimeAsync(280_000);
  expect(upload).toHaveBeenCalledTimes(1);
  mock.stateChanged({ isActive: false });
  mock.stateChanged({ isActive: true });
  await vi.advanceTimersByTimeAsync(10_000);
  mock.stateChanged({ isActive: false });
  expect(upload).toHaveBeenCalledTimes(1);
  await vi.advanceTimersByTimeAsync(50_000);
  mock.stateChanged({ isActive: true });
  mock.stateChanged({ isActive: false });
  expect(upload).toHaveBeenCalledTimes(2);
  await vi.advanceTimersByTimeAsync(0);
  expect(queue()).toEqual([]);
});

it('backs off failed uploads even when the network reconnects', async () => {
  const { upload, events } = await start();
  upload.mockResolvedValue({ ok: false });
  await vi.advanceTimersByTimeAsync(300_000);
  expect(upload).toHaveBeenCalledTimes(1);
  events.dispatchEvent(new Event('online'));
  await vi.advanceTimersByTimeAsync(60_000);
  expect(upload).toHaveBeenCalledTimes(2);
  await vi.advanceTimersByTimeAsync(60_000);
  events.dispatchEvent(new Event('online'));
  expect(upload).toHaveBeenCalledTimes(2);
  await vi.advanceTimersByTimeAsync(60_000);
  expect(upload).toHaveBeenCalledTimes(3);
});
