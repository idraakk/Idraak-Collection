import { afterEach, describe, expect, it, vi } from 'vitest';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import worker, { type Environment } from '../community-service/worker';
import { availableRelease, emptyFeed, feedSchema, visiblePosts } from '../src/community/schema';

const post = {
  id: 'hello',
  topic: 'Hello',
  kind: 'post',
  publishedAt: '2026-01-01T00:00:00.000Z',
  pinned: false,
  blocks: [{ type: 'text', text: 'Hello readers' }],
};
const feed = { ...emptyFeed, posts: [post], feedbackEnabled: true };
const databases: DatabaseSync[] = [];
const deferred: Promise<unknown>[] = [];
const execution = { waitUntil: (work: Promise<unknown>) => { deferred.push(work); } };
const fetchWorker = (request: Request, env: Environment) => worker.fetch(request, env, execution);
function environment() {
  const db = new DatabaseSync(':memory:');
  databases.push(db);
  db.exec(readFileSync(new URL('../community-service/schema.sql', import.meta.url), 'utf8'));
  db.exec(readFileSync(new URL('../community-service/engagement.sql', import.meta.url), 'utf8'));
  db.exec(
    readFileSync(new URL('../community-service/comment-ownership.sql', import.meta.url), 'utf8'),
  );
  db.exec(readFileSync(new URL('../community-service/access.sql', import.meta.url), 'utf8'));
  db.exec(readFileSync(new URL('../community-service/analytics.sql', import.meta.url), 'utf8'));
  const env: Environment = {
    STUDIO_PASSWORD: 'test-password',
    STUDIO_SESSION_SECRET: 'a-long-random-token-for-tests-only-123456789',
    ALLOWED_ORIGINS: 'https://localhost',
    ASSETS: { fetch: async () => new Response('studio') },
    LIMITER: { limit: async () => ({ success: true }) },
    ANALYTICS_LIMITER: { limit: async () => ({ success: true }) },
    DB: {
      batch: (statements) => Promise.all(statements.map((statement) => statement.run())),
      prepare(sql: string) {
        const statement = db.prepare(sql);
        let values: (string | number | null)[] = [];
        const wrapper = {
          bind(...args: unknown[]) {
            values = args as typeof values;
            return wrapper;
          },
          async first<T>() {
            return (statement.get(...values) || null) as T | null;
          },
          async all<T>() {
            return { results: statement.all(...values) as T[] };
          },
          async run() {
            return { meta: { changes: Number(statement.run(...values).changes) } };
          },
        };
        return wrapper;
      },
    },
  };
  const origin = 'https://community.example';
  const signIn = (username: string, password: string, from = origin) =>
    fetchWorker(
      new Request(origin + '/studio-auth/login', {
        method: 'POST',
        headers: { Origin: from },
        body: JSON.stringify({ username, password }),
      }),
      env,
    );
  let session: Promise<string> | undefined;
  const request = async (
    path: string,
    method = 'GET',
    body?: unknown,
    revision?: string,
    auth = true,
  ) => {
    if (auth && !session)
      session = signIn('idraakk', 'test-password').then(
        (response) => response.headers.get('Set-Cookie')!.split(';')[0],
      );
    return fetchWorker(
      new Request(origin + path, {
        method,
        headers: {
          Origin: auth ? origin : 'https://localhost',
          ...(auth ? { Cookie: await session! } : {}),
          ...(revision ? { 'If-Match': revision } : {}),
        },
        ...(body ? { body: JSON.stringify(body) } : {}),
      }),
      env,
    );
  };
  return { db, env, request, signIn };
}
afterEach(async () => {
  await Promise.all(deferred.splice(0));
  databases.splice(0).forEach((db) => db.close());
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.resetModules();
});

describe('remote content validation', () => {
  it('rejects executable links, duplicate IDs, invalid expiry, and unsupported versions', () => {
    expect(
      feedSchema.safeParse({
        ...feed,
        posts: [
          { ...post, blocks: [{ type: 'link', label: 'Click', url: 'javascript:alert(1)' }] },
        ],
      }).success,
    ).toBe(false);
    expect(feedSchema.safeParse({ ...feed, posts: [post, post] }).success).toBe(false);
    expect(
      feedSchema.safeParse({ ...feed, posts: [{ ...post, expiresAt: '2025-01-01T00:00:00.000Z' }] })
        .success,
    ).toBe(false);
    expect(feedSchema.safeParse({ ...feed, version: 2 }).success).toBe(false);
  });
  it('validates release settings and prompts only for older Android version codes', () => {
    const release = {
      versionCode: 7,
      versionName: '1.5.0',
      required: true,
      url: 'https://appdistribution.firebase.google.com/testerapps/app/releases/release',
      title: 'Update MicroGram',
      message: 'Install this release.',
    };
    const policy = feedSchema.parse({ ...feed, access: { mode: 'free', release } }).access;
    expect(availableRelease(policy?.release, 6)?.required).toBe(true);
    expect(availableRelease(policy?.release, 7)).toBeUndefined();
    expect(availableRelease(policy?.release, undefined)).toBeUndefined();
    expect(
      feedSchema.safeParse({
        ...feed,
        access: { release: { ...release, url: 'javascript:alert(1)' } },
      }).success,
    ).toBe(false);
  });
  it('filters schedules and expiry and puts pinned posts first', () => {
    const parsed = feedSchema.parse({
      ...feed,
      posts: [
        post,
        { ...post, id: 'future', publishedAt: '2030-01-01T00:00:00.000Z' },
        { ...post, id: 'expired', expiresAt: '2026-02-01T00:00:00.000Z' },
        { ...post, id: 'pinned', pinned: true },
      ],
    });
    expect(visiblePosts(parsed, Date.parse('2026-11-01')).map((p) => p.id)).toEqual([
      'pinned',
      'hello',
    ]);
    expect(visiblePosts({ ...parsed, enabled: false })).toEqual([]);
  });
  it('requires ad disclosure and disables reel sponsorship by default', () => {
    expect(feedSchema.safeParse({ ...feed, posts: [{ ...post, kind: 'sponsored' }] }).success).toBe(
      false,
    );
    expect(feedSchema.parse(feed).reelSponsor?.enabled).toBeUndefined();
  });
});
describe('publishing service', () => {
  it('issues one-time passes, verifies membership, and revokes an issued pass', async () => {
    const { request, env } = environment();
    const issued = await (
      await request('/admin/access-passes', 'POST', { label: 'Test order', days: 30 })
    ).json();
    expect(issued.code).toMatch(/^[A-F0-9-]{35}$/);
    const body = { code: issued.code };
    const redeemed = await (await request('/access/redeem', 'POST', body, undefined, false)).json();
    expect(redeemed.expiresAt).toBeGreaterThan(Date.now());
    expect((await request('/access/redeem', 'POST', body, undefined, false)).status).toBe(403);
    await request('/admin/feed', 'PUT', { ...feed, access: { mode: 'membership' } }, 'empty');
    const check = () =>
      fetchWorker(
        new Request('https://community.example/access', {
          headers: { Authorization: 'Bearer ' + redeemed.token },
        }),
        env,
      );
    expect((await (await request('/access')).json()).expiresAt).toBeUndefined();
    expect((await (await check()).json()).expiresAt).toBe(redeemed.expiresAt);
    await request('/admin/access-passes/' + issued.id, 'DELETE');
    expect((await (await check()).json()).expiresAt).toBeUndefined();
  });
  it('requires a same-origin username and password session for Studio', async () => {
    const { env, signIn, request } = environment();
    expect((await signIn('idraakk', 'wrong')).status).toBe(401);
    expect((await signIn('someone', 'test-password')).status).toBe(401);
    expect((await signIn('idraakk', 'test-password', 'https://localhost')).status).toBe(403);
    const login = await signIn('idraakk', 'test-password');
    expect(login.status).toBe(200);
    expect(login.headers.get('Set-Cookie')).toContain('Secure; HttpOnly; SameSite=Strict');
    expect((await request('/admin/feed')).status).toBe(200);
    const oldKey = new Request('https://community.example/admin/feed', {
      headers: { Authorization: 'Bearer ' + env.STUDIO_SESSION_SECRET },
    });
    expect((await fetchWorker(oldKey, env)).status).toBe(401);
  });
  it('ignores invalid checkout drafts in free mode and accepts bare HTTPS hostnames in membership mode', async () => {
    const { request } = environment();
    const free = await request(
      '/admin/feed',
      'PUT',
      { ...feed, access: { mode: 'free', checkout: 'not a link' } },
      'empty',
    );
    expect(free.status).toBe(200);
    const first = await free.json();
    expect(first.access.checkout).toBeUndefined();
    const invalid = await request(
      '/admin/feed',
      'PUT',
      { ...feed, access: { mode: 'membership', checkout: 'not a link' } },
      first.revision,
    );
    expect(invalid.status).toBe(400);
    expect((await invalid.json()).error).toContain('Enter a public HTTPS checkout URL');
    const valid = await request(
      '/admin/feed',
      'PUT',
      { ...feed, access: { mode: 'membership', checkout: 'example.com/checkout' } },
      first.revision,
    );
    expect((await valid.json()).access.checkout).toBe('https://example.com/checkout');
  });
  it('includes default editorials in Studio and stores edits and removals separately from new posts', async () => {
    const { request } = environment();
    const studio = await (await request('/admin/feed')).json();
    expect(studio.editorials).toHaveLength(3);
    const revised = {
      ...studio.editorials[0],
      topic: 'Edited original',
      font: 'serif',
      color: '#ff8899',
    };
    const saved = await request('/admin/feed', 'PUT', { ...feed, editorials: [revised] }, 'empty');
    expect(saved.status).toBe(200);
    const publicFeed = await (await request('/feed')).json();
    expect(publicFeed.posts).toHaveLength(1);
    expect(publicFeed.editorials).toEqual([revised]);
  });
  it('keeps existing posts closed by default and preserves replies when comments are turned off', async () => {
    const { request } = environment();
    let revision = 'empty';
    async function publish(commentsEnabled?: boolean) {
      const response = await request(
        '/admin/feed',
        'PUT',
        {
          ...feed,
          posts: [{ ...post, commentsEnabled }],
        },
        revision,
      );
      expect(response.status).toBe(200);
      revision = (await response.json()).revision;
    }
    const endpoint = '/posts/hello/comments';
    const write = () =>
      request(endpoint, 'POST', { name: 'Reader', message: 'Hello' }, undefined, false);
    await publish();
    expect((await write()).status).toBe(403);
    await publish(true);
    expect((await write()).status).toBe(201);
    await publish(false);
    expect(await (await request(endpoint)).json()).toEqual({ enabled: false, comments: [] });
    expect((await write()).status).toBe(403);
    await publish(true);
    expect((await (await request(endpoint)).json()).comments).toHaveLength(1);
  });
  it('counts replies and permits deletion only with the original ownership credential', async () => {
    const { env, request } = environment();
    await request(
      '/admin/feed',
      'PUT',
      { ...feed, posts: [{ ...post, commentsEnabled: true }] },
      'empty',
    );
    const ownerToken = '0'.repeat(72);
    const response = await request(
      '/posts/hello/comments',
      'POST',
      { name: 'Reader', message: 'Hello', ownerToken },
      undefined,
      false,
    );
    const reply = await response.json();
    expect(reply.owned).toBe(true);
    expect(reply).not.toHaveProperty('ownerToken');
    const endpoint = 'https://community.example/posts/hello/comments';
    const call = (url: string, method: string, owner: string) =>
      fetchWorker(
        new Request(url, { method, headers: { Authorization: 'Bearer ' + owner } }),
        env,
      );
    expect(
      (await (await request('/posts/reply-counts', 'GET', undefined, undefined, false)).json())
        .counts.hello,
    ).toBe(1);
    expect((await (await call(endpoint, 'GET', '1'.repeat(72))).json()).comments[0].owned).toBe(0);
    expect((await (await call(endpoint, 'GET', ownerToken)).json()).comments[0].owned).toBe(1);
    expect((await call(endpoint + '/' + reply.id, 'DELETE', '1'.repeat(72))).status).toBe(403);
    expect((await call(endpoint + '/' + reply.id, 'DELETE', ownerToken)).status).toBe(200);
    expect(
      (await (await request('/posts/reply-counts', 'GET', undefined, undefined, false)).json())
        .counts.hello,
    ).toBeUndefined();
  });
  it('counts a viewer once and allows only an admin to remove public replies', async () => {
    const { request } = environment();
    await request(
      '/admin/feed',
      'PUT',
      { ...feed, posts: [{ ...post, commentsEnabled: true }] },
      'empty',
    );
    const viewer = { viewer: '830cce07-eec7-4ca9-81af-d13a3fa34b44' };
    expect((await request('/posts/hello/view', 'POST', viewer, undefined, false)).status).toBe(200);
    expect((await request('/posts/hello/view', 'POST', viewer, undefined, false)).status).toBe(200);
    const response = await request(
      '/posts/hello/comments',
      'POST',
      { name: 'Reader', username: 'reader', message: 'Hello' },
      undefined,
      false,
    );
    expect(response.status).toBe(201);
    const reply = await response.json();
    const activity = await (await request('/admin/engagement')).json();
    expect(activity.views).toEqual([{ post_id: 'hello', count: 1 }]);
    expect(activity.comments).toHaveLength(1);
    expect(
      (await request('/admin/comments/' + reply.id, 'DELETE', undefined, undefined, false)).status,
    ).toBe(401);
    expect((await request('/admin/comments/' + reply.id, 'DELETE')).status).toBe(200);
    expect((await (await request('/posts/hello/comments')).json()).comments).toEqual([]);
  });
  it('requires authentication and refuses disallowed origins', async () => {
    const { request, env } = environment();
    expect((await request('/admin/feed', 'GET', undefined, undefined, false)).status).toBe(401);
    expect(
      (
        await fetchWorker(
          new Request('https://community.example/feed', {
            headers: { Origin: 'https://evil.example' },
          }),
          env,
        )
      ).status,
    ).toBe(403);
    expect((await request('/feed', 'GET', undefined, undefined, false)).status).toBe(200);
  });
  it('publishes atomically and rejects stale editors without losing new content', async () => {
    const { request } = environment();
    const first = await request('/admin/feed', 'PUT', feed, 'empty');
    expect(first.status).toBe(200);
    const initial = await first.json();
    expect((await request('/admin/feed', 'PUT', feed, 'empty')).status).toBe(409);
    expect(
      (await request('/admin/feed', 'PUT', { ...feed, enabled: false }, initial.revision)).status,
    ).toBe(200);
    expect((await request('/admin/feed', 'PUT', feed, initial.revision)).status).toBe(409);
    expect((await (await request('/feed')).json()).enabled).toBe(false);
  });
  it('rejects invalid and oversized publications and missing concurrency headers', async () => {
    const { request } = environment();
    expect((await request('/admin/feed', 'PUT', { ...feed, version: 4 }, 'empty')).status).toBe(
      400,
    );
    expect((await request('/admin/feed', 'PUT', feed)).status).toBe(428);
    expect(
      (await request('/admin/feed', 'PUT', { text: 'x'.repeat(300000) }, 'empty')).status,
    ).toBe(400);
  });
  it('stores only voluntarily submitted feedback and supports deletion and retention', async () => {
    const { request, db, env } = environment();
    const message = {
      category: 'idea',
      message: 'Please add a new feature',
      replyTo: '@reader',
      profile: { private: true },
    };
    expect((await request('/feedback', 'POST', message)).status).toBe(503);
    await request('/admin/feed', 'PUT', feed, 'empty');
    expect((await request('/feedback', 'POST', message)).status).toBe(201);
    const rows = await (await request('/admin/feedback')).json();
    expect(rows).toHaveLength(1);
    expect(rows[0].profile).toBeUndefined();
    await request(`/admin/feedback/${rows[0].id}`, 'DELETE');
    expect(await (await request('/admin/feedback')).json()).toHaveLength(0);
    db.prepare('INSERT INTO feedback VALUES (?, ?, ?, ?, ?)').run(
      'old',
      Date.now() - 91 * 86400000,
      'idea',
      'Old feedback',
      '',
    );
    await worker.scheduled({}, env);
    expect(db.prepare('SELECT * FROM feedback').all()).toHaveLength(0);
  });
  it('rate limits messages and ignores honeypot spam', async () => {
    const { request, env } = environment();
    await request('/admin/feed', 'PUT', feed, 'empty');
    expect(
      (
        await request('/feedback', 'POST', {
          category: 'idea',
          message: 'Spam message',
          website: 'spam',
        })
      ).status,
    ).toBe(200);
    expect(await (await request('/admin/feedback')).json()).toEqual([]);
    env.LIMITER.limit = async () => ({ success: false });
    expect(
      (await request('/feedback', 'POST', { category: 'idea', message: 'Test message' })).status,
    ).toBe(429);
  });
});
describe('offline feed client', () => {
  it('retains a validated cached feed after network failure and discards expired caches', async () => {
    vi.stubEnv('VITE_COMMUNITY_URL', 'https://community.example');
    const data = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      getItem: (key: string) => data.get(key),
      setItem: (key: string, value: string) => data.set(key, value),
    });
    vi.stubGlobal(
      'fetch',
      vi
        .fn()
        .mockResolvedValueOnce(new Response(JSON.stringify(feed)))
        .mockRejectedValue(new Error('offline')),
    );
    const client = await import('../src/community/client');
    expect((await client.refreshFeed(true)).posts).toHaveLength(1);
    await expect(client.refreshFeed(true)).rejects.toThrow('offline');
    expect(client.cachedFeed().posts).toHaveLength(1);
    const saved = JSON.parse(data.get('microgram.community.v1')!);
    saved.time = 0;
    data.set('microgram.community.v1', JSON.stringify(saved));
    expect(client.cachedFeed().posts).toHaveLength(0);
  });
  it('does not fetch when no endpoint is configured', async () => {
    vi.stubEnv('VITE_COMMUNITY_URL', '');
    const fetch = vi.fn();
    vi.stubGlobal('fetch', fetch);
    const client = await import('../src/community/client');
    expect(await client.refreshFeed()).toEqual(emptyFeed);
    expect(fetch).not.toHaveBeenCalled();
  });
});

describe('Android analytics', () => {
  it('deduplicates usage retries, groups active installs and keeps dashboard data private', async () => {
    const { db, request } = environment();
    const openedAt = Date.now() - 1000;
    const day = new Date(openedAt + 19800000).toISOString().slice(0, 10);
    const installation = crypto.randomUUID();
    const row = { id: crypto.randomUUID(), day, openedAt, activeMs: 75000, watchMs: 50000 };
    const send = (rows: typeof row[]) =>
      request('/analytics/sessions', 'POST', { installation, rows }, undefined, false);
    expect((await send([row])).status).toBe(200);
    const changes = db.prepare('SELECT total_changes() AS count');
    const beforeRetry = changes.get()?.count;
    expect((await send([{ ...row, activeMs: 20000 }])).status).toBe(200);
    expect((await send([row])).status).toBe(200);
    expect(changes.get()?.count).toBe(beforeRetry);
    expect((await send([{ ...row, id: crypto.randomUUID(), activeMs: 15000, watchMs: 0 }])).status).toBe(200);
    expect((await request('/admin/analytics', 'GET', undefined, undefined, false)).status).toBe(401);
    const { total, daily, weekly } = await (await request('/admin/analytics?days=7')).json();
    expect(total).toMatchObject({ installs: 1, active: 1, opens: 2, activeMs: 90000, watchMs: 50000 });
    expect(daily).toHaveLength(1);
    expect(weekly).toHaveLength(1);
  });

  it('redirects APK requests, excluding HEAD and prefetch from the counter', async () => {
    const { request, env } = environment();
    const download = (method: string, prefetch = false) => fetchWorker(
      new Request('https://community.example/download/android', {
        method, headers: prefetch ? { 'Sec-Purpose': 'prefetch' } : {},
      }), env,
    );
    const response = await download('GET');
    expect(response.status).toBe(302);
    expect(response.headers.get('Location')).toMatch(/Microgram\.apk$/);
    expect((await download('HEAD')).status).toBe(302);
    expect((await download('GET', true)).status).toBe(302);
    await Promise.all(deferred.splice(0));
    const { total, lifetimeDownloads } = await (await request('/admin/analytics')).json();
    expect(lifetimeDownloads).toBe(1);
    expect(total.downloads).toBe(1);
  });
});
