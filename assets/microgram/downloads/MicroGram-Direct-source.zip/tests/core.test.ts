import { describe, it, expect } from 'vitest';
import {
  segmentVideo,
  parseYouTubeUrl,
  parseDuration,
  recordInterval,
  complete,
  watched,
  type Video,
} from '../src/core';
const video: Video = {
  id: 'fNk_zzaMoSs',
  title: 'Vectors',
  duration: 125,
  channel: 'Teacher',
  thumbnail: '',
};
describe('reel segmentation', () => {
  it('preserves the short final reel without gaps or overlaps', () => {
    const reels = segmentVideo(video, 60);
    expect(reels.map((r) => [r.start, r.end])).toEqual([
      [0, 60],
      [60, 120],
      [120, 125],
    ]);
  });
  it('produces 60 one-minute or 240 fifteen-second reels for an hour', () => {
    expect(segmentVideo({ ...video, duration: 3600 }, 60)).toHaveLength(60);
    expect(segmentVideo({ ...video, duration: 3600 }, 15)).toHaveLength(240);
  });
  it('rejects invalid durations', () => {
    expect(segmentVideo(video, 0)).toEqual([]);
    expect(segmentVideo({ ...video, duration: 0 }, 60)).toEqual([]);
  });
});
describe('YouTube links', () => {
  it('accepts video, shortened, shorts, and playlist links', () => {
    expect(parseYouTubeUrl('https://youtu.be/fNk_zzaMoSs?t=5')).toEqual({
      kind: 'video',
      id: video.id,
    });
    expect(parseYouTubeUrl('https://youtube.com/shorts/fNk_zzaMoSs')).toEqual({
      kind: 'video',
      id: video.id,
    });
    expect(
      parseYouTubeUrl('https://www.youtube.com/watch?v=fNk_zzaMoSs&list=PL12345678901'),
    ).toEqual({ kind: 'playlist', id: 'PL12345678901' });
  });
  it('rejects lookalike domains, scripts, and malformed IDs', () => {
    for (const url of [
      'https://youtube.com.evil.test/watch?v=fNk_zzaMoSs',
      'javascript:alert(1)',
      'https://example.com',
      'https://youtube.com/watch?v=bad',
    ])
      expect(() => parseYouTubeUrl(url)).toThrow();
  });
  it('parses ISO durations including days and fractional seconds', () => {
    expect(parseDuration('PT1H2M3S')).toBe(3723);
    expect(parseDuration('P1DT1S')).toBe(86401);
    expect(parseDuration('PT0.5S')).toBe(1);
    expect(parseDuration('broken')).toBe(0);
  });
});
describe('earned progress', () => {
  it('does not award progress for forward or reverse seeking', () => {
    expect(recordInterval({}, video.id, 1, 55)).toEqual({});
    expect(recordInterval({}, video.id, 55, 1)).toEqual({});
  });
  it('counts playback once and survives reel-length changes', () => {
    let progress = {};
    for (let t = 0; t < 60; t += 0.25) progress = recordInterval(progress, video.id, t, t + 0.25);
    expect(watched(segmentVideo(video, 60)[0], progress)).toBe(1);
    expect(complete(segmentVideo(video, 30)[1], progress)).toBe(true);
    const again = recordInterval(progress, video.id, 0, 1);
    expect(again[video.id]).toHaveLength(60);
  });
  it('requires 90 percent viewing, including short trailing reels', () => {
    const last = segmentVideo(video, 60)[2];
    expect(complete(last, { [video.id]: [120, 121, 122, 123] })).toBe(false);
    expect(complete(last, { [video.id]: [120, 121, 122, 123, 124] })).toBe(true);
  });
});

it('never silently imports a video when its playlist parameter is malformed', () => {
  expect(() => parseYouTubeUrl('https://youtube.com/watch?v=fNk_zzaMoSs&list=')).toThrow(
    'playlist link is incomplete',
  );
  expect(parseYouTubeUrl('https://youtu.be/fNk_zzaMoSs?list=PL1234567890&si=shared')).toEqual({
    kind: 'playlist',
    id: 'PL1234567890',
  });
});
