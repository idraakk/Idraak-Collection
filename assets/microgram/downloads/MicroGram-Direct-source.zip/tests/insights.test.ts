import { it, expect } from 'vitest';
import { learningInsights, courseInsights } from '../src/insights';
import { initial, starter, type State } from '../src/storage';
it('counts shared lectures and watched seconds once, while replays stay in activity', () => {
  const state: State = {
    ...initial,
    courses: [starter, { ...starter, id: 'another-playlist' }],
    progress: { fNk_zzaMoSs: [0, 1, 1, 2, 99999] },
    activity: { '2026-10-29': 900, '2026-10-30': 120 },
  };
  const data = learningInsights(state, 7, new Date(2026, 9, 30, 12));
  expect(data.uniqueVideos).toBe(1);
  expect(data.covered).toBe(3);
  expect(data.duration).toBe(592);
  expect(data.periodSeconds).toBe(1020);
  expect(data.activeDays).toBe(2);
  expect(data.goalDays).toBe(1);
  expect(data.streak).toBe(2);
});
it('keeps a streak through yesterday, avoids distant-history chart scaling and includes empty days', () => {
  const data = learningInsights(
    {
      ...initial,
      courses: [],
      activity: { '2026-10-28': 30, '2026-10-29': 40, '2025-01-01': 999999 },
    },
    7,
    new Date(2026, 9, 30, 12),
  );
  expect(data.streak).toBe(2);
  expect(data.dates).toHaveLength(7);
  expect(data.periodSeconds).toBe(70);
  expect(data.covered).toBe(0);
  expect(data.remaining).toBe(0);
});
it('completed reel counts adapt to reel duration without changing coverage', () => {
  const s = { ...initial, progress: { fNk_zzaMoSs: Array.from({ length: 60 }, (_, i) => i) } };
  expect(learningInsights(s).completed).toBe(1);
  expect(learningInsights({ ...s, seconds: 15 }).completed).toBe(4);
  expect(learningInsights(s).covered).toBe(60);
});
it('lecture charts use only their videos and count shared playlist entries once', () => {
  const a = { ...starter.videos[0], duration: 120 };
  const b = { ...a, id: 'bbbbbbbbbbb', title: 'Second lecture' };
  const course = { ...starter, videos: [a, b, a] };
  const state: State = {
    ...initial,
    courses: [course],
    progress: {
      [a.id]: [...Array.from({ length: 60 }, (_, i) => i), 20, 9999],
      [b.id]: Array.from({ length: 120 }, (_, i) => i),
    },
    activity: { '2026-10-30': 9999 },
    videoActivity: {
      [a.id]: { '2026-10-30': 90, '2026-10-01': 60 },
      [b.id]: { '2026-10-30': 120 },
    },
  };
  const data = courseInsights(state, course, 7, new Date(2026, 9, 30, 12));
  expect(data.total).toBe(240);
  expect(data.viewed).toBe(180);
  expect(data.remaining).toBe(60);
  expect(data.completed).toBe(3);
  expect(data.reels).toBe(4);
  expect(data.periodSeconds).toBe(210);
  expect(data.dates.at(-1)?.seconds).toBe(210);
  expect(data.videos.map((v) => v.percent)).toEqual([50, 100]);
  expect(courseInsights(state, course, 30, new Date(2026, 9, 30, 12)).periodSeconds).toBe(270);
});
it('retains old coverage in timeline bars without inventing per-lecture daily history', () => {
  const course = { ...starter, videos: [{ ...starter.videos[0], duration: 120 }] };
  const state = {
    ...initial,
    courses: [course],
    progress: { [course.videos[0].id]: Array.from({ length: 60 }, (_, i) => i) },
    activity: { '2026-10-30': 1000 },
  };
  const data = courseInsights(state, course, 7, new Date(2026, 9, 30, 12));
  expect(data.viewed).toBe(60);
  expect(data.tracked).toBe(false);
  expect(data.periodSeconds).toBe(0);
  expect(data.timeline.map((b) => b.percent)).toEqual([...Array(6).fill(100), ...Array(6).fill(0)]);
});
