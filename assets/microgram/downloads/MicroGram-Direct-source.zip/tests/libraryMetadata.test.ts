import { expect, it } from 'vitest';
import { fetchLibraryMetadata } from '../server/libraryMetadata';
it('uses the playlist owner avatar separately from the video uploader and returns real statistics', async () => {
  const request = async (input: URL | RequestInfo) => {
    const url = new URL(input as URL);
    const items = url.pathname.endsWith('/videos')
      ? [
          {
            id: 'aaaaaaaaaaa',
            snippet: {
              channelId: 'uploader',
              channelTitle: 'Teacher',
              thumbnails: {
                maxres: { url: 'https://i.ytimg.com/vi/aaaaaaaaaaa/maxresdefault.jpg' },
              },
            },
            statistics: { viewCount: '1234' },
          },
        ]
      : url.pathname.endsWith('/playlists')
        ? [{ id: 'PL1234567890', snippet: { channelId: 'curator', channelTitle: 'Curator' } }]
        : [
            {
              id: 'uploader',
              snippet: { thumbnails: { medium: { url: 'https://yt3.ggpht.com/teacher' } } },
            },
            {
              id: 'curator',
              snippet: {
                thumbnails: { default: { url: 'https://yt3.googleusercontent.com/curator' } },
              },
            },
          ];
    return new Response(JSON.stringify({ items }));
  };
  const data = await fetchLibraryMetadata(
    ['aaaaaaaaaaa'],
    ['PL1234567890'],
    'not-a-real-key',
    request as typeof fetch,
  );
  expect(data.videos[0]).toMatchObject({
    channel: 'Teacher',
    views: '1234',
    avatar: 'https://yt3.ggpht.com/teacher',
  });
  expect(data.playlists[0]).toMatchObject({
    channel: 'Curator',
    avatar: 'https://yt3.googleusercontent.com/curator',
  });
  expect(data.playlists[0].views).toBeUndefined();
});
it('does not return arbitrary external image URLs or expose a key on API failure', async () => {
  const bad = async () =>
    new Response(
      JSON.stringify({
        items: [
          {
            id: 'aaaaaaaaaaa',
            snippet: { thumbnails: { maxres: { url: 'https://example.com/tracker' } } },
          },
        ],
      }),
    );
  const data = await fetchLibraryMetadata(['aaaaaaaaaaa'], [], 'secret', bad);
  expect(data.videos[0].thumbnail).toBeUndefined();
  await expect(
    fetchLibraryMetadata(
      ['aaaaaaaaaaa'],
      [],
      'secret',
      async () => new Response('', { status: 403 }),
    ),
  ).rejects.toThrow('Creator details are temporarily unavailable');
});
