import { it, expect } from 'vitest';
import { mediaBudget, maxMediaFile } from '../server/mediaBudget';
it('sizes admission to selected streams rather than the 2 GB ceiling', () => {
  const b = mediaBudget({
    duration: 240,
    requested_formats: [{ filesize: 24 * 1024 ** 2 }, { filesize_approx: 4 * 1024 ** 2 }],
  });
  expect(b.expected).toBeLessThan(40 * 1024 ** 2);
  expect(b.scratch).toBe(b.expected * 2);
});
it('uses bitrate when size is omitted and bounds unknown/oversized estimates', () => {
  expect(mediaBudget({ duration: 3600, tbr: 1000 }).expected).toBe(540000000);
  expect(mediaBudget().scratch).toBeLessThan(1024 ** 3);
  expect(mediaBudget({ filesize: 10 * 1024 ** 3 }).expected).toBe(maxMediaFile);
});
