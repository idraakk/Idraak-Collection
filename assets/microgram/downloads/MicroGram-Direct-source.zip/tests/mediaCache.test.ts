import { afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, writeFile, rm, open } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { mediaBudget } from '../server/mediaBudget';
import { MediaCache, GiB } from '../server/mediaCache';
const folders: string[] = [];
afterEach(async () => {
  for (const folder of folders.splice(0)) {
    if (
      !resolve(folder).startsWith(resolve(tmpdir()) + '\\') &&
      !resolve(folder).startsWith(resolve(tmpdir()) + '/')
    )
      throw new Error('Unsafe test folder');
    await rm(folder, { recursive: true, force: true });
  }
});
async function setup(free = 100 * GiB) {
  const folder = await mkdtemp(join(tmpdir(), 'microgram-cache-'));
  folders.push(folder);
  let now = 1_000_000;
  const cache = new MediaCache(
    folder,
    async () => free,
    () => now,
  );
  return {
    cache,
    advance: () => {
      now += 100_000;
    },
    file: async (id: string, kind?: 'download' | 'upload', size = 100) => {
      const f = await open(cache.path(id), 'w');
      await f.truncate(size);
      await f.close();
      if (kind) await cache.finish(id, kind);
    },
  };
}
describe('managed video storage', () => {
  it('allows a short lecture after clearing cache with less than the old 7 GB disk requirement', async () => {
    const s = await setup(4.9 * GiB);
    const budget = mediaBudget({ filesize: 50 * 1024 ** 2 });
    await expect(
      s.cache.reserve('download001', budget.expected, budget.scratch),
    ).resolves.toBeUndefined();
    await s.cache.finish('download001');
  });
  it('rechecks completed bytes against the cache limit before promotion', async () => {
    const s = await setup();
    await s.cache.setLimit(2);
    await s.cache.reserve('download001', 100, 100);
    await expect(s.cache.reserve('download001', 3 * GiB, 0)).rejects.toThrow('cache space');
    await s.cache.finish('download001');
  });

  it('keeps the budget stable while a transfer has reserved space', async () => {
    const s = await setup();
    await s.cache.reserve('download001', 100, 100);
    await expect(s.cache.setLimit(2)).rejects.toThrow('Wait');
    await s.cache.finish('download001');
    await s.cache.setLimit(2);
    expect((await s.cache.snapshot()).limit).toBe(2 * GiB);
  });
  it('clears downloaded copies while protecting uploads, legacy files and active players', async () => {
    const s = await setup();
    await s.file('download001', 'download');
    await s.file('uploaded001', 'upload');
    await s.file('legacy00001');
    await s.file('playing0001', 'download');
    s.advance();
    await s.cache.touch('playing0001');
    const result = await s.cache.clear();
    expect(result).toEqual({ removed: 1, freed: 100, skipped: 3 });
    expect((await s.cache.snapshot()).entries).toHaveLength(3);
  });
  it('evicts least recently used downloads to fit the budget', async () => {
    const s = await setup();
    await s.cache.setLimit(2);
    await s.file('download001', 'download', GiB);
    s.advance();
    await s.file('download002', 'download', GiB);
    s.advance();
    await s.cache.reserve('download003', GiB, GiB);
    expect((await s.cache.snapshot()).entries.map((e) => e.id)).toEqual(['download002']);
  });
  it('does not delete anything when protected data makes a limit impossible', async () => {
    const s = await setup();
    await s.file('uploaded001', 'upload', 3 * GiB);
    await s.file('download001', 'download', 100);
    s.advance();
    await expect(s.cache.setLimit(2)).rejects.toThrow('Protected');
    expect((await s.cache.snapshot()).entries).toHaveLength(2);
  });
  it('fails low-disk reservations before removing files when eviction cannot help', async () => {
    const s = await setup(100);
    await s.file('download001', 'download');
    s.advance();
    await expect(s.cache.reserve('download002', 100, GiB)).rejects.toThrow('Not enough');
    expect((await s.cache.snapshot()).entries).toHaveLength(1);
  });
  it('protects ongoing range responses even after a heartbeat expires', async () => {
    const s = await setup();
    await s.file('download001', 'download');
    await s.cache.hold('download001');
    s.advance();
    expect((await s.cache.clear()).removed).toBe(0);
    await s.cache.release('download001');
    expect((await s.cache.clear()).removed).toBe(1);
  });
  it('persists ownership and limits across restart and rejects invalid paths', async () => {
    const s = await setup();
    await s.file('uploaded001', 'upload');
    await s.cache.setLimit(5);
    const restored = new MediaCache(s.cache.directory);
    expect((await restored.snapshot()).entries[0].kind).toBe('upload');
    expect((await restored.snapshot()).limit).toBe(5 * GiB);
    expect(() => restored.path('../outside')).toThrow('Invalid');
  });
  it('only deletes originals explicitly and rejects an active original', async () => {
    const s = await setup();
    await s.file('uploaded001', 'upload');
    await expect(s.cache.deleteOriginal('uploaded001')).rejects.toThrow('active');
    s.advance();
    await s.cache.deleteOriginal('uploaded001');
    expect((await s.cache.snapshot()).entries).toHaveLength(0);
  });
});
