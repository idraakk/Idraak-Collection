import { it, expect, vi, afterEach } from 'vitest';
import { readNavigation } from '../src/navigationState';
import { initial, starter } from '../src/storage';
afterEach(() => vi.unstubAllGlobals());
it('defaults Saved to Screen Notes while retaining an explicit section choice', () => {
  snapshot(null);
  expect(readNavigation(initial).savedSection).toBe('screens');
  snapshot({ view: 'saved' });
  expect(readNavigation(initial).savedSection).toBe('screens');
  snapshot({ view: 'saved', savedSection: 'reels' });
  expect(readNavigation(initial).savedSection).toBe('reels');
});
function snapshot(value: unknown) {
  vi.stubGlobal('sessionStorage', { getItem: () => JSON.stringify(value) });
}
it('restores a valid profile/reel location and validates selected video', () => {
  snapshot({
    view: 'profile',
    courseId: starter.id,
    index: 2,
    immersive: true,
    reelVideoId: starter.videos[0].id,
    libraryProfile: starter.id,
    scrollY: 200,
  });
  const route = readNavigation(initial);
  expect(route.view).toBe('profile');
  expect(route.index).toBe(2);
  expect(route.immersive).toBe(true);
  expect(route.scrollY).toBe(200);
});
it('falls back safely when the remembered lecture was removed', () => {
  snapshot({
    view: 'reels',
    courseId: 'gone',
    immersive: true,
    libraryProfile: 'gone',
    index: 999,
  });
  const route = readNavigation({ ...initial, courses: [] });
  expect(route.view).toBe('library');
  expect(route.immersive).toBe(false);
  expect(route.libraryProfile).toBeNull();
});
it('ignores corrupt or unavailable navigation storage', () => {
  snapshot({ view: 'untrusted' });
  expect(readNavigation(initial).view).toBe('feed');
  vi.stubGlobal('sessionStorage', {
    getItem: () => {
      throw new Error('denied');
    },
  });
  expect(readNavigation(initial).view).toBe('feed');
});
it('restores independent list offsets and discards invalid scroll values', () => {
  snapshot({
    view: 'library',
    scrollPositions: {
      library: 1234,
      'saved:screens': 567,
      'profile:lecture': 98,
      invalid: -1,
      corrupt: '300',
    },
  });
  expect(readNavigation(initial).scrollPositions).toEqual({
    library: 1234,
    'saved:screens': 567,
    'profile:lecture': 98,
  });
});
it('retains the Saved continuation parent and nested Reels profile across refresh', () => {
  snapshot({
    view: 'reels',
    courseId: starter.id,
    immersive: true,
    savedReturn: {
      courseId: starter.id,
      segmentId: `${starter.videos[0].id}:60:0`,
      time: 12,
      paused: true,
      section: 'notes',
      screenVideo: null,
    },
    reelsProfile: { videoId: starter.videos[0].id, start: 60, time: 64, paused: false },
  });
  const route = readNavigation(initial);
  expect(route.savedReturn?.time).toBe(12);
  expect(route.savedReturn?.section).toBe('notes');
  expect(route.reelsProfile?.time).toBe(64);
  expect(route.immersive).toBe(false);
});
it('discards removed or corrupt continuation parents and profile destinations', () => {
  snapshot({
    view: 'reels',
    courseId: starter.id,
    savedReturn: { courseId: starter.id, segmentId: 'invalid', time: 20, section: 'notes' },
    reelsProfile: { videoId: 'missing', start: 0, time: 10 },
  });
  const route = readNavigation(initial);
  expect(route.savedReturn).toBeUndefined();
  expect(route.reelsProfile).toBeUndefined();
  expect(route.immersive).toBe(true);
});
