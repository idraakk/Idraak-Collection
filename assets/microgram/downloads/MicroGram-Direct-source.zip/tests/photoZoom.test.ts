import { expect, it } from 'vitest';
import { photoPanBounds, clampPhotoPan } from '../src/photoZoom';

it('keeps a zoomed landscape photo inside its fitted vertical bounds', () => {
  const bounds = photoPanBounds(960, 540, { width: 390, height: 844 }, false, 2.5);
  expect(bounds.x).toBeCloseTo(292.5);
  expect(bounds.y).toBe(0);
  expect(clampPhotoPan(1000, -500, bounds)).toEqual({ x: 292.5, y: 0 });
});
it('allows panning both axes when the same photo is turned to fit the phone', () => {
  const bounds = photoPanBounds(960, 540, { width: 390, height: 844 }, true, 2.5);
  expect(bounds.x).toBeCloseTo(292.5);
  expect(bounds.y).toBeGreaterThan(400);
  const pan = clampPhotoPan(-1000, 1000, bounds);
  expect(pan.x).toBe(-bounds.x);
  expect(pan.y).toBe(bounds.y);
});
it('has no pan range in fit view and remains bounded for portrait images', () => {
  const viewport = { width: 390, height: 844 };
  expect(photoPanBounds(540, 960, viewport, false, 1)).toEqual({ x: 0, y: 0 });
  const bounds = photoPanBounds(540, 960, viewport, false, 2.5);
  expect(clampPhotoPan(20, 30, bounds)).toEqual({ x: 20, y: 30 });
});
