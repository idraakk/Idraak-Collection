import { it, expect, vi, afterEach } from 'vitest';
import { initial, migrateState, clearDeviceStorage, localDate } from '../src/storage';
import { segments } from '../src/core';
import { activityYear } from '../src/activityHeatmap';
afterEach(() => vi.unstubAllGlobals());
it('freezes legacy reel lengths and allows independent lengths on new courses', () => {
  const old = migrateState({ ...initial, seconds: 15 });
  expect(old.courses[0].reelSeconds).toBe(15);
  const next = { ...old.courses[0], id: 'new-course', reelSeconds: 30 as const };
  expect(segments(old.courses[0], 60)).toHaveLength(40);
  expect(segments(next, 15)).toHaveLength(20);
  expect(old.courses[0].reelSeconds).toBe(15);
});
it('builds a calendar-aligned pink intensity map with exactly 365 in-range days', () => {
  const now = new Date(2026, 9, 30, 12);
  const result = activityYear({ '2026-10-30': 600, '2026-10-29': 30, '2030-01-01': 1000 }, 10, now);
  expect(result.days.filter((d) => d.inRange)).toHaveLength(365);
  expect(result.days.length % 7).toBe(0);
  expect(result.days[0].date.getDay()).toBe(0);
  expect(result.active).toBe(2);
  expect(result.days.find((d) => d.key === localDate(now))?.level).toBe(4);
  expect(result.days.find((d) => d.key === '2026-10-29')?.level).toBe(1);
});
it('clears all app-owned device keys without deleting another app’s storage', () => {
  const make = () => {
    const values = new Map([
      ['microgram.v1', 'private'],
      ['microgram.playback-speed', '2'],
      ['microgram.navigation.v1', 'route'],
      ['another-app', 'keep'],
    ]);
    return {
      get length() {
        return values.size;
      },
      key: (i: number) => [...values.keys()][i] ?? null,
      removeItem: (key: string) => values.delete(key),
      getItem: (key: string) => values.get(key),
    };
  };
  const local = make(),
    session = make();
  vi.stubGlobal('localStorage', local);
  vi.stubGlobal('sessionStorage', session);
  clearDeviceStorage();
  expect(local.getItem('microgram.v1')).toBeUndefined();
  expect(session.getItem('microgram.navigation.v1')).toBeUndefined();
  expect(local.getItem('another-app')).toBe('keep');
});
