import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { segments, type Course } from '../src/core';
import { openingTimes } from '../src/reelOpenings';
import { ReelDeck } from '../src/reelDeck';
import type { attachAdaptivePlayer } from '../src/adaptivePlayback';

const course: Course = {
  id: 'testvideo01',
  title: 'Lecture',
  channel: 'Test',
  importedAt: 0,
  reelSeconds: 60,
  videos: [{ id: 'testvideo01', title: 'Lecture', channel: 'Test', duration: 1200, thumbnail: '' }],
};
const reels = segments(course, 60);
beforeEach(() => {
  vi.useFakeTimers();
  vi.stubGlobal('document', Object.assign(new EventTarget(), { hidden: false }));
  vi.stubGlobal('navigator', { deviceMemory: 8 });
});
afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});
it('bounds short openings and extends only after dwelling, with forward priority and data-saver limits', () => {
  expect(openingTimes(reels[5], reels, 0)).toEqual([300, 360, 240, 420]);
  expect(openingTimes(reels[5], reels, 5000)).toEqual([300, 360, 240, 420, 180, 480, 540, 600]);
  expect(openingTimes(reels[5], reels, 5000, true)).toEqual([300, 360]);
  expect(openingTimes(reels[5], reels, 5000, false, -1)).toEqual([
    300, 240, 360, 180, 420, 120, 60, 0,
  ]);
  expect(openingTimes(reels[0], reels, 0)).toEqual([0, 60, 120]);
});
it('switches to a prepared element without seeking it again, rewinds the previous one, and releases every player', async () => {
  const videos = Array.from({ length: 3 }, () =>
    Object.assign(new EventTarget(), {
      currentTime: 0,
      paused: true,
      muted: true,
      readyState: 4,
      seeking: false,
      videoWidth: 1280,
      videoHeight: 720,
      duration: 1200,
      error: null,
      pause() {
        this.paused = true;
      },
    }),
  ) as unknown as HTMLVideoElement[];
  const destroy = vi.fn(async () => {}),
    select = vi.fn();
  const create = vi.fn((video: HTMLVideoElement, _id: string, start: number) => {
    video.currentTime = start;
    return { ready: Promise.resolve(), destroy, setForeground: vi.fn() };
  });
  const deck = new ReelDeck(videos, {
    create: create as unknown as typeof attachAdaptivePlayer,
    nearby: () => reels,
    select,
    frame: async () => {},
    failure: vi.fn(),
  });
  const first = await deck.activate(reels[0]);
  Object.defineProperty(first, 'paused', { configurable: true, value: false, writable: true });
  await vi.advanceTimersByTimeAsync(800);
  expect(deck.readyFor(reels[1].id)).toBe(true);
  expect(deck.readyFor(reels[2].id)).toBe(true);
  const next = await deck.activate(reels[1]);
  expect(next).not.toBe(first);
  expect(next.currentTime).toBe(60);
  expect(select).toHaveBeenLastCalledWith(videos.indexOf(next));
  expect(first.paused).toBe(true);
  expect(create.mock.calls.length).toBeLessThanOrEqual(3);
  await deck.destroy();
  expect(destroy).toHaveBeenCalledTimes(3);
});
it('keeps both neighbors in distinct slots in the middle of a lecture instead of recycling one standby forever', async () => {
  const videos = Array.from({ length: 3 }, () =>
    Object.assign(new EventTarget(), {
      currentTime: 0,
      paused: true,
      muted: true,
      readyState: 4,
      seeking: false,
      error: null,
      pause() {
        this.paused = true;
      },
    }),
  ) as unknown as HTMLVideoElement[];
  const create = vi.fn((v: HTMLVideoElement, _id: string, start: number) => {
    v.currentTime = start;
    return { ready: Promise.resolve(), destroy: async () => {}, setForeground: () => {} };
  });
  const deck = new ReelDeck(videos, {
    create: create as unknown as typeof attachAdaptivePlayer,
    nearby: () => reels,
    select: () => {},
    frame: async () => {},
    failure: () => {},
  });
  const active = await deck.activate(reels[5]);
  Object.defineProperty(active, 'paused', { configurable: true, writable: true, value: false });
  await vi.advanceTimersByTimeAsync(1800);
  expect(deck.readyFor(reels[6].id)).toBe(true);
  expect(deck.readyFor(reels[4].id)).toBe(true);
  expect(create).toHaveBeenCalledTimes(3);
  await vi.advanceTimersByTimeAsync(3000);
  expect(create).toHaveBeenCalledTimes(3);
  await deck.destroy();
});

it('uses four surfaces for high-memory lookahead but only two on low-memory devices', async () => {
  const videos = Array.from({ length: 4 }, () =>
    Object.assign(new EventTarget(), {
      currentTime: 0,
      paused: true,
      muted: true,
      readyState: 4,
      seeking: false,
      error: null,
      pause() {
        this.paused = true;
      },
    }),
  ) as unknown as HTMLVideoElement[];
  const create = vi.fn((v: HTMLVideoElement, _id: string, start: number) => {
    v.currentTime = start;
    return { ready: Promise.resolve(), destroy: async () => {}, setForeground: () => {} };
  });
  const options = {
    create: create as unknown as typeof attachAdaptivePlayer,
    nearby: () => reels,
    select: () => {},
    frame: async () => {},
    failure: () => {},
  };
  const deck = new ReelDeck(videos, options);
  const active = await deck.activate(reels[5]);
  Object.defineProperty(active, 'paused', { configurable: true, writable: true, value: false });
  await vi.advanceTimersByTimeAsync(1600);
  expect(create).toHaveBeenCalledTimes(4);
  expect(deck.readyFor(reels[7].id)).toBe(true);
  expect(deck.readyFor(reels[4].id)).toBe(true);
  await deck.destroy();
  create.mockClear();
  vi.stubGlobal('navigator', { deviceMemory: 2 });
  const smaller = new ReelDeck(videos, options);
  const low = await smaller.activate(reels[5]);
  Object.defineProperty(low, 'paused', { configurable: true, writable: true, value: false });
  await vi.advanceTimersByTimeAsync(1600);
  expect(create).toHaveBeenCalledTimes(2);
  expect(smaller.readyFor(reels[4].id)).toBe(false);
  await smaller.destroy();
});
