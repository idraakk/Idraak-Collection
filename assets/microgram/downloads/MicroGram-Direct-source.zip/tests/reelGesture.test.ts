import { describe, it, expect } from 'vitest';
import { reelSwipe } from '../src/reelGesture';
describe('charging-edge to top swipes', () => {
  it('moves forward in portrait and upside down', () => {
    expect(reelSwipe({ x: 100, y: 400 }, { x: 100, y: 100 }, 0)).toBe(1);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 100, y: 400 }, 180)).toBe(1);
  });
  it('uses the physical phone axis in both landscape orientations', () => {
    expect(reelSwipe({ x: 400, y: 100 }, { x: 100, y: 100 }, 90)).toBe(1);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 400, y: 100 }, 270)).toBe(1);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 400, y: 100 }, -90)).toBe(1);
  });
  it('supports backwards swipes and ignores taps or cross-axis drags', () => {
    expect(reelSwipe({ x: 100, y: 100 }, { x: 100, y: 400 })).toBe(-1);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 110, y: 120 })).toBe(0);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 400, y: 110 })).toBe(0);
    expect(reelSwipe({ x: 100, y: 100 }, { x: 110, y: 400 }, 90)).toBe(0);
  });
});
