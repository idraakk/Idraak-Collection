import { describe, expect, it, vi, afterEach } from 'vitest';
import { reelWarmTargets, reelBufferPlan } from '../src/reelWarmTargets';
import { warmReels } from '../src/reelPrefetch';
import type shaka from 'shaka-player';
afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});
describe('reel-aware preloading', () => {
  it('keeps two upcoming minute-reel boundaries in memory with a bounded reverse window', () => {
    expect(reelBufferPlan({start: 0, end: 60, enabled: true})).toEqual({ahead: 130, behind: 70});
    expect(reelBufferPlan({start: 0, end: 600, enabled: true})).toEqual({ahead: 180, behind: 120});
    expect(reelBufferPlan({start: 0, end: 60, enabled: false}).ahead).toBe(20);
  });
  it('prioritizes the next boundaries, then the previous reel', () => {
    expect(reelWarmTargets({ start: 60, end: 120, enabled: true }, 240).map((t) => t.time)).toEqual(
      [120, 180, 0],
    );
    expect(reelWarmTargets({ start: 0, end: 15, enabled: true }, 100).map((t) => t.time)).toEqual([
      15, 30, 45,
    ]);
  });
  it('limits data saver and avoids loading past the lecture or for isolated saved reels', () => {
    expect(reelWarmTargets({ start: 0, end: 60, enabled: true }, 65, true)).toEqual([
      { time: 60, seconds: 5 },
    ]);
    expect(reelWarmTargets({ start: 0, end: 60, enabled: false }, 240)).toEqual([]);
  });
  it('warms audio and video only during healthy foreground playback and stops on cleanup', async () => {
    vi.useFakeTimers();
    vi.stubGlobal('navigator', {});
    vi.stubGlobal('location', {
      href: 'http://localhost:3003/',
      origin: 'http://localhost:3003',
      hostname: 'localhost',
    });
    const doc = Object.assign(new EventTarget(), { hidden: false });
    vi.stubGlobal('document', doc);
    const video = Object.assign(new EventTarget(), {
      paused: false,
      seeking: false,
      readyState: 4,
      currentTime: 2,
      duration: 240,
      playbackRate: 1,
      buffered: { length: 1, start: () => 0, end: () => 40 },
    });
    let byteSpan = 7;
    let position = 0;
    const stream = (format: string) => ({
      segmentIndex: {
        getIteratorForTime: (time: number) => {
          let done = false;
          return {
            next: () => {
              if (done) return { value: null };
              done = true;
              return {
                value: {
                  getStartTime: () => time,
                  getStartByte: () => time * 100,
                  getEndByte: () => time * 100 + byteSpan,
                  getUris: () => [
                    `/api/stream/testvideo01/track/${format}?version=1234567890abcdef`,
                  ],
                },
              };
            },
          };
        },
      },
    });
    const player = {
      getVariantTracks: () => [{ id: 1, active: true }],
      getManifest: () => ({ variants: [{ id: 1, audio: stream('140'), video: stream('137') }] }),
    };
    const fetcher = vi.fn(async () => new Response(new Uint8Array(8), { status: 206 }));
    vi.stubGlobal('fetch', fetcher);
    const stop = warmReels(
      player as unknown as shaka.Player,
      video as unknown as HTMLVideoElement,
      () => ({ start: position, end: position + 60, enabled: true }),
    );
    await vi.advanceTimersByTimeAsync(600);
    expect(fetcher).toHaveBeenCalledTimes(6);
    expect(fetcher.mock.calls[0]).toBeDefined();
    video.paused = true;
    await vi.advanceTimersByTimeAsync(1200);
    expect(fetcher).toHaveBeenCalledTimes(6);
    // A high-bitrate range consumes most of the 24 MiB window budget;
    // subsequent ranges must not cause unbounded speculative downloads.
    video.paused = false;
    position = 60;
    byteSpan = 16 * 1024 * 1024;
    await vi.advanceTimersByTimeAsync(1200);
    expect(fetcher).toHaveBeenCalledTimes(7);
    stop();
    await vi.advanceTimersByTimeAsync(1200);
    expect(fetcher).toHaveBeenCalledTimes(7);
  });
});
