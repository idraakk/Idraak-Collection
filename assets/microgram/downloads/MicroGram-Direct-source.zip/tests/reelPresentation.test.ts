import { expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { ReelOverlay } from '../src/ReelOverlay';
import { coverSources } from '../src/HighQualityCover';
import { thumbnailOrder } from '../src/thumbnailUpgrade';
import type { Segment } from '../src/core';
const reel: Segment = {
  id: 'ABCDEFGHIJK:120',
  video: {
    id: 'ABCDEFGHIJK',
    title: 'Lecture title',
    channel: 'Teacher',
    duration: 600,
    thumbnail: 'https://i.ytimg.com/vi/ABCDEFGHIJK/hqdefault.jpg',
  },
  start: 120,
  end: 180,
  index: 2,
  videoIndex: 0,
};
it('uses identical title, time, avatar and counter markup before and after a swipe', () => {
  const props = { segment: reel, index: 2, total: 10, profileLink: true };
  const active = renderToStaticMarkup(createElement(ReelOverlay, props));
  const preview = renderToStaticMarkup(
    createElement(ReelOverlay, { ...props, preview: true }),
  ).replaceAll(' tabindex="-1"', '');
  expect(preview).toBe(active);
  expect(preview).not.toContain('REEL ');
});
it('requests the maximum-resolution cover first, including a playlist custom cover', () => {
  expect(coverSources('ABCDEFGHIJK', reel.video.thumbnail)[0]).toBe(
    'https://i.ytimg.com/vi/ABCDEFGHIJK/maxresdefault.jpg',
  );
  expect(coverSources('ABCDEFGHIJK', 'https://i.ytimg.com/vi/abcdefghijk/default.jpg')[0]).toBe(
    'https://i.ytimg.com/vi/abcdefghijk/maxresdefault.jpg',
  );
  expect(coverSources(undefined, '/local-cover.svg')).toEqual(['/local-cover.svg']);
});
it('upgrades queued frames in lecture order and timestamp order despite image-load order', () => {
  const jobs = [
    { ...reel, start: 240 },
    { ...reel, videoIndex: 1, start: 0 },
    { ...reel, start: 0 },
    { ...reel, start: 60 },
  ];
  expect(jobs.sort(thumbnailOrder).map((s) => [s.videoIndex, s.start])).toEqual([
    [0, 0],
    [0, 60],
    [0, 240],
    [1, 0],
  ]);
});
