import { it, expect } from 'vitest';
import { savedMoments, resolveMoment, idsForMoment } from '../src/savedMoments';
import { initial, starter } from '../src/storage';
it('deduplicates shared courses and repeated saved IDs without dropping different timestamps', () => {
  const state = {
    ...initial,
    courses: [starter, { ...starter, id: 'another-course' }],
    saved: ['fNk_zzaMoSs:15:0', 'fNk_zzaMoSs:15:0', 'fNk_zzaMoSs:15:1'],
  };
  expect(savedMoments(state, 'reels')).toHaveLength(2);
});
it('preserves saved reel lengths after settings change and merges equivalent final clips', () => {
  const course = { ...starter, videos: [{ ...starter.videos[0], duration: 40 }] };
  const state = {
    ...initial,
    courses: [course],
    seconds: 60 as const,
    saved: ['fNk_zzaMoSs:15:2', 'fNk_zzaMoSs:30:1'],
  };
  const items = savedMoments(state, 'reels');
  expect(items).toHaveLength(1);
  expect([items[0].segment.start, items[0].segment.end]).toEqual([30, 40]);
  expect(idsForMoment(items[0].segment, state.saved, state.courses)).toHaveLength(2);
});
it('finds standalone notes, keeps text and ignores missing or malformed moment links', () => {
  const state = {
    ...initial,
    saved: [],
    notes: {
      'fNk_zzaMoSs:15:1': 'A note without a bookmark',
      'fNk_zzaMoSs:15:2': '   ',
      'missing0000:15:0': 'Missing',
    },
  };
  expect(savedMoments(state, 'notes')).toHaveLength(1);
  expect(savedMoments(state, 'notes')[0].note).toBe('A note without a bookmark');
  expect(resolveMoment('fNk_zzaMoSs:15:9999', state.courses)).toBeNull();
  expect(resolveMoment('../outside:15:0', state.courses)).toBeNull();
});

it('groups legacy aliases without deleting their different note text', () => {
  const course = { ...starter, videos: [{ ...starter.videos[0], duration: 40 }] };
  const notes = { 'fNk_zzaMoSs:15:2': 'First idea', 'fNk_zzaMoSs:30:1': 'Second idea' };
  const state = { ...initial, courses: [course], notes };
  const list = savedMoments(state, 'notes');
  expect(list).toHaveLength(1);
  expect(list[0].note).toContain('First idea');
  expect(list[0].note).toContain('Second idea');
  expect(state.notes).toEqual(notes);
});
