import { afterEach, beforeEach, expect, it, vi } from 'vitest';
const disk = vi.hoisted(() => ({ get: vi.fn() }));
vi.mock('../src/screenNotes', () => ({ getScreenImage: disk.get }));
beforeEach(() => {
  vi.resetModules();
  vi.stubGlobal('window', new EventTarget());
  disk.get.mockReset();
  disk.get.mockResolvedValue(new Blob(['frame'], { type: 'image/jpeg' }));
});
afterEach(() => {
  window.dispatchEvent(new CustomEvent('microgram-screen-images'));
  vi.unstubAllGlobals();
});
it('shares one disk read and a stable URL across duplicate photos and page remounts', async () => {
  const cache = await import('../src/screenImageSources');
  const a = cache.screenImageSource('frame1'),
    b = cache.screenImageSource('frame1');
  expect(a).toBe(b);
  const url = await a;
  expect(await cache.screenImageSource('frame1')).toBe(url);
  expect(cache.cachedScreenSource('frame1')).toBe(url);
  expect(disk.get).toHaveBeenCalledTimes(1);
});
it('invalidates deleted or replaced captures and does not retain stale URLs', async () => {
  const cache = await import('../src/screenImageSources');
  const old = await cache.screenImageSource('frame1');
  window.dispatchEvent(new CustomEvent('microgram-screen-images', { detail: ['frame1'] }));
  expect(cache.cachedScreenSource('frame1')).toBe('');
  expect(await cache.screenImageSource('frame1')).not.toBe(old);
  expect(disk.get).toHaveBeenCalledTimes(2);
});
it('does not republish an in-flight photo after its cache is cleared', async () => {
  let resolve!: (blob: Blob) => void;
  disk.get.mockImplementation(
    () =>
      new Promise((r) => {
        resolve = r;
      }),
  );
  const cache = await import('../src/screenImageSources');
  const pending = cache.screenImageSource('frame1');
  window.dispatchEvent(new CustomEvent('microgram-screen-images'));
  resolve(new Blob(['frame']));
  expect(await pending).toBe('');
  expect(cache.cachedScreenSource('frame1')).toBe('');
});
