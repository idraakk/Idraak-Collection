import { describe, expect, it } from 'vitest';
import { initial, schema, type ScreenNote } from '../src/storage';
import { screenNoteGroups, readScreenNotesBackup, screenNoteTurn } from '../src/screenNotes';

const note: ScreenNote = {
  id: 'frame-one',
  videoId: 'aaaaaaaaaaa',
  videoTitle: 'Lecture',
  channel: 'Teacher',
  courseId: 'playlist',
  courseTitle: 'Course',
  playlist: true,
  time: 12.5,
  createdAt: 10,
  label: 'A formula',
  note: 'Remember this',
};
describe('Screen Notes durability', () => {
  it('keeps the capture presentation when the device turns, with a fit fallback for older notes', () => {
    const turned = { ...note, captureRotation: 90 as const, captureViewport: 'portrait' as const };
    expect(screenNoteTurn(turned, true, 1920, 1080)).toBe(true);
    expect(screenNoteTurn(turned, false, 1920, 1080)).toBe(false);
    const upright = { ...turned, captureRotation: 0 as const };
    expect(screenNoteTurn(upright, true, 1920, 1080)).toBe(false);
    expect(screenNoteTurn(note, true, 1920, 1080)).toBe(true);
    expect(screenNoteTurn(note, true, 1080, 1920)).toBe(false);
  });
  it('groups the same lecture across imports and retains captures without library metadata', () => {
    const notes = [
      note,
      { ...note, id: 'frame-two', courseId: 'another-import', createdAt: 20 },
      { ...note, id: 'frame-three', videoId: 'bbbbbbbbbbb', createdAt: 30 },
    ];
    const data = schema.parse({ ...initial, courses: [], screenNotes: notes });
    expect(data.screenNotes).toHaveLength(3);
    const groups = screenNoteGroups(notes);
    expect(groups.map((g) => [g.videoId, g.items.length])).toEqual([
      ['bbbbbbbbbbb', 1],
      ['aaaaaaaaaaa', 2],
    ]);
    expect(notes[0]).toBe(note);
  });
  it('rejects ambiguous duplicate capture IDs and unsafe capture timestamps', () => {
    expect(schema.safeParse({ ...initial, screenNotes: [note, note] }).success).toBe(false);
    expect(schema.safeParse({ ...initial, screenNotes: [{ ...note, time: -1 }] }).success).toBe(
      false,
    );
  });
  it('accepts old backups but rejects incomplete or falsely typed image payloads before writing', async () => {
    expect((await readScreenNotesBackup(initial)).images).toEqual([]);
    await expect(readScreenNotesBackup({ ...initial, screenNotes: [note] })).rejects.toThrow(
      'missing or invalid',
    );
    await expect(
      readScreenNotesBackup({
        ...initial,
        screenNotes: [note],
        screenNoteImages: { [note.id]: 'data:image/jpeg;base64,aGVsbG8=' },
      }),
    ).rejects.toThrow('Invalid Screen Note image');
    await expect(
      readScreenNotesBackup({
        ...initial,
        screenNotes: [note],
        screenNoteImages: { [note.id]: 'data:image/svg+xml;base64,aGVsbG8=' },
      }),
    ).rejects.toThrow('missing or invalid');
  });
});
