import { it, expect } from 'vitest';
import { schema, initial, expireMetadata } from '../src/storage';
it('round-trips a valid backup', () =>
  expect(schema.parse(JSON.parse(JSON.stringify(initial)))).toEqual(initial));
it('expires old imported metadata without deleting watch history or the starter', () => {
  const state = {
    ...initial,
    progress: { fNk_zzaMoSs: [0, 1] },
    courses: [
      ...initial.courses,
      { ...initial.courses[0], sample: false, id: 'old', importedAt: 1 },
    ],
  };
  const result = expireMetadata(state, 31 * 86400000);
  expect(result.courses).toHaveLength(1);
  expect(result.progress).toEqual(state.progress);
});
it('rejects corrupted backups and invalid progress', () => {
  expect(() => schema.parse({ ...initial, seconds: 0 })).toThrow();
  expect(() => schema.parse({ ...initial, progress: { video: [-1] } })).toThrow();
  expect(() => schema.parse({ ...initial, version: 2 })).toThrow();
});
