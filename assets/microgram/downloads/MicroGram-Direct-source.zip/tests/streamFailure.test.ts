import { expect, it } from 'vitest';
import { streamFailure } from '../server/streamFailure';
it('reports host blocking without leaking raw resolver output', () => {
  const failure = streamFailure({
    stderr: 'ERROR Sign in to confirm you are not a bot https://example.com/?secret=hidden',
  });
  expect(failure.reason).toBe('source_blocked');
  expect(failure.retryable).toBe(false);
  expect(failure.message).not.toContain('hidden');
});
it('distinguishes missing resolver, resource termination and transient timeouts', () => {
  expect(streamFailure({ code: 'ENOENT' }).reason).toBe('resolver_missing');
  expect(streamFailure({ signal: 'SIGKILL' }).reason).toBe('resolver_killed');
  expect(streamFailure({ killed: true }).retryable).toBe(true);
});
