import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
const run = vi.hoisted(() => vi.fn());
vi.mock('node:child_process', () => {
  const execFile = (...args: unknown[]) => run(...args);
  Object.defineProperty(execFile, Symbol.for('nodejs.util.promisify.custom'), {
    value: (...args: unknown[]) =>
      new Promise((resolve, reject) =>
        run(...args, (error: Error | null, stdout: string, stderr: string) =>
          error ? reject(error) : resolve({ stdout, stderr }),
        ),
      ),
  });
  return { execFile };
});
import { manifest } from '../server/streamSources';
function info() {
  return {
    duration: 100,
    requested_formats: [{ format_id: '140', vcodec: 'none' }],
    formats: [
      {
        format_id: '137',
        vcodec: 'avc1.640028',
        acodec: 'none',
        height: 1080,
        width: 1920,
        ext: 'mp4',
      },
      { format_id: '140', vcodec: 'none', acodec: 'mp4a.40.2', ext: 'm4a' },
    ].map((f) => ({
      ...f,
      url: `https://fixture.googlevideo.com/${f.format_id}`,
      protocol: 'https',
      filesize: 100000,
      tbr: 128,
    })),
  };
}
function indexResponse() {
  const b = Buffer.alloc(32);
  b.writeUInt32BE(16, 0);
  b.write('ftyp', 4);
  b.writeUInt32BE(16, 16);
  b.write('sidx', 20);
  return new Response(b, { status: 206 });
}
beforeEach(() => {
  run.mockReset();
  run.mockImplementation((...args: unknown[]) => {
    (args.at(-1) as Function)(null, JSON.stringify(info()), '');
  });
});
afterEach(() => vi.unstubAllGlobals());
describe('cold manifest startup recovery', () => {
  it('retries failed probes and shares concurrent first opens', async () => {
    const counts = new Map<string, number>();
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        const n = (counts.get(url) || 0) + 1;
        counts.set(url, n);
        return n === 1 ? new Response(null, { status: 503 }) : indexResponse();
      }),
    );
    const [a, b] = await Promise.all([manifest('coldstart01'), manifest('coldstart01')]);
    expect(a).toBe(b);
    expect(a).toContain('height="1080"');
    expect(run).toHaveBeenCalledTimes(1);
    expect([...counts.values()]).toEqual([2, 2]);
  });
  it('refreshes the source automatically when an entire first probe round fails', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        run.mock.calls.length === 1 ? new Response(null, { status: 503 }) : indexResponse(),
      ),
    );
    expect(await manifest('coldstart02')).toContain('height="1080"');
    expect(run).toHaveBeenCalledTimes(2);
  });
  it('retries a truncated response body rather than caching a failed index', async () => {
    const counts = new Map<string, number>();
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        const n = (counts.get(url) || 0) + 1;
        counts.set(url, n);
        if (n === 1)
          return new Response(
            new ReadableStream({
              start(c) {
                c.error(new Error('socket closed'));
              },
            }),
            { status: 206 },
          );
        return indexResponse();
      }),
    );
    expect(await manifest('coldstart03')).toContain('height="1080"');
    expect(run).toHaveBeenCalledTimes(1);
  });
  it('starts with HD and audio without waiting for a slow optional quality', async () => {
    const details = info();
    details.formats.push({
      ...details.formats[0],
      format_id: '136',
      height: 720,
      width: 1280,
      url: 'https://fixture.googlevideo.com/136',
    });
    run.mockImplementation((...args: unknown[]) =>
      (args.at(-1) as Function)(null, JSON.stringify(details), ''),
    );
    let release!: (value: Response) => void;
    const slow = new Promise<Response>((resolve) => {
      release = resolve;
    });
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => (url.endsWith('/136') ? slow : indexResponse())),
    );
    try {
      const xml = await manifest('coldstart05');
      expect(xml).toContain('height="1080"');
      expect(xml).not.toContain('height="720"');
    } finally {
      release(indexResponse());
    }
  });
  it('stops after bounded retries when the source remains unavailable', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(null, { status: 503 })),
    );
    await expect(manifest('coldstart04')).rejects.toThrow();
    expect(run).toHaveBeenCalledTimes(2);
    await vi.waitFor(() => expect(fetch).toHaveBeenCalledTimes(8));
  });
});
