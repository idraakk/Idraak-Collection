import { describe, expect, it } from 'vitest';
import { mp4Index, getSource } from '../server/streamSources';
function atom(type: string, size = 16) {
  const data = Buffer.alloc(size);
  data.writeUInt32BE(size);
  data.write(type, 4, 'ascii');
  return data;
}
describe('DASH index discovery', () => {
  it('finds precise init and index ranges in MP4 headers', () => {
    expect(
      mp4Index(Buffer.concat([atom('ftyp', 24), atom('moov', 40), atom('sidx', 32), atom('moof')])),
    ).toEqual({ initEnd: 63, indexStart: 64, indexEnd: 95 });
  });
  it('supports extended atom sizes', () => {
    const extended = Buffer.alloc(24);
    extended.writeUInt32BE(1);
    extended.write('ftyp', 4);
    extended.writeBigUInt64BE(24n, 8);
    expect(mp4Index(Buffer.concat([extended, atom('sidx')]))).toEqual({
      initEnd: 23,
      indexStart: 24,
      indexEnd: 39,
    });
  });
  it('allows an index extending past the small probe, without downloading that index', () => {
    const index = atom('sidx');
    index.writeUInt32BE(100000);
    expect(mp4Index(Buffer.concat([atom('ftyp'), index]))).toEqual({
      initEnd: 15,
      indexStart: 16,
      indexEnd: 100015,
    });
  });
  it('rejects malformed, missing or oversized indexes', () => {
    for (const data of [
      Buffer.alloc(0),
      Buffer.alloc(8),
      atom('sidx'),
      atom('mdat'),
      Buffer.from([0, 0, 0, 1, 102, 116, 121, 112]),
    ])
      expect(() => mp4Index(data)).toThrow();
    const huge = atom('sidx');
    huge.writeUInt32BE(5 * 1024 * 1024);
    expect(() => mp4Index(Buffer.concat([atom('ftyp'), huge]))).toThrow();
  });
  it('rejects invalid source IDs before starting an external process', async () => {
    await expect(getSource('../bad')).rejects.toThrow('Invalid video ID');
  });
});
