import { describe, expect, it } from 'vitest';
import { autoRotate } from '../src/videoLayout';
describe('automatic video orientation', () => {
  it('rotates landscape footage on a portrait screen', () =>
    expect(autoRotate(1920, 1080, 390, 844)).toBe(true));
  it('keeps landscape footage upright on a landscape screen', () =>
    expect(autoRotate(1920, 1080, 844, 390)).toBe(false));
  it('keeps portrait and square footage upright', () => {
    expect(autoRotate(1080, 1920, 390, 844)).toBe(false);
    expect(autoRotate(1080, 1920, 844, 390)).toBe(false);
    expect(autoRotate(1080, 1080, 390, 844)).toBe(false);
  });
  it('waits for valid dimensions', () => expect(autoRotate(0, 0, 390, 844)).toBe(false));
});
