import { expect, it } from 'vitest';
import { defaultVideoFit } from '../src/videoLayout';
import { qualityCeiling } from '../src/videoQuality';
import { initial, schema } from '../src/storage';

it('fills close aspect ratios, but preserves the complete picture when cropping would exceed 6%', () => {
  expect(defaultVideoFit(1920, 1080, 400, 740, true)).toBe(false);
  expect(defaultVideoFit(1920, 1080, 400, 900, true)).toBe(true);
  expect(defaultVideoFit(1080, 1920, 400, 710, false)).toBe(false);
  expect(defaultVideoFit(1080, 1080, 400, 800, false)).toBe(true);
  expect(defaultVideoFit(0, 0, 400, 800, false)).toBe(true);
});
it('round-trips independent video layouts and quality preferences without changing old backups', () => {
  const a = 'ABCDEFGHIJK',
    b = 'abcdefghijk';
  const restored = schema.parse(
    JSON.parse(
      JSON.stringify({
        ...initial,
        videoLayouts: { [a]: { fit: false, rotated: true }, [b]: { fit: true } },
        videoQualities: { [a]: '1080', [b]: 'saver' },
      }),
    ),
  );
  expect(restored.videoLayouts?.[a]).toEqual({ fit: false, rotated: true });
  expect(restored.videoLayouts?.[b]).toEqual({ fit: true });
  expect(restored.videoQualities?.[b]).toBe('saver');
  expect(schema.parse(initial)).toEqual(initial);
});
it('keeps the requested ceiling on standby and during stalls, leaving recovery to ABR', () => {
  expect(qualityCeiling('1080', false, false)).toBe(1080);
  expect(qualityCeiling('1080', true)).toBe(1080);
  expect(qualityCeiling('1080', false, true)).toBe(1080);
  expect(qualityCeiling('360', false, true)).toBe(360);
  expect(qualityCeiling('saver')).toBe(360);
});
it('retains optional local usernames in backups while accepting older name-only profiles', () => {
  expect(schema.parse({ ...initial, profile: { name: 'Learner' } }).profile).toEqual({ name: 'Learner' });
  expect(schema.parse({ ...initial, profile: { name: 'Learner', username: 'learner_01' } }).profile?.username).toBe('learner_01');
  expect(schema.safeParse({ ...initial, profile: { name: 'Learner', username: 'invalid name' } }).success).toBe(false);
});
