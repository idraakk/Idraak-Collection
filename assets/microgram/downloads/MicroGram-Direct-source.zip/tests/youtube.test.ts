import { it, expect, vi } from 'vitest';
import { importYouTube } from '../server/youtube';
const item = (id: string, embeddable = true) => ({
  id,
  snippet: { title: id, channelTitle: 'Teacher' },
  contentDetails: { duration: 'PT1M5S' },
  status: { embeddable },
});
it('follows pagination, keeps playlist order, deduplicates, and skips blocked videos', async () => {
  const request = vi.fn(async (input: URL | RequestInfo) => {
    const url = new URL(input as URL);
    let data;
    if (url.pathname.endsWith('/playlists'))
      data = { items: [{ snippet: { title: 'Course', channelTitle: 'Teacher' } }] };
    else if (url.pathname.endsWith('/playlistItems'))
      data = url.searchParams.has('pageToken')
        ? {
            items: [
              { snippet: { resourceId: { videoId: 'ccccccccccc' } } },
              { snippet: { resourceId: { videoId: 'aaaaaaaaaaa' } } },
            ],
          }
        : {
            items: [
              { snippet: { resourceId: { videoId: 'bbbbbbbbbbb' } } },
              { snippet: { resourceId: { videoId: 'aaaaaaaaaaa' } } },
            ],
            nextPageToken: 'page2',
          };
    else data = { items: [item('aaaaaaaaaaa'), item('ccccccccccc', false), item('bbbbbbbbbbb')] };
    return new Response(JSON.stringify(data));
  });
  const result = await importYouTube(
    'https://youtube.com/playlist?list=PL1234567890',
    'fake',
    request as typeof fetch,
  );
  expect(result.course.videos.map((v) => v.id)).toEqual(['bbbbbbbbbbb', 'aaaaaaaaaaa']);
  expect(result.skipped).toBe(2);
  expect(request).toHaveBeenCalledTimes(4);
});
it('returns an actionable error when quota is exhausted without leaking credentials', async () => {
  await expect(
    importYouTube(
      'https://youtu.be/aaaaaaaaaaa',
      'secret',
      async () => new Response('', { status: 403 }),
    ),
  ).rejects.toThrow('YouTube access or quota is unavailable');
});
it('rejects empty/private playlists', async () => {
  await expect(
    importYouTube(
      'https://youtube.com/playlist?list=PL1234567890',
      'fake',
      async () => new Response('{"items":[]}'),
    ),
  ).rejects.toThrow('private');
});
